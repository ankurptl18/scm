import matrix.db.Context;

public class emxCommonDocumentOwnershipMigration_mxJPO extends emxCommonDocumentOwnershipMigrationBase_mxJPO{

	/**
    *
    * @param context the eMatrix <code>Context</code> object
    * @param args holds no arguments
    * @throws Exception if the operation fails
    * @since AEF Rossini
    * @grade 0
    */
   public emxCommonDocumentOwnershipMigration_mxJPO (Context context, String[] args)
       throws Exception
   {
     super(context, args);
   }

}
