package com.pwc.scm.util;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

/**
 * 
 * @author Sanjay.Meena
 *
 */
public class PWCDeltaConfiguration {


	/** Singleton instance declaration */
	private static PWCDeltaConfiguration configuration;

	/** FILE containing all delta configurations */
	private static final String CONFFIG_FILE_NAME = "DeltaRules_Config.properties";
	
	/** Rule type: Config Key Suffix _class*/
	public static final String CONFIG_KEY_SUFFIX_CLASS = "_class";
	
	/** Rule type: Config Key Suffix _changedfile_class*/
	public static final String CONFIG_KEY_SUFFIX_CHANGED_FILE_CLASS = "_changedfile_class";

	/** Rule type: Config Key Suffix _newfile_class*/
	public static final String CONFIG_KEY_SUFFIX_NEW_FILE_CLASS = "_newfile_class";
	
	/** Rule type: Config Key Suffix _changedfile_relatedfilename*/
	public static final String CONFIG_KEY_SUFFIX_CHANGEDFILE_RELATEDFILENAME = "_changedfile_relatedfilename";
	
	/** Rule type: Config Key Suffix _ChangedFile_ChangedLine_RelatedFileName*/
	public static final String CONFIG_KEY_SUFFIX_CHANGEDFILE_CHANGEDLINE_RELATEDFILENAME = "_changedfile_changedline_relatedfilename";
	
	/** Rule type: Config Key Suffix _ChangedFile_NewLine_RelatedFileName*/
	public static final String CONFIG_KEY_SUFFIX_CHANGEDFILE_NEWLINE_RELATEDFILENAME = "_changedfile_newline_relatedfilename";
	
	/** Rule type: Config Key Suffix _changedfile_changedline_class*/
	public static final String CONFIG_KEY_SUFFIX_CHANGEDFILE_CHANGEDLINE_CLASS = "_changedfile_changedline_class";

	/** Rule type: Config Key Suffix _changedfile_newline_class*/
	public static final String CONFIG_KEY_SUFFIX_CHANGEDFILE_NEWLINE_CLASS = "_changedfile_newline_class";

	/** Rule type: Config Key And value placeholder for Name */
	public static final String CONFIG_PLACEHOLDER_FOR_NAME = "${Name}";

	/** Rule type: Config Key For Validating Spinner*/
	public static final String CONFIG_KEY_DELTA_EXTRACTION_VALIDATION_SWITCH_ENABLED = "delta_extraction_validation_switch_enabled";
	
	/** Delta Configuration defined in DeltaRules_Config.properties */
	private static Map<String, String> transformedProperties = new HashMap<String, String>();

	/** Delta output generation directory */
	private static String deltaOutputDir;

	/** Target Tag directory */
	private static String targetTagDir;

	/** Origin Tag directory */
	private static String originTagDir;

	/** Rule type: Copy directory/file as is without any validation */
	public static final String AS_IS_RULE = "as_is_rule";

	/** Rule type: File change check only */
	public static final String DELTA_FILE_RULE = "delta_file_rule";

	/** Rule type: File content check */
	public static final String DELTA_FILE_CONTENT_RULE = "delta_file_content_rule";

	/** Rule type: Related File check */
	public static final String RELATED_FILE_RULE = "related_file_rule";

	/** Rule type: Related File content check */
	public static final String RELATED_FILE_CONTENT_RULE = "related_file_content_rule";
	

	/** Spinner Directory Name */
	public static final String SPINNER = "Spinner";

	/** JPO File extension*/
	public static final String FILE_EXTN_MXJPO_JAVA = "_mxJPO.java";

	/** Inquiry File extension*/
	public static final String FILE_EXTN_INQ = ".inq";


	/** UNDERSCORE Separator used in config file DeltaRules_Config.properties */
	public static final String UNDERSCORE = "_";
	
	/** DOT String */
	public final static String DOT_SEPARATOR = ".";

	/** Configuration to store primary key columns for Spinner Files */
	private static Map<String, Integer> primaryKeyColumns = new HashMap<String, Integer>();
	
	/** Default Configuration for Related File content rule*/
	private static Map<String, String> defaultRelatedFileConfigMap = new ConcurrentHashMap<String, String>();

	/** Validation switch to decide if execution is to be stopped if any business requirement failed occur during extraction*/
	private Boolean isValidationSwitchOn = false;

	/** The logger. */
	private static Logger logger = Logger.getLogger(PWCDeltaConfiguration.class);

	/** Private constructor */
	private PWCDeltaConfiguration() {
	}

	/** Public method to get the only object of this class */
	public static synchronized PWCDeltaConfiguration getInstance() {
		if (configuration == null) {
			configuration = new PWCDeltaConfiguration();
			logger.info("Created Singleton object");
		}

		return configuration;
	}

	/**
	 * Method to initialize & build configuration, This will be used to get rules
	 * during delta extraction process
	 * 
	 * @param _deltaOutputDir
	 * @param _targetTagDir
	 * @param _originTagDir
	 * @throws IOException
	 */
	public void init(String _deltaOutputDir, String _targetTagDir, String _originTagDir) throws IOException {

		logger.info("****************** INITIALIZING DELTA CONFIGURATION START *****************");

		targetTagDir = _targetTagDir;
		deltaOutputDir = _deltaOutputDir;
		originTagDir = _originTagDir;

		// build configuration
		buildConfiguration();
		
		logger.info("****************** INITIALIZING DELTA CONFIGURATION END *****************");

	}

	/**
	 * Loads configuration and transform the configuration keys to lower case. it
	 * also builds configuration for all elements by applying the parent rules.
	 * 
	 * @throws IOException
	 */
	private void buildConfiguration() throws IOException {
		Properties properties = PWCDeltaExtractorUtils.readPropertiesFile(CONFFIG_FILE_NAME);

		Enumeration keylist = properties.propertyNames();
		while (keylist.hasMoreElements()) {
			String key = (String) keylist.nextElement();
			transformedProperties.put(key.toLowerCase(), (String) properties.get(key));
			
			//update related file content rule map
			if(key.toLowerCase().contains(CONFIG_PLACEHOLDER_FOR_NAME.toLowerCase())) {
				defaultRelatedFileConfigMap.put(key.toLowerCase(), (String) properties.get(key));
			}else if(key.toLowerCase().equals(CONFIG_KEY_DELTA_EXTRACTION_VALIDATION_SWITCH_ENABLED)) {
				isValidationSwitchOn = Boolean.valueOf((String)properties.get(key));
			}
			
			
		}

		// build Primary Key column Data
		buildPrimaryKeyColumns(properties);

		// load configuration for all files
		buildConfFromRoot(Paths.get(targetTagDir), "root", transformedProperties.get("root"));
		
		/*
		 * NOTE : UNCOMMENT BELOW CODE IF ALL transformedProperties to be logged
		 * 
		 * for (String key : transformedProperties.keySet()) { logger.debug("Key: " +
		 * key + "   value: " + transformedProperties.get(key)); }
		 */
		
	}

	/**
	 * Builds the primary key columns. 
	 *
	 * @param properties the properties
	 */
	public void buildPrimaryKeyColumns(Properties properties) {

		logger.info("BUILDING PRIMARY KEY COLUMNS STARTS");
		
		for (Enumeration<?> e = properties.propertyNames(); e.hasMoreElements();) {
			String name = (String) e.nextElement();
			String value = properties.getProperty(name);
			if (name.startsWith("spinner_primaryKey_file_")) {
				primaryKeyColumns.put(StringUtils.substringAfter(name, "spinner_primaryKey_file_"),
						Integer.valueOf(value));
			}
		}
		
		logger.info("BUILDING PRIMARY KEY COLUMNS ENDS");

	}

	/**
	 * Walk through the target directory structure and set configuration for all
	 * files
	 * 
	 * @param targetTagPath
	 * @param rootConfKey
	 * @param rootConfValue
	 * @param parentDeltaFileRuleClassValue
	 * @param parentConfNewClassValue
	 * @throws IOException
	 */
	private void buildConfFromRoot(Path targetTagPath, String rootConfKey, String rootConfValue) throws IOException {
		
		try (DirectoryStream<Path> stream = Files.newDirectoryStream(targetTagPath)) {

			for (Path fileEntry : stream) {
				
				/** Check if it is file, if yes than extract the file name without extension */
				String fileOrDirectoryName = fileEntry.getFileName().toString().toLowerCase();

				/** For building rules for Single Rule/Class configuration */
				String confRuleKey = rootConfKey + UNDERSCORE + fileOrDirectoryName;
				String confRuleValue = transformedProperties.get(confRuleKey);
				String confClassKey = confRuleKey + CONFIG_KEY_SUFFIX_CLASS;
				String confClassValue = transformedProperties.get(confClassKey);

				if (confRuleValue == null) {
					confRuleValue = rootConfValue;
				}

				transformedProperties.put(confRuleKey, confRuleValue);

				if (confRuleValue.contains(AS_IS_RULE)) {
					logger.info(
							"Delta Config Rule for Configuration Item " + fileOrDirectoryName + " is " + confRuleValue);
				} else if (confRuleValue.contains(DELTA_FILE_RULE)) {
					buildConfDeltaFileRule(fileEntry, confRuleKey, confRuleValue, confClassValue);
				} else if (confRuleValue.contains(DELTA_FILE_CONTENT_RULE)) {
					buildConfDeltaFileContentRule(fileEntry, confRuleKey, confRuleValue, null, null, null, null);
				}

			}

		}
	}

	/**
	 * Walk through the target directory structure and set configuration for all
	 * files
	 * 
	 * @param targetTagPath
	 * @param parentConfRuleKey
	 * @param parentConfRuleValue
	 * @param parentDeltaFileRuleClassValue
	 * @param parentConfNewClassValue
	 * @throws IOException
	 */
	private void buildConfDeltaFileRule(Path targetTagPath, String parentConfRuleKey, String parentConfRuleValue,
			String parentDeltaFileRuleClassValue) throws IOException {
		try (DirectoryStream<Path> stream = Files.newDirectoryStream(targetTagPath)) {

			for (Path fileEntry : stream) {
				/** Check if it is file, if yes than extract the file name without extension */
				String fileOrDirectoryName = fileEntry.getFileName().toString().toLowerCase();

				logger.info("buildConfDeltaFileRule : " + fileEntry.toFile().getCanonicalPath());

				/** For building rules for Single Rule/Class configuration */
				String confRuleKey = parentConfRuleKey + UNDERSCORE + fileOrDirectoryName;
				String confRuleValue = transformedProperties.get(confRuleKey);

				String confClassKey = confRuleKey + CONFIG_KEY_SUFFIX_CLASS;
				String confClassValue = transformedProperties.get(confClassKey);
				
				logger.info("confClassKey : "+ confClassKey + "confClassValue: " + confClassValue);

				if (confRuleValue == null) {
					// configuration not defined, use parent configuration which is already delta
					confRuleValue = parentConfRuleValue;
					confClassValue = parentDeltaFileRuleClassValue;
					
					if (confRuleValue.contains(RELATED_FILE_CONTENT_RULE)) {
						for (Map.Entry<String, String> entry : defaultRelatedFileConfigMap.entrySet()) {
							//"root_spinner_business_pagefiles"
							if(entry.getKey().startsWith(parentConfRuleKey+UNDERSCORE+CONFIG_PLACEHOLDER_FOR_NAME.toLowerCase())) {
								if(fileEntry.toFile().isDirectory()) {
									StringBuilder childDirRelatedFileRuleKey = new StringBuilder(entry.getKey());
								    childDirRelatedFileRuleKey.insert(entry.getKey().indexOf(CONFIG_PLACEHOLDER_FOR_NAME.toLowerCase()), fileOrDirectoryName + UNDERSCORE);
									defaultRelatedFileConfigMap.put(childDirRelatedFileRuleKey.toString(), entry.getValue());
									break;
								}else {
									
									String fileName = fileOrDirectoryName;
									String fileExtn =null;
									if(entry.getKey().contains(DOT_SEPARATOR)) {
										fileName = fileOrDirectoryName.substring(0, fileOrDirectoryName.lastIndexOf(DOT_SEPARATOR));
										fileExtn = fileOrDirectoryName.replace(fileName, "");
									}
									
									String childRelatedFileRuleKey = entry.getKey().replace(CONFIG_PLACEHOLDER_FOR_NAME.toLowerCase(), fileName);
									if(fileExtn != null){
										if(entry.getKey().contains(fileExtn)){
											transformedProperties.put(childRelatedFileRuleKey, entry.getValue());
											logger.info(
													"childRelatedFileRuleKey: " + childRelatedFileRuleKey
															+ "   entry.getValue(): " + entry.getValue());
										}
									}else {
										transformedProperties.put(childRelatedFileRuleKey, entry.getValue());
										logger.info("childRelatedFileRuleKey: "
												+ childRelatedFileRuleKey + "   entry.getValue(): " + entry.getValue());
									}
								}
								
							}
					    }
					}
				}

				if (confRuleValue.contains(DELTA_FILE_RULE)) {
					// Delta rule set for this item, either from cofig file or from Parent
					transformedProperties.put(confRuleKey, confRuleValue);
					transformedProperties.put(confClassKey, confClassValue);
					if (Files.isDirectory(fileEntry)) {
						buildConfDeltaFileRule(fileEntry, confRuleKey, confRuleValue, confClassValue);
					}
				} else if (confRuleValue.contains(DELTA_FILE_CONTENT_RULE)) {
					/** this child is configured for delta content */
					buildConfDeltaFileContentRuleRoot(fileEntry, parentConfRuleKey);
				} else if (confRuleValue.contains(AS_IS_RULE)) {
					/** this child is configured for as IS copy */
					logger.info(
							"Delta Config Rule for Configuratio Item " + fileOrDirectoryName + " is " + confRuleValue);
				}
			}
		}
	}

	/**
	 * Walk through the target directory structure and set configuration for all
	 * files
	 * 
	 * @param targetTagPath
	 * @param parentConfRuleKey
	 * @param parentConfRuleValue
	 * @param parentDeltaFileRuleClassValue
	 * @param parentConfNewClassValue
	 * @throws IOException
	 */
	private void buildConfDeltaFileContentRule(Path targetTagPath, String parentConfRuleKey, String parentConfRuleValue,
			String parentConfNewFileClassValue, String parentConfChangedFileClassValue,
			String parentConfChangedFileChangedLineClassValue, String parentConfChangedFileNewLineClassValue)
			throws IOException {

		try (DirectoryStream<Path> stream = Files.newDirectoryStream(targetTagPath)) {

			for (Path fileEntry : stream) {

				/** Check if it is file, if yes than extract the file name without extension */
				String fileOrDirectoryName = fileEntry.getFileName().toString().toLowerCase();

				/** For building rules for Single Rule/Class configuration */
				String confRuleKey = parentConfRuleKey + UNDERSCORE + fileOrDirectoryName;
				String confRuleValue = transformedProperties.get(confRuleKey);

				String confNewFileClassKey = confRuleKey + CONFIG_KEY_SUFFIX_NEW_FILE_CLASS;
				String confNewFileClassValue = (String) transformedProperties.get(confNewFileClassKey);

				String confChangedFileClassKey = confRuleKey + CONFIG_KEY_SUFFIX_CHANGED_FILE_CLASS;
				String confChangedFileClassValue = transformedProperties.get(confChangedFileClassKey);

				String confChangedFileChangedLineClassKey = confRuleKey + CONFIG_KEY_SUFFIX_CHANGEDFILE_CHANGEDLINE_CLASS;
				String confChangedFileChangedLineClassValue = transformedProperties
						.get(confChangedFileChangedLineClassKey);

				String confChangedFileNewLineClassKey = confRuleKey + CONFIG_KEY_SUFFIX_CHANGEDFILE_NEWLINE_CLASS;
				String confChangedFileNewLineClassValue = transformedProperties.get(confChangedFileNewLineClassKey);

				if (confRuleValue == null) {
					// configuration not defined, use parent configuration which is already delta
					// content in this case
					confRuleValue = parentConfRuleValue;
					confNewFileClassValue = parentConfNewFileClassValue;
					confChangedFileClassValue = parentConfChangedFileClassValue;
					confChangedFileChangedLineClassValue = parentConfChangedFileChangedLineClassValue;
					confChangedFileNewLineClassValue = parentConfChangedFileNewLineClassValue;
				}

				if (confRuleValue.contains(DELTA_FILE_CONTENT_RULE)) {
					// Delta content rule set for this item, either from config file or from Parent
					// SET Configuration
					transformedProperties.put(confRuleKey, confRuleValue);
					transformedProperties.put(confNewFileClassKey, confNewFileClassValue);

					if (confChangedFileClassValue != null) {
						transformedProperties.put(confChangedFileClassKey, confChangedFileClassValue);
					} else {
						transformedProperties.put(confChangedFileChangedLineClassKey,
								confChangedFileChangedLineClassValue);
						transformedProperties.put(confChangedFileNewLineClassKey, confChangedFileNewLineClassValue);
					}

					if (Files.isDirectory(fileEntry)) {
						buildConfDeltaFileContentRule(fileEntry, confRuleKey, confRuleValue, confNewFileClassValue,
								confChangedFileClassValue, confChangedFileChangedLineClassValue,
								confChangedFileNewLineClassValue);
					}
				} else if (confRuleValue.contains(DELTA_FILE_RULE)) {
					/** this child is configured for delta content */
					buildConfDeltaFileRuleRoot(fileEntry, parentConfRuleKey);
				} else if (confRuleValue.contains(AS_IS_RULE)) {
					/** this child is configured for as IS copy */
					logger.info(
							"Delta Config Rule for Configuration Item " + fileOrDirectoryName + " is " + confRuleValue);
				}
			}
		}
	}

	/**
	 * Walk through the target directory structure and set configuration for all
	 * files
	 * 
	 * @param targetTagPath
	 * @param parentConfRuleKey
	 * @param parentConfRuleValue
	 * @param parentDeltaFileRuleClassValue
	 * @param parentConfNewClassValue
	 * @throws IOException
	 */
	private void buildConfDeltaFileContentRuleRoot(Path targetTagPath, String parentConfRuleKey) throws IOException {

		Path fileEntry = targetTagPath.toFile().toPath();

		/** Check if it is file, if yes than extract the file name without extension */
		String fileOrDirectoryName = fileEntry.getFileName().toString().toLowerCase();

		/** For building rules for Single Rule/Class configuration */
		String confRuleKey = parentConfRuleKey + UNDERSCORE + fileOrDirectoryName;
		String confRuleValue = transformedProperties.get(confRuleKey);

		String confNewFileClassKey = confRuleKey + CONFIG_KEY_SUFFIX_NEW_FILE_CLASS;
		String confNewFileClassValue = (String) transformedProperties.get(confNewFileClassKey);

		String confChangedFileClassKey = confRuleKey + CONFIG_KEY_SUFFIX_CHANGED_FILE_CLASS;
		String confChangedFileClassValue = transformedProperties.get(confChangedFileClassKey);

		String confChangedFileChangedLineClassKey = confRuleKey + CONFIG_KEY_SUFFIX_CHANGEDFILE_CHANGEDLINE_CLASS;
		String confChangedFileChangedLineClassValue = transformedProperties.get(confChangedFileChangedLineClassKey);

		String confChangedFileNewLineClassKey = confRuleKey + CONFIG_KEY_SUFFIX_CHANGEDFILE_NEWLINE_CLASS;
		String confChangedFileNewLineClassValue = transformedProperties.get(confChangedFileNewLineClassKey);

		// Delta content rule set for this item, either from config file or from Parent
		// SET Configuration
		transformedProperties.put(confRuleKey, confRuleValue);
		transformedProperties.put(confNewFileClassKey, confNewFileClassValue);

		if (confChangedFileClassValue != null) {
			transformedProperties.put(confChangedFileClassKey, confChangedFileClassValue);
		} else {
			transformedProperties.put(confChangedFileChangedLineClassKey, confChangedFileChangedLineClassValue);
			transformedProperties.put(confChangedFileNewLineClassKey, confChangedFileNewLineClassValue);
		}

		if (Files.isDirectory(fileEntry)) {
			buildConfDeltaFileContentRule(fileEntry, confRuleKey, confRuleValue, confNewFileClassValue,
					confChangedFileClassValue, confChangedFileChangedLineClassValue, confChangedFileNewLineClassValue);
		}
	}

	/**
	 * Walk through the target directory structure and set configuration for all
	 * files
	 * 
	 * @param targetTagPath
	 * @param parentConfRuleKey
	 * @param parentConfRuleValue
	 * @param parentDeltaFileRuleClassValue
	 * @param parentConfNewClassValue
	 * @throws IOException
	 */
	private void buildConfDeltaFileRuleRoot(Path targetTagPath, String parentConfRuleKey) throws IOException {

		Path fileEntry = targetTagPath.toFile().toPath();

		/** Check if it is file, if yes than extract the file name without extension */
		String fileOrDirectoryName = fileEntry.getFileName().toString().toLowerCase();

		logger.info("buildConfDeltaFileRule: " + fileEntry.toFile().getCanonicalPath());

		/** For building rules for Single Rule/Class configuration */
		String confRuleKey = parentConfRuleKey + UNDERSCORE + fileOrDirectoryName;
		String confRuleValue = transformedProperties.get(confRuleKey);

		String confClassKey = confRuleKey + CONFIG_KEY_SUFFIX_CLASS;
		String confClassValue = transformedProperties.get(confClassKey);

		if (confRuleValue.contains(DELTA_FILE_RULE)) {
			// Delta rule set for this item, either from cofig file or from Parent
			transformedProperties.put(confRuleKey, confRuleValue);
			transformedProperties.put(confClassKey, confClassValue);
			if (Files.isDirectory(fileEntry)) {
				buildConfDeltaFileRule(fileEntry, confRuleKey, confRuleValue, confClassValue);
			}
		}
	}

	/**
	 * @return the transformedProperties
	 */
	public Map<String, String> getTransformedProperties() {
		return transformedProperties;
	}

	/**
	 * @return the deltaOutputDir
	 */
	public String getDeltaOutputDir() {
		return deltaOutputDir;
	}

	/**
	 * @return the targetTagDir
	 */
	public String getTargetTagDir() {
		return targetTagDir;
	}

	/**
	 * @return the originTagDir
	 */
	public String getOriginTagDir() {
		return originTagDir;
	}

	/**
	 * @return the primaryKeyColumns Count
	 */
	public Integer getPrimaryKeyColumnCount(String fileName) {
		Integer count = primaryKeyColumns.get(fileName);
		return count == null ? 0 : count;
	}

	/**
	 * @return the isValidationSwitchOn
	 */
	public Boolean isValidationSwitchOn() {
		return isValidationSwitchOn;
	}

}
