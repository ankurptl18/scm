package com.pwc.scm.spinner.impl;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.commons.io.FileUtils;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.opencsv.CSVWriter;
import com.pwc.scm.spinner.PWCDeltaExtractor;

/**
 * The Class PWCSpinnerDeltaFileExtractor.
 * 
 * @author ANKUR
 */
public class PWCSpinnerNormalization {

	/** The logger. */
	private static Logger logger = Logger.getLogger(PWCSpinnerNormalization.class);

	/** The dependent files. */
	private List<File> dependentFiles;

	//TODO: MOVE TO CONSTANT FILE
	/** The Constant TAB. */
	private static final String TAB = "\\t";

	//TODO: MOVE TO CONSTANT FILE
	/** The Constant PIPE. */
	private static final String PIPE = "\\|";
	
	//TODO: MOVE TO CONSTANT FILE
	private static final String spinner = "spinner";

	/**
	 * Extract.
	 *
	 * @param properties       the properties
	 * @param targetTagDir     the target tag directory
	 * @param sourcePackageDir the source package dir
	 * @throws IOException Signals that an I/O exception has occurred.
	 */

	public void transform(Properties properties, File targetTagDir, String sourcePackageDir) throws IOException {

		/*
		 * settingsColumnFile to hold file names which have settings & setting_value
		 * columns
		 */
		Set<String> settingsColumnFile = new HashSet<>(
				Arrays.asList(((String) properties.get("keyName.settings")).split(",")));

		/*
		 * multivaluedColumns to hold file names which have multi valued columns with
		 * pipe separator
		 */
		Set<String> multivaluedColumns = new HashSet<>(
				Arrays.asList(((String) properties.get("keyName.multivaluedcolumns")).split(",")));

		/*
		 * columnsToSort holds the columns name which are applicable to normalize in
		 * spinner files
		 */
		Set<String> columnsToSort = new HashSet<>(
				Arrays.asList(((String) properties.get("pwc.column.to.be.sort")).split(",")));

		File targetSpinnerDir = new File(targetTagDir.getPath() + File.separator + spinner + File.separator);

		for (File spinnerFileToNormalize : FileUtils.listFiles(targetSpinnerDir, null, Boolean.TRUE)) {

			/* Normalized file Path where the normalized file will be stored */
			File normalizedFile = new File(sourcePackageDir + File.separator + "distrib" + File.separator
					+ targetTagDir.getName() + File.separator + spinner + File.separator
					+ StringUtils.substringAfter(spinnerFileToNormalize.getAbsolutePath(), spinner));

			/* if normalized  directory does not exists then create */
			if (!normalizedFile.exists()) {
				Files.createDirectories(Paths.get(normalizedFile.getParent()));
			}
			
			/* Condition to check if file name is available in setting column key */
			if (settingsColumnFile.contains(spinnerFileToNormalize.getName()) && multivaluedColumns.contains(spinnerFileToNormalize.getName())) {
				
				// TODO : Generalize the below lines in method
				List<String[]> normalizedFileContent = normalizeBoth(spinnerFileToNormalize, columnsToSort);
				CSVWriter writer = createCSVWriter(normalizedFile);
				writer.writeAll(normalizedFileContent);
				writer.flush();
				writer.close();
			} else if (settingsColumnFile.contains(spinnerFileToNormalize.getName())) {
				List<String[]> normalizedFileContent = normalizeSpinnerFileSettingColumn(spinnerFileToNormalize);
				CSVWriter writer = createCSVWriter(normalizedFile);
				writer.writeAll(normalizedFileContent);
				writer.flush();
				writer.close();
			} else if (multivaluedColumns.contains(spinnerFileToNormalize.getName())) {
				List<String[]> normalizedFileContent = normalizeSpinnerFileMultiValuedColumn(spinnerFileToNormalize, columnsToSort);
				CSVWriter writer = createCSVWriter(normalizedFile);
				writer = createCSVWriter(normalizedFile);
				writer.writeAll(normalizedFileContent);
				writer.flush();
				writer.close();
			} else {
				logger.info("This file is not applicable for normalization :- " + spinnerFileToNormalize.getAbsolutePath());
				FileUtils.copyFile(spinnerFileToNormalize, normalizedFile);
			}

		}

	}

	/**
	 * Creates the CSV writer.
	 *
	 * @param targetFile the target file
	 * @return the CSV writer
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private CSVWriter createCSVWriter(File targetFile) throws IOException {

		CSVWriter writer = new CSVWriter(new FileWriter(targetFile), PWCDeltaExtractor.TAB_SEPERATOR,
				CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.NO_ESCAPE_CHARACTER);
		return writer;
	}

	/**
	 * Normalize both.
	 *
	 * @param file          the file
	 * @param columnsToSort the columns to sort
	 * @return the list
	 */
	private List<String[]> normalizeBoth(File file, Set<String> columnsToSort) {

		List<String[]> csvBody = null;

		try (com.opencsv.CSVReader reader = new com.opencsv.CSVReader(new FileReader(file))) {

			csvBody = reader.readAll();

			String[] header = csvBody.get(0);

			List<Integer> multiValuedColumnIndices = new ArrayList<>();
			int settingColumnIndex = 0;
			Boolean settingFound = Boolean.TRUE;

			for (int i = 0; i < header[0].split(TAB).length; i++) {
				if (columnsToSort.contains(header[0].split(TAB)[i])) {
					multiValuedColumnIndices.add(i);
				} else if (header[0].split(TAB)[i].startsWith("Setting") && settingFound) {
					settingColumnIndex = i;
					settingFound = Boolean.FALSE;
				}
			}

			logger.info("File Name -: " + file.getAbsolutePath());
			logger.info("MultiValue column index -: " + multiValuedColumnIndices);
			logger.info("Setting column index -:" + settingColumnIndex);

			TreeSet<String> multiValueColumntreeSet;

			// Get CSV row column and replace with by using row and column
			for (int i = 1; i < csvBody.size(); i++) {

				String[] strArray = csvBody.get(i);

				if (strArray[0].isEmpty()) {
					logger.info("Empty Line encountered !!!");
					continue;
				}

				//logger.debug("Line before normalization -: " + strArray[0]);
				String[] cell = strArray[0].split(TAB);

				// Normalizing multivalued columns
				multiValueColumntreeSet = new TreeSet<>();
				for (Integer inte : multiValuedColumnIndices) {

					if (inte < cell.length) {
						for (int p = 0; p < cell[inte].split(PIPE).length; p++) {
							multiValueColumntreeSet.add(cell[inte].split(PIPE)[p].trim());
						}

						cell[inte] = String.join("|", multiValueColumntreeSet);
						strArray[0].split(TAB)[inte] = String.join("|", multiValueColumntreeSet);

					}
				}

				strArray[0] = String.join("\t", cell);
				//logger.debug("Line after normalization  -: " + strArray[0]);

				// Normalize setting and its value column
				Map<String, String> settingsValueTreeMap = new TreeMap<>();
				for (int p = 0; p < cell[settingColumnIndex].split(PIPE).length; p++) {
					settingsValueTreeMap.put(cell[settingColumnIndex].split(PIPE)[p].trim(),
							cell[settingColumnIndex + 1].split(PIPE)[p].trim());
				}

				cell[settingColumnIndex] = String.join("|", settingsValueTreeMap.keySet());
				cell[settingColumnIndex + 1] = String.join("|", settingsValueTreeMap.values());

				strArray[0].split(TAB)[settingColumnIndex] = String.join("|", settingsValueTreeMap.keySet());
				strArray[0].split(TAB)[settingColumnIndex + 1] = String.join("|", settingsValueTreeMap.values());

				strArray[0] = String.join("\t", cell);
				//logger.debug("Line After normalization  -: " + strArray[0]);

			}
		} catch (IOException e) {
			logger.error(e);
		}
		return csvBody;

	}

	/**
	 * Normalize spinner file multi valued column.
	 *
	 * @param file          the file
	 * @param columnsToSort the columns to sort
	 * @return the list
	 */
	private List<String[]> normalizeSpinnerFileMultiValuedColumn(File file, Set<String> columnsToSort) {

		List<String[]> csvBody = null;

		try (com.opencsv.CSVReader reader = new com.opencsv.CSVReader(new FileReader(file))) {

			csvBody = reader.readAll();

			String[] header = csvBody.get(0);
			List<Integer> multiValuedColumnIndices = new ArrayList<>();

			for (int i = 0; i < header[0].split(TAB).length; i++) {
				if (columnsToSort.contains(header[0].split(TAB)[i])) {
					logger.info("File with multivalued Column -: " + file.getName());
					logger.info("Multivalued Column Name -:" + header[0].split(TAB)[i] + ", Column index :- " + i);
					multiValuedColumnIndices.add(i);
					break;
				}
			}

			TreeSet<String> obj;

			// Get CSV row column and replace with by using row and column
			for (int i = 1; i < csvBody.size(); i++) {

				String[] strArray = csvBody.get(i);
				logger.debug("Line before normalization :- " + strArray[0]);

				String[] cell = strArray[0].split(TAB);

				obj = new TreeSet<>();
				for (Integer inte : multiValuedColumnIndices) {

					if (inte < cell.length) {
						for (int p = 0; p < cell[inte].split(PIPE).length; p++) {
							obj.add(cell[inte].split(PIPE)[p].trim());
						}

						cell[inte] = String.join("|", obj);
						strArray[0].split(TAB)[inte] = String.join("|", obj);
					}
				}

				strArray[0] = String.join("\t", cell);
				//logger.debug("Line after normalization  :- " + strArray[0]);
			}

			return csvBody;

		} catch (IOException e) {
			logger.error(e);
		}

		return csvBody;

	}

	/**
	 * Normalize spinner file setting column.
	 *
	 * @param file the file
	 * @return the list
	 */
	private List<String[]> normalizeSpinnerFileSettingColumn(File file) {

		File inputFile = file;

		List<String[]> csvBody = null;

		try (com.opencsv.CSVReader reader = new com.opencsv.CSVReader(new FileReader(inputFile))) {

			csvBody = reader.readAll();

			String[] header = csvBody.get(0);
			int settingColumnIndex = 0;
			for (int i = 0; i < header[0].split(TAB).length - 1; i++) {
				if (header[0].split(TAB)[i].startsWith("Setting")) {
					settingColumnIndex = i;
					break;
				}
			}

			logger.info("Setting column Index -: " + settingColumnIndex + ", File Name -: " + file.getAbsolutePath());

			TreeMap<String, String> obj;

			// Get CSV row column and replace with by using row and column
			for (int i = 1; i < csvBody.size(); i++) {

				String[] strArray = csvBody.get(i);
				//logger.debug("Line before normalization :- " + strArray[0]);
				String[] cell = strArray[0].split(TAB);

				obj = new TreeMap<>();
				for (int p = 0; p < cell[settingColumnIndex].split(PIPE).length; p++) {
					obj.put(cell[settingColumnIndex].split(PIPE)[p].trim(),
							cell[settingColumnIndex + 1].split(PIPE)[p].trim());
				}

				cell[settingColumnIndex] = String.join("|", obj.keySet());
				cell[settingColumnIndex + 1] = String.join("|", obj.values());

				strArray[0].split(TAB)[settingColumnIndex] = String.join("|", obj.keySet());
				strArray[0].split(TAB)[settingColumnIndex + 1] = String.join("|", obj.values());

				strArray[0] = String.join("\t", cell);
				//logger.debug("Line after normalization :- " + strArray[0]);

			}

			return csvBody;

		} catch (IOException e) {
			logger.error("Error while normalizing spinner file with setting columns" + e);
		}

		return csvBody;
	}

	/**
	 * Gets the dependent files.
	 *
	 * @return the dependent files
	 */
	public List<File> getDependentFiles() {
		return dependentFiles;
	}

	/**
	 * Sets the dependent files.
	 *
	 * @param dependentFiles the new dependent files
	 */
	public void setDependentFiles(List<File> dependentFiles) {
		this.dependentFiles = dependentFiles;
	}

}
