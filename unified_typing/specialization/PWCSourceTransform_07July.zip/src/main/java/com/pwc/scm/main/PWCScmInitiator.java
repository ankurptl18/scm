package com.pwc.scm.main;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.apache.log4j.Logger;
import org.eclipse.jgit.api.errors.GitAPIException;

import com.pwc.scm.helper.PWCSpinnerDeltaExtractorFactory;
import com.pwc.scm.spinner.PWCDeltaExtractor;
import com.pwc.scm.util.PWCDeltaConfiguration;
import com.pwc.scm.util.PWCDeltaExtractorUtils;

import javafx.util.Pair;

/**
 * The Class ScmInitiator.
 * 
 * @author Sanjay.Meena
 */
public class PWCScmInitiator {

	/** The logger. */
	private static Logger logger = Logger.getLogger(PWCScmInitiator.class);

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws IOException     Signals that an I/O exception has occurred.
	 * @throws GitAPIException the git API exception
	 */
	public static void main(String[] args) throws IOException, GitAPIException {
		
		
		logger.info("******************* DELTA PROCESS START *******************");

		String originTag = args[0];
		String targetTag = args[1];
		String buildDir = args[2];

		
		/**Setup loggers *///TODO add log4j xml config
		String logFilePath = buildDir + File.separator + targetTag + "/logs/buildLog.txt";
		//Load configuration property file
		String deltaOutputDir = buildDir + File.separator + "delta_code_structure" ;
	    String targetTagDir = buildDir + File.separator + targetTag;
	    String originTagDir = buildDir + File.separator + originTag;
	    PWCDeltaExtractorUtils.configureLogger(logFilePath);
		
	    
	    /**Initialize one-time configuration */
		PWCDeltaConfiguration.getInstance().init(deltaOutputDir, targetTagDir, originTagDir);


		/**Setup DELTA generation location */
	    Path targetTagPath = Paths.get(targetTagDir);
	    	    
	    /**Setup DELTA generation location */
	    PWCDeltaExtractorUtils.beginDeltaExtractionProcess(targetTagPath, "root");
		
		logger.info("******************* DELTA PROCESS END *******************");

	}
}
