/**
 * 
 */
package com.pwc.scm.spinner;

/**
 * @author Sanjay.Meena
 *
 */
public class PWCDeltaExtractionException extends Exception {
	 public PWCDeltaExtractionException(String message) {
	        super(message);
	    }
}
