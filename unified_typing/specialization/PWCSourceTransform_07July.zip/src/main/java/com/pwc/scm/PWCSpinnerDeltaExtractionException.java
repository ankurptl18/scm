/**
 * 
 */
package com.pwc.scm;

/**
 * @author Sanjay.Meena
 *
 */
public class PWCSpinnerDeltaExtractionException extends Exception {
	 public PWCSpinnerDeltaExtractionException(String message) {
	        super(message);
	    }
}
