package com.ds.pwc.ipp.ws;

import matrix.db.Context;
import matrix.db.FileList;
import matrix.db.JPO;
import matrix.util.MatrixException;

import org.apache.log4j.Logger;

import com.ds.common.PWCConstants;
import com.ds.pwc.ipp.mos.PWCIPPMfgOperationList;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
 

/**
 * This class serves as an 'Exit code handler' for all the asynchronous web service method executions
 * 
 * @author ZWE
 *
 */
public class PWCIPPAsyncWSExitCodeHandler 
{

	public static void handleAWSMsgSerializationExit(Context context, PWCIPPMfgOperationList molObj, Exception e, int iErrorCode, Logger logger)
	{
		logger.error("Web service call failed to queue the message");

		String sSubject = getErrorCodeInterpretation(iErrorCode, context);	
		String sErrorMsg = PWCIPPWSUtil.getStackTrace(e);
		String sHTMLMsg = DomainConstants.EMPTY_STRING;
		try 
		{
			sHTMLMsg = molObj.toHTML(context);
		} catch (Exception e2) 
		{
			sHTMLMsg = "<Failed to generate HTML message>";
		}

		String[] arg = new String[] {molObj.getBadgeId(), sSubject, e.toString(), sHTMLMsg};
		try 
		{
			JPO.invoke(context, "PWC_IPPWSUtil", new String[]{}, "notifyUser", arg);

		} catch (MatrixException e1) 
		{
			logger.error("Failed to send email notification");
			e1.printStackTrace();
		}   

		logger.error(sSubject+"\n\n"+sErrorMsg+"\n\n"+sHTMLMsg);
	}


	public static void handleAWSMsgMandatoryCheckExit(Context context, PWCIPPMfgOperationList molObj, int iErrorCode, Logger logger) throws Exception
	{
		String sMessage = getErrorCodeInterpretation(iErrorCode, context);
		String[] arMssage = sMessage.split("\\|");
		String sSubject = arMssage[0];
		String sContent = arMssage[1];

		String sHTMLMsg = molObj.toHTML(context);

		String[] arg = new String[] {molObj.getBadgeId(), sSubject, sContent, sHTMLMsg};
		JPO.invoke(context, "PWC_IPPWSUtil", new String[]{}, "notifyUser", arg);

		logger.error("Mandatory argument check failed");
	}

	public static void handleAWSMsgExecutionExit(Context context, PWCIPPMfgOperationList molObj, CommonDocument cdQueue, Exception e, int iErrorCode, Logger logger)
	{
		//Exit code '000' represents the successful processing of Queue  
		if (iErrorCode == 000) 
		{
			try 
			{
				FileList flFiles = cdQueue.getFiles(context);
				//this is to check if any more files checked in after the files were read for processing
				//if yes, then Queue object should not be deleted but demoted to 'Ready' state
				if (flFiles.size() == 0) 
				{
					try 
					{
						cdQueue.deleteObject(context);
					} catch (Exception e2) 
					{
						logger.error("Failed to delete the Queue object");
					}
				}else
				{
					try 
					{
						cdQueue.demote(context);
					} catch (Exception e2) 
					{
						logger.error("Failed to demote the Queue object");
					}
				}
			} catch (Exception e2) 
			{
				logger.error("Failed to delete/demote the Queue object");
			}
		}else
		{
			//Marking the queue dirty
			try 
			{
				cdQueue.setAttributeValue(context, PWCConstants.ATTRIBUTE_PWC_IPP_QUEUE_DIRTY_FLAG, "true");

			} catch (Exception e2) 
			{
				logger.error("Failed to mark Queue object as dirty");
			}

			String sSubject = getErrorCodeInterpretation(iErrorCode, context); 
			String sErrorMsg = PWCIPPWSUtil.getStackTrace(e);
			String sHTMLMsg = DomainConstants.EMPTY_STRING;
			try 
			{
				sHTMLMsg = molObj.toHTML(context);
			} catch (Exception e2) 
			{
				sHTMLMsg = "<Failed to generate HTML message>";
			}

			String[] arg = new String[] {molObj.getBadgeId(), sSubject, e.getMessage(), sHTMLMsg};
			try 
			{
				JPO.invoke(context, "PWC_IPPWSUtil", new String[]{}, "notifyUser", arg);
			} catch (Exception e1)
			{
				logger.error("Failed to send email notification");
			}
			logger.error(sSubject+"\n\n"+sErrorMsg+"\n\n"+sHTMLMsg);
		}
	}

	private static String getErrorCodeInterpretation(int iErrorCode, Context context)
	{
		String sInterpretation = DomainConstants.EMPTY_STRING;
		String sErrCode = DomainConstants.EMPTY_STRING;
		StringBuilder sbErrMsg = new StringBuilder();
		
		try 
		{
		switch (iErrorCode) 
		{
		case 100:
			sErrCode = "EV6_ERROR_100 : ";
			sInterpretation = "pwcEngineeringCentral.SaveRouting.MandatoryCheck.Failure";
			sbErrMsg.append(sErrCode).append(EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), sInterpretation));

			break;

		case 110:
			sErrCode = "EV6_ERROR_110 : ";
			sInterpretation = "pwcEngineeringCentral.Queue.SaveRouting.Failure";
			sbErrMsg.append(sErrCode).append(EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), sInterpretation));

			break;

		case 120:
			sErrCode = "EV6_ERROR_120 : ";
			sInterpretation = "pwcEngineeringCentral.SaveRouting.Check.Failure";
			sbErrMsg.append(sErrCode).append(EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), sInterpretation));

			break;

		case 200:
			sErrCode = "EV6_ERROR_200 : ";
			sInterpretation = "pwcEngineeringCentral.ModifyRouting.MandatoryCheck.Failure";
			sbErrMsg.append(sErrCode).append(EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), sInterpretation));

			break;

		case 210:
			sErrCode = "EV6_ERROR_210 : ";
			sInterpretation = "pwcEngineeringCentral.Queue.ModifyRouting.Failure";
			sbErrMsg.append(sErrCode).append(EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), sInterpretation));

			break;

		case 220:
			sErrCode = "EV6_ERROR_220 : ";
			sInterpretation = "pwcEngineeringCentral.ModifyRouting.Check.Failure";
		        sbErrMsg.append(sErrCode).append(EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), sInterpretation));

			break;

		default: 
			break;
		}
			
		} catch (Exception e) 
		{
			sbErrMsg = new StringBuilder();
			sbErrMsg.append(sErrCode);
		}
		
		return sbErrMsg.toString();
	}

}
