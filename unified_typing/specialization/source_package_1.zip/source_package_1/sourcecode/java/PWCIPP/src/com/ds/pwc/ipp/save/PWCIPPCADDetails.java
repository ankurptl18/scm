package com.ds.pwc.ipp.save;

public class PWCIPPCADDetails
{
	private String m_MajorID;
	private String m_MajorType;
	private String m_MajorName;
	private String m_MajorRevision;
	
	private String m_MinorID;
	private String m_MinorType;
	private String m_MinorName;
	private String m_MinorRevision;
	
	private String m_CADType;
	
	public PWCIPPCADDetails()
	{
		m_MajorID = null;
		m_MajorType = null;
		m_MajorName = null;
		m_MajorRevision = null;
		
		m_MinorID = null;
		m_MinorType = null;
		m_MinorName = null;
		m_MinorRevision = null;
		
		m_CADType = null;
	}
	
	public void setMajorValues( String iMajorID , String iMajorType , String iMajorName , String iMajorRevision , String iCADType )
	{
		m_MajorID       = iMajorID;
		m_MajorType     = iMajorType;
		m_MajorName     = iMajorName;
		m_MajorRevision = iMajorRevision;
		m_CADType       = iCADType;
	}
	
	public void setMajorValues( String iMinorID , String iMinorType , String iMinorName , String iMinorRevision )
	{
		m_MinorID       = iMinorID;
		m_MinorType     = iMinorType;
		m_MinorName     = iMinorName;
		m_MinorRevision = iMinorRevision;
	}
	
	public void setAllValues( String iMajorID , String iMajorType , String iMajorName , String iMajorRevision ,
	                          String iMinorID , String iMinorType , String iMinorName , String iMinorRevision ,
	                          String iCADType )
	{
		m_MajorID       = iMajorID;
		m_MajorType     = iMajorType;
		m_MajorName     = iMajorName;
		m_MajorRevision = iMajorRevision;
		m_MinorID       = iMinorID;
		m_MinorType     = iMinorType;
		m_MinorName     = iMinorName;
		m_MinorRevision = iMinorRevision;
		m_CADType       = iCADType;
	}
	
	public String getMajorID()
	{
		return m_MajorID;
	}
	
	public void setMajorID( String iValue )
	{
		m_MajorID = iValue;
	}
	
	public String getMajorType()
	{
		return m_MajorType;
	}
	
	public void setMajorType( String iValue )
	{
		m_MajorType = iValue;
	}
	
	public String getMajorName()
	{
		return m_MajorName;
	}
	
	public void setMajorName( String iValue )
	{
		m_MajorName = iValue;
	}
	
	public String getMajorRevision()
	{
		return m_MajorRevision;
	}
	
	public void setMajorRevision( String iValue )
	{
		m_MajorRevision = iValue;
	}
	
	public String getMinorID()
	{
		return m_MinorID;
	}
	
	public void setMinorID( String iValue )
	{
		m_MinorID = iValue;
	}
	
	public String getMinorType()
	{
		return m_MinorType;
	}
	
	public void setMinorType( String iValue )
	{
		m_MinorType = iValue;
	}
	
	public String getMinorName()
	{
		return m_MinorName;
	}
	
	public void setMinorName( String iValue )
	{
		m_MinorName = iValue;
	}
	
	public String getMinorRevision()
	{
		return m_MinorRevision;
	}
	
	public void setMinorRevision( String iValue )
	{
		m_MinorRevision = iValue;
	}
	
	public String getCADType()
	{
		return m_CADType;
	}
	
	public void setCADType( String iValue )
	{
		m_CADType = iValue;
	}
}
