package com.ds.pwc.ipp.save;

import java.util.AbstractSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class PWCIPPSetOfCADDetails extends AbstractSet<PWCIPPCADDetails>
{
	private class WrappedIterator implements Iterator<PWCIPPCADDetails>
	{
		private Iterator<PWCIPPCADDetails> m_Master;
		private PWCIPPCADDetails m_Current;
		
		private WrappedIterator( Iterator<PWCIPPCADDetails> iMaster )
		{
			m_Master = iMaster;
			m_Current = null;
		}
		
		@Override
		public boolean hasNext()
		{
			return m_Master.hasNext();
		}
		
		@Override
		public PWCIPPCADDetails next()
		{
			m_Current = m_Master.next();
			return m_Current;
		}
		
		@Override
		public void remove()
		{
			m_ByMajorID.remove( m_Current.getMajorID() );
			m_ByMinorID.remove( m_Current.getMinorID() );
			m_Master.remove();
			m_Current = null;
		}
	}
	
	private final List<PWCIPPCADDetails> m_ForIterator;
	
	private final Map<String,PWCIPPCADDetails> m_ByMajorID;
	private final Map<String,PWCIPPCADDetails> m_ByMinorID;
	
	public PWCIPPSetOfCADDetails()
	{
		m_ForIterator = new LinkedList<PWCIPPCADDetails>();
		m_ByMajorID   = new HashMap<String,PWCIPPCADDetails>();
		m_ByMinorID   = new HashMap<String,PWCIPPCADDetails>();
	}

	public PWCIPPSetOfCADDetails( int iInitialCapacity )
	{
		m_ForIterator = new LinkedList<PWCIPPCADDetails>();
		m_ByMajorID   = new HashMap<String,PWCIPPCADDetails>( iInitialCapacity );
		m_ByMinorID   = new HashMap<String,PWCIPPCADDetails>( iInitialCapacity );
	}
	
	@Override
	public boolean add( PWCIPPCADDetails iValue )
	{
		String st_majorID = iValue.getMajorID();
		String st_minorID = iValue.getMinorID();
		
		PWCIPPCADDetails previousByMajor = m_ByMajorID.put( st_majorID , iValue );
		PWCIPPCADDetails previousByMinor = m_ByMinorID.put( st_minorID , iValue );

		boolean b_modified = false;
		if( null == previousByMajor && null == previousByMinor )
		{
			m_ForIterator.add( iValue );
			b_modified = true;
		}
		else
		{
			if( null != previousByMajor ) { m_ByMajorID.put( st_majorID , previousByMajor ); }
			else { m_ByMajorID.remove( st_majorID ); }
			
			if( null != previousByMinor ) { m_ByMinorID.put( st_minorID , previousByMinor ); }
			else { m_ByMinorID.remove( st_minorID ); }
		}
		
		return b_modified;
	}
	
	@Override
	public Iterator<PWCIPPCADDetails> iterator()
	{
		return new WrappedIterator( m_ForIterator.iterator() );
	}
	
	@Override
	public int size()
	{
		return m_ForIterator.size();
	}
	
	@Override
	public void clear()
	{
		m_ForIterator.clear();
		m_ByMajorID.clear();
		m_ByMinorID.clear();
	}
	
	public PWCIPPCADDetails getByMajorID( String iID )
	{
		return m_ByMajorID.get( iID );
	}

	public boolean containsMajorID( String iID )
	{
		return m_ByMajorID.containsKey( iID );
	}

	public PWCIPPCADDetails getByMinorID( String iID )
	{
		return m_ByMinorID.get( iID );
	}

	public boolean containsMinorID( String iID )
	{
		return m_ByMinorID.containsKey( iID );
	}
}
