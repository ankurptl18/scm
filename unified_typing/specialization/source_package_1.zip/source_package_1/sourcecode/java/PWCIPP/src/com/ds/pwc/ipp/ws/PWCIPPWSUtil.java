package com.ds.pwc.ipp.ws;

/**
 * This is an utility class
 * 
 * @author ZWE
 *
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import matrix.db.Context;
import matrix.db.FileCheckinOutputStream;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.Role;
import matrix.util.SelectList;
import matrix.util.StringList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ds.common.PWCCommonUtil;
import com.ds.pwc.ipp.mos.PWCIPPMfgOperation;
import com.ds.pwc.ipp.mos.PWCIPPMfgOperationList;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCIPPWSUtil
{
	private static final Logger _LOGGER  = Logger.getLogger(PWCIPPWSUtil.class.getName());
	private static final String FSEPERATOR = System.getProperty("file.separator");
	private static final String SECU_CONTEXT_PREFIX = "ctx::";
	private static final String COMMA_SEPERATOR = ",";

	/**
	 * This API checks if the given CAD Object is external to the given MOL or not
	 * 
	 * @param sCATObjName - name of the CAD Object
	 * @param sMOLName - name of the MOL
	 * @return boolena - true if it is external, else false
	 */
	public static boolean isExternalToMOL(String sCATObjName, String sMOLName)
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::isExternalToMOL()");
		
		boolean bExternalPart = false;
		
		if(!sCATObjName.startsWith(sMOLName)) 
		{						
			bExternalPart = true;
		}
		
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::isExternalToMOL()");
		
		return bExternalPart;
	}
	
	/**
	 * This API checks if the given CAD Object is external to the given Operation or not
	 * 
	 * @param sCATObjName - name of the CAD Object
	 * @param sOperationName - name of the Operation
	 * @return boolena - true if it is external, else false
	 */
	public static boolean isExternalToOperation(String sCATObjName, String sOperationName)
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::isExternalToOperation()");
		
		boolean bExternalPart = false;
		
		if(!sCATObjName.startsWith(sOperationName)) 
		{						
			bExternalPart = true;
		}
		
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::isExternalToOperation()");
		
		return bExternalPart;
	}
	
	/**
	 * This method checks if the the Integration User has appropriate products assigned 
	 * to be able to queue the web service message. If not then throws exception else pushesh the context to super user.
	 * It is called from all the asynchronous web service API's
	 * 
	 * @param context
	 * @throws Exception
	 */
	public static void connectAsynchWSContext(Context context) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::connectAsynchWSContext()");

		// Integration User License check
		String sIntegUserProductAssignments = EnoviaResourceBundle.getProperty(context, "pwcEngineeringCentral.IPP.WS.IntegrationUser.Products");
		checkPersonsProductAssignements(context, context.getUser(), sIntegUserProductAssignments);

		pushContextToSuperUser(context);

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::connectAsynchWSContext()");
	}

	/**
	 * It does the product assignment check for both Integration and BadgeId users.
	 * Then pushes the context to BadgeIdUser followed by setting the physical location.
	 * It is called from all the synchronous web service API's
	 * 
	 * @param context
	 * @param sEV6User - SAP BadgeId User
	 * @param sLocation - Physical Location of the BadgeId user
	 * @return Context - newly created matrix context
	 * @throws Exception
	 */
	public static Context connectSynchWSContext(Context context, String sEV6User, String sLocation, boolean bIsFromMOSMerge) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::connectSynchWSContext()");

		// Integration User License check
		String sIntegUserProductAssignments = EnoviaResourceBundle.getProperty(context, "pwcEngineeringCentral.IPP.WS.IntegrationUser.Products");
		checkPersonsProductAssignements(context, context.getUser(), sIntegUserProductAssignments);

		/*boolean bSuperUser = PWCCommonUtil.isSuperUser(context);
		if (!bSuperUser) 
		{
			pushContextToSuperUser(context);
		}*/
		
		// The above lines have been commented out and added below ones during 2014x upgrade for #BT0000000004815
		// API Context frameContext = context.getFrameContext("EXCPersonLicenseCheckBase") fails in external authentication environment with 'Invalid Password' exception in below condition
		//  "a context of non-super user is pushed to super user and then pushed back to non-super user and then cloned (provided both non-super users are different)"
		// The above condition appears in the case of synchronous webservice calls
		// And the solution is.. instead of pushing the existing context to super user, create a new one.. as done below. It then avoids the above situation. 
		Context newContext = new Context(DomainConstants.EMPTY_STRING);
		pushContextToSuperUser(newContext);
		ContextUtil.pushContext(newContext, sEV6User, DomainConstants.EMPTY_STRING, getPersonsVault(context, sEV6User));

		// BadgeId User License check
		String sBadgeIdUserProductAssignments = DomainConstants.EMPTY_STRING;
		if (bIsFromMOSMerge) 
		{
			sBadgeIdUserProductAssignments = sIntegUserProductAssignments;
		}else
		{
			sBadgeIdUserProductAssignments = EnoviaResourceBundle.getProperty(newContext, "pwcEngineeringCentral.IPP.WS.SAPBadgeIdUser.Products");
		}
		checkPersonsProductAssignements(newContext, newContext.getUser(), sBadgeIdUserProductAssignments);

		// set Location for BadgeId User
		//currently since SAP does not have the 'Location' info, it is sending the blank value. Hence if it is blank, it will not be set for now
		//But from the point when SAP starts to have this info, then this 'if' condition should be removed, so that in case of blank value the initial Location will be set to 'NO_LOCATION_DEFINED'
		if (!UIUtil.isNullOrEmpty(sLocation)) 
		{
			String[] arg = new String[] {sLocation};
			
			JPO.invoke(newContext, "PWC_IPP_CV5_EV6_Integration", null, "setPWCPhysicalLocation", arg);
	
			_LOGGER.debug("Physical location is set to '"+sLocation+"'");
		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::connectSynchWSContext()");
		
		return newContext;
	}


	/**
	 * It does the product assignment check for Integration user.
	 * Then pushesh the context to BadgeIdUser followed by setting the physical location.
	 * It is called from all the synchronous web service API's
	 * 
	 * @param context
	 * @param sEV6User - SAP BadgeId User
	 * @param sLocation - Physical Location of the BadgeId user
	 * @throws Exception
	 */
	public static void connectBgpThreadContext(Context context, String sEV6User, String sLocation) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::connectBgpThreadContext()");

		ContextUtil.pushContext(context, sEV6User, DomainConstants.EMPTY_STRING, PWCIPPWSUtil.getPersonsVault(context, sEV6User));

		// BadgeId User License check
		String sBadgeIdUserProductAssignments = EnoviaResourceBundle.getProperty(context, "pwcEngineeringCentral.IPP.WS.SAPBadgeIdUser.Products");
		checkPersonsProductAssignements(context, context.getUser(), sBadgeIdUserProductAssignments);

		// set Location for BadgeId User
		//set Location for BadgeId User
		//currently since SAP does not have the 'Location' info, it is sending the blank value. Hence if it is blank, it will not be set for now
		//But from the point when SAP starts to have this info then this code needs to be modified to set Location to 'NO_LOCATION_DEFINED' if it is blank
		if (!UIUtil.isNullOrEmpty(sLocation)) 
		{
			String[] arg = new String[] {sLocation};
			JPO.invoke(context, "PWC_IPP_CV5_EV6_Integration", new String [] {}, "setPWCPhysicalLocation", arg);
			_LOGGER.debug("Physical location is set to '"+sLocation+"'");
		}

		//fix for login context set Upgrade 2014x FP1432
		// set the required SecurityContext (added during 2014x upgrade project)
		setSecurityContext(context);
		
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::connectBgpThreadContext()");
	}

	/**
	 * This method has been introduced during 2014x upgrade project 
	 * It takes care of setting the required securityContext on the background thread context
	 * 		This is required because all the background thread contexts are programmatically created from scratch
	 * 
	 * @param context - matrix context
	 * @throws Exception - throws exception if operation fails OR if user is not assigned required security context
	 */
	public static void setSecurityContext(Context context) throws Exception 
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::setSecurityContext()");
		String sUserName = DomainConstants.EMPTY_STRING;
		try 
		{
			// get the configured list of roles
			String sRequiredRoles = EnoviaResourceBundle.getProperty(context,"pwcEngineeringCentral.IPP.WebService.BackgroundContextUser.ParentRoles");
			StringList slReqRoles = FrameworkUtil.split(sRequiredRoles, COMMA_SEPERATOR);
			_LOGGER.debug("Configured list of roles are: "+ slReqRoles);
			
			//Check if the configured roles has property 'isaproject=TRUE'
			StringList slReqIsaProejctRoles = filterIsaProjectRoles(context, slReqRoles);
			
			if ( slReqIsaProejctRoles.size() < 1 ) 
			{
				String[] message1Keys = new String[]{"Required_Role_List"};
				String[] message1Values = new String[]{slReqRoles.toString()};
				String sMsg = MessageUtil.getMessage(context,"pwcEngineeringCentral.PWCIPP.WebService.BackgroundContextUser.InvalidRoles", message1Keys, message1Values, null, context.getLocale(), "emxEngineeringCentralStringResource");
				throw new Exception(sMsg);
			}
			
			//first check if the person has 'preference_DefaultSecurityContext' property
			//and then check if that is the valid security context
			String sPersonAdminType = PersonUtil.personAdminType;
			sUserName = context.getUser();
			String sDSCProperty = PropertyUtil.getAdminProperty(context, sPersonAdminType, sUserName, PersonUtil.PREFERENCE_DEFAULT_SECURITY_CONTEXT);
			
			boolean bIsValidUser = false;
			String sSCRole = DomainConstants.EMPTY_STRING;
			
			// check if any of the security context's parent roles is one of from the configured list 
			if( !UIUtil.isNullOrEmpty(sDSCProperty) )
			{
				sSCRole = (new StringBuilder(SECU_CONTEXT_PREFIX)).append(sDSCProperty).toString();
				bIsValidUser = isValidSCRole( context, sSCRole, slReqIsaProejctRoles );
			}
			
			//If it is not then check with 'Security Context Assignments' 
			if( !bIsValidUser )
			{
				// get all the security contexts assinged to the user/context
				Vector vSCAssignments = PersonUtil.getSecurityContextAssignments(context);
				
				_LOGGER.debug("List of Security Contexts Assinged: "+ vSCAssignments);
				
				// check if any of the security context's parent roles is one of from the configured list 
				for (int i = 0; i < vSCAssignments.size(); i++) 
				{
					sSCRole = vSCAssignments.get(i).toString();
					sSCRole = (new StringBuilder(SECU_CONTEXT_PREFIX)).append(sSCRole).toString();
					
					bIsValidUser = isValidSCRole( context, sSCRole, slReqIsaProejctRoles );
					
					if(bIsValidUser)
					{
						break;
					}
				}
			}
			
			// now set the corresponding security context as role on the given context
			if(bIsValidUser)
			{
				_LOGGER.debug("Setting the security context as: "+ sSCRole);
				context.resetRole(sSCRole);
			}
			else
			{
				String sErrMsg = EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), "pwcEngineeringCentral.PWCIPP.WebService.Background.NoValidSC");
				throw new Exception(sErrMsg);
			}
			
		} catch (Exception e) 
		{
			String[] message1Keys = new String[]{"UserName"};
			String[] message1Values = new String[]{sUserName};
			String sMsg = MessageUtil.getMessage(context,"pwcEngineeringCentral.PWCIPP.WebService.Background.SCSetFailure", message1Keys, message1Values, null, context.getLocale(), "emxEngineeringCentralStringResource");

			throw new Exception( (new StringBuilder(sMsg)).append(e.getMessage()).toString(), e );
		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::setSecurityContext()");
	}
	
	/**
	 * This method filters the given list of roles and returns the new list having only the roles with property 'isaproject=TRUE'
	 * 
	 * @param context
	 * @param slRoles
	 * @return
	 * @throws FrameworkException
	 */
	public static StringList filterIsaProjectRoles( Context context, StringList slRoles ) throws FrameworkException
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::filterIsaProjectRoles()");
		
		StringList slResult = new StringList();
		
		String sRole = DomainConstants.EMPTY_STRING;
		StringBuilder sbCommand = new StringBuilder();
		
		for (int i = 0; i < slRoles.size(); i++) 
		{
			sRole = slRoles.get(i).toString().trim();
			
			sbCommand.append("print role '").append(sRole).append("' select isaproject");
			
			String sResult = MqlUtil.mqlCommand( context, false, sbCommand.toString(), true );
			StringList sl = FrameworkUtil.split(sResult, "=");
			
			sResult = sl.get(1).toString().trim();
			
			if ("TRUE".equals(sResult)) 
			{
				slResult.add(sRole);
			}
			
			sbCommand.delete(0, sbCommand.length());
		}
		
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::filterIsaProjectRoles()");
		
		return slResult;
	}
	
		private static boolean isValidSCRole( Context context, String sSCRole, StringList slReqRoles ) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::isValidSCRole()");
		
		boolean bResult = false;
		
		// get all the parent roles of the security context
		Role roleObj = new Role( sSCRole );
		StringList slTLRoles = roleObj.getParents(context, true);
		_LOGGER.debug("Parent Roles of Security Context '"+sSCRole+"' are: "+ slTLRoles);
		
		//Check if the parent roles has property 'isaproject=TRUE'
		StringList slIsaProjectRoles = filterIsaProjectRoles(context, slTLRoles);
		
		if ( slIsaProjectRoles.size() > 0 ) 
		{
			// check if parent role list contains at least one of the configured roles
			String sPRole = DomainConstants.EMPTY_STRING;
			for (int j = 0; j < slReqRoles.size(); j++) 
			{
				sPRole = (String) slReqRoles.get(j);
				sPRole = sPRole.trim();
				
				if ( slIsaProjectRoles.contains(sPRole) )
				{
					bResult = true;
					break;
				}
			}
			
		}else
		{
			_LOGGER.warn("None of the parent roles, '"+slTLRoles+"' of '"+sSCRole+"' has property 'isaproject=TRUE'");
		}
		
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::isValidSCRole()");
		
		return bResult;
	}
	

	/**
	 * This API disconnects the context
	 * It is called from Synchronous and the Asynchrounous web services
	 * 
	 * @param context
	 */
	public static void disconnectWsContext(Context context)
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::disconnectWsContext()");

		try 
		{
			context.shutdown();

		} catch (Exception e) 
		{
			_LOGGER.warn("Failed to disconnect the context");
		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::disconnectWsContext()");
	}


	private static void checkPersonsProductAssignements(Context context, String sPersonName, String sRequiredProds) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::checkPersonsProductAssignements()");
		
		sRequiredProds = sRequiredProds.replaceAll("\\s", DomainConstants.EMPTY_STRING);
		String[] arRequiredProducts = sRequiredProds.split("\\,");

		MQLCommand mqlCommand = new MQLCommand();
		String strcommand = "print person \""+sPersonName+"\" select product dump |";

		boolean bMQLResult = false;
		bMQLResult =  mqlCommand.executeCommand(context, strcommand);

		if (bMQLResult) 
		{
			String sResult = mqlCommand.getResult();
			sResult = sResult.replaceAll("\\s", DomainConstants.EMPTY_STRING);

			String[] arAssignedProds = sResult.split("\\|");
			StringList slAssignedProds = new StringList(arAssignedProds);
			_LOGGER.debug("\n slAssignedProds: "+slAssignedProds);

			StringList slReqProds = new StringList(arRequiredProducts);
			_LOGGER.debug("\n slReqProds: "+slReqProds);
			
			
			if (!slAssignedProds.containsAll(slReqProds)) 
			{
				//throw new Exception("User does not have all the required products (i.e. "+slReqProds+") assigned.");
				String[] message1Keys = new String[]{"slReqProds"};
				String[] message1Values = new String[]{slReqProds.toString()};
				String sErrMsg = MessageUtil.getMessage(context,"pwcEngineeringCentral.WSUtil.checkPersonsProductAssignements.Failure",message1Keys,message1Values,null,context.getLocale(),"emxEngineeringCentralStringResource");
				throw new Exception(sErrMsg);
			}
		}
		
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::checkPersonsProductAssignements()");
	}


	/**
	 * This API pushesh the given context to 'User Agent' sets the vault specified in the SafetyVaulg peroperty
	 * 
	 * @param context - context to be pushed
	 * @return context - pushed context
	 * @throws FrameworkException - if operation fails
	 */
	public static void pushContextToSuperUser(Context context) throws FrameworkException
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::pushContextToSuperUser()");
		
		String sSafteyVault = EnoviaResourceBundle.getProperty(context,"eServiceEngineeringCentral.emxSafetyVault");
		String sSuperUser = PropertyUtil.getSchemaProperty(context, "person_UserAgent");
		ContextUtil.pushContext(context, sSuperUser, DomainConstants.EMPTY_STRING, sSafteyVault);
		
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::pushContextToSuperUser()");
		
	}
	
	
	/**
	 * This API does a file check in the xml node content on the given DomainObject without writting it to the file
	 * 
	 * @param context - matrix context object
	 * @param dom - DomainObject on which file to be checked in
	 * @param element - XML Document node (root)
	 * @param sFileName - check in file name
	 * @throws Exception - if operation fails
	 */
	public static void checkInXMLFile(Context context, DomainObject dom, Node element, String sFileName) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::checkInXMLFile()");
		dom.open(context);

		FileCheckinOutputStream binary = new FileCheckinOutputStream( context , dom , DomainConstants.FORMAT_GENERIC , sFileName , true , true );

                if (null != element) 
		{
			deleteNullNode(element);
		}
		DOMSource source = new DOMSource( element );
		StreamResult result = new StreamResult( binary );

		boolean bSuccess = false;
		try
		{
			//There is no transformation happening here but this is used only for writting xml node to the Stream
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			//transformer.setOutputProperty( OutputKeys.INDENT , "yes" );
			transformer.transform( source , result );
			bSuccess = true;
		}
		catch( Exception e )
		{
			_LOGGER.error("Failed to check in message on queue object, exception while transforming the XML document to an output stream"+e);
			throw e ;
		}
		finally
		{
			try
			{
				if( bSuccess ) 
				{ 
					binary.close(); 
				}else                
				{ 
					binary.abort(); 
				}
			}
			catch( Exception e )
			{
				_LOGGER.error("Failed to check in message on queue object, exception while closing an output stream"+e);
				throw e;
			}
		}

		dom.close(context);
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::checkInXMLFile()");
	}


	/**
	 * This utility API removes which scans through all the child nodes of the given 
	 * node with 'null' values and removes the 'null' value
	 * 
	 * @param node - xml document node
	 */
	public static void deleteNullNode(Node node)
	{
		NodeList nl = node.getChildNodes();
		for (int i = 0; i < nl.getLength(); i++)
		{
			if (nl.item(i).getNodeType() == Node.TEXT_NODE && nl.item(i).getNodeValue() == null)
			{
				nl.item(i).getParentNode().removeChild(nl.item(i));
			}
			else
			{
				deleteNullNode(nl.item(i));
			}
		}
	}


	/**
	 * Thsi API gives the HTML representation of the given xml web service message
	 * 
	 * @param context - matrix context object
	 * @param sXMLPath - absolute path of an xml file
	 * @return - HTML string
	 * @throws Exception - id operation fails
	 */
	public static String generateHTMLMsg(Context context, Document xmlDom) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::generateHTMLMsg()");

		String sXSLPath = getXslFilePath(context);
		StringWriter sbWriter = new StringWriter();

		try 
		{
			TransformerFactory tFactory    = 	TransformerFactory.newInstance();
			Source xslSource = new StreamSource(sXSLPath);
			DOMSource xmlSource = new DOMSource( xmlDom );

			Transformer transformer = tFactory.newTransformer(xslSource);
			transformer.setOutputProperty( OutputKeys.INDENT , "yes" );
			transformer.transform(xmlSource, new StreamResult(sbWriter));	    	    
		}
		catch (Exception e) 
		{
			_LOGGER.debug("Exception in "+PWCIPPWSUtil.class.getName()+"::generateQueueInfo()");
			e.printStackTrace( );
		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::generateHTMLMsg()");
		return sbWriter.toString();
	}


	/**
	 * This API gives the absolute path for the xsl resource 
	 * 
	 * @param context
	 * @throws FrameworkException 
	 */
	public static String getXslFilePath(Context context) throws FrameworkException
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::getXslFilePath()");

		String sXSLFileName = EnoviaResourceBundle.getProperty(context, "pwcEngineeringCentral.IPP.WS.SAPDataTransofrmation.XSLTFileName");

		PWCIPPWSUtil obj = new PWCIPPWSUtil();
		ClassLoader cl = obj.getClass().getClassLoader();
		URL url = cl.getResource(sXSLFileName);
		String sXslPath = url.toExternalForm();

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::getXslFilePath()");
		return sXslPath;
	}


	/**
	 * This utility API adds the element under root node of the DOM object passed
	 * @param doc - xml document object
	 * @param sElementName - element name which is to be added under root node
	 * @param mAttrMap - map of the values to be added under the node
	 */
	@SuppressWarnings("unchecked")
	public static void addElementInDocumentUnderRoot(Document doc, String sElementName, Map mAttrMap)
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::addElementInDocumentUnderRoot()");

		Element opAttr = doc.createElement(sElementName);
		Element root = doc.getDocumentElement();
		buildElementFromMap(doc, opAttr, mAttrMap);
		root.appendChild(opAttr);

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::addElementInDocumentUnderRoot()");
	}

	/**
	 * This utility API returns the "Attributes" element for the operation object
	 * @param doc - xml document object
	 * @param sElementName - element name which is to be added under root node
	 * @param mAttrMap - map of the values to be added under the node
	 */
	@SuppressWarnings("unchecked")
	public static void buildElementFromMap(Document doc, Element elTemp, Map mAttrMap)
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::buildElementFromMap()");

		try 
		{
			Element temp = null;
			String sKey = DomainConstants.EMPTY_STRING;
			String sValue = DomainConstants.EMPTY_STRING;
			Iterator entries = mAttrMap.entrySet().iterator();
			Map.Entry entry = null;
			while (entries.hasNext()) 
			{
				entry = (Map.Entry) entries.next();
				sKey = (String)entry.getKey();
				sValue = (String)entry.getValue();
				temp = doc.createElement(sKey);
				temp.appendChild(doc.createTextNode(sValue));
				elTemp.appendChild(temp);
			}
		} 
		catch (Exception e) 
		{
			_LOGGER.debug("Exception in "+PWCIPPWSUtil.class.getName()+"::buildElementFromMap()");
			e.printStackTrace();
		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::buildElementFromMap()");
	}


	public static Map<String,String> buildMapFromXML(Node nodeAttr)
	throws Exception 
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::buildAttributesMapFromXML()");
		Map<String,String> mAttr = new HashMap<String,String>();

		try
		{
			String sName = DomainConstants.EMPTY_STRING;
			String sVal = DomainConstants.EMPTY_STRING;

			NodeList attrChilds = nodeAttr.getChildNodes();
			int iSize = attrChilds.getLength();
			Element eleChild = null;
			for(int i=0; i<iSize; i++)
			{
				eleChild = (Element)attrChilds.item(i);
				sName = eleChild.getNodeName();
				sVal = eleChild.getTextContent();
				mAttr.put(sName,sVal);
			}
		} 
		catch(Exception e)
		{
			_LOGGER.debug("Exception in "+PWCIPPWSUtil.class.getName()+"::buildAttributesMapFromXML()");
			e.printStackTrace();
		}
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::buildAttributesMapFromXML()");
		return mAttr;
	}

	/**
	 * This API serializes the given string content into the file in the server workspace and returns its absolute path
	 * The file is named as per the given name and extension
	 * 
	 * @param context
	 * @param strContent - String content to be serialized
	 * @param strFileName - Name of the file to be created
	 * @param strExtension - extension of the file to be created
	 * @return - absolute path of the file 
	 * @throws Exception
	 */
	public static String serializeFile(Context context, String sContent, String sFileName) throws Exception 
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::serializeFile()");

		String sWorkspace = context.createWorkspace()+FSEPERATOR;
		File file = new File(sWorkspace);
		if(!(file.exists() && file.isDirectory()))
		{
			try
			{
				file.mkdir();				
			}
			catch(Exception ex)
			{		
				ex.printStackTrace();
				throw ex;
			}
		}
		StringBuilder sb = new StringBuilder();
		File file1 = new File(sb.append(sWorkspace).append(sFileName).append(".").toString());
		BufferedWriter bfWriter;
		try 
		{
			bfWriter = new BufferedWriter(new FileWriter(file1));
			bfWriter.append(sContent);
			bfWriter.close();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			throw e;
		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::serializeFile()");
		return file1.getAbsolutePath();
	}

	/**
	 * This method checks for Mandatory arguments of List and Operation objects passed to the web service
	 * 
	 * @param sMandatoryArgs - mandatory arguments key value
	 * @param molObj - MOL object
	 * @return, true - if attribute values are not empty/null, false - if values are empty/null
	 */
	public static boolean checkMandetoryArgs(String sMaderotyArgs, PWCIPPMfgOperationList molObj) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::chekMandetoryArgs()");

		boolean bCheck = true;
		if(null != molObj)
		{
			ArrayList<PWCIPPMfgOperation> arMOS = molObj.readOperationList();
			String[] arArgs = sMaderotyArgs.split("\\|");
			String[] arMOLArgs = arArgs[0].split("\\,");
			String[] arMOSArgs = arArgs[1].split("\\,");

			bCheck = checkMOLArgs(arMOLArgs, molObj);

			if(bCheck)
			{
				for (int i = 0; i < arMOS.size(); i++) 
				{
					bCheck = checkMOSArgs(arMOSArgs, arMOS.get(i));
					if(!bCheck)
					{
						break;
					}
				}
			}
		}
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::chekMandetoryArgs()");
		return bCheck;
	}

	private static boolean checkMOLArgs(String[] arMOLArgs, PWCIPPMfgOperationList objMOL) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::checkMOLArgs()");

		boolean bCheckResult = true;
		String sArgValue = DomainConstants.EMPTY_STRING;

		for( int j=0; j < arMOLArgs.length; j++ )
		{
			if("Group".equalsIgnoreCase(arMOLArgs[j]))
			{
				sArgValue = objMOL.getGroup();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}
			else if("TaskType".equalsIgnoreCase(arMOLArgs[j]))
			{
				sArgValue = objMOL.getTaskType();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}
			else if("GroupCounter".equalsIgnoreCase(arMOLArgs[j]))
			{
				sArgValue = objMOL.getGroupCounter();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}
			else if("SAPChangeNumber".equalsIgnoreCase(arMOLArgs[j]))
			{
				sArgValue = objMOL.getSAPChangeNumber();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}
			else if("TimeStamp".equalsIgnoreCase(arMOLArgs[j]))
			{
				sArgValue = objMOL.getSAPTimeStamp();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}
			else if("BadgeId".equalsIgnoreCase(arMOLArgs[j]))
			{
				sArgValue = objMOL.getBadgeId();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}
			else if("Location".equalsIgnoreCase(arMOLArgs[j]))
			{
				sArgValue = objMOL.getLocation();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}else
			{
				throw new Exception("Unexpected mandatory MOL property value '"+arMOLArgs[j]+"'");
			}

		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::checkMOLArgs()");
		return bCheckResult;
	}

	private static boolean checkMOSArgs(String[] arMOSArgs, PWCIPPMfgOperation objMOS)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::checkMOSArgs()");

		boolean bCheckResult = true;
		String sArgValue = DomainConstants.EMPTY_STRING;
		for( int j=0; j < arMOSArgs.length; j++ )
		{
			if("DRFName".equalsIgnoreCase(arMOSArgs[j]))
			{
				sArgValue = objMOS.getDRFName();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}
			else if("DRFVersion".equalsIgnoreCase(arMOSArgs[j]))
			{
				sArgValue = objMOS.getDRFVersion();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}else if("processingOption".equalsIgnoreCase(arMOSArgs[j]))
			{
				sArgValue = objMOS.getProcessingOption();
				if (UIUtil.isNullOrEmpty(sArgValue)) 
				{
					bCheckResult = false;
					break;
				}
			}else
			{
				throw new Exception("Unexpected mandatory MfgOp property value '"+arMOSArgs[j]+"'");
			}
		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::checkMOSArgs()");
		return bCheckResult;
	}

	/**
	 * This API is used to generate stack trace along with an appropriate custom error message
	 * 
	 * @param e - java exception object with default stack trace and message
	 * @return - String representation of the Custom message and the stack trace
	 */
	public static String getStackTrace(Exception e)
	{
		StringWriter stringWriter = new StringWriter();
		PrintWriter printWriter = new PrintWriter(stringWriter, true);
		e.printStackTrace(printWriter);

		return stringWriter.toString();

		/*StringBuilder sbSTrace = new StringBuilder(e.toString());
		StackTraceElement[] stStrace = e.getStackTrace();
		for (int i = 0; i < stStrace.length; i++) 
		{
			sbSTrace.append("\n\t").append(stStrace[i].toString());
		}
		return sbSTrace.toString();*/
	}
	
	
	/**
	 * Returns map for operation when XML string is passed
	 * This method has been modified for IPP_M3_006
	 * 
	 * @param sXMLString - XML in string format
	 * @return MapList - list of maps of operations in XML string
	 * @throws Exception 
	 */
	public static MapList getOperationMapFromXMLString(String sXMLString) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::getOperationMapFromXMLString()");

		MapList mlOpList = new MapList();

		Document doc = getDOMObjectFromXMLString(sXMLString);
		if(doc != null)
		{
			doc.getDocumentElement().normalize();
		}
		//Get the Operation Name, revision & Result if exist.
		NodeList nlTemp = doc.getElementsByTagName("Operation");
		if(nlTemp != null && nlTemp.getLength() > 0)
		{
			Element elOp = null;
			String sOperationName = DomainConstants.EMPTY_STRING;
			String sOperationRev = DomainConstants.EMPTY_STRING;
			String sOperationValidateState = DomainConstants.EMPTY_STRING;
			
			String sValidateCATPart = DomainConstants.EMPTY_STRING;
			String sValidateCATProduct = DomainConstants.EMPTY_STRING;
			String sValidateCATDrawing = DomainConstants.EMPTY_STRING;
			
			Map<String,String> mOpInfo = null;
			int iAttrElementsSize = nlTemp.getLength();
			for(int iTemp =0; iTemp<iAttrElementsSize; iTemp++)
			{
				elOp = (Element)nlTemp.item(iTemp);			
				sOperationName = (String)elOp.getAttribute("name");
				sOperationRev = (String)elOp.getAttribute("revision");
				sOperationValidateState = (String)elOp.getAttribute("validatestate");
				
				sValidateCATPart = (String)elOp.getAttribute("CATPart");
				sValidateCATProduct = (String)elOp.getAttribute("CATProduct");
				sValidateCATDrawing = (String)elOp.getAttribute("CATDrawing");
				
				String sOperationResult = (String)elOp.getAttribute("result");
				mOpInfo = new HashMap();
				mOpInfo.put("Name", sOperationName);
				mOpInfo.put("Revision", sOperationRev);
				mOpInfo.put("ValidateState", sOperationValidateState);

				if(!UIUtil.isNullOrEmpty(sValidateCATPart))
					mOpInfo.put("CATPart", sValidateCATPart);
				if(!UIUtil.isNullOrEmpty(sValidateCATProduct))
					mOpInfo.put("CATProduct", sValidateCATProduct);
				if(!UIUtil.isNullOrEmpty(sValidateCATDrawing))
					mOpInfo.put("CATDrawing", sValidateCATDrawing);

				if(!UIUtil.isNullOrEmpty(sOperationResult))
					mOpInfo.put("Result", sOperationResult);

				mlOpList.add(mOpInfo);
			}
		}
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::getOperationMapFromXMLString()");
		return mlOpList;
	}
	
	
	/**
	 * This API is used to generate DOM object when XML string is passed
	 * 
	 * @param sInputXML - XML string
	 * @return - Document representing DOM object for above XML string
	 */
	public static Document getDOMObjectFromXMLString(String sInputXML) throws ParserConfigurationException, SAXException, IOException
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::getDOMObjectFromXMLString()");
		
		Document doc = null;
		DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
		if(!UIUtil.isNullOrEmpty(sInputXML))
		{
			doc = docBuilder.parse(new InputSource(new StringReader(sInputXML)));
		}
		else
		{
			doc = docBuilder.newDocument();
		}
		
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::getDOMObjectFromXMLString()");
		return doc;
	}

	/**
	 * This API returns the vault of the given person 
	 * 
	 * @param context
	 * @param sPersonName
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static String getPersonsVault(Context context, String sPersonName)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+" : getPersonsVault()");

		MapList mlAllRevisions = new MapList();
		String sVault = DomainConstants.EMPTY_STRING;
		try 
		{
			SelectList slResultSelects = new SelectList(2);
			slResultSelects.add("latest");
			slResultSelects.add(DomainObject.SELECT_VAULT);

			mlAllRevisions =  DomainObject.findObjects(context,
					DomainConstants.TYPE_PERSON,
					sPersonName,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					PWCCommonUtil.getVaultPattern(context),
					null,
					false,
					slResultSelects);
			
			String sLatest = DomainConstants.EMPTY_STRING;
			Map mp;
			for (int i = 0; i < mlAllRevisions.size(); i++) 
			{
				mp = (Map)mlAllRevisions.get(i);
				sLatest = (String)mp.get("latest");
				sVault = (String)mp.get("vault");
				if ("TRUE".equalsIgnoreCase(sLatest)) 
				{
					break;
				}
			}

		} catch (Exception e) 
		{
			throw new Exception(new StringBuilder("Faild to retrieve vault of person '"+sPersonName+"' due to below error :  \n\n").append(e).toString(), e);
		}
		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+" : getPersonsVault()");
		return sVault;
	}

	
}
