@javax.xml.bind.annotation.XmlSchema(namespace = "")
package com.sap.document.sap.soap.functions.mc_style;
