
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ZMosGetEngChgs.RfcExceptions.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ZMosGetEngChgs.RfcExceptions">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PlannrIsEmpty"/>
 *     &lt;enumeration value="EngineeringChangesTabEmpty"/>
 *     &lt;enumeration value="RoutingNotFound"/>
 *     &lt;enumeration value="PlnalIsEmpty"/>
 *     &lt;enumeration value="TypeIsEmpty"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ZMosGetEngChgs.RfcExceptions")
@XmlEnum
public enum ZMosGetEngChgsRfcExceptions {

    @XmlEnumValue("PlannrIsEmpty")
    PLANNR_IS_EMPTY("PlannrIsEmpty"),
    @XmlEnumValue("EngineeringChangesTabEmpty")
    ENGINEERING_CHANGES_TAB_EMPTY("EngineeringChangesTabEmpty"),
    @XmlEnumValue("RoutingNotFound")
    ROUTING_NOT_FOUND("RoutingNotFound"),
    @XmlEnumValue("PlnalIsEmpty")
    PLNAL_IS_EMPTY("PlnalIsEmpty"),
    @XmlEnumValue("TypeIsEmpty")
    TYPE_IS_EMPTY("TypeIsEmpty");
    private final String value;

    ZMosGetEngChgsRfcExceptions(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ZMosGetEngChgsRfcExceptions fromValue(String v) {
        for (ZMosGetEngChgsRfcExceptions c: ZMosGetEngChgsRfcExceptions.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
