package com.ds.pwc.ipp.save;

import java.util.LinkedList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.matrixone.apps.domain.DomainConstants;

@XmlRootElement(name="MfgOps")
@XmlSeeAlso(PWCIPPXMLOperation.class)
public class PWCIPPXMLMfgOps
{
	private List<PWCIPPXMLOperation> m_Operations;
	
	public PWCIPPXMLMfgOps()
	{
		m_Operations = new LinkedList<PWCIPPXMLOperation>();
	}
	
	@XmlElement(name="Operation")
	public List<PWCIPPXMLOperation> getOperations()
	{
		return m_Operations;
	}

	public void setOperations( List<PWCIPPXMLOperation> iOperations )
	{
		m_Operations = iOperations;
	}

	public void validate()
	{
		if( null == m_Operations )
		{
			throw new IllegalArgumentException( "invalid MfgOps definition - no operations defined" );
		}
		
		for( PWCIPPXMLOperation operation : m_Operations )
		{
			operation.validate();
		}
	}
}
