
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Zmippsec complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Zmippsec">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Mandt" type="{urn:sap-com:document:sap:rfc:functions}clnt3"/>
 *         &lt;element name="Matnr" type="{urn:sap-com:document:sap:rfc:functions}char18"/>
 *         &lt;element name="Aennr" type="{urn:sap-com:document:sap:rfc:functions}char12"/>
 *         &lt;element name="Revlv" type="{urn:sap-com:document:sap:rfc:functions}char2"/>
 *         &lt;element name="Aetxt" type="{urn:sap-com:document:sap:rfc:functions}char40"/>
 *         &lt;element name="Datuv" type="{urn:sap-com:document:sap:rfc:functions}date10"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Zmippsec", propOrder = {
    "mandt",
    "matnr",
    "aennr",
    "revlv",
    "aetxt",
    "datuv"
})
public class Zmippsec {

    @XmlElement(name = "Mandt", required = true)
    protected String mandt;
    @XmlElement(name = "Matnr", required = true)
    protected String matnr;
    @XmlElement(name = "Aennr", required = true)
    protected String aennr;
    @XmlElement(name = "Revlv", required = true)
    protected String revlv;
    @XmlElement(name = "Aetxt", required = true)
    protected String aetxt;
    @XmlElement(name = "Datuv", required = true)
    protected String datuv;

    /**
     * Gets the value of the mandt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMandt() {
        return mandt;
    }

    /**
     * Sets the value of the mandt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMandt(String value) {
        this.mandt = value;
    }

    /**
     * Gets the value of the matnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMatnr() {
        return matnr;
    }

    /**
     * Sets the value of the matnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMatnr(String value) {
        this.matnr = value;
    }

    /**
     * Gets the value of the aennr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAennr() {
        return aennr;
    }

    /**
     * Sets the value of the aennr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAennr(String value) {
        this.aennr = value;
    }

    /**
     * Gets the value of the revlv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevlv() {
        return revlv;
    }

    /**
     * Sets the value of the revlv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevlv(String value) {
        this.revlv = value;
    }

    /**
     * Gets the value of the aetxt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAetxt() {
        return aetxt;
    }

    /**
     * Sets the value of the aetxt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAetxt(String value) {
        this.aetxt = value;
    }

    /**
     * Gets the value of the datuv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDatuv() {
        return datuv;
    }

    /**
     * Sets the value of the datuv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDatuv(String value) {
        this.datuv = value;
    }

}
