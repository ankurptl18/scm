package com.ds.pwc.ipp.ws;

import com.matrixone.apps.domain.DomainConstants;

/**
 * @author ZWE
 *
 */
public class PWCIPPWSException extends Exception 
{
	private String sExceptionId = DomainConstants.EMPTY_STRING;
	private String sExceptionMsg = DomainConstants.EMPTY_STRING;

	public PWCIPPWSException(Exception e)
	{
		super(e);
	}

	public String getsExceptionId() 
	{
		return sExceptionId;
	}

	public void setsExceptionId(String sExceptionId) 
	{
		this.sExceptionId = sExceptionId;
	}

	public String getsExceptionMsg() 
	{
		return sExceptionMsg;
	}

	public void setsExceptionMsg(String sExceptionMsg) 
	{
		this.sExceptionMsg = sExceptionMsg;
	}


}
