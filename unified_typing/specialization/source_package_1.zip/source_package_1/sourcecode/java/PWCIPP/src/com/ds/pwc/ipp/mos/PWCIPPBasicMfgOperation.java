package com.ds.pwc.ipp.mos;

import java.util.HashMap;
import java.util.Map;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.Context;
import matrix.db.FileList;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;

import org.apache.log4j.Logger;

import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.exportcontrol.ExportControlConstants;
import com.matrixone.apps.library.LibraryCentralConstants;

public class PWCIPPBasicMfgOperation 
{

	private DomainObject domObj = null;
	private static final Logger _LOGGER  = Logger.getLogger(PWCIPPBasicMfgOperation.class.getName());

	protected Context CONTEXT;

	protected String sObjectId = DomainConstants.EMPTY_STRING;
	protected String _sDRFNAME = DomainConstants.EMPTY_STRING;
	protected String _sDRFVersion = DomainConstants.EMPTY_STRING;


	@SuppressWarnings("static-access")
	public void putContext(Context context)
	{
		this.CONTEXT = context;
	}

	public String readObjectId()
	{
		return sObjectId;
	}

	public void putObjectId(String OBJECTID)
	{
		sObjectId = OBJECTID;
	}

	public String getDRFName() 
	{
		return _sDRFNAME;
	}

	public void setDRFName(String _sDRFNAME) 
	{
		this._sDRFNAME = _sDRFNAME;
	}


	public String getDRFVersion() 
	{
		return _sDRFVersion;
	}

	public void setDRFVersion(String _sDRFVersion) 
	{
		this._sDRFVersion = _sDRFVersion;
	}


	/**
	 * This checks if Object already exists
	 * @return
	 * @throws Exception
	 */
	public boolean checkIfExists() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":checkIfExists()");

		boolean bDoesObjectExists = false;
		try 
		{
			BusinessObject busObject = new BusinessObject(PWCConstants.TYPE_MOS_PART, _sDRFNAME, _sDRFVersion, PWCCommonUtil.getVaultPattern(CONTEXT)); 
			if(busObject.exists(CONTEXT)) 
			{
				bDoesObjectExists = true;
				busObject.open(CONTEXT);
				sObjectId= busObject.getObjectId(CONTEXT);
				busObject.close(CONTEXT);
			}

		} catch (Exception e) 
		{
			throw new Exception(new StringBuilder("Faild to check if operation '"+_sDRFNAME+"' already exists due to below error :  \n\n").append(e).toString(), e);
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":checkIfExists()");
		return bDoesObjectExists;
	}

	/**
	 * This is to promote Object to next State
	 * @return
	 * @throws Exception
	 */
	public String promote() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":promote()");
		String sCurrentState = DomainConstants.EMPTY_STRING;
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			domObj.promote(CONTEXT);
			sCurrentState = domObj.getInfo(CONTEXT, DomainConstants.SELECT_CURRENT);
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":promote()");
		return sCurrentState;
	}


	/**
	 * This API checks if there is/are any CAD attached to 'this' operation
	 * ( (checks if any objects are connected with relationship 'Part Specification') )
	 * If yes, then it checks if all of them are released of not
	 * 
	 * @return - boolean[2], first boolean = is there any cad attached?, second boolean = are all the attached CADs released?
	 * @throws Exception, if operation fails
	 */
	public boolean[] checkIfCADAttachedAndReleased() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":isCADAttached()");

		//first boolean = is there any cad attached?, second boolean = are all the attached CADs released?
		boolean[] arr_bResult = new boolean[]{false, true};

		domObj = new DomainObject( this.readObjectId());

		StringList slSelectList = new StringList(2);
		slSelectList.addElement(DomainObject.SELECT_ID);
		slSelectList.addElement(DomainObject.SELECT_CURRENT);

		StringBuffer sbWhere = new StringBuffer();
		sbWhere.append(DomainObject.SELECT_POLICY)
		.append(" == \"")
		.append( PWCConstants.POLICY_PWC_MOS_CAD)
		.append("\"");
		MapList mlMapList = domObj.getRelatedObjects(CONTEXT, 
				DomainObject.RELATIONSHIP_PART_SPECIFICATION, // relationship pattern
				DomainObject.QUERY_WILDCARD, // object type pattern
				slSelectList, // object selects
				null, // relationship selects
				false, // to direction
				true, // from direction
				(short) 0, // recursion level
				sbWhere.toString(), // object where clause
				null, // relationship where clause 
				(int)0);     

		if ( !mlMapList.isEmpty() )
		{
			arr_bResult[0] = true; // there is cad attached

			// now we want to check if all the cad attached are released
			for(int i = 0; i < mlMapList.size(); i++)
			{
				Map map_anItem = (Map) mlMapList.get(i);
				String str_anItemState = (String) map_anItem.get(DomainObject.SELECT_CURRENT);
				if( !PWCConstants.STATE_POLICY_PWC_MOS_CAD_RELEASE.equalsIgnoreCase(str_anItemState) )
				{
					// not all the cads attached are released
					arr_bResult[1] = false;
					break;
				}
			}
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":isCADAttached()");

		return arr_bResult ;
	}

	/**
	 * This API checks if current object is in Release state or not.
	 * 
	 * @return - true, if it is in Release state, else return false.
	 * @throws Exception, if operation fails
	 */
	public boolean checkIfInReleaseState() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":isInReleaseState()");
		boolean bIsReleaseState = false;

		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			String sCurrentState = domObj.getInfo(CONTEXT, DomainConstants.SELECT_CURRENT);			

			if(PWCConstants.STATE_POLICY_MOS_PART_RELEASE.equalsIgnoreCase( sCurrentState ) )
				bIsReleaseState = true;						
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":isInReleaseState()");

		return bIsReleaseState;
	}

	/**
	 * retrieveRefDocList : Returns IPP PDF Documnet list is Operation is in release state
	 * @return
	 * @throws Exception
	 */
	public StringList retrieveRefDocList() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":retrieveRefDocList()");

		StringList slRefDocs = new StringList();
		StringBuffer sbWhereSelectRefDoc = new StringBuffer("from[");
		sbWhereSelectRefDoc.append(DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT)
		.append("|to.type==\"")
		.append(PWCConstants.TYPE_DERIVED_OUTPUT)
		.append("\"].to.id");

		StringBuffer sbSelectDataList = new StringBuffer("from[");
		sbSelectDataList.append(DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT)
		.append("].to.id");
		StringList slSelectables = new StringList(sbWhereSelectRefDoc.toString());
		BusinessObjectWithSelectList bowsSpecificationDetailsList = BusinessObject.getSelectBusinessObjectData(CONTEXT,new String[]{sObjectId},slSelectables);

		if(null!=bowsSpecificationDetailsList && !bowsSpecificationDetailsList.isEmpty())
		{	
			BusinessObjectWithSelect bowsRequirement = (BusinessObjectWithSelect)bowsSpecificationDetailsList.getElement(0);
			slRefDocs	= bowsRequirement.getSelectDataList(sbSelectDataList.toString());
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":retrieveRefDocList()");
		return slRefDocs;
	}

	/**
	 * hasAccess :: Checks if object has access
	 * @param doObj 
	 * @param sAccess
	 * @return
	 * @throws Exception
	 */
	public boolean hasAccess(DomainObject doObj, String sAccess) throws Exception
	{
		boolean bAccess  = (new Boolean((String) doObj.getInfo(CONTEXT, sAccess))).booleanValue();		
		return bAccess;
	}

	/**
	 * @param alDataHandlerList
	 * @param sTempDir
	 * @param flFiles
	 */
	private void loadFileDataHandler(HashMap<String,DataHandler> fileMap, String sTempDir, FileList flFiles)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":loadFileDataHandler()");

		StringBuilder 	sbFileSource 	= new StringBuilder();
		DataHandler 	dhObj 			= null;
		matrix.db.File 	fTemp 			= null;
		FileDataSource 	fds = null;
		if(null != flFiles && flFiles.size()>0)
		{	
			int iFileListSize = flFiles.size();
			for(int index1 = 0; index1 < iFileListSize; index1++)
			{	
				fTemp = (matrix.db.File)flFiles.get(index1);
				String sFileName = fTemp.getName();
				sbFileSource.setLength(0);
				sbFileSource.append(sTempDir).append(System.getProperty("file.separator")).append(fTemp.getName());
				fds = new FileDataSource(sbFileSource.toString());
				dhObj = new DataHandler(fds);
				fileMap.put(sFileName, dhObj);
			}
		}		

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":loadFileDataHandler()");
	}

	/**
	 * This method extract attached files to Document objects. 
	 * @param Context and slRefDocs
	 * @return ArrayList of dataHandler objects.
	 * @throws Exception
	 */
	private void extractAttachedFiles(Context context, StringList slRefDocs, HashMap<String,DataHandler> fileMap, String sFormat)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":extractAttachedFiles()");

		try 
		{
			String 			sDocId 			= DomainObject.EMPTY_STRING;
			String 			sTempDir        = context.getWorkspacePath();
			FileList 		flFiles			= null;   			
			domObj 			= DomainObject.newInstance(CONTEXT);  		
			int 			iRefDocsSize 	= slRefDocs.size();
			boolean bCheckoutAccess = false;
			for (int index = 0; index < iRefDocsSize; index++)
			{   
				sDocId = (String) slRefDocs.get(index);				
				domObj.setId(sDocId);
				bCheckoutAccess = hasAccess(domObj, CommonDocument.SELECT_HAS_CHECKOUT_ACCESS);

				if (bCheckoutAccess)
				{
					flFiles = domObj.getFiles(CONTEXT, sFormat);
					if (flFiles.size()>0)
					{
						try
						{				
							domObj.checkoutFiles(CONTEXT, false, sFormat, flFiles, sTempDir);
						} 
						catch (MatrixException me)
						{
							throw new MatrixException("Faild to access attached Files "+me.getMessage());
						}
						loadFileDataHandler(fileMap, sTempDir, flFiles);
					}
				}
				else
					throw new MatrixException("Access Denied - No checkout access for user "+CONTEXT.getUser());
			}
		} 
		catch (Exception e) 
		{			
			throw e;
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":extractAttachedFiles()");
	}

	/**
	 * This API checkout connected file.
	 * bIsInRelease : Operation is in release state boolean value
	 * @return - ArrayList of DataHandler Object which contains .
	 * @throws Exception, if operation fails
	 */
	public HashMap<String,DataHandler> checkOutAttachedFile(boolean bIsInRelease) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":isInReleaseState()");

		HashMap<String,DataHandler> fileMap = new HashMap<String,DataHandler>();

		StringList slRefDocs = new StringList();
		String sFormat = EnoviaResourceBundle.getProperty(CONTEXT, "emxDocumentCentralStringResource", CONTEXT.getLocale(), "emxDocumentCentral.Format.PDF");

		if (bIsInRelease)
		{
			slRefDocs = retrieveRefDocList();
		}
		else
		{
			slRefDocs = retrieveDerOutList();
		}
		if(null != slRefDocs && !slRefDocs.isEmpty())
		{	
			extractAttachedFiles(CONTEXT, slRefDocs, fileMap, sFormat);
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":isInReleaseState()");
		return fileMap;
	}

	/**
	 * retrieveDerOutList : Returns Derived Output list is Operation is not in release state
	 * modified for BT0000000004129
	 * @return
	 * @throws Exception
	 */
	public StringList retrieveDerOutList() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":retrieveDerOutList()");

		StringBuffer sbWhereSelectRelDerOut = new StringBuffer();

		StringList slCATDrawingStates = new StringList();

		sbWhereSelectRelDerOut.append("from[")
		.append(DomainConstants.RELATIONSHIP_PART_SPECIFICATION)
		.append("|to.type==\"")
		.append(PWCConstants.TYPE_CATDRAWING)
		.append("\"].to.current");

		StringBuffer sbSelectDataList = new StringBuffer("from[");
		sbSelectDataList.append(DomainConstants.RELATIONSHIP_PART_SPECIFICATION)
		.append("].to.current");

		StringList slSelectables = new StringList(sbWhereSelectRelDerOut.toString());
		BusinessObjectWithSelectList bowsSpecificationDetailsList = BusinessObject.getSelectBusinessObjectData(CONTEXT, new String[]{sObjectId},slSelectables);

		if(null!=bowsSpecificationDetailsList && !bowsSpecificationDetailsList.isEmpty())
		{	
			BusinessObjectWithSelect bowsRequirement = (BusinessObjectWithSelect)bowsSpecificationDetailsList.getElement(0);
			slCATDrawingStates	= bowsRequirement.getSelectDataList(sbSelectDataList.toString());
		}

		StringList slRefDocs = new StringList();
		// added below 'if' condition as a fix for #BT0000000004434
		// the value of 'slCATDrawingStates' can be null in case there is no CATDrasing connected to the given MfgOp
		if( null != slCATDrawingStates && slCATDrawingStates.size() > 0 )
		{
			String sDrawingState = (String)slCATDrawingStates.get(0);

			// if the CATDrawing is released then take the PDF from major else from minor
			if ( "Release".equalsIgnoreCase(sDrawingState) ) 
			{
				sbWhereSelectRelDerOut = new StringBuffer();

				sbWhereSelectRelDerOut.append("from[")
				.append(DomainConstants.RELATIONSHIP_PART_SPECIFICATION)
				.append("].to.from[")
				.append(PWCConstants.REL_DERIVED_OUTPUT)
				.append("].to.id");

				slRefDocs = domObj.getInfoList(CONTEXT, sbWhereSelectRelDerOut.toString());

			}else
			{
				sbWhereSelectRelDerOut.delete(0, sbWhereSelectRelDerOut.length());

				sbWhereSelectRelDerOut.append("from[")
				.append(DomainConstants.RELATIONSHIP_PART_SPECIFICATION)
				.append("].to.")
				.append("from[")
				.append(CommonDocument.RELATIONSHIP_ACTIVE_VERSION)
				.append("].to.from[")
				.append(PWCConstants.REL_DERIVED_OUTPUT)
				.append("].to.id");
				slRefDocs = domObj.getInfoList(CONTEXT, sbWhereSelectRelDerOut.toString());
			}
		}


		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":retrieveDerOutList()");

		return slRefDocs;
	}


	/**
	 * This API gives the classificatin information of the operation
	 * 
	 * @return - Maplist containing maps of information of each class connected to operation 
	 * @throws Exception
	 */
	public MapList readAssociatedClassifications() throws Exception 
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":readAssociatedClassifications()");

		domObj = DomainObject.newInstance(CONTEXT, sObjectId);

		SelectList slSelectStmts      = new SelectList(3);
		slSelectStmts.addElement(DomainConstants.SELECT_ID);
		slSelectStmts.addElement(DomainConstants.SELECT_TYPE);
		slSelectStmts.addElement(DomainConstants.SELECT_NAME);
		slSelectStmts.addElement(DomainConstants.SELECT_REVISION);

		StringBuilder sbObjWhere = new StringBuilder();
		//sbObjWhere.append(DomainConstants.SELECT_TYPE).append("==").append(ExportControlConstants.TYPE_EXPORT_CONTROL_CLASS);

		MapList mlAssociatedClasses   = (MapList)domObj.getRelatedObjects(CONTEXT,
				LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,  // relationship pattern
				ExportControlConstants.TYPE_EXPORT_CONTROL_CLASS,         // type pattern
				slSelectStmts,        	// Object selects
				null,               	// relationship selects
				true,               	// to
				false,              	// from
				(short)1,           	// expand level
				sbObjWhere.toString(),  // object where
				null,               	// relationship where
				0);                 	// limit

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":readAssociatedClassifications()");

		return mlAssociatedClasses;
	}
}
