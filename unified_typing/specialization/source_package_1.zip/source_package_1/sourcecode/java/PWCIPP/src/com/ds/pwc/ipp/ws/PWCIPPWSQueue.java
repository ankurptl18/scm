package com.ds.pwc.ipp.ws;

import java.util.HashMap;
import java.util.Map;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.FileList;
import matrix.util.StringList;

import org.apache.log4j.Logger;

import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.framework.ui.UIUtil;


/**
 * This class represents the Queue object from the database. It hosts all the operations related to this object and holds its current state.
 * 
 * @author ZWE
 *
 */
public class PWCIPPWSQueue
{
	private static final Logger _LOGGER  = Logger.getLogger(PWCIPPWSQueue.class.getName());

	private static Context CONTEXT;

	private String sObjId 			= DomainConstants.EMPTY_STRING;
	private DomainObject domObj 	= null;

	private String 	_sSUI 			= DomainConstants.EMPTY_STRING;
	private boolean _bIsDirty 		= false;
	private String 	_sName			= DomainConstants.EMPTY_STRING;
	private String 	_sRev			= DomainConstants.EMPTY_STRING;
	private String 	_sDescription	= DomainConstants.EMPTY_STRING;


	public PWCIPPWSQueue()
	{

	}

	@SuppressWarnings("rawtypes")
	public PWCIPPWSQueue(Context context, String[] arQueueInfo) 
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+":: constructor");

		PWCIPPWSQueue.CONTEXT = context;
		this._sName = arQueueInfo[0];
		this._sRev = arQueueInfo[1];

		if(!UIUtil.isNullOrEmpty(_sName) && !UIUtil.isNullOrEmpty(_sRev) && arQueueInfo.length > 2) 
		{
			_sSUI = arQueueInfo[2];
			sObjId = arQueueInfo[3];
			String sDirtyFlagVal = arQueueInfo[4];

			if("true".equalsIgnoreCase(sDirtyFlagVal))
			{
				_bIsDirty = true;
			}
		} 
		_LOGGER.debug("End of "+PWCIPPWSQueue.class.getName()+":: constructor");
	}

	/************************************************ accessors and mutators ******************************************/

	public String getObjId() 
	{
		return sObjId;
	}

	public void setObjId(String oBJECT_ID) 
	{
		sObjId = oBJECT_ID;
	}

	public String getName() 
	{
		return _sName;
	}

	public void setName(String _sName) 
	{
		this._sName = _sName;
	}

	public String getSUI() 
	{
		return _sSUI;
	}

	public void setSUI(String _sSUI) 
	{
		this._sSUI = _sSUI;
	}

	public boolean isDirty() 
	{
		return _bIsDirty;
	}

	public void markDirty(boolean _bIsDirty) 
	{
		this._bIsDirty = _bIsDirty;
	}

	/****************************************************** operations ************************************************/	

	/**
	 * This API creates the object of type 'PWC_MOSWS Queue' in database (name=Group_TaskType_GroupCounter, revision=SAPChange#) 
	 * 
	 * @return - objectId, of the created Queue
	 * @throws Exception, if operation fails
	 */
	public String create() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+" :: create()");
		try 
		{
			if(!checkIfExists())
			{
				BusinessObject bObjQueue = new BusinessObject(PWCConstants.TYPE_PWC_IPPWSQUEUE,_sName,_sRev,CONTEXT.getVault().getName());
				bObjQueue.create(CONTEXT,PWCConstants.POLICY_PWC_IPPWSQUEUE);
				sObjId= bObjQueue.getObjectId(CONTEXT);
				update(DomainObject.newInstance(CONTEXT,sObjId));
				ContextUtil.commitTransaction(CONTEXT);
			}
		} 
		catch (Exception e) 
		{
			_LOGGER.error("Failed to create the queue '"+_sName+"'");
			throw e;
		}

		_LOGGER.debug("End of "+PWCIPPWSQueue.class.getName()+" :: create()");
		return sObjId;
	}

	public void delete() throws Exception 
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+" :: delete()");
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjId);
			domObj.deleteObject(CONTEXT);
		}
		_LOGGER.debug("End of "+PWCIPPWSQueue.class.getName()+" :: delete()");
	}

	public String promote() throws Exception 
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+" :: promote()");
		String sCurrentState = DomainConstants.EMPTY_STRING;
		if(checkIfExists())
		{
			domObj=DomainObject.newInstance(CONTEXT, sObjId);
			domObj.promote(CONTEXT);
			sCurrentState = domObj.getInfo(CONTEXT, DomainConstants.SELECT_CURRENT);
		}
		_LOGGER.debug("End of "+PWCIPPWSQueue.class.getName()+" :: promote()");
		return sCurrentState;
	}

	public String demote() throws Exception 
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+" :: demote()");
		String sCurrentState = DomainConstants.EMPTY_STRING;
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjId);
			domObj.demote(CONTEXT);
			sCurrentState = domObj.getInfo(CONTEXT, DomainConstants.SELECT_CURRENT);
		}
		_LOGGER.debug("End of "+PWCIPPWSQueue.class.getName()+" :: demote()");
		return sCurrentState;
	}

	/**
	 * This API checks if given object (name=Group_TaskType_GroupCounter, revision=SAPChange#) exists in the database
	 * 
	 * @return - true, if it does else false
	 * @throws Exception, if operation fails
	 */
	public boolean checkIfExists() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+" :: checkIfExists()");

		boolean doesObjectExists = false;
		try 
		{
			BusinessObject busObject = new BusinessObject(PWCConstants.TYPE_PWC_IPPWSQUEUE, _sName, _sRev, PWCCommonUtil.getVaultPattern(CONTEXT)); 
			if(busObject.exists(CONTEXT)) 
			{
				doesObjectExists = true;
				busObject.open(CONTEXT);
				sObjId= busObject.getObjectId(CONTEXT);
				busObject.close(CONTEXT);
			}

		} catch (Exception e) 
		{
			_LOGGER.error("Failed to check if the queue with name '"+_sName+"' already exists");
			throw e;
		}

		_LOGGER.debug("End of "+PWCIPPWSQueue.class.getName()+" :: checkIfExists()");
		return doesObjectExists;
	}

	/**
	 * This API checks if this Queue object has an empty place holder file of Web service call message 
	 * 
	 * @return - true, if it has else false
	 * @throws Exception - if operation fails
	 */
	public boolean checkForEmptyFile() throws Exception
	{
		boolean bHasEmptyFile = false;

		CommonDocument cdQueue = new CommonDocument(sObjId);
		FileList flFiles 	   = cdQueue.getFiles(CONTEXT);

		String sFileName = DomainConstants.EMPTY_STRING;
		matrix.db.File fTemp;

		for(int i=0; i < flFiles.size(); i++)
		{
			fTemp = (matrix.db.File)flFiles.get(i);
			sFileName = fTemp.getName();

			bHasEmptyFile = sFileName.contains("empty_");
			if (bHasEmptyFile) 
			{
				break;
			}
		}

		return bHasEmptyFile;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String loadFromDB() throws Exception
	{
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjId);			
			String sDIRTYFLAG_SELECTABLE = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_QUEUE_DIRTY_FLAG).append("]").toString();
			StringList slSelectList = new StringList();
			slSelectList.add(sDIRTYFLAG_SELECTABLE);			
			Map mQueueDataMap = domObj.getInfo(CONTEXT, slSelectList);
			String sCheckDirty = (String)mQueueDataMap.get(sDIRTYFLAG_SELECTABLE);			
			_bIsDirty = Boolean.valueOf(sCheckDirty);
		}
		return sObjId;
	}

	/*public PWCIPPMfgOperationList getWSMessage() throws MatrixException, ParserConfigurationException
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+" :: getWSMessage()");

		String sPriorityMsg = sortWSMsgFiles();
		domObj = DomainObject.newInstance(CONTEXT, sObjId);
		domObj.checkoutFile(CONTEXT, true, "", "", "");

		DocumentBuilderFactory dFact = DocumentBuilderFactory.newInstance();
		DocumentBuilder build = dFact.newDocumentBuilder();
		Document xmlDoc = build.newDocument();

		_LOGGER.debug("End of "+PWCIPPWSQueue.class.getName()+" :: getWSMessage()");
		return loadXMLMessage(xmlDoc);
	}

	private String sortWSMsgFiles()
	{

		return "fileName";
	}

	private PWCIPPMfgOperationList loadXMLMessage(Document xmlDoc)
	{

		return new PWCIPPMfgOperationList();
	}*/


	/*	public void updateForFailure()
	{

	}*/

	/**
	 * This API overrides all the properties/attributes of 'this' object on 
	 * the corresponding 'PWC_IPPWSQueue' object in DB
	 * 
	 * @throws Exception, if operation fails
	 */
	public void update() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+" :: update()");

		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjId);
			update(domObj);
		}
		_LOGGER.debug("End of "+PWCIPPWSQueue.class.getName()+" :: update()");
	}

	@SuppressWarnings({ "unchecked"})
	public void update(DomainObject domObj) throws Exception
	{		
		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+" :: update() with queue object as parameter");

		domObj.setDescription(CONTEXT, _sDescription);
		Map mAttributeMap = new HashMap();
		mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_IPP_QUEUE_DIRTY_FLAG,Boolean.toString(_bIsDirty));
		mAttributeMap.put(PWCConstants.ATTRIBUTE_SERVER_UNIQUE_IDENTIFIER,_sSUI);
		domObj.setAttributeValues(CONTEXT, mAttributeMap);

		_LOGGER.debug("Start of "+PWCIPPWSQueue.class.getName()+" :: update() with queue object as parameter");
	}


}
