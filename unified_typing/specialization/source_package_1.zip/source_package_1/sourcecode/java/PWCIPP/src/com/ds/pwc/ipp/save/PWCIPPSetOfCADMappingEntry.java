package com.ds.pwc.ipp.save;

import java.util.AbstractSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import matrix.db.Context;

import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;

import matrix.util.MatrixException;
import com.matrixone.MCADIntegration.utils.MCADException;

public class PWCIPPSetOfCADMappingEntry extends AbstractSet<PWCIPPCADMappingEntry>
{
	private class WrappedIterator implements Iterator<PWCIPPCADMappingEntry>
	{
		private Iterator<PWCIPPCADMappingEntry> m_Master;
		private PWCIPPCADMappingEntry m_Current;
		
		private WrappedIterator( Iterator<PWCIPPCADMappingEntry> iMaster )
		{
			m_Master = iMaster;
			m_Current = null;
		}
		
		@Override
		public boolean hasNext()
		{
			return m_Master.hasNext();
		}
		
		@Override
		public PWCIPPCADMappingEntry next()
		{
			m_Current = m_Master.next();
			return m_Current;
		}
		
		@Override
		public void remove()
		{
			m_BySrcMajorID.remove( m_Current.getSource().getMajorID() );
			m_BySrcMinorID.remove( m_Current.getSource().getMinorID() );
			m_Master.remove();
			m_Current = null;
		}
	}
	
	private final List<PWCIPPCADMappingEntry> m_ForIterator;
	
	private final Map<String,PWCIPPCADMappingEntry> m_BySrcMajorID;
	private final Map<String,PWCIPPCADMappingEntry> m_BySrcMinorID;
	
	public PWCIPPSetOfCADMappingEntry()
	{
		m_ForIterator  = new LinkedList<PWCIPPCADMappingEntry>();
		m_BySrcMajorID = new HashMap<String,PWCIPPCADMappingEntry>();
		m_BySrcMinorID = new HashMap<String,PWCIPPCADMappingEntry>();
	}

	public PWCIPPSetOfCADMappingEntry( int iInitialCapacity )
	{
		m_ForIterator  = new LinkedList<PWCIPPCADMappingEntry>();
		m_BySrcMajorID = new HashMap<String,PWCIPPCADMappingEntry>( iInitialCapacity );
		m_BySrcMinorID = new HashMap<String,PWCIPPCADMappingEntry>( iInitialCapacity );
	}
	
	@Override
	public boolean add( PWCIPPCADMappingEntry iValue )
	{
		String st_majorID = iValue.getSource().getMajorID();
		String st_minorID = iValue.getSource().getMinorID();
		
		PWCIPPCADMappingEntry previousByMajor = m_BySrcMajorID.put( st_majorID , iValue );
		PWCIPPCADMappingEntry previousByMinor = m_BySrcMinorID.put( st_minorID , iValue );

		boolean b_modified = false;
		if( null == previousByMajor && null == previousByMinor )
		{
			m_ForIterator.add( iValue );
			b_modified = true;
		}
		else
		{
			if( null != previousByMajor ) { m_BySrcMajorID.put( st_majorID , previousByMajor ); }
			else { m_BySrcMajorID.remove( st_majorID ); }
			
			if( null != previousByMinor ) { m_BySrcMinorID.put( st_minorID , previousByMinor ); }
			else { m_BySrcMinorID.remove( st_minorID ); }
		}
		
		return b_modified;
	}
	
	@Override
	public Iterator<PWCIPPCADMappingEntry> iterator()
	{
		return new WrappedIterator( m_ForIterator.iterator() );
	}
	
	@Override
	public int size()
	{
		return m_ForIterator.size();
	}
	
	@Override
	public void clear()
	{
		m_ForIterator.clear();
		m_BySrcMajorID.clear();
		m_BySrcMinorID.clear();
	}
	
	public PWCIPPCADMappingEntry getBySourceMajorID( String iID )
	{
		return m_BySrcMajorID.get( iID );
	}

	public boolean containsSourceMajorID( String iID )
	{
		return m_BySrcMajorID.containsKey( iID );
	}

	public PWCIPPCADMappingEntry getBySourceMinorID( String iID )
	{
		return m_BySrcMinorID.get( iID );
	}

	public boolean containsSourceMinorID( String iID )
	{
		return m_BySrcMinorID.containsKey( iID );
	}

	public void loadTargetIDs( Context iContext , MCADMxUtil iMCADMxUtil )  throws MatrixException , MCADException
	{
		for( PWCIPPCADMappingEntry entry : m_ForIterator )
		{
			entry.loadTargetIDs( iContext , iMCADMxUtil );
		}
	}
}
