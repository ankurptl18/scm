package com.ds.pwc.ipp.report;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.matrixone.apps.domain.DomainConstants;

/**
 * @author ZWE
 *
 */
@XmlSeeAlso(PWCIPPMfgOpCADValidationResult.class)
public class PWCIPPMfgOpCADValidationResult 
{
	private String sResult = DomainConstants.EMPTY_STRING;
	private String sName = DomainConstants.EMPTY_STRING;
	private String sRev = DomainConstants.EMPTY_STRING;
	private List<PWCIPPCADObjectValidationResult> CADObjResultList = new ArrayList<PWCIPPCADObjectValidationResult>();

	@XmlAttribute(name="name")
	public String getsName() 
	{
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	
	@XmlAttribute(name="revision")
	public String getsRev() 
	{
		return sRev;
	}
	public void setsRev(String sRev) 
	{
		this.sRev = sRev;
	}
	
	@XmlAttribute(name="result")
	public String getsResult() 
	{
		return sResult;
	}
	public void setsResult(String sResult) 
	{
		this.sResult = sResult;
	}

	@XmlElement(name = "CAD")
	public List<PWCIPPCADObjectValidationResult> getCADObjResultList() 
	{
		return CADObjResultList;
	}
	public void setCADObjResultList(
			List<PWCIPPCADObjectValidationResult> cADObjResultList) 
	{
		CADObjResultList = cADObjResultList;
	}
	
	
	
}
