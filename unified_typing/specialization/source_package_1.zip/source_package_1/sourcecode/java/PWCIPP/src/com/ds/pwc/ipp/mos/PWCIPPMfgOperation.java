package com.ds.pwc.ipp.mos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.SelectList;
import matrix.util.StringList;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.ds.pwc.ipp.ws.PWCIPPWSUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.MessageUtil;

/**
 * This class represents the 'Manufacturing Operation' (MfgOp) object from the database. 
 * It hosts all the operation methods related to this object and holds its current state.
 * 
 * @author ZWE
 *
 */

public class PWCIPPMfgOperation extends PWCIPPBasicMfgOperation
{	
	private static final Logger _LOGGER  = Logger.getLogger(PWCIPPMfgOperation.class.getName());

	private static String ATTRIBUTE_DESIGN_PURCHASE = PropertyUtil.getSchemaProperty("attribute_DesignPurchase");
	private static String ATTRIBUTE_END_ITEM = PropertyUtil.getSchemaProperty("attribute_EndItemOverrideEnabled");

	private static StringBuilder SELECTABLE_ATTRIBUTE_PWC_IPP_OPERATION_NUMBER = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_OPERATION_NUMBER).append("]");
	private static StringBuilder SELECTABLE_ATTRIBUTE_PWC_IPP_ESA_FLAG = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_ESA_FLAG).append("]");
	private static StringBuilder SELECTABLE_ATTRIBUTE_PWC_MOS_SEQUENCE_OPERATION = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_MOS_SEQUENCE_OPERATION).append("]");
	private static StringBuilder SELECTABLE_ATTRIBUTE_DESIGN_PURCHASE = new StringBuilder().append("attribute[").append(ATTRIBUTE_DESIGN_PURCHASE).append("]");
	private static StringBuilder SELECTABLE_ATTRIBUTE_END_ITEM = new StringBuilder().append("attribute[").append(ATTRIBUTE_END_ITEM).append("]");

	private DomainObject domObj = null;

	private String sProcessingOption = DomainConstants.EMPTY_STRING;
	private String _sSequenceNumber = DomainConstants.EMPTY_STRING;
	private String _sOperationNo = DomainConstants.EMPTY_STRING;
	private String _sDescription = DomainConstants.EMPTY_STRING;
	private String _sESAFlag = DomainConstants.EMPTY_STRING;
	//private String _sLockStatus = DomainConstants.EMPTY_STRING;


	public PWCIPPMfgOperation()
	{

	}

	/**
	 * This constructor reads the passed in map and initialize all member variables accordingly
	 * 
	 * @param mpOpInfo - contains property/attribute information of 'this' MfgOp. It will have below keys
	 * 						1. DRFName* (this will be the actual NAME of an MfgOp)
	 * 						2. OperationNo*
	 *						3. SequenceNo*
	 *						4. ESAFlag
	 *						5. DRFVersion* (this will be the actual REVISION of an MfgOp)
	 * 						6. Description
	 */
	/*public PWCIPPMfgOperation(Context context, HashMap<String,String> mpOpInfo) 
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+" constructor with map object as parameter");
		PWCIPPMfgOperation.CONTEXT = context;
		_sDRFNAME		=(String)mpOpInfo.get("_sDRFNAME");
		_sDRFVersion	=(String)mpOpInfo.get("_sDRFVersion");
		if(!UIUtil.isNullOrEmpty(_sDRFNAME) && !UIUtil.isNullOrEmpty(_sDRFVersion))
		{
			loadAttrData(mpOpInfo);
	}
		else
	{
			System.out.println("Throw Erorr..............................");
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+" constructor with map object as parameter");
	}*/

	/**
	 * This constructor reads the passed in XML DOM and initialize all member variables accordingly
	 * 
	 */
	public PWCIPPMfgOperation(Context context, Document doc) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+" constructor with DOM Object object as parameter");

		doc.getDocumentElement().normalize();
		this.CONTEXT = context;
		Map<String,String> mAttr = new HashMap<String,String>();
		Element eleRoot = doc.getDocumentElement();
		_sDRFNAME		= (String)eleRoot.getAttribute("name");
		_sDRFVersion	= (String)eleRoot.getAttribute("revision");

		if(!UIUtil.isNullOrEmpty(_sDRFNAME) && !UIUtil.isNullOrEmpty(_sDRFVersion)) 
		{
			mAttr = PWCIPPWSUtil.buildMapFromXML(eleRoot);
			loadAttrData(mAttr);
		}
		else
		{
			throw new Exception("Failed to initialize the MfgOp object as either DRFName OR DRFVersion is null or empty");
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+" constructor with DOM Object object as parameter");
	}	

	public PWCIPPMfgOperation(Context context, Node nodeAttr) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+" constructor with DOM Object object as parameter");

		this.CONTEXT = context;
		Map<String,String> mAttr = new HashMap<String,String>();

		if(nodeAttr != null) 
		{
			_sDRFNAME		=(String)((Element)nodeAttr).getAttribute("name");
			_sDRFVersion	=(String)((Element)nodeAttr).getAttribute("revision");
			if(!UIUtil.isNullOrEmpty(_sDRFNAME) && !UIUtil.isNullOrEmpty(_sDRFVersion))
			{
				mAttr = PWCIPPWSUtil.buildMapFromXML(nodeAttr.getFirstChild());
				loadAttrData(mAttr);
			}
		}
		else
		{
			throw new Exception("Failed to initialize the MfgOp object as either DRFName OR DRFVersion is null or empty");
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+" constructor with DOM Object object as parameter");
	}	

	/****************************************************** operations ************************************************/	

	/**
	 * This API loads the attribute data of operation to bean
	 * 
	 */
	public void loadAttrData(Map<String,String> mpOpInfo)
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":loadAttrData()");
		if(mpOpInfo != null)
		{
			_sOperationNo		= (String)mpOpInfo.get("OperationNo");
			_sDescription		= (String)mpOpInfo.get("Description");
			_sSequenceNumber	= (String)mpOpInfo.get("SequenceNumber");
			_sESAFlag			= (String)mpOpInfo.get("ESAFlag");
			sProcessingOption	= (String)mpOpInfo.get("ProcessingOption");
			//_sLockStatus		= (String)mpOpInfo.get("LockStatus");
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":loadAttrData()");
	}

	@SuppressWarnings("unchecked")
	public Map buildAttributesMapForXML()
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":buildAttributesMapForXML()");
		Map<String,String> mReturn = new HashMap<String,String>();
		mReturn.put("OperationNo", _sOperationNo);
		mReturn.put("Description", _sDescription);
		mReturn.put("SequenceNumber", _sSequenceNumber);
		mReturn.put("ESAFlag", _sESAFlag);
		mReturn.put("ProcessingOption", sProcessingOption);
		//mReturn.put("LockStatus", _sLockStatus);
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":buildAttributesMapForXML()");
		return mReturn;
	}

	/**
	 * This API creates the object of type 'PWC_MOS Part' in database and 
	 * updates all the attribute values
	 * 
	 * @return - objectId, of the created MfgOp
	 * @throws Exception, if operation fails
	 */
	public String create(boolean bIsFromSAP) throws Exception
	{	
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":create()");
		if(!checkIfExists())
		{
			try 
			{
				/*Part part = (Part) DomainObject.newInstance(CONTEXT,DomainConstants.TYPE_PART, DomainConstants.ENGINEERING);
				sObjectId = part.createPart(CONTEXT, PWCConstants.TYPE_MOS_PART, _sDRFNAME,_sDRFVersion, PWCConstants.POLICY_MOS_PART, 
						PWCCommonUtil.getVaultPattern(CONTEXT), CONTEXT.getUser(),null, DomainConstants.EMPTY_STRING, "Not Selected");*/
				
				domObj = DomainObject.newInstance(CONTEXT);
				//sRevision = readRevision();
				domObj.createObject(CONTEXT, PWCConstants.TYPE_MOS_PART, _sDRFNAME, _sDRFVersion, PWCConstants.POLICY_MOS_PART, CONTEXT.getVault().getName());
				sObjectId = domObj.getObjectId(CONTEXT);
				//domObj.setAttributeValue(CONTEXT,PWCConstants.ATTRIBUTE_PWC_MOS_CHANGE_NUMBER,_sSAPChangeNumber);
				
			}
			catch (Exception e)
			{
				//throw new Exception(new StringBuilder("Faild to create operation '"+_sDRFNAME+"' due to below error :  \n\n").append(e).toString(), e);
				String[] message1Keys = new String[]{"name"};
				String[] message1Values = new String[]{_sDRFNAME};			
				throw new Exception(new StringBuilder(MessageUtil.getMessage(CONTEXT,"pwcEngineeringCentral.MOSCAD.PointedOlderVersionAlert",message1Keys,message1Values,null,CONTEXT.getLocale(),"emxEngineeringCentralStringResource")).append(PWCConstants.STR_NEWLINE).append(e).toString(), e);
			}

			putFromSAPFlag(bIsFromSAP);
			update(DomainObject.newInstance(CONTEXT,sObjectId));

		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":create()");
		return sObjectId;
	}

	/**
	 * It deletes 'this' object 
	 * 
	 * @throws Exception, if operation fails
	 */
	public void delete() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":delete()");
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			domObj.deleteObject(CONTEXT);
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":delete()");
	}

	/**
	 * This API creates a new revision of 'this' object
	 * 
	 * @return - bean of new revision
	 * @throws Exception, if operation fails
	 */
	public void revise(String sNewRevision, boolean bIsFromSAP) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":revise()");
		if(checkIfExists())
		{	
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			if(UIUtil.isNullOrEmpty(sNewRevision))
				sNewRevision = domObj.getNextSequence(CONTEXT);

			BusinessObject busObj = domObj.revise(CONTEXT, sNewRevision, PWCCommonUtil.getVaultPattern(CONTEXT));	
			_sDRFNAME = busObj.getName();
			_sDRFVersion = busObj.getRevision();
			sObjectId = busObj.getObjectId(CONTEXT);
			
			putFromSAPFlag(bIsFromSAP);
			update(domObj);
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":revise()");
	}

	/**
	 * This is to demote Object to previous state
	 * @return
	 * @throws Exception
	 */
	public String demote() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":demote()");
		String sCurrentState = DomainConstants.EMPTY_STRING;
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			domObj.demote(CONTEXT);
			sCurrentState = domObj.getInfo(CONTEXT, DomainConstants.SELECT_CURRENT);
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":demote()");
		return sCurrentState;
	}

	/**
	 * This API finds the given object based on (_sDRFNAME = name & _sDRFVersion = revision) 
	 * and loads all its properties/attributes into 'this' bean object
	 * 
	 * @return, objectId of 'this' object
	 * @throws Exception, if operation fails
	 */
	@SuppressWarnings("unchecked")
	public String loadFromDB() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":loadFromDB()");
		if(checkIfExists())
		{
			Map mMosPartDataMap =  readMOSPartData(CONTEXT, sObjectId);
			loadDataToBean(mMosPartDataMap);			
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":loadFromDB()");
		return sObjectId;
	}	

	/**
	 * This API gets all the data of given OBJECT_ID from database and load into bean class.
	 * @return, void
	 * @throws Exception, if operation fails
	 */
	@SuppressWarnings("unchecked")
	public void loadOperationBeanFromDB(Context context, String sNewObjectId) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":loadOperationBeanFromDB()");

		putObjectId(sNewObjectId);
		domObj = DomainObject.newInstance(context, sNewObjectId);
		StringList selectList = buildSelectables();
		selectList.add(DomainConstants.SELECT_NAME);
		selectList.add(DomainConstants.SELECT_REVISION);
		selectList.add(DomainConstants.SELECT_ID);
		Map mosPartDataMap = domObj.getInfo(context, selectList);
		loadDataToBean(mosPartDataMap);

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":loadOperationBeanFromDB()");

	}

	/**
	 * This API loads data to bean for this object
	 * @param mMosPartDataMap
	 */
	@SuppressWarnings("unchecked")
	public void loadDataToBean(Map mMosPartDataMap )
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":loadDataToBean()");
		setDescription((String)mMosPartDataMap.get(DomainConstants.SELECT_DESCRIPTION));
		setOperationNo((String)mMosPartDataMap.get(SELECTABLE_ATTRIBUTE_PWC_IPP_OPERATION_NUMBER.toString()));
		setESAFlag((String)mMosPartDataMap.get(SELECTABLE_ATTRIBUTE_PWC_IPP_ESA_FLAG.toString()));
		//setLockStatus((String)mMosPartDataMap.get(SELECTABLE_ATTRIBUTE_END_ITEM.toString()));
		//setProcessingOption((String)mMosPartDataMap.get(SELECTABLE_ATTRIBUTE_DESIGN_PURCHASE.toString()));		
		setSequenceNumber((String)mMosPartDataMap.get(SELECTABLE_ATTRIBUTE_PWC_MOS_SEQUENCE_OPERATION.toString()));
		if(mMosPartDataMap.containsKey(DomainConstants.SELECT_ID))
		{
			putObjectId((String)mMosPartDataMap.get(DomainConstants.SELECT_ID));
		}
		if(mMosPartDataMap.containsKey(DomainConstants.SELECT_NAME))
		{
			setDRFName((String)mMosPartDataMap.get(DomainConstants.SELECT_NAME));
		}
		if(mMosPartDataMap.containsKey(DomainConstants.SELECT_REVISION))
		{
			setDRFVersion((String)mMosPartDataMap.get(DomainConstants.SELECT_REVISION));
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":loadDataToBean()");
	}
	/**
	 * This API returns info Map for this Object
	 * @param context
	 * @param sObjectId
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Map readMOSPartData(Context context, String sObjectId)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":getMOSPartData()");
		domObj = DomainObject.newInstance(context, sObjectId);
		StringList slSelectList = buildSelectables();
		Map mMosPartDataMap = domObj.getInfo(context, slSelectList);
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":getMOSPartData()");
		return mMosPartDataMap;
	}
	/**
	 * This builds selectable list
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static StringList buildSelectables()
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":buildSelectables()");
		StringList slSelectList = new StringList();
		slSelectList.add(DomainConstants.SELECT_DESCRIPTION);
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_IPP_OPERATION_NUMBER.toString());
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_IPP_ESA_FLAG.toString());
		slSelectList.add(SELECTABLE_ATTRIBUTE_END_ITEM.toString());
		slSelectList.add(SELECTABLE_ATTRIBUTE_DESIGN_PURCHASE.toString());		
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_MOS_SEQUENCE_OPERATION.toString());
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":buildSelectables()");
		return slSelectList;
	}

	/**
	 * This API overrides all the properties/attributes of 'this' object on 
	 * the corresponding 'PWC_MOS Part' object in DB in order to bring it to up to date with SAP
	 * 
	 * @throws Exception, if operation fails
	 */
	public void update() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":update()");
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			update(domObj);

		}
		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":update()");
	}
	/**
	 * This updates
	 * @param domObj
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void update(DomainObject domObj) throws Exception
	{		
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":update() with Operation object as parameter");

		try 
		{
			domObj.setDescription(CONTEXT, _sDescription);
			Map mAttributeMap = new HashMap();
			if(!UIUtil.isNullOrEmpty(_sOperationNo))
				mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_IPP_OPERATION_NUMBER,_sOperationNo);
			if(!UIUtil.isNullOrEmpty(_sSequenceNumber))
				mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_MOS_SEQUENCE_OPERATION,_sSequenceNumber);
			if(!UIUtil.isNullOrEmpty(_sESAFlag))
				mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_IPP_ESA_FLAG,_sESAFlag);
			/*if(!UIUtil.isNullOrEmpty(_sLockStatus))
				mAttributeMap.put(ATTRIBUTE_END_ITEM,_sLockStatus);*/
			domObj.setAttributeValues(CONTEXT, mAttributeMap);
			
		} catch (Exception e) 
		{
			//throw new Exception(new StringBuilder("Faild to update operation '"+_sDRFNAME+"' due to below error :  \n\n").append(e).toString(), e);
			String[] message1Keys = new String[]{"name"};
			String[] message1Values = new String[]{_sDRFNAME};
			throw new Exception(new StringBuilder(MessageUtil.getMessage(CONTEXT,"pwcEngineeringCentral.PWCIPPMfgOperation.UpdateOperationFailedAlert",message1Keys,message1Values,null,CONTEXT.getLocale(),"emxEngineeringCentralStringResource")).append(PWCConstants.STR_NEWLINE).append(e).toString(), e);
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":update() with Operation object as parameter");
	}


	/**
	 * This API adds the XML element representing 'this' MfgOp to the document object passed to it
	 * @param - Document object of DOM
	 * @return - void
	 * @throws Exception, if operation fails
	 */
	public void toXML(Document doc) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":toXML()");
		try
		{
			Element elMfgOp = null;
			NodeList nlTemp = doc.getElementsByTagName("MfgOps");
			if(nlTemp != null && nlTemp.getLength() > 0)
			{
				elMfgOp = (Element)nlTemp.item(0);  // as there will be only one "MfgOp" element
			}
			else
			{
				elMfgOp = doc.createElement("MfgOps");
			}

			// "Operation" element
			Element elOp = doc.createElement("Operation");
			elMfgOp.appendChild(elOp);
			// setting attributes on operation element for name and revision
			Attr attr = doc.createAttribute("name");
			attr.setValue(_sDRFNAME);
			elOp.setAttributeNode(attr);
			// short way to create attribute
			elOp.setAttribute("revision", _sDRFVersion);

			Element opAttr = doc.createElement("Attributes");
			PWCIPPWSUtil.buildElementFromMap(doc, opAttr, buildAttributesMapForXML());
			elOp.appendChild(opAttr);
		} 
		catch(Exception e)
		{
			_LOGGER.error("Exception in "+PWCIPPMfgOperation.class.getName()+":toXML()");
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":toXML()");
	}

	/**
	 * This connects this object with MOS ITEM relationship
	 * @param strMOLId
	 * @return
	 * @throws Exception
	 */
	public boolean checkIfConnectedToList(String strMOLId) throws Exception
	{
		boolean bIsConnected = false;
		try 
		{
			if(checkIfExists())
			{
				domObj = DomainObject.newInstance(CONTEXT, sObjectId);
				String listId = domObj.getInfo(CONTEXT, new StringBuilder("to[").append(PWCConstants.REL_MOS_ITEM).append("].from.id").toString());
				if(!UIUtil.isNullOrEmpty(listId) && listId.equals(strMOLId))
				{
					bIsConnected = true;
				}			
			}

		} catch (Exception e) 
		{
			throw new Exception(new StringBuilder("Faild to check if operation '"+_sDRFNAME+"' is already connected to MOL due to below error :  \n\n").append(e).toString(), e);
		}

		return bIsConnected;
	}

	/**
	 * This connects this object with MOS ITEM relationship
	 * @param strMOLId
	 * @return
	 * @throws Exception
	 */
	public boolean checkIfConnectedToList() throws Exception
	{
		boolean bIsConnected = false;
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			String listId = domObj.getInfo(CONTEXT, new StringBuilder("to[").append(PWCConstants.REL_MOS_ITEM).append("].from.id").toString());
			if(!UIUtil.isNullOrEmpty(listId))
			{
				bIsConnected = true;
			}			
		}
		return bIsConnected;
	}

	/**
	 * This method disconnect MOS Part from connected MOL object.
	 * @param 
	 * @return void
	 * @throws Exception
	 */
	public void disconnectFromList()throws Exception
	{
		try 
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			String sRelId = domObj.getInfo(CONTEXT, new StringBuilder("to[").append(PWCConstants.REL_MOS_ITEM).append("].id").toString());
			if(!UIUtil.isNullOrEmpty(sRelId))
			{
				//MqlUtil.mqlCommand(CONTEXT, "disconnect connection'"+ sRelId +"'preserve");
				DomainRelationship.disconnect(CONTEXT, sRelId, true);
			}

		} catch (Exception e) 
		{
			throw new Exception(new StringBuilder("Faild to disconnect operation "+_sDRFNAME+" from MOL due to below error :  \n\n").append(e).toString(), e);
		}
	}


	/**
	 * This API checks all the revision exist in database with same DRFName
	 * @return - true, if it has else false
	 * @throws Exception, if operation fails
	 */
	@SuppressWarnings("unchecked")
	public MapList readAllRevisions(String sOperationName)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperation.class.getName()+":readAllRevisions()");

		MapList allRevisions = new MapList();
		try 
		{
			SelectList resultSelects = new SelectList(3);
			resultSelects.add(DomainObject.SELECT_ID);
			resultSelects.add(DomainObject.SELECT_NAME);
			resultSelects.add(DomainObject.SELECT_REVISION);

			allRevisions =  DomainObject.findObjects(CONTEXT,
					PWCConstants.TYPE_MOS_PART,
					sOperationName,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					PWCCommonUtil.getVaultPattern(CONTEXT),
					null,
					false,
					resultSelects);

		} catch (Exception e) 
		{
			throw new Exception(new StringBuilder("Faild to retrieve the revisions of operation '"+_sDRFNAME+"' due to below error :  \n\n").append(e).toString(), e);
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperation.class.getName()+":readAllRevisions()");
		return allRevisions;
	}

	/**
	 * This API find the latest revision of the object and Revise it
	 * @return - New revised object.
	 * @throws Exception, if operation fails
	 */
	@SuppressWarnings("unchecked")
	public static PWCIPPMfgOperation reviseLastRevisionOfMOS(Context context, String sDRFVersion, MapList mlOperationRevisions, boolean bIsFromSAP)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::reviseLastRevisionOfMOS()");

		PWCIPPMfgOperation operationObj = new PWCIPPMfgOperation();
		operationObj.putContext(context);
		try 
		{
			int  size = mlOperationRevisions.size();
			Map objectDetailsMap = null;
			Map<Integer, String> revMapping = new HashMap<Integer, String>();

			for(int index=0; index<size; index++)
			{	
				objectDetailsMap = (Map)mlOperationRevisions.get(index);
				revMapping.put(Integer.valueOf((String)objectDetailsMap.get(DomainObject.SELECT_REVISION)), (String)objectDetailsMap.get(DomainObject.SELECT_ID));
			}
			List<Integer> revisionSet = new  ArrayList<Integer>(revMapping.keySet());
			Collections.sort(revisionSet);
			String strLatestRevisionObjectId = revMapping.get(revisionSet.get(revisionSet.size()-1));

			operationObj.loadOperationBeanFromDB(context, strLatestRevisionObjectId);
			operationObj.revise(sDRFVersion,bIsFromSAP);	

		} catch (Exception e) 
		{
			//throw new Exception(new StringBuilder("Faild to revise operation "+operationObj.getDRFName()+" due to below error :  \n\n").append(e).toString(), e);
			String[] message1Keys = new String[]{"name"};
			String[] message1Values = new String[]{operationObj.getDRFName()};
			throw new Exception(new StringBuilder(MessageUtil.getMessage(context,"pwcEngineeringCentral.MOSCAD.PointedOlderVersionAlert",message1Keys,message1Values,null,context.getLocale(),"emxEngineeringCentralStringResource")).append(PWCConstants.STR_NEWLINE).append(e).toString(), e);
		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::reviseLastRevisionOfMOS()");
		return operationObj;
	}

	/**
	 * This API sets "FromSAPFlag" on MOS Part object if the MOS Part is coming from SAP
	 * 
	 * @throws Exception, if operation fails
	 */
	public void putFromSAPFlag(boolean bIsFromSAP) throws Exception
	{
		try 
		{
			if(checkIfExists())
			{
				domObj = DomainObject.newInstance(CONTEXT, sObjectId);
				domObj.setAttributeValue(CONTEXT,PWCConstants.ATTRIBUTE_PWC_IPP_FROMSAPFLAG,String.valueOf(bIsFromSAP));
			}

		} catch (Exception e) 
		{
			throw new Exception(new StringBuilder("Faild to update 'FromSAPFlag' due to below error :  \n\n").append(e).toString(), e);
		}
	}

	/************************************************ accessors and mutators ******************************************/	


	public String getSequenceNumber() 
	{
		return _sSequenceNumber;
	}


	public void setSequenceNumber(String _sSequenceNumber) 
	{
		this._sSequenceNumber = _sSequenceNumber;
	}


	public String getOperationNo() 
	{
		return _sOperationNo;
	}


	public void setOperationNo(String _sOperationNo) 
	{
		this._sOperationNo = _sOperationNo;
	}


	public String getDescription() 
	{
		return _sDescription;
	}

	public void setDescription(String _sDescription) 
	{
		this._sDescription = _sDescription;
	}

	public String getESAFlag() 
	{
		return _sESAFlag;
	}


	public void setESAFlag(String _sESAFlag) 
	{
		this._sESAFlag = _sESAFlag;
	}


	public String getProcessingOption() 
	{
		return sProcessingOption;
	}

	public void setProcessingOption(String sProcessingOption) 
	{
		this.sProcessingOption = sProcessingOption;
	}


	/*public String getLockStatus() 
	{
		return _sLockStatus;
	}

	public void setLockStatus(String _sLockStatus) 
	{
		this._sLockStatus = _sLockStatus;
	}*/

}
