package com.ds.pwc.ipec.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.TimerClient;
import org.apache.log4j.Logger;

import com.ds.pwc.crm.framework.PWCRFACRMIntegrationDataMappingHolder;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;

/**
 * This is an initialization servlet which invokes process for XML Export of Granted Access Export Logs. It implements TimerClient interface
 * so as to satisfy the requirement where same process needs to be executed in timely manner. 
 * 
 * @author Q63
 *
 */
public class PWCEXCExportLogEntriesServlet extends HttpServlet implements TimerClient {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @param args
	 */
	private static final Logger _LOGGER 								= Logger.getLogger(PWCEXCExportLogEntriesServlet.class.getName());
	private Context CONTEXT;

	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY				= "PWCEXC.ExportLogEntries.ExportFrequency";
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_DESTINATION				= "PWCEXC.ExportLogEntries.ExportDestination";	
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT 			= "PWCEXC.ExportLogEntries.PurgeOnExport";
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION 		= "PWCEXC.ExportLogEntries.RetentionDuration";
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME 				= "PWCEXC.ExportLogEntries.ReportName";	
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_ADMIN_EMAILS				= "PWCEXC.ExportLogEntries.AdminUsers.Emails";
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_EXTERNAL_CONFIG_FILE		= "PWCEXCExportLogEntriesExternalConfig.properties";
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_SERVER_UNIQUE_IDENTIFIER	= "PWCEXC.ExportLogEntries.ServerUniqueIdentifier";
	
	
	// default period in hours to specify how often the entries are exported
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY_DEFAULT				= "24";
	
	// default to specify whether or not each exported Log Entry should be deleted afterwards
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT_DEFAULT 			= "true";
	
	// default in Days, to specify the minimum age a record must have in order to be deleted
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION_DEFAULT 		= "7";
	
	// default name of XML file to which Export Log Entries shall be exported
	private static String EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME_DEFAULT 				= "PWC_ExportLogEntry_XML_Export";	

	/**
	 * This variable specifies list of users to whom email notification should be sent in case of failure
	 */ 
	private static String TO_LIST_ADMIN 									= DomainConstants.EMPTY_STRING;

	/**
	 * This variable specifies in hours, to specify how often the entries are exported
	 */ 
	private static String EC2_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY				= DomainConstants.EMPTY_STRING;

	/**
	 * This variable defines Windows or Unix folder path to specify where to send the export file
	 */
	private static String EC2_EXPORT_LOG_ENTRY_EXPORT_DESTINATION			= DomainConstants.EMPTY_STRING;

	/**
	 * This variable defines true or false to specify whether or not each exported Log Entry should be deleted afterwards
	 */
	private static String EC2_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT			= DomainConstants.EMPTY_STRING;

	/**
	 * This variable defines in Days, to specify the minimum "age" a record must have in order to be deleted
	 */
	private static String EC2_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION	= DomainConstants.EMPTY_STRING;

	/**
	 * This variable defines name of XML file to which Export Log Entries shall be exported
	 */
	private static String EC2_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME				= DomainConstants.EMPTY_STRING;

	/**
	 * This variable defines value of SERVER UNIQUE IDENTIFIER
	 */
	private static String EC2_EXPORT_LOG_ENTRY_SERVER_UNIQUE_IDENTIFIER		= DomainConstants.EMPTY_STRING;

	/**
	 * init method
	 *
	 * @param ServletConfig
	 */
	public void init(ServletConfig config) throws ServletException 
	{	
		_LOGGER.debug("Start of PWCEXCExportLogEntriesServlet :: init()");
		super.init(config);

		Properties properties	= null;
		try 
		{
			properties	= getAllEntriesFromPropertyFile(EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_EXTERNAL_CONFIG_FILE);
			
			if (!properties.isEmpty())
			{
				
				CONTEXT = new Context("");
				ContextUtil.pushContext(CONTEXT, "creator", null, null);

				String sSUI = FrameworkUtil.getServerUniqueIdentifier(CONTEXT);

				// Get server unique identifier
				EC2_EXPORT_LOG_ENTRY_SERVER_UNIQUE_IDENTIFIER = properties.getProperty(EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_SERVER_UNIQUE_IDENTIFIER);				


				if ( !sSUI.equalsIgnoreCase(EC2_EXPORT_LOG_ENTRY_SERVER_UNIQUE_IDENTIFIER) ) 
				{
					_LOGGER.error( "The ServerUniquIdentifier of the current server '"+sSUI+"' does not match with the configured value of '"+EC2_EXPORT_LOG_ENTRY_SERVER_UNIQUE_IDENTIFIER+"'" ) ;
					throw new Exception("The ServerUniquIdentifier of the current server '"+sSUI+"' does not match with the configured value of '"+EC2_EXPORT_LOG_ENTRY_SERVER_UNIQUE_IDENTIFIER+"'");
				}



				// Get how often the entries are exported
				EC2_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY			= properties.getProperty(EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY);			
				if(UIUtil.isNullOrEmpty(EC2_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY))
				{
					EC2_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY	= EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY_DEFAULT;
					_LOGGER.error("No property entry found for " +EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY+ ". Default value "+EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY_DEFAULT+" is assigned");
				}



				// Get Windows or Unix folder path to specify where to send the export file
				EC2_EXPORT_LOG_ENTRY_EXPORT_DESTINATION			= properties.getProperty(EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_DESTINATION);
				if (UIUtil.isNullOrEmpty(EC2_EXPORT_LOG_ENTRY_EXPORT_DESTINATION))
				{
					throwExceptionIfNoPropertyFound(CONTEXT, EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_DESTINATION);
				}



				// Get whether or not each Log Entry exported should be deleted afterwards
				EC2_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT		= properties.getProperty(EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT);
				if(UIUtil.isNullOrEmpty(EC2_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT))
				{
					EC2_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT	= EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT_DEFAULT;
					_LOGGER.error("No property entry found for " +EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT+ ". Default value "+EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT_DEFAULT+" is assigned");
				}


				// Get the minimum age a record must have in order to be deleted
				EC2_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION 	= properties.getProperty(EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION);
				if(UIUtil.isNullOrEmpty(EC2_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION))
				{
					EC2_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION	= EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION_DEFAULT;
					_LOGGER.error("No property entry found for " +EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION+ ". Default value "+EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION_DEFAULT+" is assigned");					
				}


				// Get the name of XML file to which Export Log Entries shall be exported
				EC2_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME			= properties.getProperty(EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME);
				if(UIUtil.isNullOrEmpty(EC2_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME))
				{
					EC2_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME	=	EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME_DEFAULT;
					_LOGGER.error("No property entry found for " +EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME+ ". Default value "+EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME_DEFAULT+" is assigned");
				}

				// Get the list of users to whom email notification should be sent in case of failure
				TO_LIST_ADMIN 									= properties.getProperty(EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_ADMIN_EMAILS);
				if(UIUtil.isNullOrEmpty(TO_LIST_ADMIN))
				{
					throwExceptionIfNoPropertyFound(CONTEXT, EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_ADMIN_EMAILS);
				}


				timerExpired(null);	
			} else
			{
				_LOGGER.error("The external config file '"+EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_EXTERNAL_CONFIG_FILE+"' cannot be found. Please make sure config file is placed correctly.");
				throw new Exception("The external config file '"+EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_EXTERNAL_CONFIG_FILE+"' cannot be found. Please make sure config file is placed correctly.");
			}
			
		} 
		catch (Exception ex) 
		{
			_LOGGER.error("Error in PWCEXCExportLogEntriesServlet :: init()" + ex.toString());			

			
			// Get the list of users to whom email notification should be sent in case of failure
			TO_LIST_ADMIN 									= properties.getProperty(EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_ADMIN_EMAILS);
			if(UIUtil.isNullOrEmpty(TO_LIST_ADMIN))
			{
				try {
					throwExceptionIfNoPropertyFound(CONTEXT, EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_ADMIN_EMAILS);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			String sSubject = EnoviaResourceBundle.getProperty(CONTEXT,"emxExportControlStringResource",CONTEXT.getLocale(),
					"pwcExportControl.XMLExportInitializationError.Subject");
			String sMsssage = new StringBuilder(EnoviaResourceBundle.getProperty(CONTEXT,"emxExportControlStringResource",CONTEXT.getLocale(),
					"pwcExportControl.XMLExportInitializationError.Message")).append(getStackTrace(ex)).toString();
			try 
			{
				//send e-mail notification				
				String[] args = {	TO_LIST_ADMIN,	sSubject,	sMsssage	};
				JPO.invoke(CONTEXT,"PWC_IPECExportLogEntry",new String[0],"sendMail",args);
			} catch (Exception e1) 
			{
				_LOGGER.error("Failed to send the Granted Access Logs XML Export Process Initialization failure notification due to this error: "+ getStackTrace(e1));
			}
			ex.printStackTrace();			
		}       
	}


	/**
	 * This API is used to throw an Exception if no value for property entry is found in property file.
	 * 
	 * @param context - ematrix context
	 * @param strPropertyEntry	- property whose value is not found
	 * @return - nothing
	 * @throws	Exception
	 */
	public static void throwExceptionIfNoPropertyFound(Context context, String strPropertyEntry) throws Exception
	{
		
			_LOGGER.debug("Start of "+PWCEXCExportLogEntriesServlet.class.getName()+"::throwExceptionIfNoPropertyFound()");
			
			String strErrorMessage	= EnoviaResourceBundle.getProperty(context, "emxExportControlStringResource", context.getLocale(), "pwcExportControl.XMLExportError.NoPropertyFound"); 

			strErrorMessage			= FrameworkUtil.findAndReplace(strErrorMessage, "$<property>", EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY );

			_LOGGER.error(strErrorMessage);
						
			_LOGGER.debug("End of "+PWCEXCExportLogEntriesServlet.class.getName()+"::throwExceptionIfNoPropertyFound()");

			throw new Exception(strErrorMessage);
	}


	/**
	 * This API is used to generate stack trace along with an appropriate custom error message
	 * 
	 * @param e - java exception object with default stack trace and message
	 * @return - String representation of the Custom message and the stack trace
	 */
	public static String getStackTrace(Exception e)
	{
		_LOGGER.debug("Start of "+PWCEXCExportLogEntriesServlet.class.getName()+"::getStackTrace()");
		
		StringWriter stringWriter = new StringWriter();
		
		PrintWriter printWriter = new PrintWriter(stringWriter, true);
		
		e.printStackTrace(printWriter);
		
		_LOGGER.debug("End of "+PWCEXCExportLogEntriesServlet.class.getName()+"::getStackTrace()");

		return stringWriter.toString();
	}


	/* 
	 * Timer to restart the service after specified period (EC2_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY) in hours
	 */
	private void startTimers()throws Exception
	{
		_LOGGER.debug("Start of "+PWCEXCExportLogEntriesServlet.class.getName()+"::startTimers()");

		try
		{
			int iSleepInterval = 5;			
			if(!UIUtil.isNullOrEmpty(EC2_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY))
			{
				iSleepInterval = Integer.parseInt(EC2_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY);
			}	
			long iNextTime 			= (iSleepInterval * 60 * 60) * 1000; //Hours in Millisecond
			int NEXT_RUN 			= ((int) Math.ceil(iNextTime/1000));	
	
			matrix.util.Timer timer = new matrix.util.Timer(this, NEXT_RUN);		            
			timer.start();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}

		_LOGGER.debug("End of "+PWCEXCExportLogEntriesServlet.class.getName()+"::startTimers()");
	}
	
	
	public synchronized void timerExpired(matrix.util.Timer timer) 
	{			
		_LOGGER.debug("Start of "+PWCEXCExportLogEntriesServlet.class.getName()+"::timerExpired()");

		try 
		{
			_LOGGER.debug("# Starting the XML Export process");

			String[] args = {EC2_EXPORT_LOG_ENTRY_EXPORT_FREQUENCY,				//how often the entries are exported
					EC2_EXPORT_LOG_ENTRY_EXPORT_DESTINATION,					//Windows or Unix folder path to specify where to send the export file
					EC2_EXPORT_LOG_ENTRY_EXPORT_PURGEONEXPORT,					//whether or not each Log Entry exported should be deleted afterwards
					EC2_EXPORT_LOG_ENTRY_EXPORT_RETENTION_DURATION,				//the minimum age a record must have in order to be deleted
					EC2_EXPORT_LOG_ENTRY_EXPORT_FILE_NAME,						//the name of XML file to which Export Log Entries shall be exported
					TO_LIST_ADMIN												//the list of users to whom email notification should be sent in case of failure
			};

			JPO.invoke(CONTEXT,"PWC_IPECExportLogEntry",new String[0],"exportLogEntries",args);

			startTimers();			
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		_LOGGER.debug("End of "+PWCEXCExportLogEntriesServlet.class.getName()+"::timerExpired()");
	}



	public void destroy()
	{
		_LOGGER.debug("Start of "+PWCEXCExportLogEntriesServlet.class.getName()+"::destroy()");				

		_LOGGER.debug("End of "+PWCEXCExportLogEntriesServlet.class.getName()+"::destroy()");
	}

	@Override
	public void timerStarted(matrix.util.Timer paramTimer) {
		// TODO Auto-generated method stub

	}

	/**
	 * This API reads the property file and holds the properties to read all at once
	 * 
	 * @param sPropertyFileName	- Name of properties file
	 * @return -	All property entries from properties file
	 * @throws FrameworkException
	 */
	public static Properties getAllEntriesFromPropertyFile(String sPropertyFileName) throws FrameworkException
	{
		_LOGGER.debug("Start of "+PWCEXCExportLogEntriesServlet.class.getName()+" : getAllEntriesFromPropertyFile()");

		Properties prop = new Properties();

		InputStream input = null;		
		String sExternalPropertyFilePath = DomainConstants.EMPTY_STRING ;

		try 
		{
			String sExternalFolderPath = System.getenv("PWC_ENOVIA_EXTERNAL_CONFIG_FOLDER_PATH") ;

			if(!UIUtil.isNullOrEmpty(sExternalFolderPath))
			{
				sExternalFolderPath = sExternalFolderPath.trim();
				if (System.getProperty("file.separator").toCharArray()[0] == sExternalFolderPath.charAt(sExternalFolderPath.length()-1) ) 
				{
					sExternalPropertyFilePath = new StringBuilder(sExternalFolderPath).append(sPropertyFileName).toString() ;
				}else
				{
					sExternalPropertyFilePath =  new StringBuilder(sExternalFolderPath).append(System.getProperty("file.separator")).append(sPropertyFileName).toString() ;
				}

				File propertiesFile = new File(sExternalPropertyFilePath);
				if(propertiesFile.exists())
				{
					input = new FileInputStream(sExternalPropertyFilePath);
				}
			}		

			if(null == input)
			{
				input = PWCRFACRMIntegrationDataMappingHolder.class.getClassLoader().getResourceAsStream(sPropertyFileName)	;			
			}

			if (input != null)
			{
				prop.load(input);
			}		

		} catch (IOException ex) 
		{
			_LOGGER.error("Failed to read the property file " + EC2_PROPERTY_EXPORT_LOG_ENTRY_EXPORT_EXTERNAL_CONFIG_FILE + " due to this error:\n "+ getStackTrace(ex) ) ;
			ex.printStackTrace();
		} finally 
		{
			if (input != null) 
			{
				try 
				{
					input.close();
				} catch (IOException e) 
				{
					_LOGGER.error("Failed to close the input stream of the file '"+sExternalPropertyFilePath+"' due to this error:\n " + getStackTrace(e)) ;
					e.printStackTrace();
				}
			}
		}	

		_LOGGER.debug("End of "+PWCEXCExportLogEntriesServlet.class.getName()+" : getAllEntriesFromPropertyFile()");
		return prop ;
	}


}
