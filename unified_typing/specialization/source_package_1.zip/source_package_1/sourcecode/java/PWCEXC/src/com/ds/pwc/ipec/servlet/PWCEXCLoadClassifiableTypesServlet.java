package com.ds.pwc.ipec.servlet;

import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.servlet.FrameworkServlet;

public class PWCEXCLoadClassifiableTypesServlet extends FrameworkServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @param args
	 */
	private static final Logger _LOGGER 								= Logger.getLogger(PWCEXCLoadClassifiableTypesServlet.class.getName());
	private Context context												= null;
	public Properties IPEC_Properties									= null;
	
	private static String IPEC_PROPRTY_NOT_IP_CLASSIFIABLE_TYPES 		= "pwcComponents.Type.NOTIPClassifiableTypes";
	private static String IPEC_PROPRTY_NOT_EXPORT_CLASSIFIABLE_TYPES 	= "pwcComponents.Type.NOTExportClassifiableTypes";
	
	private static String IPEC_PROPRTY_CLASSIFIABLE_TYPES_GENERIC 		= "pwcComponents.Types.ClassifiableTypes.Generic";
	private static String IPEC_PROPRTY_CLASSIFIABLE_TYPES_SPECIFIC 		= "pwcComponents.Types.ClassifiableTypes.Specific";
	
	private static String IPEC_PROPRTY_ANY_TECHNOLOGY_TYPES_GENERIC 	= "pwcComponents.Types.AnyTechnologyTypes.Generic";
	private static String IPEC_PROPRTY_ANY_TECHNOLOGY_TYPES_SPECIFIC 	= "pwcComponents.Types.AnyTechnologyTypes.Specific";
	
	private static String IPEC_PROPRTY_LOW_TECHNOLOGY_TYPES_GENERIC 	= "pwcComponents.Types.LowTechnologyTypes.Generic";
	private static String IPEC_PROPRTY_LOW_TECHNOLOGY_TYPES_SPECIFIC 	= "pwcComponents.Types.LowTechnologyTypes.Specific";
	
	private static String IPEC_PROPRTY_NO_TECHNOLOGY_TYPES_GENERIC 		= "pwcComponents.Types.NoTechnologyTypes.Generic";
	private static String IPEC_PROPRTY_NO_TECHNOLOGY_TYPES_SPECIFIC 	= "pwcComponents.Types.NoTechnologyTypes.Specific";

	private static String IP_PROPRTY_IP_ALWAYS_OWNED_BY_PWC_TYPES_SPECIFIC = "pwcComponents.Types.IPClassifiableTypes.IPAlwaysOwnedByPWC.Specific";

	/**
	 * This variable defines All the Classifiable Types. This includes Any/Low/All technology and IP/Export types
	 */ 
	private static StringList PWC_IPEC_CLASSIFIABLE_TYPES	= new StringList();
	
	/**
	 * This variable defines All Any Technology Types. This include both IP/Export Types
	 */
	private static StringList PWC_IPEC_ANY_TECHNOLOGY_TYPES	= new StringList();
	
	/**
	 * This variable defines All Low Technology Types. This include both IP/Export Types
	 */
	private static StringList PWC_IPEC_LOW_TECHNOLOGY_TYPES	= new StringList();
	
	/**
	 * This variable defines All No Technology Types. This include both IP/Export Types
	 */
	private static StringList PWC_IPEC_NO_TECHNOLOGY_TYPES	= new StringList();
	
	/**
	 * This variable defines All Types for which IP is always owned by PWC.
	 */
	private static StringList PWC_IP_ALWAYS_OWNED_BY_PWC = new StringList();
	
	
	public static StringList getPWCIPECClassifiableTypes() {
		return PWC_IPEC_CLASSIFIABLE_TYPES;
	}

	public static StringList getPWCIPECAnyTechnologyTypes() {
		return PWC_IPEC_ANY_TECHNOLOGY_TYPES;
	}

	public static StringList getPWCIPECLowTechnologyTypes() {
		return PWC_IPEC_LOW_TECHNOLOGY_TYPES;
	}

	public static StringList getPWCIPECNoTechnologyTypes() {
		return PWC_IPEC_NO_TECHNOLOGY_TYPES;
	}

	public static StringList getIPAlwaysOwnedByPWCTypes() {
		return PWC_IP_ALWAYS_OWNED_BY_PWC;
	}

	
	
	/**
     * init method
     *
     * @param ServletConfig
     */
	public void init(ServletConfig config) throws ServletException 
	{	
		_LOGGER.debug("Start of PWCEXCLoadClassifiableTypesServlet :: init()");
		super.init(config);	
		try 
		{
			context = new Context("");
			ContextUtil.pushContext(context, "creator", null, null);
			
			// Get Classifiable Types
			PWC_IPEC_CLASSIFIABLE_TYPES 	= getTypes(context, IPEC_PROPRTY_CLASSIFIABLE_TYPES_GENERIC, IPEC_PROPRTY_CLASSIFIABLE_TYPES_SPECIFIC);
			
			// Get Any Technology Types
			PWC_IPEC_ANY_TECHNOLOGY_TYPES 	= getTypes(context, IPEC_PROPRTY_ANY_TECHNOLOGY_TYPES_GENERIC, IPEC_PROPRTY_ANY_TECHNOLOGY_TYPES_SPECIFIC);
			
			// Get Low Technology Types
			PWC_IPEC_LOW_TECHNOLOGY_TYPES 	= getTypes(context, IPEC_PROPRTY_LOW_TECHNOLOGY_TYPES_GENERIC, IPEC_PROPRTY_LOW_TECHNOLOGY_TYPES_SPECIFIC);
			
			// Get No Technology Types
			PWC_IPEC_NO_TECHNOLOGY_TYPES 	= getTypes(context, IPEC_PROPRTY_NO_TECHNOLOGY_TYPES_GENERIC, IPEC_PROPRTY_NO_TECHNOLOGY_TYPES_SPECIFIC);
			
			// Get IP Always Owned By PWC Types
			PWC_IP_ALWAYS_OWNED_BY_PWC 		= getTypes(context, DomainConstants.EMPTY_STRING, IP_PROPRTY_IP_ALWAYS_OWNED_BY_PWC_TYPES_SPECIFIC);
		} 
		catch (MatrixException ex) 
		{
			_LOGGER.error("Error in PWCEXCLoadClassifiableTypesServlet :: init()" + ex.toString());
			ex.printStackTrace();
		} 
		catch (Exception ex) 
		{
			_LOGGER.error("Error in PWCEXCLoadClassifiableTypesServlet :: init()" + ex.toString());
			ex.printStackTrace();
		}
				
		_LOGGER.debug("End of PWCEXCLoadClassifiableTypesServlet :: init()");
	}

	/**
     * Method to get classified Types from Page object
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args
     * @return string with comma separated symbolic names of Classifiable Types
     * @throws Exception if operation fails
     */
	public StringList getTypes(Context context, String strPropertyGeneric, String strPropertySpecific)
		throws Exception
	{
		_LOGGER.debug("Start of PWCEXCLoadClassifiableTypesServlet :: getTypes()");
		
		StringList strLstReturnTypes 	= new StringList();
		//String strDerivatives 			= DomainConstants.EMPTY_STRING;
		//String strSpecificTypes			= DomainConstants.EMPTY_STRING;
		String strIPECTypeGeneric 		= DomainConstants.EMPTY_STRING;
		String strIPECTypeSpecific 		= DomainConstants.EMPTY_STRING;
		
		try 
		{
			if (strPropertyGeneric != null && !DomainConstants.EMPTY_STRING.equals(strPropertyGeneric))
				strIPECTypeGeneric 	= EnoviaResourceBundle.getProperty(context, strPropertyGeneric);
			
			if (strPropertySpecific != null && !DomainConstants.EMPTY_STRING.equals(strPropertySpecific))
				strIPECTypeSpecific 	= EnoviaResourceBundle.getProperty(context, strPropertySpecific);
			
			// Get all derivative of each parent types
			if (strIPECTypeGeneric != null && !DomainConstants.EMPTY_STRING.equals(strIPECTypeGeneric))
			{
				strLstReturnTypes.addAll(getAllDerivatives(context, strIPECTypeGeneric.trim()));
			}
			
			if (strIPECTypeSpecific != null && !DomainConstants.EMPTY_STRING.equals(strIPECTypeSpecific))
			{
				strLstReturnTypes.addAll(FrameworkUtil.split(strIPECTypeSpecific, ",")); 
			}
			
			// Return List
			/*if(strDerivatives != null && !DomainConstants.EMPTY_STRING.equals(strDerivatives))
			{
				strReturnTypes = strDerivatives;
			}*/
			
			/*if(strSpecificTypes != null && !DomainConstants.EMPTY_STRING.equals(strSpecificTypes))
			{
				strReturnTypes = strReturnTypes + "," + strSpecificTypes;
			}*/
		} 
		catch (Exception exp) 
		{
			_LOGGER.error("Error in PWCEXCLoadClassifiableTypesServlet :: getTypes()" + exp.toString());
			exp.printStackTrace();
		}

		_LOGGER.debug("End of PWCEXCLoadClassifiableTypesServlet :: getTypes()");
		return strLstReturnTypes;
	}
	
	public StringList getAllDerivatives(Context context, String strClassTypes)
		throws Exception
	{
		_LOGGER.debug("Start of PWCEXCLoadClassifiableTypesServlet :: getAllDerivatives()");

		String strType 				= DomainConstants.EMPTY_STRING;
		String strTypeSymbolic 		= DomainConstants.EMPTY_STRING;
		String strMQLCommand		= DomainConstants.EMPTY_STRING;
		String strMQLResult			= DomainConstants.EMPTY_STRING;
		String strClassifiableTypes = DomainConstants.EMPTY_STRING;
		
		String[] strDerivative		= new String[]{};
		int intDerivative			= 0;
		
		StringList strLstClassifiableTypes = new StringList();
		
		try
		{
			StringList strLstClassTypes = FrameworkUtil.split(strClassTypes, ",");
			
			int intClssType = strLstClassTypes.size();
			
			for(int i = 0; i < intClssType; i++)
			{
				strType = (String) strLstClassTypes.get(i);
				strLstClassifiableTypes.add(strType);

				strTypeSymbolic = PropertyUtil.getSchemaProperty(strType);
				strMQLCommand	= new StringBuilder("print type \"").append(strTypeSymbolic)
															.append("\" select derivative dump ~").toString();
				strMQLResult	= MqlUtil.mqlCommand(context, strMQLCommand);
				
				if (strMQLResult !=  null && !DomainConstants.EMPTY_STRING.equals(strMQLResult))
				{
				strDerivative 	= strMQLResult.split("~");
				intDerivative 	= strDerivative.length;
				
				for(int j = 0; j < intDerivative; j++)
				{
					strLstClassifiableTypes.add(FrameworkUtil.getAliasForAdmin(context, "Type", strDerivative[j], true));
				}
			}
			}
			
			/*if (strLstClassifiableTypes != null && strLstClassifiableTypes.size() > 0)
			{
				strClassifiableTypes = strLstClassifiableTypes.toString();
				
				// Remove [ and ] from Return String
				strClassifiableTypes = strClassifiableTypes.substring(1, strClassifiableTypes.length() - 1);
				
				// Remove space between commas
				strClassifiableTypes = strClassifiableTypes.replaceAll(", ", ",");
				
			}*/
		}
		catch (Exception exc)
		{
			_LOGGER.error("Error in PWCEXCLoadClassifiableTypesServlet :: getAllDerivatives()" + exc.toString());
			exc.printStackTrace();
		}
		
		_LOGGER.debug("End of PWCEXCLoadClassifiableTypesServlet :: getAllDerivatives()");
		return strLstClassifiableTypes;
	}

}
