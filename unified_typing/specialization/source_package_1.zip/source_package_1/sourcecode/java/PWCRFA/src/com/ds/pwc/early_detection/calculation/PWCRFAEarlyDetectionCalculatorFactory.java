package com.ds.pwc.early_detection.calculation;

import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionCalculator;

public class PWCRFAEarlyDetectionCalculatorFactory {

	public static IPWCRFAEarlyDetectionCalculator getCalculatorInstance(String iClassName) throws Exception
	{
		Class<?> cls = Class.forName(iClassName);
		Object instance = (Object) cls.newInstance();
		return (IPWCRFAEarlyDetectionCalculator) instance;
	}
}
