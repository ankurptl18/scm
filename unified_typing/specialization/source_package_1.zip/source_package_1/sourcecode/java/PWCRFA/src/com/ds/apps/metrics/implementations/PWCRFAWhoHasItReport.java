package com.ds.apps.metrics.implementations;

import static com.ds.common.PWCConstants.ATTRIBUTE_ISSUE_CLASSIFICATION;
import static com.ds.common.PWCConstants.ATTRIBUTE_PROB_FOUND_DURING;
import static com.ds.common.PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_TYPE;
import static com.ds.common.PWCConstants.ATTRIBUTE_PWC_RFA_OCCURRENCE_TYPE;
import static com.ds.common.PWCConstants.ATTRIBUTE_PWC_RFA_PART_TYPE;
import static com.ds.common.PWCConstants.ATTRIBUTE_RFA_BUSINESS_PROCESS;
import static com.ds.common.PWCConstants.POLICY_RFA_DRDEV;
import static com.ds.common.PWCConstants.RELATIONSHIP_PWC_RFA_EVENT_LOCATION;
import static com.ds.common.PWCConstants.RELATIONSHIP_PUBLIC_LINE_MODELS;
import static com.matrixone.apps.domain.DomainConstants.EMPTY_STRING;
import static com.matrixone.apps.domain.DomainConstants.SELECT_CURRENT;
import static com.matrixone.apps.domain.DomainConstants.SELECT_ID;
import static com.matrixone.apps.domain.DomainConstants.SELECT_NAME;
import static com.matrixone.apps.domain.DomainConstants.SELECT_POLICY;
import static com.matrixone.apps.domain.DomainConstants.SELECT_ORIGINATED;


import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectItr;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

import com.ds.apps.metrics.PWCRFAMetricsReports;
import com.ds.apps.metrics.interfaces.IPWCRFAReport;
import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCRFAWhoHasItReport implements IPWCRFAReport {
    public Date FROM_DATE=null;
    public Date TO_DATE=null;
    
	@SuppressWarnings({ "unchecked" })
	public String buildSearchCriteria(Context paramContext, StringList objectList, HashMap searchCriteriaDataMap) throws Exception {

		System.out.println("Criteria : " + searchCriteriaDataMap);

		String SELECT_RFA_BUSINESS_PROCESS = "attribute[" + ATTRIBUTE_RFA_BUSINESS_PROCESS + "]";
		String SELECT_RFA_EVENT_TYPE = "attribute[" + ATTRIBUTE_PWC_RFA_EVENT_TYPE + "]";
		String SELECT_RFA_SUB_TYPE = "attribute[" + ATTRIBUTE_ISSUE_CLASSIFICATION + "]";
		String SELECT_RFA_PFD = "attribute[" + ATTRIBUTE_PROB_FOUND_DURING + "]";
		String SELECT_RFA_PART_TYPE = "attribute[" + ATTRIBUTE_PWC_RFA_PART_TYPE + "]";
		String SELECT_RFA_OCCURRENCE_TYPE = "attribute[" + ATTRIBUTE_PWC_RFA_OCCURRENCE_TYPE + "]";
		String SELECT_RFA_SUB_PROCESS = "attribute[" + PropertyUtil.getSchemaProperty("attribute_PWC_RFAProcessSubType") + "]";
		String REl_PWC_RFA_MODEL = PropertyUtil.getSchemaProperty("relationship_PWC_RFAModel");
		String TYPE_PWC_RFA_ISSUE = PropertyUtil.getSchemaProperty("type_PWC_RFAIssue");
		String SELECT_RFA_EVENT_LOCATION = "from[" + RELATIONSHIP_PWC_RFA_EVENT_LOCATION + "].to.id";
		String STATE_CANCEL = PropertyUtil.getSchemaProperty("policy", POLICY_RFA_DRDEV, "state_Cancelled");
		String STATE_CLOSE = PropertyUtil.getSchemaProperty("policy", POLICY_RFA_DRDEV, "state_Closed");
		String STATE_CREATE = PropertyUtil.getSchemaProperty("policy", POLICY_RFA_DRDEV, "state_Create");
		String SELECT_ATTR_SEVERITY = "attribute[" + PropertyUtil.getSchemaProperty("attribute_PWC_RFASeverity") + "]";
		String SELECT_ATTR_IPT_ID = "attribute[" + PropertyUtil.getSchemaProperty("attribute_PWC_IPTID") + "]";
		String SELECT_ATTR_LIABLE_GROUP = "attribute[" + PropertyUtil.getSchemaProperty("attribute_PWC_RFALiableGroup") + "]";
		
		String strSelectedBusinessProcess = (String) searchCriteriaDataMap.get("selectedBusinessProcess");
		String strSelectedEventType = (String) searchCriteriaDataMap.get("selectedEventType");
		String strSelectedSubType = (String) searchCriteriaDataMap.get("selectedSubType");
		String strSelectedPFD = (String) searchCriteriaDataMap.get("selectedPFD");
		String strSelectedPartType = (String) searchCriteriaDataMap.get("selectedPartType");
		String strSelectedEventLocationOID = (String) searchCriteriaDataMap.get("txtActualContainedEventLocationOID");
		String strSelectedSubProcess = (String) searchCriteriaDataMap.get("selectedSubProcess");
		String strSelectedOccurrenceType = (String) searchCriteriaDataMap.get("selectedOccurrenceType");
		String strSelectedLiableGroup = (String) searchCriteriaDataMap.get("selectedLiableOrganization");
		String strSelectedIPTID = (String) searchCriteriaDataMap.get("selectedResponsibleInvestigationGroup");
		String strSelectedSeverity = (String) searchCriteriaDataMap.get("selectedSeverity");
		
		String strSelectedEngineFamilyOIDs = (String) searchCriteriaDataMap.get("txtActualContainedEngineModelFamilyOID");
		String strSelectedLifecycleState = (String) searchCriteriaDataMap.get("selectedLifecycleState");
		String strSelectedCreationFromDate = (String) searchCriteriaDataMap.get("txtFromDate_msvalue");
		String strSelectedCreationToDate = (String) searchCriteriaDataMap.get("txtToDate_msvalue");
		String strPeriodPriorToCurrentDate = (String) searchCriteriaDataMap.get("PeriodPriorToCurrentDate");
		String strDateUnit = (String) searchCriteriaDataMap.get("optDateUnit");
		
		if(!UIUtil.isNullOrEmpty(strSelectedCreationFromDate) && 
				!UIUtil.isNullOrEmpty(strSelectedCreationToDate))
		{
			FROM_DATE = new Date(strSelectedCreationFromDate);
			TO_DATE = new Date(strSelectedCreationToDate);
		}
				
		if(!UIUtil.isNullOrEmpty(strPeriodPriorToCurrentDate) && !UIUtil.isNullOrEmpty(strDateUnit))
        	setFromToDate(strPeriodPriorToCurrentDate, strDateUnit);
        
		
		
		String strSearchCriteria = EMPTY_STRING;
		StringBuffer sbSearchCriteria = new StringBuffer();
		StringList models = objectList;
		StringList TARGET_RFA_NAME_LIST = new StringList();
		StringList TARGET_RFA_ID_LIST = new StringList();
		
		// Evaluating engine model list based on engine family, if model list is empty, since we aren't storing engine family direct on RFA
		if((null==models || models.size()==0) && !UIUtil.isNullOrEmpty(strSelectedEngineFamilyOIDs))
		models = PWCRFAMetricsReports.getModelListBasedOnFamily(paramContext, strSelectedEngineFamilyOIDs);
		
		// if engine model list is empty then we need to look all RFAs
		if(null==models || models.size()==0)
		{
			StringList objectSelects = new StringList(DomainConstants.SELECT_ID);
			MapList allRFAList = DomainObject.findObjects(paramContext, 
														PWCConstants.TYPE_RFA,
														DomainConstants.QUERY_WILDCARD, 
														DomainConstants.QUERY_WILDCARD, 
														DomainConstants.QUERY_WILDCARD,
														PWCCommonUtil.getVaultPattern(paramContext), 
														null, 
														false, 
														objectSelects);
			
			int nSize = allRFAList.size();
			if(nSize > 0)
			{
				for(int n=0;n<nSize;n++)
				{
					Map tempMap = (Map)allRFAList.get(n);
					TARGET_RFA_ID_LIST.add((String)tempMap.get(DomainConstants.SELECT_ID));
				}
			}
			
		}else{
		
			// get all the RFA IDs.
			StringList MODEL_SELECTS = new StringList();
	
			MODEL_SELECTS.add("to[" + REl_PWC_RFA_MODEL + "].from.id");
	
			Set<String> modelIdSet = new HashSet<String>();
			for (int i = 0; i < models.size(); i++) {
				modelIdSet.add(((String) models.get(i)).trim());
			}
			BusinessObjectWithSelectList RFAList = BusinessObject.getSelectBusinessObjectData(paramContext, (String[]) modelIdSet.toArray(new String[0]),
			        MODEL_SELECTS);
			BusinessObjectWithSelectItr RFAWithSelectItr = new BusinessObjectWithSelectItr(RFAList);
	
			while (RFAWithSelectItr.next()) {
				BusinessObjectWithSelect RFAWithSelect = RFAWithSelectItr.obj();
				StringList strIdList = (StringList) RFAWithSelect.getSelectDataList("to[" + REl_PWC_RFA_MODEL + "].from.id");
				if (null != strIdList && strIdList.size() > 0) {
					for (int n = 0; n < strIdList.size(); n++) {
						TARGET_RFA_ID_LIST.add((String) strIdList.get(n));
					}
				}
			}
			
		}
		System.out.println("--TARGET_RFA_ID_LIST-->" + TARGET_RFA_ID_LIST);
		StringList RFA_SELECTS = new StringList();
		RFA_SELECTS.add(SELECT_POLICY);
		RFA_SELECTS.add(SELECT_CURRENT);
		RFA_SELECTS.add(SELECT_NAME);
		RFA_SELECTS.add(SELECT_ID);
		RFA_SELECTS.add(SELECT_ORIGINATED);
		
		if (!UIUtil.isNullOrEmpty(strSelectedBusinessProcess))
			RFA_SELECTS.add(SELECT_RFA_BUSINESS_PROCESS);
		if (!UIUtil.isNullOrEmpty(strSelectedEventType))
			RFA_SELECTS.add(SELECT_RFA_EVENT_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedSubType))
			RFA_SELECTS.add(SELECT_RFA_SUB_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedPFD))
			RFA_SELECTS.add(SELECT_RFA_PFD);
		if (!UIUtil.isNullOrEmpty(strSelectedPartType))
			RFA_SELECTS.add(SELECT_RFA_PART_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedOccurrenceType))
			RFA_SELECTS.add(SELECT_RFA_OCCURRENCE_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedSubProcess))
			RFA_SELECTS.add(SELECT_RFA_SUB_PROCESS);
		if (!UIUtil.isNullOrEmpty(strSelectedEventLocationOID))
			RFA_SELECTS.add(SELECT_RFA_EVENT_LOCATION);
		if (!UIUtil.isNullOrEmpty(strSelectedSeverity))
			RFA_SELECTS.add(SELECT_ATTR_SEVERITY);
		if (!UIUtil.isNullOrEmpty(strSelectedIPTID))
			RFA_SELECTS.add(SELECT_ATTR_IPT_ID);
		if (!UIUtil.isNullOrEmpty(strSelectedLiableGroup))
			RFA_SELECTS.add(SELECT_ATTR_LIABLE_GROUP);

		Set<String> RFAIdSet = new HashSet<String>();
		if (null != TARGET_RFA_ID_LIST && TARGET_RFA_ID_LIST.size() > 0) {
			for (int i = 0; i < TARGET_RFA_ID_LIST.size(); i++) {
				RFAIdSet.add(((String) TARGET_RFA_ID_LIST.get(i)).trim());
			}
		}

		BusinessObjectWithSelectList busRFAList = BusinessObject.getSelectBusinessObjectData(paramContext, (String[]) RFAIdSet.toArray(new String[0]),
		        RFA_SELECTS);
		BusinessObjectWithSelectItr busWithSelectItr = new BusinessObjectWithSelectItr(busRFAList);

		while (busWithSelectItr.next()) {
			String strRFAName = null;
			String strState = null;
			String strRFABusProcess = null;
			String strRFAEventType = null;
			String strRFASubType = null;
			String strRFAPFD = null;
			String strRFAPartType = null;
			String strRFAOccurenceType = null;
			String strRFASubProcess = null;
			String strRFAEventLocation = null;
			String strRFAIPTID = null;
			String strRFALiableGroup = null;
			String strRFASeverity = null;
			String strRFAOriginated = null;

			BusinessObjectWithSelect busWithSelect = busWithSelectItr.obj();
			StringList strNameList = (StringList) busWithSelect.getSelectDataList(SELECT_NAME);
			StringList strStateList = (StringList) busWithSelect.getSelectDataList(SELECT_CURRENT);
			StringList strRFABusProcessList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_BUSINESS_PROCESS);
			StringList strRFAEventTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_EVENT_TYPE);
			StringList strRFASubTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_SUB_TYPE);
			StringList strRFAPFDList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_PFD);
			StringList strRFAPartTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_PART_TYPE);
			StringList strRFAOccurenceTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_OCCURRENCE_TYPE);
			StringList strRFASubProcessList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_SUB_PROCESS);
			StringList strRFAEventLocationList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_EVENT_LOCATION);
			StringList strRFAIPTIDList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_IPT_ID);
			StringList strRFALiableGroupList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_LIABLE_GROUP);
			StringList strRFASeverityList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_SEVERITY);
			StringList strRFAoriginatedList = (StringList) busWithSelect.getSelectDataList(SELECT_ORIGINATED);

			if (null != strNameList && strNameList.size() > 0)
				strRFAName = (String) strNameList.get(0);
			if (null != strStateList && strStateList.size() > 0)
				strState = (String) strStateList.get(0);
			if (null != strRFABusProcessList && strRFABusProcessList.size() > 0)
				strRFABusProcess = (String) strRFABusProcessList.get(0);
			if (null != strRFAEventTypeList && strRFAEventTypeList.size() > 0)
				strRFAEventType = (String) strRFAEventTypeList.get(0);
			if (null != strRFASubTypeList && strRFASubTypeList.size() > 0)
				strRFASubType = (String) strRFASubTypeList.get(0);
			if (null != strRFAPFDList && strRFAPFDList.size() > 0)
				strRFAPFD = (String) strRFAPFDList.get(0);
			if (null != strRFAPartTypeList && strRFAPartTypeList.size() > 0)
				strRFAPartType = (String) strRFAPartTypeList.get(0);
			if (null != strRFAOccurenceTypeList && strRFAOccurenceTypeList.size() > 0)
				strRFAOccurenceType = (String) strRFAOccurenceTypeList.get(0);
			if (null != strRFASubProcessList && strRFASubProcessList.size() > 0)
				strRFASubProcess = (String) strRFASubProcessList.get(0);
			if (null != strRFAEventLocationList && strRFAEventLocationList.size() > 0)
				strRFAEventLocation = (String) strRFAEventLocationList.get(0);
			if (null != strRFAIPTIDList && strRFAIPTIDList.size() > 0)
				strRFAIPTID = (String) strRFAIPTIDList.get(0);
			if (null != strRFALiableGroupList && strRFALiableGroupList.size() > 0)
				strRFALiableGroup = (String) strRFALiableGroupList.get(0);
			if (null != strRFASeverityList && strRFASeverityList.size() > 0)
				strRFASeverity = (String) strRFASeverityList.get(0);
			if (null != strRFAoriginatedList && strRFAoriginatedList.size() > 0)
				strRFAOriginated = (String) strRFAoriginatedList.get(0);
			
			boolean add = true;

			if (STATE_CANCEL.equals(strState) || STATE_CREATE.equals(strState) || STATE_CLOSE.equals(strState))
				add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedLifecycleState))
				if (strSelectedLifecycleState.indexOf(strState) == -1)
					add = false;
			if (add && UIUtil.isNullOrEmpty(strRFAName))
				add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedBusinessProcess))
				if (UIUtil.isNullOrEmpty(strRFABusProcess) || strSelectedBusinessProcess.indexOf(strRFABusProcess) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedEventType))
				if (UIUtil.isNullOrEmpty(strRFAEventType) || strSelectedEventType.indexOf(strRFAEventType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedSubType))
				if (UIUtil.isNullOrEmpty(strRFASubType) || strSelectedSubType.indexOf(strRFASubType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedPFD))
				if (UIUtil.isNullOrEmpty(strRFAPFD) || strSelectedPFD.indexOf(strRFAPFD) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedPartType))
				if (UIUtil.isNullOrEmpty(strRFAPartType) || strSelectedPartType.indexOf(strRFAPartType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedOccurrenceType))
				if (UIUtil.isNullOrEmpty(strRFAOccurenceType) || strSelectedOccurrenceType.indexOf(strRFAOccurenceType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedSubProcess))
				if (UIUtil.isNullOrEmpty(strRFASubProcess) || strSelectedSubProcess.indexOf(strRFASubProcess) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedEventLocationOID))
				if (UIUtil.isNullOrEmpty(strRFAEventLocation) || strSelectedEventLocationOID.indexOf(strRFAEventLocation) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedIPTID))
				if (UIUtil.isNullOrEmpty(strRFAIPTID) || strSelectedIPTID.indexOf(strRFAIPTID) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedLiableGroup))
				if (UIUtil.isNullOrEmpty(strRFALiableGroup) || strSelectedLiableGroup.indexOf(strRFALiableGroup) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedSeverity))
				if (UIUtil.isNullOrEmpty(strRFASeverity) || strSelectedSeverity.indexOf(strRFASeverity) == -1)
					add = false;
            
			if (add && (null!=FROM_DATE && null!=TO_DATE))
			{
				Date RFAOriginated = new Date(strRFAOriginated);
				if(RFAOriginated.before(FROM_DATE) || RFAOriginated.after(TO_DATE))
					add = false;
			}
				
			if (add)
				TARGET_RFA_NAME_LIST.add(strRFAName);
		}

		if (TARGET_RFA_NAME_LIST.size() > 0) {
			
			sbSearchCriteria.append("temp query bus \"" + TYPE_PWC_RFA_ISSUE + "\" ");

			for (int j = 0; j < TARGET_RFA_NAME_LIST.size(); j++) {
				String strRFAName = (String) TARGET_RFA_NAME_LIST.get(j);
				sbSearchCriteria.append(strRFAName);

				if (j != TARGET_RFA_NAME_LIST.size() - 1)
					sbSearchCriteria.append(",");
			}
			
			sbSearchCriteria.append(" -");
		}

		strSearchCriteria = sbSearchCriteria.toString();
		
		if (strSearchCriteria.equals(EMPTY_STRING) && null != models && models.size() > 0) {
			String strModelId = (String) models.get(0);
			strSearchCriteria = "print bus " + strModelId + "select name";
		}
		if (strSearchCriteria.equals(EMPTY_STRING))
		{
			strSearchCriteria = "print bus Model GENERAL \"\" select name";
		}

		System.out.println("--strSearchCriteria--in Who has it report--->" + strSearchCriteria);

		return strSearchCriteria;
	}
	
	private void setFromToDate(String strPeriod, String strDateUnit)
	{
		Calendar cal =  Calendar.getInstance();
		TO_DATE = cal.getTime();
	 	
		int period = Integer.parseInt(strPeriod);
		if(!UIUtil.isNullOrEmpty(strDateUnit))
		{
			if(strDateUnit.equalsIgnoreCase("M"))
				cal.add(cal.MONTH, -period);
			if(strDateUnit.equalsIgnoreCase("Y"))
				cal.add(cal.YEAR, -period);
			if(strDateUnit.equalsIgnoreCase("Q"))
				cal.add(cal.MONTH, -(3*period));
			if(strDateUnit.equalsIgnoreCase("W"))
				cal.add(cal.DATE, -(7*period));
			
			FROM_DATE = cal.getTime();
		}
		cal.setTime(new Date());
	}
}
