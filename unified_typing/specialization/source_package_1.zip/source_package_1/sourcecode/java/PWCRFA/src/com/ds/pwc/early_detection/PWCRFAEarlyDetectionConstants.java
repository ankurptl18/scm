package com.ds.pwc.early_detection;

import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.productline.ProductLineConstants;

public class PWCRFAEarlyDetectionConstants {

	
	// Type Definition
	public static final String TYPE_DEFECT_DEVIATION = PropertyUtil.getSchemaProperty("type_PWC_RFAEDDefectDeviation");
	public static final String TYPE_ENGINE_SYMPTOM = PropertyUtil.getSchemaProperty("type_PWC_RFAEngineSymptom");
	public static final String TYPE_ENGINE_CONDITION = PropertyUtil.getSchemaProperty("type_PWC_RFAEngineCondition");
	public static final String TYPE_PART_CONDITION = PropertyUtil.getSchemaProperty("type_PWC_RFAPartCondition");
	public static final String TYPE_ENGINE_POSITION = PropertyUtil.getSchemaProperty("type_PWC_RFAEnginePosition");
	public static final String TYPE_PART_CLASSIFICATION = PropertyUtil.getSchemaProperty("type_PWC_RFAPartClassification");
	public static final String TYPE_ALERT = PropertyUtil.getSchemaProperty("type_PWC_RFAEDAlert");

	// Attribute Definition
	public static final String ATTRIBUTE_ED_PARAMETER_WEIGHT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDParameterWeight");
	public static final String ATTRIBUTE_ED_COMBINED_DEFECT_RL = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDCombinedDefectRL");
	public static final String ATTRIBUTE_ED_COMBINED_DEFECT_RECURRENCE = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDCombinedDefectRecurrence");
	public static final String ATTRIBUTE_ED_COMBINED_DEFECT_SR = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDCombinedDefectSR");
	public static final String ATTRIBUTE_ED_COMBINED_DEFECT_SRL = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDCombinedDefectSRL");
	public static final String ATTRIBUTE_ED_COMBINED_DEFECT_SEVERITY = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDCombinedDefectSeverity");
	public static final String ATTRIBUTE_ED_COMBINED_WEIGHTED_DEFECT_FREQ = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDCombinedWeightedDefectFrequency");
	public static final String ATTRIBUTE_ED_FREQ_Q1 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ1");
	public static final String ATTRIBUTE_ED_FREQ_Q2 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ2");
	public static final String ATTRIBUTE_ED_FREQ_Q3 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ3");
	public static final String ATTRIBUTE_ED_FREQ_Q4 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ4");
	public static final String ATTRIBUTE_ED_FREQ_Q5 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ5");
	public static final String ATTRIBUTE_ED_FREQ_Q6 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ6");
	public static final String ATTRIBUTE_ED_FREQ_Q7 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ7");
	public static final String ATTRIBUTE_ED_FREQ_Q8 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ8");
	public static final String ATTRIBUTE_ED_FREQ_Q9 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ9");
	public static final String ATTRIBUTE_ED_FREQ_ENGINE_Q1 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqEngineQ1");
	public static final String ATTRIBUTE_ED_FREQ_ENGINE_Q2 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqEngineQ2");
	public static final String ATTRIBUTE_ED_FREQ_PART_Q1 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqPartQ1");
	public static final String ATTRIBUTE_ED_FREQ_PART_Q2 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqPartQ2");
	public static final String ATTRIBUTE_ED_FREQ_PART_Q3 = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqPartQ3");
	public static final String ATTRIBUTE_ED_DEFECT_MULTIPLE = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectMultiple");
	public static final String ATTRIBUTE_ED_DEFECT_TYPE = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectType");
	public static final String ATTRIBUTE_ED_ENGINE_DEFECT_RL = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEngineDefectRL");
	public static final String ATTRIBUTE_ED_ENGINE_DEFECT_RECURRENCE = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEngineDefectRecurrence");
	public static final String ATTRIBUTE_ED_ENGINE_DEFECT_SR = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEngineDefectSR");
	public static final String ATTRIBUTE_ED_ENGINE_DEFECT_SRL = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEngineDefectSRL");
	public static final String ATTRIBUTE_ED_ENGINE_DEFECT_SEVERITY = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEngineDefectSeverity");
	public static final String ATTRIBUTE_ED_ENGINE_WEIGHTED_DEFECT_FREQ = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEngineWeightedDefectFrequency");
	public static final String ATTRIBUTE_ED_LOCATION_RATE = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDLocationRate");
	public static final String ATTRIBUTE_ED_PART_DEFECT_RL = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDPartDefectRL");
	public static final String ATTRIBUTE_ED_PART_DEFECT_RECURRENCE = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDPartDefectRecurrence");
	public static final String ATTRIBUTE_ED_PART_DEFECT_SR = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDPartDefectSR");
	public static final String ATTRIBUTE_ED_PART_DEFECT_SRL = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDPartDefectSRL");
	public static final String ATTRIBUTE_ED_PART_DEFECT_SEVERITY = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDPartDefectSeverity");
	public static final String ATTRIBUTE_ED_PART_WEIGHTED_DEFECT_FREQ = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDPartWeightedDefectFrequency");
	public static final String ATTRIBUTE_ED_TIMESTAMP = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDTimestamp");
	public static final String ATTRIBUTE_ED_ENGINE_POSITION_WEIGHT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEnginePositionWeight");
	public static final String ATTRIBUTE_ED_PART_CLASSIFICATION_WEIGHT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDPartClassificationWeight");
	public static final String ATTRIBUTE_ED_PART_CONDITION_WEIGHT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDPartConditionWeight");
	public static final String ATTRIBUTE_ENGINE_MODEL_FAMILY = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEngineModelFamily");
	public static final String ATTRIBUTE_ED_EM_COEFFICIENT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEMCoefficient");
	public static final String ATTRIBUTE_ED_PN_COEFFICIENT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDPNCoefficient");
	public static final String ATTRIBUTE_ENGINE_SYMPTOM_WEIGHT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEngineSymptomWeight");
	public static final String ATTRIBUTE_ENGINE_CONDITION_WEIGHT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDEngineConditionWeight");
	public static final String ATTRIBUTE_ED_ALERT_TIMESTAMP = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDAlertTimestamp");
	public static final String ATTRIBUTE_ED_FREQ_Q1_INFO = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqQ1Info");
	public static final String ATTRIBUTE_ED_FREQ_PART_Q1_INFO = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqPartQ1Info");
	public static final String ATTRIBUTE_ED_FREQ_ENGINE_Q1_INFO = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDDefectFreqEngineQ1Info");
	public static final String ATTRIBUTE_ED_ALERT_TYPE = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDAlertType");
	public static final String ATTRIBUTE_ED_BP_WEIGHT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDBusinessProcessWeight");
	public static final String ATTRIBUTE_ED_PFD_WEIGHT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDProblemFoundDuringWeight");
	public static final String ATTRIBUTE_ED_ST_WEIGHT = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEDSubTypeWeight");

	// Interface Definition
	public static final String INTERFACE_COMBINED_DEFECT = PropertyUtil.getSchemaProperty("interface_PWC_RFAEDCombinedDefect");
	public static final String INTERFACE_ENGINE_DEFECT = PropertyUtil.getSchemaProperty("interface_PWC_RFAEDEngineDefect");
	public static final String INTERFACE_PART_DEFECT = PropertyUtil.getSchemaProperty("interface_PWC_RFAEDPartDefect");

	// Relationship Definition
	public static final String RELATIONSHIP_ED_DEFECT = PropertyUtil.getSchemaProperty("relationship_PWC_RFAEDIssueDefect");
	public static final String RELATIONSHIP_ED_ALERT = PropertyUtil.getSchemaProperty("relationship_PWC_RFAEDAlert");

	// Policy Definition
	public static final String STR_POLICY_ED_DEFECT = "policy_PWC_RFAEDDefectDeviation";
	public static final String STR_POLICY_ED_ALERT = "policy_PWC_RFAEDAlert";

	// String Definition
	public static final String TYPE_EDM_CONFIG = PropertyUtil.getSchemaProperty("type_PWC_RFAEDMConfig");
	public static final String STR_PART_NAME = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PART_NAME).append("]").toString();
	public static final String STR_PART_CONDITION = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PART_CONDITION).append("]").toString();
	public static final String STR_ENGINE_POSITION = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_ENGINE_POSITION).append("]").toString();
	public static final String STR_ENGINE_SYMPTOM = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINE_SYMPTOM_DEVIATION).append("]").toString();
	public static final String STR_ENGINE_CONDITION = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_ENGINE_CONDITION).append("]").toString();
	public static final String STR_ENGINEMODEL = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINEMODEL).append("]").toString();
	public static final String STR_REL_MODEL_NAME = new StringBuilder("from[").append(PWCConstants.RELATIONSHIP_PWC_RFA_MODEL).append("].to.name").toString();
	public static final String STR_REL_PHYSICALPART_PC = new StringBuilder("relationship[").append(PWCConstants.RELATIONSHIP_PWC_RFA_PHYSICAL_PART).append("].").append(STR_PART_CONDITION).toString();
	public static final String STR_REL_ENGINEINFO_IFSD = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_RFA_IFSD).append("]").toString();
	public static final String STR_REL_PHYSCALPART_PN = new StringBuilder("relationship[").append(PWCConstants.RELATIONSHIP_PWC_RFA_PHYSICAL_PART).append("].to.").append(STR_PART_NAME).toString();
	//public static final String STR_PART_COEFFICIENT = new StringBuilder("relationship[").append(PWCConstants.RELATIONSHIP_PWC_RFA_PHYSICAL_PART).append("].to.attribute[").append(ATTRIBUTE_ED_PN_COEFFICIENT).append("]").toString();
	public static final String STR_REL_MODEL_COEFFICIENT = new StringBuilder("from[").append(PWCConstants.RELATIONSHIP_PWC_RFA_MODEL).append("].to.attribute[").append(ATTRIBUTE_ED_EM_COEFFICIENT).append("]").toString();
	public static final String STR_REL_MODEL_FLY = new StringBuilder("from[").append(PWCConstants.RELATIONSHIP_PWC_RFA_MODEL).append("].to.relationship[").append(ProductLineConstants.RELATIONSHIP_PRODUCTLINE_MODELS).append("].from.name").toString();
	public static final String STR_TYPE_ED_DEFECT = "type_PWC_RFAEDDefectDeviation";
	public static final String STR_PART_FAMILY = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_FAMILY).append("]").toString();
	public static final String STR_PART_NUMBER = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PART_NUMBER).append("]").toString();
	public static final String STR_SELECT_LOCATIONRATE = new StringBuilder("attribute[").append(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_LOCATION_RATE).append("]").toString();
	public static final String STR_SELECT_ENGINEINFO_EP = new StringBuilder("relationship[").append(PWCConstants.RELATIONSHIP_PWC_RFA_ENGINE_INFO).append("].to.").append(STR_ENGINE_POSITION).toString();
	public static final String STR_SELECT_ENGINEINFO_ESY =new StringBuilder("relationship[").append(PWCConstants.RELATIONSHIP_PWC_RFA_ENGINE_INFO).append("].to.").append(STR_ENGINE_SYMPTOM).toString();
	public static final String STR_SELECT_ENGINEINFO_EC =new StringBuilder("relationship[").append(PWCConstants.RELATIONSHIP_PWC_RFA_ENGINE_INFO).append("].to.").append(STR_ENGINE_CONDITION).toString();
	public static final String STR_SELECT_ENGINEINFO_IFSD =new StringBuilder("relationship[").append(PWCConstants.RELATIONSHIP_PWC_RFA_ENGINE_INFO).append("].to.attribute[").append(PWCConstants.ATTRIBUTE_PWC_RFA_IFSD).append("]").toString();
	public static final String STR_COMMANDED_IFSD = "COMMANDED IFSD" ;
	public static final String STR_UNCOMMANDED_IFSD = "UNCOMMANDED IFSD" ;
	public static final String STR_ENGINE_POSITION_NAME = "Engine Position";
    public static final String STR_SELECT_BP = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_RFA_BUSINESS_PROCESS).append("]").toString();
	public static final String STR_SELECT_PFD = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PROB_FOUND_DURING).append("]").toString();
	public static final String STR_SELECT_SUBTYPE = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_ISSUE_CLASSIFICATION).append("]").toString();
	public static final String STR_SELECT_EVENTTYPE = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_TYPE).append("]").toString();
	public static final String STR_TYPE_ED_ALERT = "type_PWC_RFAEDAlert";

	public static final String STR_SELECT_COMBINED_Q1_INFO = new StringBuilder("attribute[").append(ATTRIBUTE_ED_FREQ_Q1_INFO).append("]").toString();
	public static final String STR_SELECT_ENGINE_Q1_INFO = new StringBuilder("attribute[").append(ATTRIBUTE_ED_FREQ_ENGINE_Q1_INFO).append("]").toString();
	public static final String STR_SELECT_PART_Q1_INFO = new StringBuilder("attribute[").append(ATTRIBUTE_ED_FREQ_PART_Q1_INFO).append("]").toString();
	public static final String STR_EMPTY = "Empty" ;
	public static final String STR_ATT_PART_SERIAL_NUMBER = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PART_SERIAL_NUMBER).append("]").toString();
	public static final String STR_ATT_QTY_DEF = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PART_QTY_DEF).append("]").toString();
	public static final String STR_PART_SERIAL_NUMBER = new StringBuilder("relationship[").append(PWCConstants.RELATIONSHIP_PWC_RFA_PHYSICAL_PART).append("].").append(STR_ATT_PART_SERIAL_NUMBER).toString();
	public static final String STR_QTY_DEF = new StringBuilder("relationship[").append(PWCConstants.RELATIONSHIP_PWC_RFA_PHYSICAL_PART).append("].").append(STR_ATT_QTY_DEF).toString();
	//State Definition
    public static final String POLICY_ED_DEFECT= PropertyUtil.getSchemaProperty("policy_PWC_RFAEDDefectDeviation");
	public static final String STATE_POLICY_ED_DEFECT =PropertyUtil.getSchemaProperty("policy",POLICY_ED_DEFECT,"state_Obsolete");
	public static final String STR_PART_EMPTY = "(Empty)" ;

}
