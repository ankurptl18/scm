package com.ds.pwc.early_detection;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.StringList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.ds.pwc.early_detection.implementations.PWCRFAEarlyDetectionDefectData;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;


public class PWCRFAEarlyDetectionUtil {
	// XML cache holder
	private static HashMap<String,Document> XMLCACHEHOLDER = new HashMap<String,Document>();
	private static final Logger LOG = Logger.getLogger(PWCRFAEarlyDetectionUtil.class.getSimpleName());
	private static final String PWC_ENOVIA_EXTERNAL_CONFIG_FOLDER_PATH = "PWC_ENOVIA_EXTERNAL_CONFIG_FOLDER_PATH";

	/**
	 * The function reads the xml file, and stores the content in a
	 * HashMap "XMLCACHEHOLDER" 
	 * @param - String filename
	 * @return - Document
	 * @throws PWCRFAEarlyDetectionException 
	 * @throws Exception
	 *             when problems occurred
	 */
	public static synchronized Document loadRuleDocument(String ruleFileName) throws PWCRFAEarlyDetectionException {
		Document document = null;
		document =  XMLCACHEHOLDER.get(ruleFileName);
		// If document is null , means the file has not been read before
		if (document == null) {
			InputStream IS = null;
			//Loads the file  from Environmental Path
			String strConfigFolderPath = System.getenv( PWC_ENOVIA_EXTERNAL_CONFIG_FOLDER_PATH );
			if(strConfigFolderPath != null && !"".equals(strConfigFolderPath) && new File(strConfigFolderPath).exists()){
				LOG.debug("INFO: " + strConfigFolderPath + " folder path declared in enovia environment file");
				File configFile = new File(strConfigFolderPath + File.separator + ruleFileName);
				if (configFile.exists())
				{
					try {
						IS = new FileInputStream( configFile );
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
				}
			}
			// Loads the file from class loader if it is not in  Environmental Path and store it in InputStream
			if(null == IS)
			{
				IS =  PWCRFAEarlyDetectionUtil.class.getClassLoader().getResourceAsStream(ruleFileName);
				if (null == IS)
				{
					LOG.error("ERROR: Cannot find the configuration file: [" + ruleFileName + "]");
					try {
						throw new Exception("Cannot find the configuration file: [" + ruleFileName + "]");
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				else
				{
					LOG.debug("Configuration file: [" + ruleFileName+ "] loaded from web stack .../enovia/WEB-INF/classes");
				}
			}
			else
			{
				LOG.debug("Configuration file: [" + ruleFileName+ "] loaded from env variable: " + PWC_ENOVIA_EXTERNAL_CONFIG_FOLDER_PATH + " = " + strConfigFolderPath);
			}

			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = null;
			
			try {
				docBuilder = docBuilderFactory.newDocumentBuilder();
				// Parse the content of the given InputStream as an XML document
				if(IS!=null){
					document = docBuilder.parse(IS);
				}else{
					String message = "Early Detection failed. Could not find "+ruleFileName+".xml";
					throw new PWCRFAEarlyDetectionException(message);
				}
			} 
			catch (ParserConfigurationException e) {
				e.printStackTrace();
			}catch (SAXException e) {
					String message = "Early Detection failed. Could not parse "+ruleFileName+".xml";
					throw new PWCRFAEarlyDetectionException(message);
			} catch (IOException e) {
				String message = "Early Detection failed. Could not read "+ruleFileName+".xml";
				throw new PWCRFAEarlyDetectionException(message);
			}
			
			XMLCACHEHOLDER.put(ruleFileName, document);
		}
		LOG.debug("End of PWCRFAEarlyDetectionUtil:loadRuleDocument");
		return document;
	}	



	/**
	 * The function gets the information on Engine and Part connected to RFA object
	 * 
	 * @param context
	 * @param Object
	 *            Id
	 * @return - MapList
	 * @throws Exception
	 *             when problems occurred
	 */
	public static MapList getRelatedPartAndEngineInfo(Context context, String sObjectId)
			throws Exception {
		LOG.debug("Start of PWCRFAEarlyDetectionUtil: getRelatedPartAndEngineInfo");
		MapList mapObjPart = null;
		try {

			// Create Domain Object of RFA Object and form selectables
			DomainObject RFAObj = DomainObject.newInstance(context, sObjectId);
			StringList busSelects = new StringList(2);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_PART_NAME);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_PART_NUMBER);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_REL_PHYSICALPART_PC);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_PART_FAMILY);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_PART_SERIAL_NUMBER);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_QTY_DEF);
			//busSelects.add(PWCRFAEarlyDetectionConstants.STR_PART_COEFFICIENT);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_ENGINE_POSITION);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_REL_ENGINEINFO_IFSD);
			busSelects.add(DomainConstants.SELECT_RELATIONSHIP_TYPE);
			busSelects.add(DomainConstants.SELECT_ID);
			StringList relSelects = new StringList(2);

			String strType = new StringBuilder(PWCConstants.TYPE_PWC_RFA_PHYSICAL_PART).append(",").append(PWCConstants.TYPE_PWC_RFA_ENGINE_INFO).toString();
			String strRelationship = new StringBuilder(PWCConstants.RELATIONSHIP_PWC_RFA_PHYSICAL_PART).append(",").append(PWCConstants.RELATIONSHIP_PWC_RFA_ENGINE_INFO).toString();

			// Getting Objects of type "Physical Part"  and Engine Info by traversing
			mapObjPart = RFAObj.getRelatedObjects(context, 	// context
					strRelationship, 						// relpattern
					strType, 								// type pattern
					busSelects,								// bus select
					relSelects, 							// rel select
					false, 									// get to
					true, 									// get from					
					(short) 1, 								// one level
					DomainConstants.EMPTY_STRING, 			// object where
					DomainConstants.EMPTY_STRING,			// rel where
					0); 									//limit

		} catch (Exception ex) {
			LOG.error("Exception in PWC_RFAEarlyDection: getRelatedPartAndEngineInfo : "
					+ ex.getMessage());
		}

		LOG.debug("End of PWCRFAEarlyDetectionUtil: getRelatedPartAndEngineInfo");
		return mapObjPart;

	}
	
	/**
	 * The function deletes Defect if they are already connected to RFA Object the information on Physical Part object
	 * 
	 * @param context
	 * @param Object
	 *            Id
	 * @return - MapList
	 * @throws Exception
	 *             when problems occurred
	 */
	public static void deleteRFADefects(Context context, DomainObject domRFAObject) throws Exception
		{
		LOG.debug("Start of PWCRFAEarlyDetectionUtil : deleteRFADefects");
		boolean isAccessGranted = false;
		try {

			//Get list of Defects connected to RFA	
			DomainObject domDefectObjectId = DomainObject.newInstance(context);
			String strDefectRelationship 		= new StringBuilder("relationship[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_DEFECT)
			.append("].to.id").toString();
			isAccessGranted = PWCCommonUtil.grantAccessToRFA(context, domRFAObject);

			StringList slDefectList = domRFAObject.getInfoList(context, strDefectRelationship);
			if(!slDefectList.isEmpty())
			{	
				DomainObject.deleteObjects(context, (String[])slDefectList.toArray(new String[slDefectList.size()]));
			}
			
			
			/*int iDefectSize = slDefectList.size();
				for(int nCount=0;nCount<iDefectSize;nCount++)
				{
					//Deletion of each Defect Object
					domDefectObjectId.setId((String)slDefectList.get(nCount));
					domDefectObjectId.deleteObject(context);
				}*/
		} catch (Exception t) {
			LOG.error("Exception in PWCRFAEarlyDetectionUtil : deleteRFADefects : "
					+ t.getMessage());
		}
		finally
		{
			if (isAccessGranted)
			{
				PWCCommonUtil.revokeAccessGrantedToRFA(context,domRFAObject);
			}
		}
		LOG.debug("End of PWCRFAEarlyDetectionUtil : deleteRFADefects");

	}


	/**
	 * The function gets the information on Model object connected to RFA
	 * 
	 * @param context
	 * @param Object
	 *            Id
	 * @return - Map
	 * @throws FrameworkException 
	 * @throws Exception
	 *             when problems occurred
	 */
	public static Map getRelatedRFAInfo(Context context, DomainObject domRFAObject) throws FrameworkException{
	
		LOG.debug("Start of PWCRFAEarlyDetectionUtil : deleteRFADefects");
		// Getting all information related to RFA which will be used further in calculation
		StringList selectables = new StringList();
		selectables.add(PWCRFAEarlyDetectionConstants.STR_REL_MODEL_NAME);
		selectables.add(PWCRFAEarlyDetectionConstants.STR_REL_MODEL_FLY);
		selectables.add(PWCRFAEarlyDetectionConstants.STR_REL_MODEL_COEFFICIENT);
		selectables.add(PWCRFAEarlyDetectionConstants.STR_SELECT_LOCATIONRATE);
		selectables.add(DomainConstants.SELECT_OWNER);
		LOG.debug("End of PWCRFAEarlyDetectionUtil : getRelatedRFAInfo");
		return domRFAObject.getInfo(context, selectables);

	}

	/**
	 * The function to Create Defect Object and Connect it with RFA Object
	 * 
	 * @param context
	 * @param interfaceType
	 *            String
	 * @param connectRFAObjId
	 *            String 
	 * @return - String
	 * @throws Exception 
     * when problems occurred
	 */
	public static String createAndConnectDefect(Context context,String interfaceType,String connectRFAObjId) throws Exception{
		
		LOG.debug("Start of PWCRFAEarlyDetectionUtil : createAndConnectDefect");
		String strObjectId =  "";
		boolean isAccessGranted = false;
		DomainObject domRFA = DomainObject.newInstance(context,connectRFAObjId);
		try{
		StringBuilder cmdMQL = new StringBuilder();
		String strOwner = domRFA.getOwner(context).toString();

		//Creating Defect Object with autoname and connecting it with RFA Object
		strObjectId = FrameworkUtil.autoName(context,PWCRFAEarlyDetectionConstants.STR_TYPE_ED_DEFECT, "", PWCRFAEarlyDetectionConstants.STR_POLICY_ED_DEFECT);
		DomainObject domDefect = DomainObject.newInstance(context,strObjectId);
		isAccessGranted = PWCCommonUtil.grantAccessToRFA(context, domRFA);
		domDefect.setOwner(context,strOwner);
		DomainRelationship rel = domDefect.connect(context,	PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_DEFECT, domRFA, true);

		// Check if interface has been already been added
		String strInterfaceExists = domDefect.getInfo(context,"interface[" + interfaceType + "]");

		// If no interface is added to the Defect Type then add one
		if (strInterfaceExists.equals("FALSE")) {
			cmdMQL.append("modify bus '");
			cmdMQL.append(strObjectId);
			cmdMQL.append("' add interface '");
			cmdMQL.append(interfaceType);
			cmdMQL.append("';");
			MqlUtil.mqlCommand(context, cmdMQL.toString());
		}

		LOG.debug("End of PWCRFAEarlyDetectionUtil : createAndConnectDefect");

		}
		catch(Exception ex){
			
			ex.printStackTrace();
		}
		finally
		{
			if (isAccessGranted)
			{
				PWCCommonUtil.revokeAccessGrantedToRFA(context,domRFA);
			}
		}
		return strObjectId;	}
	
	/**
	 * The function is to compare critical limits of various parameter after completing calculation
	 * @param context
	 * @param defect
	 *            PWCRFAEarlyDetectionDefectData
	 * @return - boolean
	 * @throws Exception 
     * when problems occurred
	 */
	public static boolean isSatisfiesCriticalLimits(Context context,PWCRFAEarlyDetectionDefectData defect) throws PWCRFAEarlyDetectionException
	{
	LOG.debug("Start of PWCRFAEarlyDetectionUtil : isSatisfiesCriticalLimits");
	int iCLimit =0;
	int iNumLimit = 0;
	int iSize = 0;
	String strAttributeName ="";
	boolean isSatisfied = true;
	String strLimitValue = "";	
	String strEnumAttrKey = "";	
	String strEnumAttrValue = "";	
	String strAttrValue = "";	
	ArrayList arrAlertTypeList = new ArrayList();
	// Function to compare critical limits of various parameter after completing calulation
	// Getting CriticalLimitRules xml
	Document documentCriticalLimit = PWCRFAEarlyDetectionUtil.loadRuleDocument("CriticalLimitRules.xml");
	//Getting all the parameters to be compared in a arraylist
	PWCRFAEarlyDetectionCriticalimitEnum[] arrComparator = PWCRFAEarlyDetectionCriticalimitEnum.values();
	iNumLimit = arrComparator.length;
	StringBuilder strBuilder = new StringBuilder();
	
	for(int c=0;c<iNumLimit;c++){
		
		//Getting Key from Enum , ex: Msc,Mse
		strEnumAttrKey = arrComparator[c].name();
		//Getting Value  from Enum , ex: Msc = attribute_PWC_RFAEDCombinedDefectSeverity
		strEnumAttrValue = arrComparator[c].getAttributeName();
		//Getting Values for parameters Msc,Mse etc from xml document
		NodeList CLList = documentCriticalLimit.getElementsByTagName(strEnumAttrKey);
		//Getting value for parameters from NodeList CLList
		strLimitValue = CLList.item(0).getTextContent().trim();	
		//Getting attribute value from the defect object
		strEnumAttrValue = PropertyUtil.getSchemaProperty(context,strEnumAttrValue);
		strAttrValue = defect.getAttributeValue(strEnumAttrValue);
		//Comparing each Defect attribute value with critical value
		//If either one of the Defect attribute value is less that Critical limit,
		if(null != strAttrValue && (Double.parseDouble(strAttrValue) > Double.parseDouble(strLimitValue))){
			
			if(strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_SEVERITY)||strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SEVERITY) || strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SEVERITY)){
				//strBuilder.append("S");
				if(!arrAlertTypeList.contains("S")){
				arrAlertTypeList.add("S");
				}
			}
			if(strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_RECURRENCE)||strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_RECURRENCE) || strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_RECURRENCE)){
				//strBuilder.append("R");
				if(!arrAlertTypeList.contains("R")){
					arrAlertTypeList.add("R");
					}
			}
			if(strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_SR)||strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SR) || strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SR)){
				//strBuilder.append("C");
				if(!arrAlertTypeList.contains("C")){
					arrAlertTypeList.add("C");
					}
			}
			if(strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_RL)||strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_RL) || strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_RL)){
				//strBuilder.append("K");
				if(!arrAlertTypeList.contains("K")){
					arrAlertTypeList.add("K");
					}
			}
			if(strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_SRL)||strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SRL) || strEnumAttrValue.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SRL)){
				//strBuilder.append("P");
				if(!arrAlertTypeList.contains("P")){
					arrAlertTypeList.add("P");
					}
			}
			isSatisfied = false;
			//break;
		}
		}
	iSize = arrAlertTypeList.size();
	for (int i=0;i<iSize;i++){
		strBuilder.append(arrAlertTypeList.get(i));
	}
	defect.setAlertType(strBuilder.toString());	
	LOG.debug("End of PWCRFAEarlyDetectionUtil : isSatisfiesCriticalLimits");
	return isSatisfied;

}
	
	/**
	 * The function is to compare VSM with Severity code
	 * @param context
	 * @param defect
	 *            PWCRFAEarlyDetectionDefectData
	 * @return - boolean
	 * @throws Exception 
     * when problems occurred
	 */
	
	public static boolean isSatisfiesVSMLimits(Context context,HashMap hVSMMap) throws PWCRFAEarlyDetectionException
	{
	LOG.debug("Start of PWCRFAEarlyDetectionUtil : isSatisfiesVSMLimits");
	int iCLimit =0;
	int iNumLimit = 0;
	String strAttributeName ="";
	String strAttributeOriginalName ="";
	boolean isSatisfied = true;
	String strLimitValue = "";	
	String strAttrValue = "";
	HashMap hDefectAttributeMap ;
	
	// Function to compare VSM with various Severity codes after completing calulation
	// Getting CriticalLimitRules xml
	Document documentCriticalLimit = PWCRFAEarlyDetectionUtil.loadRuleDocument("CriticalLimitRules.xml");
	NodeList CLList = documentCriticalLimit.getElementsByTagName("VSM");
	strLimitValue = CLList.item(0).getTextContent().trim();
	
	//Getting value for VSM key from Enum -PWCRFAEarlyDetectionCriticalimitEnum
	strAttributeName = PWCRFAEarlyDetectionCriticalimitEnum.VSM.getAttributeName();
	StringTokenizer strTokens = new StringTokenizer(strAttributeName,",");
	//Comparing Each Severity Code attribute value with VSM Limit
	while (strTokens.hasMoreTokens()){
		strAttributeOriginalName = 	PropertyUtil.getSchemaProperty(strTokens.nextToken());
		if(hVSMMap.containsKey(strAttributeOriginalName))
		{
		strAttrValue = hVSMMap.get(strAttributeOriginalName).toString();
		//System.out.println("strAttrValue :: "+strAttrValue + "strLimitValue ::"+strLimitValue);
		if( null !=strAttrValue && (Double.parseDouble(strAttrValue) >Double.parseDouble(strLimitValue)))
		{
			isSatisfied = false;
			break;
		}
		}
	}
	LOG.debug("End of PWCRFAEarlyDetectionUtil : isSatisfiesVSMLimits");
	return isSatisfied;

}	
	
	/**
	 * The function to connect other Defect Object with 100% match in similarity rule with Alert Object
	 * 
	 * @param context

	 * @param domDefect
	 * 	 *            DomainObject 
	 * @return - String
	 * @throws Exception 
     * when problems occurred
	 */
	public static String createAndConnectAlertObject(Context context,String connectDefectId,String strAlertType,ArrayList mDefectArrayList) throws Exception{
		
		LOG.debug("Start of PWCRFAEarlyDetectionUtil : createAndConnectAlertObject");
		String strObjectId =  "";
		boolean isAccessGranted = false;
		DomainObject domDefect = DomainObject.newInstance(context,connectDefectId);
		try{
		StringBuilder cmdMQL = new StringBuilder();
		String strOwner = domDefect.getOwner(context).toString();
		isAccessGranted = PWCCommonUtil.grantAccessToRFA(context, domDefect);
		//Issue fix for production issue 35
		Date baseDate = new Date();
		Date rfaDate = new Date();
		long baseRFATime = 0;
		long otherRFATime = 0;
		long differenceInMillis = 0;
		String strBaseEventDate = getEventDate(context,domDefect);
		baseDate = new Date(strBaseEventDate);
		baseRFATime = baseDate.getTime();
		//Issue fix for production issue 35
		
		//Disconnecting any previous Alert object connected to Defect
		String strDefectRelationship 		= new StringBuilder("relationship[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_ALERT).append("].to.id").toString();
		StringList slDefectList = domDefect.getInfoList(context, strDefectRelationship);
		if(!slDefectList.isEmpty())
		{	
			DomainObject.deleteObjects(context, (String[])slDefectList.toArray(new String[slDefectList.size()]));
		}
	
		//Creating Defect Object with autoname and connecting it with RFA Object
		strObjectId = FrameworkUtil.autoName(context,PWCRFAEarlyDetectionConstants.STR_TYPE_ED_ALERT,"",PWCRFAEarlyDetectionConstants.STR_POLICY_ED_ALERT);
		DomainObject domAlert = DomainObject.newInstance(context,strObjectId);
		domAlert.setOwner(context,strOwner);
		domAlert.setAttributeValue(context,PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ALERT_TYPE, strAlertType);
		DomainRelationship rel = domAlert.connect(context,	PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_ALERT, domDefect, true);
		rel.setAttributeValue(context, PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ALERT_TIMESTAMP, "0");
		int imatchSize = mDefectArrayList.size();
		for(int i=0;i<imatchSize;i++){
		DomainObject dobjTempDefect = 	DomainObject.newInstance(context,mDefectArrayList.get(i).toString());	
		StringList strDefectList = dobjTempDefect.getInfoList(context, strDefectRelationship);
		if(!strDefectList.isEmpty())
		{	
			DomainObject.deleteObjects(context, (String[])strDefectList.toArray(new String[strDefectList.size()]));
		}
		//added for production bug fix 35 starts
		String strEventDate = getEventDate(context,dobjTempDefect);
		rfaDate = new Date(strEventDate);
		otherRFATime = rfaDate.getTime();
		differenceInMillis = otherRFATime - baseRFATime;
		//conversion from millisecond to days
		differenceInMillis = differenceInMillis / (24*60*60*1000);
		//added for production bug fix 35

		DomainRelationship dRel = DomainRelationship.connect(context,dobjTempDefect   ,PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_ALERT,domAlert);
		//commented and added for production bug fix 35
		dRel.setAttributeValue(context,PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ALERT_TIMESTAMP, Long.toString(differenceInMillis));
		}

		LOG.debug("End of PWCRFAEarlyDetectionUtil : createAndConnectAlertObject");
		
		}
		catch(Exception ex){
			
			ex.printStackTrace();
		}
		finally
		{
			if (isAccessGranted)
			{
				PWCCommonUtil.revokeAccessGrantedToRFA(context,domDefect);
			}
		}
		return strObjectId;
		
}
	
	/**
	 * The function to connect other Defect Object with 100% match in similarity rule with Alert Object
	 * 
	 * @param context

	 * @param domDefect
	 * 	 *            DomainObject 
	 * @return - String
	 * @throws Exception 
     * when problems occurred
	 */
	public static String connectAlertToDefects(Context context, PWCRFAEarlyDetectionDefectData defect,String connectDefectId ,String strAlertType ) throws Exception
		{
		LOG.debug("Start of PWCRFAEarlyDetectionUtil : connectAlertToDefects");
		boolean isAccessGranted = false;
		String  strRFAInfo = "";
		String strDefectType = "";
		String strDefectId = "";
		String strDefectEC = "";
		String strDefectESy = "";
		String strDefectPC = "";
		Set strKey ;
		String strMatchKey = "";
		Set strW2Key ;
		Set strW2NoMatchKey ;
		strDefectId = defect.getStrObjectId();
		int iSize = 0;
		int iAlertCount = 0;
		String strFixedAlert = "" ;
		boolean bMatchingDef = false;
		boolean bReuse = false;
		//Issue fix for production issue 35
		Date baseDate = new Date();
		Date rfaDate = new Date();
		long baseRFATime = 0;
		long otherRFATime = 0;
		long differenceInMillis = 0;

		//Issue fix for production issue 35

		//StringList slDefectList = new StringList();
		StringList slBusSelect = new StringList();
		StringList slRelSelect 	= new StringList();
		slBusSelect.add(DomainConstants.SELECT_NAME);
		slBusSelect.add(DomainConstants.SELECT_ID);
		slBusSelect.add(new StringBuilder("relationship[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_ALERT)
				.append("].to.id").toString());
		
	    slRelSelect.add(DomainConstants.SELECT_RELATIONSHIP_ID);
		DomainObject dobjDefect = DomainObject.newInstance(context,strDefectId);
		ArrayList mDefectArrayList = new ArrayList();
		Map mCombined = defect.getW1CombinedMatch();
		Map mEngine = defect.getW1EngineMatch();
		Map mPart = defect.getW1PartMatch();
		Map mW2Part = defect.getW2PartMatch();
		Map mW2NoMatchPart = defect.getW2PartNoMatch();
		String strAlertRelationship 		= new StringBuilder("relationship[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_ALERT)
		.append("].from.id").toString();
		String strEngineModelFlySelect = new StringBuilder("attribute[").append(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_MODEL_FAMILY).append("]").toString();
		DomainObject domDefectObject = null;
		DomainObject dommatchingDefObj = null;
	
		try {
			StringList busSelects = new StringList();
			busSelects.add(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_TYPE);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_SELECT_COMBINED_Q1_INFO);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_SELECT_ENGINE_Q1_INFO);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_SELECT_PART_Q1_INFO);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
			busSelects.add(PWCRFAEarlyDetectionConstants.STR_PART_CONDITION);
			//Get list of Defects connected to RFA	
			isAccessGranted = PWCCommonUtil.grantAccessToRFA(context, dobjDefect);

			strDefectType = defect.getStrEDDefectType();

			Map slDefectMap = dobjDefect.getInfo(context, busSelects);
			BusinessObject busObject = new BusinessObject();

			if(!slDefectMap.isEmpty())
			{	
				strDefectEC = (String)slDefectMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
				strDefectESy = (String)slDefectMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
				strDefectPC = (String)slDefectMap.get(PWCRFAEarlyDetectionConstants.STR_PART_CONDITION);

				if(strDefectType.equals("Combined")){
					strRFAInfo = (String)slDefectMap.get(PWCRFAEarlyDetectionConstants.STR_SELECT_COMBINED_Q1_INFO);
				}
				else if(strDefectType.equals("Engine")){
					strRFAInfo = (String)slDefectMap.get(PWCRFAEarlyDetectionConstants.STR_SELECT_ENGINE_Q1_INFO);
				}
				
				else if(strDefectType.equals("Part")){
					strRFAInfo = (String)slDefectMap.get(PWCRFAEarlyDetectionConstants.STR_SELECT_PART_Q1_INFO);
				}

				StringTokenizer strToken = new StringTokenizer(strRFAInfo,",");
				while(strToken.hasMoreTokens()){
					String tempRFA = strToken.nextToken();

					if(!tempRFA.equals(""))
					{
					busObject = new BusinessObject(PWCConstants.TYPE_RFA, tempRFA, "-", context.getVault().getName());
					DomainObject domObject = new DomainObject(busObject);
					String strDefectRelationship 		= new StringBuilder("relationship[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_DEFECT)
					.append("].to.id").toString();
					StringList slDefectList = domObject.getInfoList(context, strDefectRelationship);
					slDefectList.remove(strDefectId);
					if(!slDefectList.isEmpty())
					{
						iSize = slDefectList.size();
						for(int i=0;i<iSize;i++){
							boolean isMatch = false;
							boolean isW1Match = false;
							String strtempDefect = slDefectList.get(i).toString();
							domDefectObject = new DomainObject(strtempDefect);
							StringList strLstSelect = new StringList(3);
							strLstSelect.add("attribute["+PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_TYPE+"]");
							strLstSelect.add(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
							strLstSelect.add(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
							strLstSelect.add(PWCRFAEarlyDetectionConstants.STR_ENGINEMODEL);
							strLstSelect.add(PWCRFAEarlyDetectionConstants.STR_PART_CONDITION);
							strLstSelect.add(PWCRFAEarlyDetectionConstants.STR_PART_NUMBER);
							strLstSelect.add(PWCRFAEarlyDetectionConstants.STR_PART_NAME);
							strLstSelect.add(PWCRFAEarlyDetectionConstants.STR_PART_FAMILY);
							strLstSelect.add(strEngineModelFlySelect);
							strLstSelect.add(DomainConstants.SELECT_CURRENT);
							Map mapRFAVal = domDefectObject.getInfo(context, strLstSelect);
							String strCurrent	= (String) mapRFAVal.get(DomainConstants.SELECT_CURRENT);
							if(!mapRFAVal.isEmpty()){
								String strTempDefectEC = (String)mapRFAVal.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
								String strTempDefectESy = (String)mapRFAVal.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
								String strTempDefectPC = (String)mapRFAVal.get(PWCRFAEarlyDetectionConstants.STR_PART_CONDITION);
								if(strDefectType.equals("Combined")){
									strKey = (Set)mCombined.keySet();
									Iterator itr = strKey.iterator();

									while(itr.hasNext()){
										 String key = (String)itr.next();
										 String value = (String)mCombined.get(key);
										 String toMatchValue = (String)mapRFAVal.get("attribute["+key+"]");

										 if(value.equals(toMatchValue)){
											 isMatch= true;
										 }
										 else{
											 isMatch= false;
											 break;
										 }
									 }
								}
								else if(strDefectType.equals("Engine")){
									strKey = (Set)mEngine.keySet();
									Iterator itr = strKey.iterator();
									while(itr.hasNext()){
										 String key = (String)itr.next();
										 String value = (String)mEngine.get(key);
										 String toMatchValue = (String)mapRFAVal.get("attribute["+key+"]");
										if(value.equals(toMatchValue)){
											 isMatch= true;
										 }
										 else{
											 isMatch= false;
											 break;
										 }
									 }
								
								}
								else if(strDefectType.equals("Part")){
									strKey = (Set)mPart.keySet();
									strW2Key = (Set)mW2Part.keySet();
									strW2NoMatchKey = (Set)mW2NoMatchPart.keySet();
									Iterator itrW1 = strKey.iterator();
									Iterator itrW2 = strW2Key.iterator();
									Iterator itrnoMatchW2 = strW2NoMatchKey.iterator();
									while(itrW1.hasNext()){
										 String key = (String)itrW1.next();
										 String value = (String)mPart.get(key);
										 String toMatchValue = (String)mapRFAVal.get("attribute["+key+"]");

										 if(value.equals(toMatchValue)){
											 isMatch= true;
											 isW1Match = true;
										 }
										 else{
											 
											 isMatch= false;
											 break;
										 }
									 }
									 if(!isMatch)
											while(itrW2.hasNext()){
												 String keyW2 = (String)itrW2.next();
												 String valueW2 = (String)mW2Part.get(keyW2);
												 String toW2MatchValue = (String)mapRFAVal.get("attribute["+keyW2+"]");

												 if(valueW2.equals(toW2MatchValue)){
													 isMatch= true;
												 }
												 else{
													 
													 isMatch= false;
													 break;
												 }
											}
									 if(isMatch && !isW1Match){
											while(itrnoMatchW2.hasNext()){
												 String keyNoMatchW2 = (String)itrnoMatchW2.next();
												 String valuenoMatchW2 = (String)mW2NoMatchPart.get(keyNoMatchW2);
												 String toW2MatchValue = (String)mapRFAVal.get("attribute["+keyNoMatchW2+"]");;

												 if(!valuenoMatchW2.equals(toW2MatchValue)){
													 isMatch= true;
												 }
												 else{
													 
													 isMatch= false;
													 break;
												 }
											}						 
									 }
									 
									 }
								
								}
							if(isMatch && !mDefectArrayList.contains(strtempDefect) && !strCurrent.equals(PWCRFAEarlyDetectionConstants.STATE_POLICY_ED_DEFECT)){
								String strTempDefectType =  (String)mapRFAVal.get("attribute["+PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_TYPE+"]");
								if(strTempDefectType.equals(strDefectType)){
								dommatchingDefObj = DomainObject.newInstance(context,strtempDefect);
								mDefectArrayList.add(strtempDefect);
								bMatchingDef = true;
								}
								//else{
									//bMatchingDef = false;
								//}
							}						
						}
						}
						
					}
				}
			}

if(bMatchingDef){
				//int iDefSize = mDefectArrayList.size();
				//for(int i=0;i<iDefSize;i++){

				strFixedAlert = dommatchingDefObj.getInfo(context, "relationship["+PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_ALERT+"].to.id");
				if(null!=strFixedAlert && !strFixedAlert.equals("null")&& !strFixedAlert.equals(""))
				{					
				DomainObject dobjFixAlert = DomainObject.newInstance(context,strFixedAlert);
			    slRelSelect.add("attribute[" + PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ALERT_TIMESTAMP + "]");

				MapList  mtotalDefect = dobjFixAlert.getRelatedObjects(context, 	// context
						PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_ALERT,	// relpattern
						PWCRFAEarlyDetectionConstants.TYPE_DEFECT_DEVIATION,// type pattern
						slBusSelect,								// bus select
						slRelSelect, 							// rel select
						true, 									// get to
						false, 									// get from					
						(short) 1, 								// one level
						DomainConstants.EMPTY_STRING, 			// object where
						DomainConstants.EMPTY_STRING,			// rel where
						0);
				iAlertCount = mtotalDefect.size();
				if (mtotalDefect.size()>0)
				{
					for(int i=0;i<mtotalDefect.size();i++){
						String strTimeStampZero = (String) ((Map)mtotalDefect.get(i)).get("attribute[" + PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ALERT_TIMESTAMP + "]");
						String strMatchingDefect = (String) ((Map)mtotalDefect.get(i)).get(DomainConstants.SELECT_ID);
						if(strTimeStampZero.equals("0")){
						//Fix for production issue 35 starts
						DomainObject dobjBaseDefect = DomainObject.newInstance(context,strMatchingDefect);
						String strBaseEventDate = getEventDate(context,dobjBaseDefect);
						baseDate = new Date(strBaseEventDate);
						baseRFATime = baseDate.getTime();
						}
					}
						//added for production bug fix 35 starts
						String strEventDate = getEventDate(context,dobjDefect);
						rfaDate = new Date(strEventDate);
						otherRFATime = rfaDate.getTime();
						differenceInMillis = otherRFATime -baseRFATime;
						//conversion from millisecond to days
						differenceInMillis = differenceInMillis / (24*60*60*1000);
						//added for production bug fix 35
				

						//Fix for production issue 35 starts
						DomainRelationship dRel = DomainRelationship.connect(context,dobjDefect,PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_ALERT,dobjFixAlert);
						dobjFixAlert.setAttributeValue(context,PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ALERT_TYPE, strAlertType);
						dRel.setAttributeValue(context,PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ALERT_TIMESTAMP, Long.toString(differenceInMillis));
						bReuse = true;

				}
				if(!bReuse){
					int imatchSize = mDefectArrayList.size();
					//for(int i=0;i<imatchSize;i++){
					//DomainObject dobjTempDefect = DomainObject.newInstance(context,mDefectArrayList.get(i).toString());
					if (null!=mtotalDefect &&  mtotalDefect.size()>0)
					{
						DomainRelationship.disconnect(context, (String) ((Map)mtotalDefect.get(0)).get(DomainObject.SELECT_RELATIONSHIP_ID));
						
						  String strTempAlert = (String) ((Map)mtotalDefect.get(0)).get(new StringBuilder("relationship[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_ALERT)
									.append("].to.id").toString());
						  DomainObject dobjTempAlert = DomainObject.newInstance(context,strTempAlert);
								dobjTempAlert.deleteObject(context);
						 
					}
					strFixedAlert = createAndConnectAlertObject(context,connectDefectId,strAlertType,mDefectArrayList);
					
			//}
				}
			}
			else{
					strFixedAlert = createAndConnectAlertObject(context,connectDefectId,strAlertType,mDefectArrayList);

				}
			}
			else{
				strFixedAlert = createAndConnectAlertObject(context,connectDefectId,strAlertType,mDefectArrayList);
				
			}

		} catch (Exception t) {
			LOG.error("Exception in PWCRFAEarlyDetectionUtil : connectAlertToDefects : "
					+ t.getMessage());
		}
		finally
		{
			if (isAccessGranted)
			{
				PWCCommonUtil.revokeAccessGrantedToRFA(context,dobjDefect);
			}
		}
		LOG.debug("End of PWCRFAEarlyDetectionUtil : connectAlertToDefects");
		return strFixedAlert;
	}
	/**
	 * The function gets the information on Engine and Part connected to RFA object
	 * 
	 * @param context
	 * @param Object
	 *            Id
	 * @return - MapList
	 * @throws Exception
	 *             when problems occurred
	 */
	public static String getEventDate(Context context, DomainObject dObjDefect)
			throws Exception {
		LOG.debug("Start of PWCRFAEarlyDetectionUtil: getEventDate");
		String strEventDate =  "";
		try {

			String strRFAId = dObjDefect.getInfo(context,"relationship["+PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_DEFECT+"].from.id");
			DomainObject domRFA = DomainObject.newInstance(context,strRFAId);
			strEventDate = domRFA.getAttributeValue(context,PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_DATE);

		} catch (Exception ex) {
			LOG.error("Exception in PWCRFAEarlyDetectionUtil: getEventDate : "
					+ ex.getMessage());
		}

		LOG.debug("End of PWCRFAEarlyDetectionUtil: getEventDate");
		return strEventDate;

	}
	
	/**
	 * The function checks if the engine info is the primary data or not
	 * 
	 * @param context
	 * @param Object
	 *            Id
	 * @return - MapList
	 * @throws Exception
	 *             when problems occurred
	 */	public static String getPrimaryData(Context context,String rfaObjectId)throws Exception
	{
		String returnValue = "";  
		// Create Domain Object of RFA Object
		DomainObject RFAObj = DomainObject.newInstance(context, rfaObjectId);
		String strExpression = new StringBuilder("from[").append(PWCConstants.RELATIONSHIP_PWC_RFA_PRIMARY_DATA).append("].torel[")
				.append(PWCConstants.RELATIONSHIP_PWC_RFA_ENGINE_INFO).append("].to.id").toString();

		String strValue = RFAObj.getInfo(context, strExpression);
		if(!UIUtil.isNullOrEmpty(strValue))
		{
			returnValue = strValue;
		}

		return returnValue;
	}	
}
