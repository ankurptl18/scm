package com.ds.report.utils;

public abstract class XmlReportConstants 
{
	//XmlReportBuilder & XmlReportLoader
	public static final String NODE_TOP_COMPONENT = "top_component";
	public static final String NODE_COMPONENT = "component";
	public static final String NODE_LABEL = "label";
	public static final String NODE_VALUE = "value";
	
	//ApplicabilityProvider
	public static final String NODE_PENDING = "Pending";
	public static final String NODE_ECO_ADD = "ECO_ADD";
	public static final String NODE_ECO_CUT = "ECO_CUT";
	public static final String NODE_ECO = "ECO";
	public static final String NODE_APPLICABILITY = "APPLICABILITY";
	public static final String APPLICABILITY_STATUS_PENDING = "Pending";
	
	//EffectivityProvider
	public static final String NODE_CURRENT_EFFECTIVITY = "CURRENTEFFECTIVITY";
	public static final String APPLICABILITY_STATUS_RELEASED = "Released";
	public static final String ATTR_NAME = "NAME";
	public static final String ATTR_TYPE = "TYPE";
	public static final String ATTR_REVISION = "REVISION";
	
	//EbomChecker

	public static final String UPPER_STRUCT_SEPARATOR = "|";
	
	
	//EbomStructureCompare
	//SELECT_TYPE is mapped to the "name" attribute's value of the tag "select" from the query template xml
	//COMPUTE_TOTAL_QUANTIITY is computed by the checker
	public static final String SELECT_TYPE = "type";
	public static final String SELECT_NAME = "name";
	public static final String SELECT_REVISION = "revision";
	public static final String SELECT_FIND_NUMBER = "find_number";
	public static final String SELECT_QUANTITY = "quantity";
	public static final String SELECT_USAGE = "usage";
	public static final String SELECT_APPLICABILITY = "applicability";
	public static final String SELECT_EFFECTIVITY = "effectivity";
	public static final String SELECT_PUE_ECO = "pue_eco";
	public static final String COMPUTE_TOTAL_QUANTITY = "total_quantity";
	public static final String COMPUTE_UPPER_STRUCTURE = "upper_structure";
	public static final String COMPUTE_IMMEDIATE_PARENT = "immediate_parent";
	
	
	public static final String LIST_CHANGES = "changes";
	public static final String BEAN_REMOVED = "removed";
	public static final String BEAN_ADDED = "added";
	
	
	
	
}
