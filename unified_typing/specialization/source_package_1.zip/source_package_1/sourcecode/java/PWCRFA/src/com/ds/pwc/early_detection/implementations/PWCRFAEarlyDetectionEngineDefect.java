package com.ds.pwc.early_detection.implementations;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import matrix.db.Context;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import com.ds.common.PWCConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionRFAData;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionUtil;
import com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionCalculatorFactory;
import com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionSeverityCalculator;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionCalculator;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionDefect;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCRFAEarlyDetectionEngineDefect implements IPWCRFAEarlyDetectionDefect {
	private static final Logger LOG = Logger.getLogger("PWCRFAEarlyDetectionEngineDefect");
	/**
	 * The function is to create an ED Object of type "Engine"
	 * 
	 * @param context
	 * @param EngineInfo
	 *            Maplist
	 * @param integer
	 *            EngineInfosize
	 * @param String
	 *            RFA Object
	 * @return - Map connectionAttrRFAMap
	 * @throws Exception
	 *             when problems occurred
	 */
	public Vector calculateDefectDeviation(Context context,PWCRFAEarlyDetectionRFAData rfaData)  {
		
		LOG.debug("Start of PWC_RFAEarlyDection:createEngineDefectDeviation");
		String strDefectCategory = "";
		double EngineWiQi = 0.0;
		int iRecurrenceE = 0;

		String strEngineModel = "";
		String strEngineModelFly = "";
		MapList engineInfo = rfaData.getEnginesInfo();
		int iEngine = engineInfo.size();
		HashMap hMap = null;
		HashMap hVSMMap = new HashMap();
		String strDefectId = "";
		DomainObject dObjDefect;
		Vector vDefects =  new Vector();
		Vector vAlertIds =  new Vector();
		boolean showAlert = false;
		Vector vAlerts =  new Vector();
		boolean bSymptomandCondition = false;
		
		// Creating format for the Decimal Number based on locale
		DecimalFormat format = new DecimalFormat("#.##",new DecimalFormatSymbols(context.getLocale()));
		
		// Getting info on Model,If no Model is connected then make null values blank
		String strModelCoefficient  = rfaData.getModelCoefficient();
		strEngineModel = rfaData.getModelName();
		strEngineModelFly = rfaData.getModelFly();
		int iIFSDLimitValue = rfaData.getIFSDValue();


		try {
			if (iEngine == 1)
				strDefectCategory = "Single";
			else
				strDefectCategory = "Multiple";
			for (int i = 0; i < iEngine; i++) {
				// For each map from maplistEngine get attribute PWC_RFA Engine
				// Position , PWC_RFA Engine Symptom deviation , PWC_Engine
				// Condition,IFSD
				int iSeverityS1 = 0;
				int iSeverityS2 = 0;
				int iSeverityS3 = 0;
				double SFEC = 0.0;
				double SFES = 0.0;		
				Map engineMap = (Map) engineInfo.get(i);
				String strEnginePos = (String) engineMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_POSITION);
				String strEngineSymp = (String) engineMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
				String strEngineCon = (String) engineMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
				String strEngineIFSD = (String) engineMap.get(PWCRFAEarlyDetectionConstants.STR_REL_ENGINEINFO_IFSD);
				
				
				if(!DomainConstants.EMPTY_STRING.equals(strEngineSymp) || !DomainConstants.EMPTY_STRING.equals(strEngineCon))
				{
					
				// Get Weights on PWC_RFA Engine Position , PWC_RFA Engine
				// Symptom deviation , PWC_Engine Condition by getPartialSeverity()
				// i.e getting Partial Severities S1
				if (DomainConstants.EMPTY_STRING.equals(strEnginePos))
				{
					strEnginePos = "(Empty)" ;
				}	
					iSeverityS1 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,
							PWCRFAEarlyDetectionConstants.TYPE_EDM_CONFIG,PWCRFAEarlyDetectionConstants.STR_ENGINE_POSITION_NAME, strEnginePos,PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);

				// i.e getting Partial Severities S2                       
				if (!strEngineSymp.equals("")) {
					iSeverityS2 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,
							PWCRFAEarlyDetectionConstants.TYPE_ENGINE_SYMPTOM, strEngineSymp,
							"1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);

					if (iSeverityS2 < iIFSDLimitValue
							&& (strEngineIFSD.equals(PWCRFAEarlyDetectionConstants.STR_COMMANDED_IFSD) || strEngineIFSD
									.equals(PWCRFAEarlyDetectionConstants.STR_UNCOMMANDED_IFSD)))
					{
						iSeverityS2 = iIFSDLimitValue;
					}
				}
				// i.e getting Partial Severities S3
				if (!strEngineCon.equals("") && UIUtil.isNullOrEmpty(strEngineSymp)) {
					iSeverityS3 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,
							PWCRFAEarlyDetectionConstants.TYPE_ENGINE_CONDITION, strEngineCon,
							"1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);
					if (iSeverityS3 < iIFSDLimitValue
							&& (strEngineIFSD.equals(PWCRFAEarlyDetectionConstants.STR_COMMANDED_IFSD) || strEngineIFSD
									.equals(PWCRFAEarlyDetectionConstants.STR_UNCOMMANDED_IFSD)))
					{
						iSeverityS3 = iIFSDLimitValue;
					}
				}
				System.out.println("Value of strEnginePos in Engine Defect => "+strEnginePos+" Value of strEngineSymp in Engine Defect => " + strEngineSymp+" Value of strEngineCon in Engine Defect=> " + strEngineCon);
				System.out.println("S1 :: "+iSeverityS1+"  S2 :: " + iSeverityS2+"  S3 :: " + iSeverityS3);

				PWCRFAEarlyDetectionEngineDefectData engineDefect = new PWCRFAEarlyDetectionEngineDefectData(context, rfaData.getRFAObjId());
				engineDefect.setStrPositionWeight(Integer.toString(iSeverityS1));
				if (!strEngineSymp.equals(""))
				{
					engineDefect.setStrPWCRFAEngineSymptomDeviation(strEngineSymp);
					engineDefect.setStrEngineSymptomWeight(Integer.toString(iSeverityS2));
				}
				if (!strEngineCon.equals(""))
				{
					engineDefect.setStrEngineConditionWeight(Integer.toString(iSeverityS3));
					engineDefect.setStrPWCEngineCondition(strEngineCon);
				}
				engineDefect.setStrPWCEnginePosition(strEnginePos);
				engineDefect.setStrEngineModelFamily(strEngineModelFly);
				engineDefect.setStrPWCRFAEngineModel(strEngineModel);
				engineDefect.setStrEDDefectMultiple(strDefectCategory);
				engineDefect.setStrEDDefectType("Engine");
				engineDefect.setStrEDEMCoefficient(strModelCoefficient);
				engineDefect.setStrEngineIFSD(strEngineIFSD);
			
				// Calculating Severities SFES/SFEC and adding them to Map to
				// store on Defect Object
				if (!DomainConstants.EMPTY_STRING.equals(strEngineSymp))
					SFES = Math.pow((iSeverityS1 * iSeverityS2), 1.0 / 2);
				
				if (!strEngineCon.equals("") &&  UIUtil.isNullOrEmpty(strEngineSymp))
					SFEC = Math.pow((iSeverityS1 * iSeverityS3), 1.0 / 2);
				
				if (null != strEngineSymp && (!DomainConstants.EMPTY_STRING.equals(strEngineSymp))) {
					engineDefect.setStrEDEngineDefectSeverity(format.format(SFES));
					hVSMMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SEVERITY, SFES);

				} else if(null != strEngineCon && (!DomainConstants.EMPTY_STRING.equals(strEngineCon)) &&  UIUtil.isNullOrEmpty(strEngineSymp)) {
					engineDefect.setStrEDEngineDefectSeverity(format.format(SFEC));
					hVSMMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SEVERITY, SFEC);
			}

				System.out.println("SFEC :: "+SFEC+"  SFES :: " + SFES);
				if(!UIUtil.isNullOrEmpty(strEngineSymp) && !UIUtil.isNullOrEmpty(strEngineCon)){
					strEngineCon = "";
					bSymptomandCondition = true;
				}
				Map mapDefectAttr = new HashMap();
				mapDefectAttr.put (PWCConstants.ATTRIBUTE_PWC_RFA_ENGINEMODEL,strEngineModel);
				mapDefectAttr.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_MODEL_FAMILY,strEngineModelFly);
				mapDefectAttr.put(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINE_SYMPTOM_DEVIATION,strEngineSymp);
				mapDefectAttr.put(PWCConstants.ATTRIBUTE_ENGINE_CONDITION,strEngineCon);
				mapDefectAttr.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT,strModelCoefficient);
				mapDefectAttr.put("SymptomAndCondition",bSymptomandCondition);

				if(!PWCRFAEarlyDetectionUtil.isSatisfiesVSMLimits(context,hVSMMap))	
				{		
				// Getting Similarity Rules NodesList from XML document,
				Document document = PWCRFAEarlyDetectionUtil.loadRuleDocument("SimilarityRules.xml");
				NodeList similarityRuleList = document.getElementsByTagName("SIMILARITYRULESENGINE");
	
				hMap = new HashMap();
				hMap.put("similarityRuleList", similarityRuleList);
				hMap.put("context", context);
				hMap.put("mapDefectAttr", mapDefectAttr);
				hMap.put("defect", engineDefect);
				hMap.put("rfaData", rfaData);
				hMap.put("from", "engine");

				IPWCRFAEarlyDetectionCalculator instanceWQ =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionFrequencyCalculator");
				Double dEngineWiQi = (Double)instanceWQ.calculate(hMap);
				EngineWiQi = dEngineWiQi.doubleValue();
			
				//double Ne = EngineWiQi * Double.parseDouble(strModelCoefficient);
				double Ne = EngineWiQi;
				engineDefect.setStrEDEngineDefectRecurrence(Integer.toString(iRecurrenceE));
				engineDefect.setStrEDEngineWeightedDefectFreq(format.format(Ne));
				System.out.println("Ne :: " + Ne);

				// Function to calculate recurrence for Defect type Engine
				// Getting Similarity Rules NodesList from XML document,
				Document documentR = PWCRFAEarlyDetectionUtil.loadRuleDocument("RecurrenceRules.xml");
				NodeList recurrenceEngineList = documentR.getElementsByTagName("RECURRENCEENGINE");
				hMap = new HashMap();
				hMap.put("recurrenceList", recurrenceEngineList);
				hMap.put("N", Ne);
				IPWCRFAEarlyDetectionCalculator instanceR =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionRecurrenceCalculator");
				Integer intRecurrenceE = (Integer)instanceR.calculate(hMap);
				iRecurrenceE = intRecurrenceE.intValue();
				engineDefect.setStrEDEngineDefectRecurrence(Integer.toString(iRecurrenceE));
				System.out.println("Re :: "+iRecurrenceE);
		
				// Function to calculate C K and P for Defect type Engine
				hMap.put("context", context);
				hMap.put("SFES", SFES);
				hMap.put("SFEC", SFEC);
				hMap.put("iRecurrenceP", iRecurrenceE) ;
				hMap.put("RFALocationRate", rfaData.getLocation());
				hMap.put("Type", "Engine");	
				hMap.put("defect", engineDefect);	
				IPWCRFAEarlyDetectionCalculator instance =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionCKPCalculator");
				Object iResult = instance.calculate(hMap);	
				
				//set Engine attributes
				engineDefect.setEngineAttributes(context);
				// If atleast one of the defect parameter > critical limit then show alert process.
				if (!PWCRFAEarlyDetectionUtil.isSatisfiesCriticalLimits(context,engineDefect)){
					/*if(!strEngineCon.equals(""))
					{
					vDefects.add("Engine Condition : "+strEngineCon); 
					}
					if(!strEngineSymp.equals(""))
					{
					vDefects.add("Engine Symptom :"+strEngineSymp); 
					}*/
					showAlert = true;
					String strDefectObject = engineDefect.getStrObjectId();
					String strAlertType = engineDefect.getAlertType();
					PWCRFAEarlyDetectionAlert alertObject = new PWCRFAEarlyDetectionAlert(context,strDefectObject,engineDefect,strAlertType);
					vAlerts.add(alertObject.getAlertName(context));
					vAlertIds.add(alertObject.getAlertId(context));

				}
			}
			else{
				engineDefect.setEngineAttributes(context);
			}

			}
		
		}
			
			
		//Commenting Alert Pop-up 	
		/*
		if(showAlert){
			//MqlUtil.mqlCommand(context, "notice $1","Critical limit exceeds for these Objects"+vDefects);
			MqlUtil.mqlCommand(context, "notice $1","Alert(s)\n Following alerts have been generated,please click OK to get the details :: "+vAlerts);
			}*/
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Exception in PWCRFAEarlyDetectionEngineDefect :createEDDefectDeviation : "
							+ ex.getMessage());
		}
		
		LOG.debug("End of PWCRFAEarlyDetectionEngineDefect :createEngineDefectDeviation");
		return vAlertIds;
	}


}
