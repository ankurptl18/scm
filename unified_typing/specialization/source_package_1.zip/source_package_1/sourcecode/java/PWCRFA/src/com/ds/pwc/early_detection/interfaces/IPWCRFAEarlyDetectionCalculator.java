package com.ds.pwc.early_detection.interfaces;
import java.util.HashMap;
import com.matrixone.apps.domain.util.MapList;

//Interface used by PWCRFAEarlyDetectionCKPCalculator.java ,PWCRFAEarlyDetectionRecurrenceCalculator.java
//to implement calculate()
public interface IPWCRFAEarlyDetectionCalculator {
	public abstract Object calculate(HashMap iMap);
}