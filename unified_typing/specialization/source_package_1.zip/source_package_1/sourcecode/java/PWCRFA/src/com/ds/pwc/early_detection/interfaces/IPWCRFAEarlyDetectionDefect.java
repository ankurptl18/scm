package com.ds.pwc.early_detection.interfaces;
import java.util.Vector;

import matrix.db.Context;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionRFAData;

//Interface used by PWCRFAEarlyDetectionCombinedDefect.java ,PWCRFAEarlyDetectionEngineDefect.java,PWCRFAEarlyDetectionPartDefect.java
//to implement calculateDefectDeviation()
public interface IPWCRFAEarlyDetectionDefect {
	Vector calculateDefectDeviation(Context context,PWCRFAEarlyDetectionRFAData rfaData);
}
