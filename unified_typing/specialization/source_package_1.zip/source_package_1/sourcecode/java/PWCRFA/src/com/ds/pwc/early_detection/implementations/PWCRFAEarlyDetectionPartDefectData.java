package com.ds.pwc.early_detection.implementations;
import java.io.Serializable;
import java.util.HashMap;
import matrix.db.Context;
import com.ds.common.PWCConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;


public class PWCRFAEarlyDetectionPartDefectData extends PWCRFAEarlyDetectionDefectData implements Serializable {
	private String strEDPartConditionWeight;
	private String strEDPartClassificationWeight;
	private String strPartCondition;
	private String strPartName;
	private String strPWCFamily;
	private String strPartNumber;
	private String strEDPNCoefficient;
	private String strEDPartDefectSeverity;
	private String strEDPartWeightedDefectFREQ;
	private String strEDPartDefectRL;
	private String strEDPartDefectSR;
	private String strEDPartDefectSRL;
	private String strEDPartDefectRecurrence;

	
	HashMap<String,String> attributeMap = new HashMap<String,String>();
	private String strPartSerialNumber;
	private String strPartQtyDef;	
	
	public PWCRFAEarlyDetectionPartDefectData() {
	}
	
	//Constructor for PWCRFAEarlyDetectionPartDefectData class to create defect Object and setting ObjectId
	public PWCRFAEarlyDetectionPartDefectData(Context context,String connectRFAObjId) throws Exception{
		String objId = PWCRFAEarlyDetectionUtil.createAndConnectDefect(context,PWCRFAEarlyDetectionConstants.INTERFACE_PART_DEFECT,connectRFAObjId);
		setStrObjectId(objId);
	}
	
	
	/**
	 * @return the strEDPartDefectRL
	 */
	public String getStrEDPartDefectRL() {
		return strEDPartDefectRL;
	}
	
	
	/**
	 * @param strEDPartDefectRL the strEDPartDefectRL to set
	 */
	public void setStrEDPartDefectRL(String strEDPartDefectRL) {
		this.strEDPartDefectRL = strEDPartDefectRL;
	}
	
	
	/**
	 * @return the strEDPartDefectSR
	 */
	public String getStrEDPartDefectSR() {
		return strEDPartDefectSR;
	}
	
	
	/**
	 * @param strEDPartDefectSR the strEDPartDefectSR to set
	 */
	public void setStrEDPartDefectSR(String strEDPartDefectSR) {
		this.strEDPartDefectSR = strEDPartDefectSR;
	}
	
	
	/**
	 * @return the strEDPartDefectSRL
	 */
	public String getStrEDPartDefectSRL() {
		return strEDPartDefectSRL;
	}
	
	
	/**
	 * @param strEDPartDefectSRL the strEDPartDefectSRL to set
	 */
	public void setStrEDPartDefectSRL(String strEDPartDefectSRL) {
		this.strEDPartDefectSRL = strEDPartDefectSRL;
	}
	
	
	/**
	 * @return the strEDPartConditionWeight
	 */
	public String getStrEDPartConditionWeight() {
		return strEDPartConditionWeight;
	}
	
	
	/**
	 * @param strEDPartConditionWeight the strEDPartConditionWeight to set
	 */
	public void setStrEDPartConditionWeight(String strEDPartConditionWeight) {
		this.strEDPartConditionWeight = strEDPartConditionWeight;
	}
	
	
	/**
	 * @return the strEDPartClassificationWeight
	 */
	public String getStrEDPartClassificationWeight() {
		return strEDPartClassificationWeight;
	}
	
	
	/**
	 * @param strEDPartClassificationWeight the strEDPartClassificationWeight to set
	 */
	public void setStrEDPartClassificationWeight(
			String strEDPartClassificationWeight) {
		this.strEDPartClassificationWeight = strEDPartClassificationWeight;
	}
	
	
	/**
	 * @return the strPartCondition
	 */
	public String getStrPartCondition() {
		return strPartCondition;
	}
	
	
	/**
	 * @param strPartCondition the strPartCondition to set
	 */
	public void setStrPartCondition(String strPartCondition) {
		this.strPartCondition = strPartCondition;
	}
	
	
	/**
	 * @return the strPartName
	 */
	public String getStrPartName() {
		return strPartName;
	}
	
	
	/**
	 * @param strPartName the strPartName to set
	 */
	public void setStrPartName(String strPartName) {
		this.strPartName = strPartName;
	}
	
	
	/**
	 * @return the strPWCFamily
	 */
	public String getStrPWCFamily() {
		return strPWCFamily;
	}
	
	
	/**
	 * @param strPWCFamily the strPWCFamily to set
	 */
	public void setStrPWCFamily(String strPWCFamily) {
		this.strPWCFamily = strPWCFamily;
	}
	
	
	/**
	 * @return the strPartNumber
	 */
	public String getStrPartNumber() {
		return strPartNumber;
	}
	
	
	/**
	 * @param strPartNumber the strPartNumber to set
	 */
	public void setStrPartNumber(String strPartNumber) {
		this.strPartNumber = strPartNumber;
	}
	

	/**
	 * @return the strEDPNCoefficient
	 */
	public String getStrEDPNCoefficient() {
		return strEDPNCoefficient;
	}
	
	
	/**
	 * @param strEDPNCoefficient the strEDPNCoefficient to set
	 */
	public void setStrEDPNCoefficient(String strEDPNCoefficient) {
		if(null == strEDPNCoefficient || strEDPNCoefficient.equals("")){
			strEDPNCoefficient = "1";
		}
		this.strEDPNCoefficient = strEDPNCoefficient;
	}
	
	
	/**
	 * @return the strEDPartDefectSeverity
	 */
	public String getStrEDPartDefectSeverity() {
		return strEDPartDefectSeverity;
	}
	
	
	/**
	 * @param strEDPartDefectSeverity the strEDPartDefectSeverity to set
	 */
	public void setStrEDPartDefectSeverity(String strEDPartDefectSeverity) {
		this.strEDPartDefectSeverity = strEDPartDefectSeverity;
	}
	
	
	/**
	 * @return the strEDPartWeightedDefectFREQ
	 */
	public String getStrEDPartWeightedDefectFREQ() {
		return strEDPartWeightedDefectFREQ;
	}
	
	
	/**
	 * @param strEDPartWeightedDefectFREQ the strEDPartWeightedDefectFREQ to set
	 */
	public void setStrEDPartWeightedDefectFREQ(String strEDPartWeightedDefectFREQ) {
		this.strEDPartWeightedDefectFREQ = strEDPartWeightedDefectFREQ;
	}
	
	
	/**
	 * @return the strComparisionAttribute
	 */
	public String getAttributeValue(String strComparisionAttribute) {
		return attributeMap.get(strComparisionAttribute);
	}
	

	/**
	 * @return the strEDPartDefectRecurrence
	 */
	public String getStrEDPartDefectRecurrence() {
		return strEDPartDefectRecurrence;
	}
	

	/**
	 * @param strEDPartDefectRecurrence the strEDPartDefectRecurrence to set
	 */
	public void setStrEDPartDefectRecurrence(String strEDPartDefectRecurrence) {
		this.strEDPartDefectRecurrence = strEDPartDefectRecurrence;
	}
	
	
	void setPartAttributes(Context context){
		//Part Attributes
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_RL, strEDPartDefectRL);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SR, strEDPartDefectSR);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SRL, strEDPartDefectSRL);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_RECURRENCE,strEDPartDefectRecurrence);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_CONDITION_WEIGHT,strEDPartConditionWeight);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_CLASSIFICATION_WEIGHT,strEDPartClassificationWeight);
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_CONDITION, strPartCondition);
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_NAME, strPartName);
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_FAMILY, strPWCFamily);
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_NUMBER, strPartNumber);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_MULTIPLE,this.getStrEDDefectMultiple());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_TYPE, this.getStrEDDefectType());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT, strEDPNCoefficient);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_RECURRENCE,strEDPartDefectRecurrence);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_MODEL_FAMILY, this.getStrEngineModelFamily());
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINEMODEL, this.getStrPWCRFAEngineModel());
		
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SEVERITY,strEDPartDefectSeverity);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_WEIGHTED_DEFECT_FREQ,strEDPartWeightedDefectFREQ);
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_SERIAL_NUMBER,strPartSerialNumber);
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_QTY_DEF,strPartQtyDef);
					
		//Getting ID of Defect Object generated ,setting attribute values for the Defect Object 
		try {
			String strDefectObject = getStrObjectId();
			DomainObject dObj = DomainObject.newInstance(context,strDefectObject);
			dObj.setAttributeValues(context, attributeMap);
		} catch (FrameworkException e) {
			e.printStackTrace();
		}	

	}

	public void setStrPWCRFASerialNumber(String strPartSerialNumber) {
		this.strPartSerialNumber = strPartSerialNumber;
		
	}

	public void setStrPWCRFAQtyDefect(String strPartQtyDef) {
		this.strPartQtyDef = strPartQtyDef;
		
	}
	public String getStrPWCRFASerialNumber( ) {
		return strPartSerialNumber;
		
	}

	public String getStrPWCRFAQtyDefect( ) {
		return strPartQtyDef;
		
	}
	
}
