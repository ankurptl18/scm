package com.ds.apps.metrics.ui;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import matrix.db.AttributeType;
import matrix.db.Context;
import matrix.util.StringList;

import com.ds.apps.metrics.PWCRFAMetricsReports;
import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.metrics.MetricsReports;

public class PWCRFAUIMetricsReports extends com.matrixone.apps.metrics.ui.UIMetricsReports {

	private static Logger _logger = Logger.getLogger("PWCRFAUIMetricsReports");
	private static final String COMMA = ",";

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map uiTabularColumnHeaderMappings = Collections.synchronizedMap(new TreeMap());

	public static StringList getAllSubTypePolicies(Context context, String type) {
		try {
			Method m = com.matrixone.apps.metrics.ui.UIMetricsReports.class.getDeclaredMethod("getAllSubTypePolicies", new Class[] { context.getClass(),
			        String.class });
			m.setAccessible(true);
			Object value = m.invoke(null, context, type);
			m.setAccessible(false);
			return (StringList) value;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public StringList prepareObjectCountColumnHeaders(Context context, Map chartDetailsMap, String strGroupBy, String strGroupByAlt, String strSubGroup, String strType,
	        String strLanguage) throws FrameworkException {
		_logger.debug( new StringBuilder().append("PWCRFAUIMetricsReports::prepareObjectCountColumnHeaders - start with groupby=[").append(strGroupBy).append("] and alt group by=[").append(strGroupByAlt).append("] and sub group=[").append(strSubGroup).append("]").toString() );
		StringList colHeaders = new StringList();
		try {
			String grpByi18n = strGroupByAlt == null ? strGroupBy : strGroupByAlt;
			try {
				grpByi18n = i18nNow.getBasicI18NString(grpByi18n, strLanguage);
			} catch (Exception e) {
				grpByi18n = i18nNow.getAttributeI18NString(grpByi18n, strLanguage);
			}
			colHeaders.add(grpByi18n);
			uiTabularColumnHeaderMappings.put(grpByi18n, strGroupBy);

			if ((strSubGroup != null) && (!"".equals(strSubGroup))) {
				if ("current".equals(strSubGroup)) {

					Set chartDetailsMapKeySet = chartDetailsMap.keySet();
					TreeMap stateMap = new TreeMap();
					
					MetricsReports mr = new MetricsReports();
					StringList policies = getAllSubTypePolicies(context, strType);

					for (Iterator itr = policies.iterator(); itr.hasNext();) {
						String policy = (String) itr.next();
						for (Iterator statesItr = mr.getStateNames(context, policy).iterator(); statesItr.hasNext();) {
							String state = (String) statesItr.next();
							if (chartDetailsMapKeySet.contains(state)) {
								String statei18n = i18nNow.getStateI18NString(policy, state, context.getSession().getLanguage());
								stateMap.put(state, statei18n);
							}
						}
					}
					
					for (Iterator stateMapKeysItr = stateMap.keySet().iterator(); stateMapKeysItr.hasNext();) {
						String statei18n = (String) stateMapKeysItr.next();
						String state = (String) stateMap.get(statei18n);
						colHeaders.add(statei18n);
						//Modification starts - To fix issue, Array Index Out Of Bound for Active RFA Report and Who Has It Report.
						//uiTabularColumnHeaderMappings.put(statei18n, state);
						uiTabularColumnHeaderMappings.put(statei18n, statei18n);
						//Modification starts - To fix issue, Array Index Out Of Bound for Active RFA Report and Who Has It Report.
					}
					
				} else if ("status_report_category".equals(strSubGroup)) {
					Set chartDetailsMapKeySet = chartDetailsMap.keySet();
					for (Iterator itr = chartDetailsMapKeySet.iterator(); itr.hasNext();) {
						String subGrpByRangeListMember = (String) itr.next();
						if ("CellNumber,SummaryResultsList,Originated".indexOf(subGrpByRangeListMember) == -1 && !colHeaders.contains(subGrpByRangeListMember)) {
							colHeaders.add(subGrpByRangeListMember);
							uiTabularColumnHeaderMappings.put(subGrpByRangeListMember, subGrpByRangeListMember);
						}
					}

					final StringList subGrpByRangeList4Sort = FrameworkUtil.split(
							EnoviaResourceBundle.getProperty(context, "pwcRFAMetrics.MetricsReports.RFAStatusRangeY"), ",");

                    Collections.sort(colHeaders.subList(1, colHeaders.size()), new Comparator() {
                        public int compare(Object s1, Object s2) {
                            int i = subGrpByRangeList4Sort.indexOf(s1);
                            int j = subGrpByRangeList4Sort.indexOf(s2);

                            if (i < j)
                                return 1;
                            if (i > j)
                                return -1;
                            if (i == j)
                                return 0;

                            return 0;
                        }
                    });

				} else if ("act_graph_severity".equals(strSubGroup)) {

					StringList subGrpByRangeList = FrameworkUtil
					        .split(EnoviaResourceBundle.getProperty(context, "pwcRFAMetrics.MetricsReports.ActivityGraphRangeY"), ",");

					Set chartDetailsMapKeySet = chartDetailsMap.keySet();
					for (Iterator subGrpByRangeListItr = subGrpByRangeList.iterator(); subGrpByRangeListItr.hasNext();) {
						String subGrpByRangeListMember = (String) subGrpByRangeListItr.next();
						String subGrpByRangeListMemberi18n;
						if (chartDetailsMapKeySet.contains(subGrpByRangeListMember)) {
							subGrpByRangeListMemberi18n = EnoviaResourceBundle.getProperty(context, super.METRICS_STRING_RESOURCE_BUNDLE, context.getLocale(), "pwcRFAMetrics.ActivityGraph." + subGrpByRangeListMember);
							
							colHeaders.add(subGrpByRangeListMemberi18n);
							uiTabularColumnHeaderMappings.put(subGrpByRangeListMemberi18n, subGrpByRangeListMember);
						}
					}

				} else if ("whohasit_severity".equals(strSubGroup)) {

					StringList subGrpByRangeList = FrameworkUtil.split(EnoviaResourceBundle.getProperty(context, "pwcRFAMetrics.MetricsReports.WhoHasItRangeX"), ",");

					java.util.Set chartDetailsMapKeySet = chartDetailsMap.keySet();
					for (Iterator subGrpByRangeListItr = subGrpByRangeList.iterator(); subGrpByRangeListItr.hasNext();) {
						String subGrpByRangeListMember = (String) subGrpByRangeListItr.next();
						String subGrpByRangeListMemberi18n;
						if (chartDetailsMapKeySet.contains(subGrpByRangeListMember)) {
							if ("No Active Task".equals(subGrpByRangeListMember)) {
								subGrpByRangeListMemberi18n = EnoviaResourceBundle.getProperty(context, super.METRICS_STRING_RESOURCE_BUNDLE, context.getLocale(), "pwcRFAMetrics.WhoHasItReport.NoActiveTask");
							} else {
								subGrpByRangeListMemberi18n = i18nNow.getRangeI18NString(strSubGroup, subGrpByRangeListMember, strLanguage);
							}
							colHeaders.add(subGrpByRangeListMemberi18n);
							uiTabularColumnHeaderMappings.put(subGrpByRangeListMemberi18n, subGrpByRangeListMember);
						}
					}

				} else {
					StringList subGrpAttrRanges = new StringList();
					
                    // put manual ranges in string resource file
					if(strSubGroup.equalsIgnoreCase(PropertyUtil.getSchemaProperty("attribute_PWC_RFAEventImpact")))
					{
						subGrpAttrRanges = PWCRFAMetricsReports.getAllRanges(context, "attribute_PWC_RFAEventImpact");
					}
					else if(strSubGroup.equalsIgnoreCase(PropertyUtil.getSchemaProperty("attribute_PWC_RFALiableGroup")))
					{
						subGrpAttrRanges = PWCRFAMetricsReports.getAllRanges(context, "attribute_PWC_RFALiableGroup");
					}
					else if(strSubGroup.equalsIgnoreCase("Event Location"))
					{
						subGrpAttrRanges = PWCRFAMetricsReports.getAllRanges(context, "Event Location");
					}
					else if(strSubGroup.equalsIgnoreCase(PropertyUtil.getSchemaProperty("attribute_PWC_RFAEventType")))
					{
						subGrpAttrRanges = PWCRFAMetricsReports.getAllRanges(context, "attribute_PWC_RFAEventType");
					}
					else if(strSubGroup.equalsIgnoreCase(PropertyUtil.getSchemaProperty("attribute_PWC_RFAProcessSubType")))
					{
						subGrpAttrRanges = PWCRFAMetricsReports.getAllRanges(context, "attribute_PWC_RFAProcessSubType");
					}
					else if(strSubGroup.equalsIgnoreCase(PropertyUtil.getSchemaProperty("attribute_PWC_IPTID")))
					{
						subGrpAttrRanges = PWCRFAMetricsReports.getAllRanges(context, "attribute_PWC_IPTID");
					}
					else if(strSubGroup.equalsIgnoreCase(PropertyUtil.getSchemaProperty("attribute_PWC_RFAStepProblemFound")))
					{
						subGrpAttrRanges = FrameworkUtil.split(EnoviaResourceBundle.getProperty(context, "pwcComponents.RFAActivityReport.ProblemFoundDuring.Range"), ",");
					}
					else if(strSubGroup.equalsIgnoreCase(PropertyUtil.getSchemaProperty("attribute_IssueClassification")))
					{
						subGrpAttrRanges = FrameworkUtil.split(EnoviaResourceBundle.getProperty(context, "pwcComponents.RFAActivityReport.SubType.Range"), ",");
					}
					else if(strSubGroup.equalsIgnoreCase("Engine Family"))
					{
						subGrpAttrRanges = PWCRFAMetricsReports.getAllRanges(context, "Engine Family");
					}
					else
					{
					AttributeType subGrpAttr = new AttributeType(strSubGroup);
					subGrpAttr.open(context);
					subGrpAttrRanges = FrameworkUtil.getRanges(context, strSubGroup);
					subGrpAttr.close(context);
					}
					
					if ((subGrpAttrRanges != null) && (subGrpAttrRanges.size() > 0)) {
						Set chartDetailsMapKeySet = chartDetailsMap.keySet();
						for (Iterator subGrpAttrRangesItr = subGrpAttrRanges.iterator(); subGrpAttrRangesItr.hasNext();) {
							String subGrpAttrRangeVal = (String) subGrpAttrRangesItr.next();
							if (chartDetailsMapKeySet.contains(subGrpAttrRangeVal)) {
								String subGrpAttrRangeVali18n = internationalizedValue(context, "", "", strSubGroup, (String) subGrpAttrRangeVal, "Range");
								colHeaders.add(subGrpAttrRangeVali18n);
								uiTabularColumnHeaderMappings.put(subGrpAttrRangeVali18n, subGrpAttrRangeVal);
							}
						}
					}
					
				}
			} else {
				colHeaders.add(EnoviaResourceBundle.getProperty(context, "emxMetricsStringResource", context.getLocale(), "emxMetrics.label.TotalObjects"));
				uiTabularColumnHeaderMappings.put(EnoviaResourceBundle.getProperty(context, "emxMetricsStringResource", context.getLocale(), "emxMetrics.label.TotalObjects"), "Total Objects");
			}
            super.TABULAR_FORMAT_SETTINGS_MAP.put("Non Internationalized Column Headers", uiTabularColumnHeaderMappings);

		} catch (Exception e) {
			_logger.error( "PWCRFAUIMetricsReports::prepareObjectCountColumnHeaders - failed due to exception " + e.getMessage() );
			throw new FrameworkException("Building, Object Count Column Headers failed: " + e.toString().trim());
		}

		_logger.debug("PWCRFAUIMetricsReports::prepareObjectCountColumnHeaders - end");
		return colHeaders;
	}
	
	/* (non-Javadoc)
	 * Will prepare the rows for the tabular view even if the "group by" is generic
	 * @see com.matrixone.apps.metrics.ui.UIMetricsReports#prepareObjectCountRowHeaders(matrix.db.Context, java.util.Map, java.lang.String, java.lang.String)
	 */
	public StringList prepareObjectCountRowHeaders(Context context,Map chartDetailsMap,String strType,String strGroupBy) throws FrameworkException
	{
		_logger.debug( new StringBuilder().append("PWCRFAUIMetricsReports::prepareObjectCountRowHeaders - start with groupby=[").append(strGroupBy).append("] and type=[").append(strType).append("]").toString() );
		StringList finalRanges = super.prepareObjectCountRowHeaders( context, chartDetailsMap, strType, strGroupBy);
		
		// If no result is returned, it is probably because the group by is not handled by OOTB reporting
		if( finalRanges.isEmpty() ){
			String groupByValue = (String) chartDetailsMap.get(strGroupBy);
			if(groupByValue.indexOf(COMMA)!=-1)
			{
				if(groupByValue.lastIndexOf(COMMA)==(groupByValue.length() - 1))
				{
					groupByValue = groupByValue.substring(0,groupByValue.lastIndexOf(COMMA));
				}
				finalRanges = FrameworkUtil.split(groupByValue,COMMA);
			}
			else
			{
				finalRanges.add( groupByValue );
			}

		}
		if(finalRanges.size()==0)
		{
			finalRanges.addElement("");
		}
		_logger.debug( new StringBuilder().append("PWCRFAUIMetricsReports::prepareObjectCountRowHeaders - end with finalRanges size=[").append(finalRanges.size()).append("]").toString() );
		return finalRanges;
	}	
}