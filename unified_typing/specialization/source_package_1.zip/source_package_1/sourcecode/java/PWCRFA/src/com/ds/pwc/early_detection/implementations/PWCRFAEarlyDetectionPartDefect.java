package com.ds.pwc.early_detection.implementations;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import matrix.db.Context;
import matrix.util.StringList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.ds.common.PWCConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionRFAData;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionUtil;
import com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionCKPCalculator;
import com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionCalculatorFactory;
import com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionFrequencyCalculator;
import com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionRecurrenceCalculator;
import com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionSeverityCalculator;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionCalculator;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionDefect;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionCriticalimitEnum;

public class PWCRFAEarlyDetectionPartDefect implements IPWCRFAEarlyDetectionDefect{
	private static final Logger LOG = Logger.getLogger("PWC_RFAEarlyDection");
	/**
	 * The function is to create an ED Object of type "Part"
	 * 
	 * @param context
	 * @param mapObjPart
	 *            Maplist
	 * @param integer
	 *            iPart
	 * @param String
	 *            RFA Object
	 * @return - Map connectionAttrRFAMap
	 * @throws Exception
	 *             when problems occurred
	 */
	public Vector calculateDefectDeviation(Context context,PWCRFAEarlyDetectionRFAData rfaData) {
		LOG.debug("Start of  PWC_RFAEarlyDection:getCombinedDefectDeviationParameter");
		String strObjectId = "";
		String strDefectCategory = "";
		StringBuilder cmdMQL = new StringBuilder();
		double PartWiQi = 0.0;
		int iRecurrenceP = 0;
		MapList mapObjPart = rfaData.getPartInfo();
		int iPart = mapObjPart.size();
		HashMap hMap = null;
		int iCLimit =0;
		String strAttributeName ="";
		String strCode = "";
		String strLimitValue = "";	
		String strAttrToCompare = "";	
		HashMap hVSMMap = new HashMap();
		String strDefectId = "";
		DomainObject dObjDefect;
		Vector vDefects =  new Vector();
		Vector vAlerts =  new Vector();
		Vector vAlertIds =  new Vector();
		
		boolean showAlert = false;	
		boolean bSymptomandCondition = false;
		// Creating format for the Decimal Number based on locale
		DecimalFormat format = new DecimalFormat("#.##",
				new DecimalFormatSymbols(context.getLocale()));

		// Getting info from RFA Object
		String strRFALocationRate = rfaData.getLocation();
		String strEngineModel = rfaData.getModelName();
		String strEngineModelFly = rfaData.getModelFly();
		StringList defectSelectables = new StringList();
		defectSelectables.addElement(PWCRFAEarlyDetectionConstants.STR_PART_NUMBER);
		defectSelectables.addElement(PWCRFAEarlyDetectionConstants.STR_PART_FAMILY);
		defectSelectables.addElement(PWCRFAEarlyDetectionConstants.STR_PART_NAME);
		try {
			if (iPart == 1) {
				strDefectCategory = "Single";
			} else
				strDefectCategory = "Multiple";

			// For each map from mapObjPart get attribute PWC_RFA Part
			// Condition, PWC_RFA Part Name
			for (int j = 0; j < iPart; j++) {
				String strPartCoefficient = "0";
				int iSeverityS4 = 0;
				int iSeverityS5 = 0;
				double SFPC = 0.0;
				Map partMap = (Map) mapObjPart.get(j);
				String strPartCond = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_REL_PHYSICALPART_PC);
				String strPartName = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_PART_NAME);
				String strPartNumber = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_PART_NUMBER);
				String strPartFly = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_PART_FAMILY);
				String strPartSerialNumber = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_PART_SERIAL_NUMBER);
				String strPartQtyDef = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_QTY_DEF);
				if (DomainConstants.EMPTY_STRING.equals(strPartName))
				{
					strPartName = PWCRFAEarlyDetectionConstants.STR_PART_EMPTY ;
				}
				if(!DomainConstants.EMPTY_STRING.equals(strPartCond))
				{
				// Get Weights on PWC_RFA Part Condition, PWC_RFA Part Name by
				// getPartialSeverity()
				// i.e getting Partial Severities
				if (!DomainConstants.EMPTY_STRING.equals(strPartCond))
				{
					iSeverityS4 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,
							PWCRFAEarlyDetectionConstants.TYPE_PART_CONDITION, strPartCond, "1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);
				}
				if (!DomainConstants.EMPTY_STRING.equals(strPartName))
				{
					iSeverityS5 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,
							PWCRFAEarlyDetectionConstants.TYPE_PART_CLASSIFICATION, strPartName,
							"1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);
					
					strPartCoefficient = Integer.toString(PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,
							PWCRFAEarlyDetectionConstants.TYPE_PART_CLASSIFICATION,
							strPartName, "1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT));
			    	if(UIUtil.isNullOrEmpty(strPartCoefficient)){
			    		strPartCoefficient = "1";
			    	}
				}
				System.out.println("Value of strPartCond in Part Defect "+strPartCond+" Value of strPartName in Part Defect => " + strPartName);
				System.out.println("S4 :: "+iSeverityS4+"  S5 :: " + iSeverityS5);
				

				//Creating instance of PWCRFAEarlyDetectionPartDefectData and setting attributes
				PWCRFAEarlyDetectionPartDefectData partDefect = new PWCRFAEarlyDetectionPartDefectData(context,rfaData.getRFAObjId());
				partDefect.setStrEDPartConditionWeight(Integer.toString(iSeverityS4));
				partDefect.setStrEDPartClassificationWeight(Integer.toString(iSeverityS5));
				partDefect.setStrPartCondition(strPartCond);
				partDefect.setStrPartName(strPartName);
				partDefect.setStrPWCFamily(strPartFly);
				partDefect.setStrPartNumber(strPartNumber);
				partDefect.setStrEDDefectMultiple(strDefectCategory);
				partDefect.setStrEDDefectType("Part");
				partDefect.setStrEDPNCoefficient(strPartCoefficient);
				partDefect.setStrEngineModelFamily(strEngineModelFly);
				partDefect.setStrPWCRFAEngineModel(strEngineModel);	
				partDefect.setStrPWCRFASerialNumber(strPartSerialNumber);
				partDefect.setStrPWCRFAQtyDefect(strPartQtyDef);
				// Calculating Severities SFPC and adding them to Map to store
				// on Defect Object
				if (!DomainConstants.EMPTY_STRING.equals(strPartCond))
				{
					SFPC = Math.pow((iSeverityS4 * iSeverityS5), 1.0 / 2);
					partDefect.setStrEDPartDefectSeverity(format.format(SFPC));
					hVSMMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SEVERITY, SFPC);
				}
				System.out.println("SFPC :: "+SFPC);
				
				// If atleast one "S" > VSM then continue ED process where (S=SFESc, S=SFECc, S=SFES, S=SFEC or S=SFPC)
				if(!PWCRFAEarlyDetectionUtil.isSatisfiesVSMLimits(context,hVSMMap))	
				{
					
				// Getting Similarity Rules NodesList from XML document,
				Document document = PWCRFAEarlyDetectionUtil.loadRuleDocument("SimilarityRules.xml");
				NodeList similarityRulePartList = document.getElementsByTagName("SIMILARITYRULESPART");

				Map mapDefectAttr = new HashMap(); 

				mapDefectAttr.put(PWCConstants.ATTRIBUTE_PART_NUMBER,strPartNumber);
				mapDefectAttr.put(PWCConstants.ATTRIBUTE_PWC_FAMILY,strPartFly);
				mapDefectAttr.put(PWCConstants.ATTRIBUTE_PART_NAME,strPartName);
				mapDefectAttr.put(PWCConstants.ATTRIBUTE_PART_CONDITION,strPartCond);
				mapDefectAttr.put(PWCConstants.ATTRIBUTE_PART_SERIAL_NUMBER,strPartSerialNumber);
				mapDefectAttr.put(PWCConstants.ATTRIBUTE_PART_QTY_DEF,strPartQtyDef);
				mapDefectAttr.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT,strPartCoefficient);
				hMap = new HashMap();
				hMap.put("similarityRuleList", similarityRulePartList);
				hMap.put("context", context);
				hMap.put("mapDefectAttr", mapDefectAttr);
				hMap.put("defect", partDefect);
				hMap.put("rfaData", rfaData);			
				hMap.put("from", "part");
				mapDefectAttr.put("SymptomAndCondition",bSymptomandCondition);
				IPWCRFAEarlyDetectionCalculator instanceWQ =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionFrequencyCalculator");
				Double dPartWiQi = (Double)instanceWQ.calculate(hMap);
				PartWiQi = dPartWiQi.doubleValue();
				
				//double Np = PartWiQi * Double.parseDouble(strPartCoefficient);
				double Np = PartWiQi;
				partDefect.setStrEDPartWeightedDefectFREQ(format.format(Np));
				System.out.println("PART :: Np:: "+Np);


				// Function to calculate recurrence for Defect type Part
				// Getting Similarity Rules NodesList from XML document,
				Document documentR = PWCRFAEarlyDetectionUtil.loadRuleDocument("RecurrenceRules.xml");
				NodeList recurrencePartList = documentR.getElementsByTagName("RECURRENCEPART");
				hMap = new HashMap();
				hMap.put("recurrenceList", recurrencePartList);
				hMap.put("N", Np);
				IPWCRFAEarlyDetectionCalculator instanceR =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionRecurrenceCalculator");
				Integer intRecurrenceP = (Integer)instanceR.calculate(hMap);
				iRecurrenceP = intRecurrenceP.intValue();
				partDefect.setStrEDPartDefectRecurrence(Integer.toString(iRecurrenceP));
				System.out.println("PART :: Rp:: "+iRecurrenceP);
				
				// Function to calculate C K and P for Defect type Part
				hMap = new HashMap();
				hMap.put("context", context);
				hMap.put("SFPC", SFPC);
				hMap.put("iRecurrenceP", iRecurrenceP) ;
				hMap.put("RFALocationRate", strRFALocationRate);
				hMap.put("Type", "Part");
				hMap.put("defect", partDefect);	

				IPWCRFAEarlyDetectionCalculator instanceCKP =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionCKPCalculator");
				Object iResult = instanceCKP.calculate(hMap);
				//set Part attributes
				partDefect.setPartAttributes(context);
			
				// If atleast one of the defect parameter > critical limit then show alert process.
				if (!PWCRFAEarlyDetectionUtil.isSatisfiesCriticalLimits(context,partDefect)){
					//vDefects.add("Part Condition :"+strPartCond);
					showAlert = true;
					String strDefectObject = partDefect.getStrObjectId();
					String strAlertType = partDefect.getAlertType();
					PWCRFAEarlyDetectionAlert alertObject = new PWCRFAEarlyDetectionAlert(context,strDefectObject,partDefect,strAlertType);
					vAlerts.add(alertObject.getAlertName(context));
					vAlertIds.add(alertObject.getAlertId(context));

				}
			}
			else{
				partDefect.setPartAttributes(context);

			}
		}
		}
		//Commenting Alert Pop-up 	
		/*
		if(showAlert){
			//MqlUtil.mqlCommand(context, "notice $1","Critical limit exceeds for these Objects"+vDefects);
			MqlUtil.mqlCommand(context, "notice $1","Alert(s)\n Following alerts have been generated,please click OK to get the details :: "+vAlerts);
			}*/
		} catch (Exception ex) {
			LOG.error("Exception in PWC_RFAEarlyDectionPartDefect: createEDDefectDeviation : "+ ex.getMessage());
		}
		LOG.debug("End of PWC_RFAEarlyDectionPartDefect: createEDDefectDeviation");
		return vAlertIds;
	}


}
