package com.ds.pwc.crm.framework;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.StringList;

import org.apache.log4j.Logger;

import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.ds.pwc.crm.implementations.PWCRFACRMIntegrationRFA;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.exportcontrol.ExportControlConstants;
import com.matrixone.apps.framework.ui.UIUtil;


public class PWCRFACRMIntegrationManager
{
	private static final Logger _LOGGER = Logger.getLogger(PWCRFACRMIntegrationManager.class.getName());
	private static PWCRFACRMIntegrationProcessingInfoHolder objInfoHolder = null ;

	private static Context CONTEXT;
	private static PWCRFACRMIntegrationDataMappingHolder MAPPING_INSTANCE = null;
	public static StringList strLstClassification = new StringList();
	public static String strCRMDefaultClassification = DomainConstants.EMPTY_STRING;
	
	// Map for CRM Default Classification Names and IDs
	public static HashMap<String, HashMap <String, String>> CRM_DEFAULT_MAP = new HashMap<String, HashMap<String, String>>();
	
	private static String TO_LIST_ADMIN = null;
	private static String TO_LIST_NONADMIN = null;
	
	public PWCRFACRMIntegrationManager() throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationManager.class.getName()+"::PWCRFACRMIntegrationManager()");

		try
		{

			_LOGGER.debug("# Creating and connectiong the context");
			CONTEXT =  new Context(DomainConstants.EMPTY_STRING);
			PWCRFACRMIntegrationUtil.connectCRMIntegrationUser(CONTEXT);

			_LOGGER.debug("# Checking if the 'ServerUniquIdentifier' of the current server matches with the configured value");
			String sSUI = FrameworkUtil.getServerUniqueIdentifier(CONTEXT);
			String sConfiguredSUI = PWCRFACRMIntegrationUtil.getPropertyValue("PWCCRMIntegration.RFA.ServerUniqueIdentifier");
			if ( !sSUI.equalsIgnoreCase(sConfiguredSUI) ) 
			{
				_LOGGER.error( "The ServerUniquIdentifier of the current server '"+sSUI+"' does not match with the configured value of '"+sConfiguredSUI+"'" ) ;
				throw new Exception("The ServerUniquIdentifier of the current server '"+sSUI+"' does not match with the configured value of '"+sConfiguredSUI+"'");
			}

			_LOGGER.debug("# Initializing the 'DataMappingHolder'");
			MAPPING_INSTANCE = PWCRFACRMIntegrationDataMappingHolder.getInstance();

			_LOGGER.debug("# Loading the shared folders");
			PWCRFACRMIntegrationDataManipulator.loadSharedFolder();

			//TODO: initialise TO_LIST_ADMIN and TO_LIST_NONADMIN here
			TO_LIST_ADMIN = PWCRFACRMIntegrationUtil.getPropertyValue("PWCCRMIntegration.RFA.CRMIntegration.AdminUsers.Emails");
			TO_LIST_NONADMIN = PWCRFACRMIntegrationUtil.getPropertyValue("PWCCRMIntegration.RFA.CRMIntegration.NonAdminUsers.Emails");
			
			String sRFACoordinator = PWCRFACRMIntegrationUtil.getPropertyValue("PWCCRMIntegration.RFA.Coordinator.DefaultValue");
			
			if ( !PWCRFACRMIntegrationUtil.checkIfEVUserBOExists(CONTEXT, sRFACoordinator)) 
			{
				throw new Exception( "User '"+sRFACoordinator+"' does not exist " );
			}

			if ( !PWCRFACRMIntegrationUtil.checkIPInformationAvailability(CONTEXT)) 
			{
				throw new Exception( "IP Sensitivity Level and IP Source default objects are not found" );
			}			

		}catch(Exception e)
		{
			_LOGGER.error("Failed to initialize the IntegrationManger due to this error "+ PWCRFACRMIntegrationUtil.getStackTrace(e));

			StringList slTo = new StringList( TO_LIST_ADMIN.replaceAll("\\s", "").split(",") ) ;

			String sSubject = "CRM Integration Process Initialization failure notification" ;
			String sMsssage = new StringBuilder("Hello, \n\nPlease note that the CRM Integration Process has failed to start due to the error shown below: \n\n").append(PWCRFACRMIntegrationUtil.getStackTrace(e)).toString() ;

			try 
			{
				PWCRFACRMIntegrationUtil.sendMail( CONTEXT, slTo, new StringList(), sSubject, sMsssage, null );
			} catch (Exception e1) 
			{
				_LOGGER.error("Failed to send the CRM Integration Process Initialization failure notification due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			}

			throw e ;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationManager.class.getName()+"::PWCRFACRMIntegrationManager()");
	}

	/**
	 * This API disconnects the context
	 * It is called from Synchronous and the Asynchrounous web services
	 * 
	 * @param context
	 */
	public static void disconnectCRMIntegrationUser(  )
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationManager.class.getName()+"::disconnectCRMIntegrationUser()");

		try 
		{
			CONTEXT.shutdown();

		} catch (Exception e) 
		{
			_LOGGER.warn("Failed to disconnect the context");
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationManager.class.getName()+"::disconnectCRMIntegrationUser()");
	}

	public void initiateProcessing()
	{	
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationManager.class.getName()+"::initiateProcessing()");
		
		boolean isContextPushed = false;
		try
		{
			//read CRM files from shared folder	
			PWCRFACRMIntegrationDataManipulator crmData = new PWCRFACRMIntegrationDataManipulator();
			File[] crmFiles = crmData.readCRMFiles();

			HashMap<String,String> mCRMData = new HashMap<String,String>();
			for(File file:crmFiles)
			{
				try
				{
					ContextUtil.startTransaction(CONTEXT, true);

					// initialize the infoHolder instance
					objInfoHolder = PWCRFACRMIntegrationProcessingInfoHolder.getInstance();
					objInfoHolder.setDataFileName(file.getName());

					mCRMData = crmData.getCRMData(file);

					_LOGGER.debug("************************** Start of processing Data File '"+file.getName()+"' **************************");

					if( crmData.validateCRMFile( CONTEXT, mCRMData ) )
					{						

						objInfoHolder.logSuccess("AVM", "CRM Data File '"+file.getName()+"' validation is successful");

						PWCRFACRMIntegrationRFA objRFA = new PWCRFACRMIntegrationRFA( CONTEXT ) ;

						StringBuilder sbRFAOid = new StringBuilder();

						// Reset security Context to Project : Field Event and Org: Pratt and Whitney Canada
						String strSecContext = EnoviaResourceBundle.getProperty(CONTEXT, "PWCCRMIntegration.Default.SecurityContext");
						
						if (UIUtil.isNotNullAndNotEmpty(strSecContext))
						{
							CONTEXT.resetRole(strSecContext);
						}

						if( objRFA.checkIfRFAExists(mCRMData, sbRFAOid) )
						{
							objInfoHolder.logSuccess("ADD", "RFA Object already exists");

							objRFA.updateExistingRFA(mCRMData, sbRFAOid.toString());

						}
						else
						{
							objRFA.createNewRFA(mCRMData);
						}			
					}

				}catch(Exception e)
				{
					ContextUtil.abortTransaction(CONTEXT);

					objInfoHolder.logError("ADD", "Failed to process CRM Data File '"+file.getName()+"'");
					_LOGGER.error("Failed to process CRM Data File '"+file.getName()+"' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));

				}
				finally
				{
					_LOGGER.debug( "********************** Generating log file" ) ;

					String sStatus = objInfoHolder.getStatus();

					ArrayList alLog = objInfoHolder.generateLogFile();

					String sLogContent = (String) alLog.get(0) ;
					File fLogFile = (File) alLog.get(1) ;
					File[] files = { file, fLogFile } ;
					StringList slCc = new StringList();

					_LOGGER.debug( "********************** Generating zip file" ) ;

					String sZipFileAbsolutePath = DomainConstants.EMPTY_STRING ;
					String sTempDir = System.getProperty("java.io.tmpdir").trim() ;
					String sTimeStamp = PWCRFACRMIntegrationUtil.getCurrentTimeStamp();
					if ( System.getProperty("file.separator").toCharArray()[0] == sTempDir.charAt(sTempDir.length()-1) ) 
					{
						sZipFileAbsolutePath = ( new StringBuilder(sTempDir)).append(file.getName()).append("_").append(sTimeStamp).append(".zip").toString() ;
					}else
					{
						sZipFileAbsolutePath = ( new StringBuilder(sTempDir)).append(System.getProperty("file.separator")).append(file.getName()).append("_").append(sTimeStamp).append(".zip").toString() ;
					}
					
					if ( "KO".equals(sStatus) ) 
					{
						if ( null != fLogFile ) 
						{
							String[] arrSourceFile1AbsolutePaths 	= { file.getAbsolutePath(), fLogFile.getAbsolutePath() } ;
							String[] arrSourceFileNames 			= { file.getName(), fLogFile.getName() } ;

							PWCRFACRMIntegrationUtil.CreateZipOfMultipleFiles( arrSourceFile1AbsolutePaths, arrSourceFileNames, sZipFileAbsolutePath );

						}else // if log file is not generated then add only the data file
						{
							String[] arrSourceFile1AbsolutePaths 	= { file.getAbsolutePath() } ;
							String[] arrSourceFileNames 			= { file.getName() } ;

							PWCRFACRMIntegrationUtil.CreateZipOfMultipleFiles( arrSourceFile1AbsolutePaths, arrSourceFileNames, sZipFileAbsolutePath );
						}
					}

					File fZip = new File(sZipFileAbsolutePath) ;
					File fAttachment = null;

					if ( fZip.exists() ) 
					{
						fAttachment = fZip ;
					}

					boolean bIsFileMovedToDestination = false ;
					try 
					{
						_LOGGER.debug( "********************** Moving files to the destination folder" ) ;

						crmData.moveFilesToDestination( files );
						bIsFileMovedToDestination = true ;

					} catch (Exception e2) 
					{
						// In this case the whole transaction of this file has to be rolled back. 
						_LOGGER.error("Failed to move the 'CRM Data File' to distination folder due to this error: \n" + PWCRFACRMIntegrationUtil.getStackTrace(e2)) ;
					}
					
					
					/*
					 * Moved the Commit transaction code before sending email regarding the Integration status.
					 */
					if( ContextUtil.isTransactionActive(CONTEXT) )
					{
						if ( "KO".equals(sStatus) || !bIsFileMovedToDestination ) 
						{
							ContextUtil.abortTransaction(CONTEXT);
						}
						else
						{
							
							/*
							 * Modified code to push context to Super User before committing transaction on 18Mar2015.
							 * CRM integration was failing with exception "Transaction Aborted" while committing transaction.
							 * RFA was getting created but deferred triggers were not getting called and transaction failed Emails were sending to users. 
							 * This was because of the classification. Context person "PWCRFACRMIntegrationUser" (and owner too) doesn't have access to 
							 * the class. While committing, it internally checks for subScriptions of Class and because of no access it was failing in 
							 * emxSubscriptionBaseUtil.getSubscribers(). One solution was setting the physical location to 'PWCRFACRMIntegrationUser' 
							 * when creating the context, but this will not work for all cases. Because the RFA's can be classified to any class with
							 * different security rules. So the possible solution is to push context to super user and commit transaction. In that case 
							 * transaction is getting committed without fail, RFA gets created with all secondary ownership and connected objects.
							 * RFA Owner will be as per coordinator assignment and Originator will be PWCRFACRMIntegrationUser. This issue might need to 
							 * handle in IPP and other RFA (Routes) cases too.
							 */
							
							ContextUtil.pushContext(CONTEXT, PWCConstants.SUPER_USER, null, null);
							isContextPushed = true;
							
							ContextUtil.commitTransaction(CONTEXT);
							
							ContextUtil.popContext(CONTEXT);
							isContextPushed = false;
						}
					}
					
					try 
					{
						if( bIsFileMovedToDestination )
						{
							if ( "KO".equals(sStatus) )
							{
								_LOGGER.debug( "********************** Sending Email notification for KO status" ) ;

								StringList slTo = new StringList( TO_LIST_ADMIN.replaceAll("\\s", "").split(",") ) ;

								String sSubject = "'CRM Data File' processing failure notification" ;
								String sMsssage = DomainConstants.EMPTY_STRING ;
								if ( null == fLogFile ) 
								{
									sMsssage = new StringBuilder("Hello, \n\nPlease find attached the zip file containing the 'CRM Data File' and the corresponding log details as below as 'Log File' creation has failed: \n\n").append(sLogContent).toString() ;
								}else
								{
									sMsssage = "Hello, \nPlease find attached the zip file containing the 'CRM Data File' and the corresponding 'Log File' for more details." ;
								}

								PWCRFACRMIntegrationUtil.sendMail( CONTEXT, slTo, slCc, sSubject, sMsssage, fAttachment );

								_LOGGER.debug( "********************** Deleting zip file" ) ;
								if ( fZip.exists() ) 
								{
									fZip.delete() ;
								}

							}else if( "WARNING".equals(sStatus) )
							{
								_LOGGER.debug( "********************** Sending Email notification for WARNING status" ) ;

								StringList slTo = new StringList( TO_LIST_NONADMIN.replaceAll("\\s", "").split(",") ) ;

								String sSubject = "'CRM Data File' processing warning notification" ;
								String sMsssage = new StringBuilder("Hello, \n\nPlease find the 'CRM Data File' processing log as below: \n\n").append(sLogContent).toString() ;

								PWCRFACRMIntegrationUtil.sendMail( CONTEXT, slTo, slCc, sSubject, sMsssage, null );
							}
						}else
						{
							StringList slTo = new StringList( TO_LIST_ADMIN.replaceAll("\\s", "").split(",") ) ;

							String sSubject = "'CRM Data File' processing failure notification" ;
							String sMsssage = new StringBuilder("Hello, \n\nPlease note that the movement of the CRM Data File '"+file.getName()+"' to destination folder has failed and hence the file processing.").toString() ;

							PWCRFACRMIntegrationUtil.sendMail( CONTEXT, slTo, slCc, sSubject, sMsssage, fAttachment );
						}

					} catch (Exception e2) 
					{
						_LOGGER.error("Failed to send the email notification to CRM Integration Users due to this error: " + PWCRFACRMIntegrationUtil.getStackTrace(e2)) ;
					}

					
					objInfoHolder.clearInfo();
				}

				_LOGGER.debug("************************** End of processing Data File '"+file.getName()+"' **************************");
			}			
		}
		catch(Exception e)
		{
			_LOGGER.error("Failed to process CRM data due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));

			StringList slTo = new StringList( TO_LIST_ADMIN.replaceAll("\\s", "").split(",") ) ;

			String sSubject = "CRM Integration Process run failure notification" ;
			String sMsssage = new StringBuilder("Hello, \n\nPlease note that the CRM Integration Process has failed to process any data files during this perticular run due to the error shown below: \n\n").append(PWCRFACRMIntegrationUtil.getStackTrace(e)).toString() ;

			try 
			{
				PWCRFACRMIntegrationUtil.sendMail( CONTEXT, slTo, new StringList(), sSubject, sMsssage, null );
			} catch (Exception e1) 
			{
				_LOGGER.error("Failed to send the CRM Integration Process run failure notification due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			}
		}
		finally
		{
			if (isContextPushed)
			{
				try 
				{
					ContextUtil.popContext(CONTEXT);
					isContextPushed = false;
				} catch (FrameworkException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationManager.class.getName()+"::initiateProcessing()");
	}

	public static StringList getStrLstClassification() 
	{
		return strLstClassification;
	}

	public static void setStrLstClassification(StringList strClassificationIds) 
	{
		strLstClassification.clear();
		strLstClassification = strClassificationIds;
	}
	
	//Method added for CRM Default implementation	
	public static void getCRMDefaultClassifications(Context context) throws Exception{

		HashMap<String,HashMap<String,String>> mapEngClassMap = PWCRFACRMIntegrationDataMappingHolder.getInstance().mEngineClassificationMap;
		HashMap<String,String> mapDefaultClassification = (HashMap<String,String>) mapEngClassMap.get("CRMDefault");
		
		HashMap<String, String> mpCRMDefaultUSClassification = new HashMap<String, String>();
		HashMap<String, String> mpCRMDefaultUSExtClassification = new HashMap<String, String>();
		HashMap<String, String> mpCRMDefaultCAClassification = new HashMap<String, String>();
		
		String strClassId = DomainConstants.EMPTY_STRING;
		
		if (mapDefaultClassification != null && !mapDefaultClassification.isEmpty()){
			String strDefaultUSJurClass 	= (String) mapDefaultClassification.get("USJURISDICTION"); 
			String strDefaultUSEXTJurClass 	= (String) mapDefaultClassification.get("USEXTERNALJURISDICTION");
			String strDefaultCAJurClass 	= (String) mapDefaultClassification.get("CAJURISDICTION");
			
			//if(UIUtil.isNullOrEmpty(strCRMDefaultUSClassification) || UIUtil.isNullOrEmpty(strCRMDefaultUSExtClassification) || UIUtil.isNullOrEmpty(strCRMDefaultCAClassification))
			if(CRM_DEFAULT_MAP.isEmpty())
			{
				try 
				{
					//Getting USJURISDICTION default class id
					strClassId = PWCRFACRMIntegrationDataManipulator.getClassID(context, strDefaultUSJurClass, "USJURISDICTION");
					mpCRMDefaultUSClassification.put("id", strClassId);
					mpCRMDefaultUSClassification.put("name", strDefaultUSJurClass);
					
					CRM_DEFAULT_MAP.put("USJURISDICTION", mpCRMDefaultUSClassification);
					
					//Getting USEXTERNALJURISDICTION default class id
					strClassId = PWCRFACRMIntegrationDataManipulator.getClassID(context, strDefaultUSEXTJurClass, "USEXTERNALJURISDICTION");
					mpCRMDefaultUSExtClassification.put("id", strClassId);
					mpCRMDefaultUSExtClassification.put("name", strDefaultUSEXTJurClass);
					
					CRM_DEFAULT_MAP.put("USEXTERNALJURISDICTION", mpCRMDefaultUSExtClassification);
					
					//Getting USEXTERNALJURISDICTION default class id
					strClassId = PWCRFACRMIntegrationDataManipulator.getClassID(context, strDefaultCAJurClass, "CAJURISDICTION");
					mpCRMDefaultCAClassification.put("id", strClassId);
					mpCRMDefaultCAClassification.put("name" ,strDefaultCAJurClass);
					
					CRM_DEFAULT_MAP.put("CAJURISDICTION", mpCRMDefaultCAClassification);
					
				}catch (Exception e) {
					e.printStackTrace();
				}	
			}

		}

	}


}
