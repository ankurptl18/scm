package com.ds.pwc.crm.implementations;

import java.util.HashMap;
import java.util.Iterator;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

import org.apache.log4j.Logger;

import com.ds.common.PWCConstants;
import com.ds.pwc.crm.framework.PWCRFACRMIntegrationDataMappingHolder;
import com.ds.pwc.crm.framework.PWCRFACRMIntegrationProcessingInfoHolder;
import com.ds.pwc.crm.framework.PWCRFACRMIntegrationUtil;
import com.matrixone.apps.common.Issue;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;


public class PWCRFACRMIntegrationRFA
{
	private static final Logger _LOGGER = Logger.getLogger(PWCRFACRMIntegrationRFA.class.getName());
	private static PWCRFACRMIntegrationDataMappingHolder MAPPING_INSTANCE = null;
	private static PWCRFACRMIntegrationProcessingInfoHolder objInfoHolder = null ;

	protected Context CONTEXT;	
	String RFA_OID = DomainConstants.EMPTY_STRING;

	public PWCRFACRMIntegrationRFA(Context context) throws Exception 
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::PWCRFACRMIntegrationRFA()");
		try 
		{
			MAPPING_INSTANCE = PWCRFACRMIntegrationDataMappingHolder.getInstance();
			objInfoHolder = PWCRFACRMIntegrationProcessingInfoHolder.getInstance();

		} catch (Exception e) 
		{
			_LOGGER.error("Failed to initialize the PWCRFACRMIntegrationRFA object due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			e.printStackTrace();
			throw e ;
		}

		CONTEXT = context;
		RFA_OID = DomainConstants.EMPTY_STRING;

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::PWCRFACRMIntegrationRFA()");
	}

	public boolean checkIfRFAExists(HashMap<String, String> mCRMData, StringBuilder sbRFAOid) throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::checkIfRFAExists()");

		boolean bReturnValue = false;
		boolean bisContextPushed = false ;
		try
		{
			PWCRFACRMIntegrationUtil.pushContextToSuperUser(CONTEXT);
			bisContextPushed = true ;
			
			PWCRFACRMIntegrationUtil utiObject = new PWCRFACRMIntegrationUtil(MAPPING_INSTANCE);
			String sCRMReportNumber = utiObject.getCRMReportNumber(mCRMData);
			PWCRFACRMIntegrationRFAUpdateUtil updateRFAObject = new PWCRFACRMIntegrationRFAUpdateUtil();
			bReturnValue = updateRFAObject.checkIfExist(CONTEXT, sCRMReportNumber);
			sbRFAOid.append(updateRFAObject.sRFA_ID);

		}catch(Exception e)
		{
			_LOGGER.error("Failed to check if RFA exists due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			objInfoHolder.logError("ADD", "Failed to check if RFA exists");

			e.printStackTrace();
			throw e;
		}
		finally
		{
			if ( bisContextPushed ) 
			{
				ContextUtil.popContext(CONTEXT);
			}
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::checkIfRFAExists()");
		return bReturnValue;
	}

	public void updateExistingRFA(HashMap<String, String> mCRMData, String sRFAOid) throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::updateExistingRFA()");

		HashMap<String,HashMap<String,String>> mRFAUpdateInformationMap = new HashMap<String,HashMap<String,String>>();
		boolean bIsContextPushed = false;
		try
		{
			PWCRFACRMIntegrationUtil.pushContextToSuperUser(CONTEXT);
			bIsContextPushed = true;
			
			PWCRFACRMIntegrationUtil utiObject = new PWCRFACRMIntegrationUtil(MAPPING_INSTANCE);
			mRFAUpdateInformationMap = utiObject.generateUpdateRFAInformationMap(mCRMData);
			PWCRFACRMIntegrationRFAUpdateUtil updateRFAObject = new PWCRFACRMIntegrationRFAUpdateUtil();
			updateRFAObject.updateExistingRFA(CONTEXT, mRFAUpdateInformationMap, sRFAOid);

			objInfoHolder.logSuccess("ADD", "RFA '"+DomainObject.newInstance(CONTEXT, sRFAOid).getInfo(CONTEXT, DomainObject.SELECT_NAME)+"' update is successful");

		}catch(Exception e)
		{
			_LOGGER.error("Failed to update existing RFA '"+mCRMData+"' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}		
		finally
		{
			if(bIsContextPushed)
			{
				ContextUtil.popContext(CONTEXT);
			}
		}
		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::updateExistingRFA()");
	}

	/**
	 * @param
	 * @param 
	 */
	@SuppressWarnings("unchecked")
	public void createNewRFA( HashMap<String, String> mCRMData )throws Exception
	{		
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::createNewRFA()");

		try
		{
			PWCRFACRMIntegrationUtil utiObject = new PWCRFACRMIntegrationUtil(MAPPING_INSTANCE);
			HashMap<String,Object> mRFAAllInformationMap = utiObject.generateCreateRFAInformationMap(mCRMData);		
			RFA_OID = createRFAObject((HashMap<String,String>)mRFAAllInformationMap.get("RFAAttributeMap"));

			if(!UIUtil.isNullOrEmpty(RFA_OID))
			{
				try 
				{
					String sEngineModelId = DomainConstants.EMPTY_STRING;						
					connectToReportingOrganization();
					sEngineModelId = createAndConnectEngineInfo((HashMap<String,String>)mRFAAllInformationMap.get("EngineAttributeMap"),(HashMap<String,String>)mRFAAllInformationMap.get("EngineRelAttributeMap"));     
					createAndConnectPartInfo((HashMap<String,String>)mRFAAllInformationMap.get("PartAttributeMap"),(HashMap<String,String>)mRFAAllInformationMap.get("PartRelAttributeMap"));
					createAndConnectAircraftInfo((HashMap<String,String>)mRFAAllInformationMap.get("AircraftAttributeMap"));
					createAndConnectReferenceInfo((HashMap<String,String>)mRFAAllInformationMap.get("ReferanceAttributeMap"));
					createAndConnectAttachmentInfo((HashMap<String,String>)mRFAAllInformationMap.get("AttachmentAttributeMap"));
					connectToCustomerLocation();
					setIPInformation();
					//autoAssignCompanyToRFA();
					connectRFACoordinator(sEngineModelId);
				} catch (Exception e) 
				{
					_LOGGER.error("Failed to add 'Event Information' to new RFA due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
				}
				promoteRFAToCordVal();
				classifyRFA((StringList)mRFAAllInformationMap.get("ClassificationList"));	
			}

		}catch(Exception e)
		{
			_LOGGER.error("Failed to create new RFA due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::createNewRFA()");
	}

	/**
	 * @param
	 * @param 
	 */
	private String createRFAObject(HashMap<String,String> mRFAAttributeMap) throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::createRFAObject()");

		String sRFAName = DomainConstants.EMPTY_STRING;
		String sRFAId 	= DomainConstants.EMPTY_STRING;
		try
		{
			String RFA_TYPE = PWCConstants.TYPE_RFA;			
			String RFA_Business_PROCESS = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.BusinessProcess");
			String sRFAEventTypeEngine = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.EventType.Engine");
			String sRFAEventTypePart = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.EventType.Part");
			String sRFASubType = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.SubType.DefaultValue");
			String sRFAPartType = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.PartType.DefaultValue");
			String sProblemFoundDuring = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.ProblemFoundDuring.DefaultValue");
			String RFA_POLICY = PWCConstants.POLICY_PWC_RFAFLD;

			sRFAName = DomainObject.getAutoGeneratedName(CONTEXT,PWCConstants.ADMIN_TYPE_RFA,RFA_Business_PROCESS);
			DomainObject domObj = new DomainObject();
			domObj.createObject(CONTEXT, RFA_TYPE, sRFAName, "-", RFA_POLICY, PWCConstants.PRODUCTION_VAULT);
			sRFAId = domObj.getObjectId(CONTEXT);

			if(mRFAAttributeMap.containsKey("Description"))
			{							
				domObj.setDescription(CONTEXT,mRFAAttributeMap.get("Description"));
				mRFAAttributeMap.remove("Description");
			}

			HashMap<String,String> mAttributeMap = new HashMap<String,String>();
			getAttributeMap(mRFAAttributeMap,mAttributeMap);			
			mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_BUSINESS_PROCESS, RFA_Business_PROCESS);
			mAttributeMap.put(PWCConstants.ATTRIBUTE_ISSUE_CLASSIFICATION, sRFASubType);
			mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_PART_TYPE, sRFAPartType);
			mAttributeMap.put(DomainConstants.ATTRIBUTE_ORIGINATOR, CONTEXT.getUser());	
			mAttributeMap.put(PWCConstants.ATTRIBUTE_CONTAINS_TECH_DATA,"Yes");
			mAttributeMap.put(PWCConstants.ATTRIBUTE_CONTAINS_THIRD_PARTY_INFO,"No");

			if(PWCRFACRMIntegrationDataMappingHolder.sMilitaryUses.equalsIgnoreCase("Yes"))
			{
				mAttributeMap.put(PWCConstants.ATTRIBUTE_IS_FIRST_MILITART_USAGE,"Yes");
			} else {
				mAttributeMap.put(PWCConstants.ATTRIBUTE_IS_FIRST_MILITART_USAGE,"No");
			}
			
			String sEventDate = (String)mAttributeMap.get(PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_DATE);			
			if(!UIUtil.isNullOrEmpty(sEventDate))
			{		
				mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_DATE, PWCRFACRMIntegrationRFAEventUtil.getMatrixDate(sEventDate));
			} else{	
				mAttributeMap.remove(PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_DATE);
			}

			if(UIUtil.isNullOrEmpty((String)mAttributeMap.get(PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_TYPE)))
			{
				mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_TYPE, sRFAEventTypeEngine);
			} else {
				mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_TYPE, sRFAEventTypePart);
			}
			
			if(UIUtil.isNullOrEmpty((String)mAttributeMap.get(PWCConstants.ATTRIBUTE_PROB_FOUND_DURING)))
			{
				mAttributeMap.put(PWCConstants.ATTRIBUTE_PROB_FOUND_DURING, sProblemFoundDuring);
			}
			
			domObj.setAttributeValues(CONTEXT, mAttributeMap);
			objInfoHolder.logSuccess("ADD", "Creation of new RFA '"+domObj.getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' is successful");
		}
		catch(Exception e)
		{
			objInfoHolder.logError("ADD", "RFA creation has failed");
			_LOGGER.error("RFA creation has failed due to this error "+ PWCRFACRMIntegrationUtil.getStackTrace(e));

			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::createRFAObject()");

		return sRFAId;
	}

	/**
	 * This method create Reference Information and connect to new RFA Object.
	 * @param
	 */
	private void connectToReportingOrganization()throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::connectToReportingOrganization()");
		DomainObject issueDOM = null;

		try
		{
			String sReportOrgID = DomainConstants.EMPTY_STRING;
			String sReportingOrganization = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.ReportingOrganization.DefaultValue");
			BusinessObject companyObj = new BusinessObject(DomainConstants.TYPE_COMPANY,sReportingOrganization,"-",PWCConstants.PRODUCTION_VAULT);
			if(companyObj.exists(CONTEXT))
			{
				sReportOrgID = companyObj.getObjectId(CONTEXT);
				if((sReportOrgID != null) && (sReportOrgID.equals("") == false))
				{					
					DomainObject fromDOM = DomainObject.newInstance(CONTEXT,sReportOrgID);
					issueDOM = DomainObject.newInstance(CONTEXT,RFA_OID);
					DomainRelationship rel = issueDOM.connect(CONTEXT, PWCConstants.RELATIONSHIP_REPORTING_ORGANIZATION, fromDOM, true);
				}
			}else
			{
				objInfoHolder.logWarning("ADD", "Comapny 'Pratt and Whitney Canada' does not exist to connect to new RFA '"+issueDOM.getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' as 'Reporting Organization'");
			}
		}catch(Exception e)
		{
			objInfoHolder.logWarning("ADD", "Failed to connect new RFA '"+issueDOM.getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' to 'Reporting Organization'");
			_LOGGER.warn("Failed to connect new RFA '"+issueDOM.getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' to 'Reporting Organization' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::connectToReportingOrganization()");
	}

	/**
	 * This method create Reference Information and connect to new RFA Object.
	 * @param
	 */
	private void createAndConnectReferenceInfo(HashMap<String, String> mReferenceInfoMap)throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::createAndConnectReferenceInfo()");
		String Referance_Document_Name = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.ReferanceDocument.DefaultValue"); 

		try
		{
			if(!mReferenceInfoMap.isEmpty() && mReferenceInfoMap.containsKey(PWCConstants.ADMIN_ATTRIBUTE_PWC_RFA_REFERENCE_NUMBER))
			{	
				String sReferenceDocNumber = (String)mReferenceInfoMap.get(PWCConstants.ADMIN_ATTRIBUTE_PWC_RFA_REFERENCE_NUMBER);
				String sReferenceDocID = DomainConstants.EMPTY_STRING;
				BusinessObject referanceObj = new BusinessObject(PWCConstants.TYPE_PWC_RFA_REFERENCE,Referance_Document_Name,"1",PWCConstants.PRODUCTION_VAULT);

				if(referanceObj.exists(CONTEXT) && !UIUtil.isNullOrEmpty(sReferenceDocNumber))
				{
					sReferenceDocID = referanceObj.getObjectId(CONTEXT);
					if((sReferenceDocID != null) && (sReferenceDocID.equals("") == false))
					{
						PWCRFACRMIntegrationRFAEventUtil eventObj = new PWCRFACRMIntegrationRFAEventUtil();
						eventObj.addReferenceInfoToRFA(CONTEXT, RFA_OID, sReferenceDocID, CONTEXT.getTimezone(), sReferenceDocNumber);
					}
				}			
			}else
			{
				objInfoHolder.logWarning("ADD", "'CMS Report Number' is not availabe in 'CRM Data File' to connect 'ReferenceInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			}

		}catch(Exception e)
		{
			objInfoHolder.logWarning("ADD", "Failed to create and connect 'ReferenceInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			_LOGGER.error("Failed to create and connect 'ReferenceInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::createAndConnectReferenceInfo()");
	}

	/**
	 * This method create Aircraft Information and connect to new RFA Object.
	 * @param
	 */
	private void createAndConnectAircraftInfo(HashMap<String, String> mAircraftInfoMap)throws Exception
	{		
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::createAndConnectAircraftInfo()");

		try
		{
			if(!mAircraftInfoMap.isEmpty())
			{	
				HashMap<String, String> mAircraftAttributeMap = new HashMap<String,String>();
				getAttributeMap(mAircraftInfoMap,mAircraftAttributeMap);

				String sAttrubuteAircraftType = PWCConstants.ATTRIBUTE_PWC_RFA_AIRCRAFT_TYPE;
				if(!mAircraftAttributeMap.isEmpty() && mAircraftAttributeMap.containsKey(sAttrubuteAircraftType))
				{	
					String sAircraftName = (String)mAircraftAttributeMap.get(sAttrubuteAircraftType).trim();
					String sAircraftFamily = DomainConstants.EMPTY_STRING;
					BusinessObject aircraftTypeObj = new BusinessObject(PWCConstants.TYPE_PLM_PARAMETER,sAircraftName,PWCConstants.TYPE_PWC_RFA_AIRCRAFT_TYPE,PWCConstants.PRODUCTION_VAULT);			
					if(aircraftTypeObj.exists(CONTEXT))
					{	
						DomainObject aircraftObj = new DomainObject(aircraftTypeObj);
						sAircraftFamily = aircraftObj.getAttributeValue(CONTEXT, PWCConstants.ATTRIBUTE_PWC_FAMILY);
						mAircraftAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_AIRCRAFT_CONFIGURATION_FAMILY, sAircraftFamily);
					} else
					{
						mAircraftAttributeMap.remove(sAttrubuteAircraftType);
						objInfoHolder.logWarning("ADD", "'Aircraft Type' and 'Configuration Family' are not available for new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
					}						
				}			
				PWCRFACRMIntegrationRFAEventUtil eventObj = new PWCRFACRMIntegrationRFAEventUtil();
				eventObj.createAircraftForRFA(CONTEXT, RFA_OID, mAircraftAttributeMap);
			}		

		}catch(Exception e)
		{
			objInfoHolder.logWarning("ADD", "Failed to create and connect 'AircraftInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			_LOGGER.error("Failed to create and connect 'AircraftInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::createAndConnectAircraftInfo()");
	}

	/**
	 * This method create Attachment and connect to new RFA Object.
	 * @param
	 */
	private void createAndConnectAttachmentInfo(HashMap<String, String> mAttachmentInfoMap)throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::createAndConnectAttachmentInfo()");

		try 
		{
			String sCaseURL = (String)mAttachmentInfoMap.get("Attachment_Info");
			if(!UIUtil.isNullOrEmpty(sCaseURL))
			{
				PWCRFACRMIntegrationRFAEventUtil eventObj = new PWCRFACRMIntegrationRFAEventUtil();
				eventObj.createAttachmentForRFA(CONTEXT, RFA_OID, sCaseURL);
			}else
			{
				objInfoHolder.logWarning("ADD", "'CASE URL' is not available in 'CRM Data File' to create 'Document' for new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			}

		} catch (Exception e) 
		{
			objInfoHolder.logWarning("ADD", "Failed to create and connect 'AttachmentInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			_LOGGER.error("Failed to create and connect 'AttachmentInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::createAndConnectAttachmentInfo()");
	}

	/**
	 * This method create Part Information and connect to new RFA Object.
	 * @param
	 */
	private void createAndConnectPartInfo(HashMap<String, String> mPartInfoMap,HashMap<String, String> mPartRelAttributeMap)throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::createAndConnectPartInfo()");

		try
		{
			if(!mPartInfoMap.isEmpty())
			{	
				HashMap<String, String> mPartAttributeMap = new HashMap<String,String>();
				HashMap<String, String> mPartRelationshipAttributeMap = new HashMap<String,String>();
				getAttributeMap(mPartInfoMap,mPartAttributeMap);
				getAttributeMap(mPartRelAttributeMap,mPartRelationshipAttributeMap);		
				PWCRFACRMIntegrationRFAEventUtil eventObj = new PWCRFACRMIntegrationRFAEventUtil();
				eventObj.getPartInfoFromERIS(CONTEXT,mPartAttributeMap);
				eventObj.createPhysicalPartForRFA(CONTEXT, RFA_OID, mPartAttributeMap, mPartRelationshipAttributeMap);
			}

		}catch(Exception e)
		{
			objInfoHolder.logWarning("ADD", "Failed to create and connect 'PartInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			_LOGGER.warn("Failed to create and connect 'PartInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::createAndConnectPartInfo()");
	}

	/**
	 * This method create Engine Information and connect to new RFA Object.
	 * @param
	 */
	private String createAndConnectEngineInfo(HashMap<String, String> mEngineInfoMap,HashMap<String, String> mEngineRelAttributeMap)throws Exception
	{
		String sEngineModelID = DomainConstants.EMPTY_STRING;
		try
		{
			if(!mEngineInfoMap.isEmpty())
			{	
				HashMap<String, String> mEngineAttributeMap = new HashMap<String,String>();
				HashMap<String, String> mEngineRelationshipAttributeMap = new HashMap<String,String>();
				String sEngineSectionID = DomainConstants.EMPTY_STRING;
				sEngineSectionID = "123";
				String sEngineModel = (String)mEngineInfoMap.get(PWCConstants.ADMIN_ATTRIBUTE_PWC_RFA_ENGINE_MODEL);
				if(!UIUtil.isNullOrEmpty(sEngineModel))
				{
					sEngineModelID = connectEngineModelToRFA(sEngineModel,RFA_OID);
					mEngineInfoMap.remove(PWCConstants.ADMIN_ATTRIBUTE_PWC_RFA_ENGINE_MODEL);
				}
				getAttributeMap(mEngineInfoMap,mEngineAttributeMap);
				getAttributeMap(mEngineRelAttributeMap,mEngineRelationshipAttributeMap);
				PWCRFACRMIntegrationRFAEventUtil eventObj = new PWCRFACRMIntegrationRFAEventUtil();
				eventObj.createEngineInfoForRFA(CONTEXT, RFA_OID, mEngineAttributeMap, mEngineRelationshipAttributeMap, sEngineModelID, sEngineSectionID);
			}else
			{
				objInfoHolder.logWarning("ADD", "No 'Engine Information' available to create and connect 'EngineInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			}

		}catch(Exception e)
		{
			objInfoHolder.logWarning("ADD", "Failed to create and connect 'EngineInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			_LOGGER.warn("Failed to create and connect 'EngineInfo' to new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::createAndConnectEngineInfo()");
		return sEngineModelID;
	}

	/**
	 * This method connect Model object to new RFA Object.
	 * @param
	 */
	@SuppressWarnings("deprecation")
	public String connectEngineModelToRFA(String sEngineModel,String sRFA_OID)throws Exception
	{
		String sEngineModelID = DomainConstants.EMPTY_STRING;
		BusinessObject engineModelObj = new BusinessObject("Model",sEngineModel,"",PWCConstants.PRODUCTION_VAULT);
		if(engineModelObj.exists(CONTEXT))
		{
			sEngineModelID = engineModelObj.getObjectId(CONTEXT);
			if((sEngineModelID != null) && (sEngineModelID.equals("") == false))
			{
				DomainObject engModelDOM = DomainObject.newInstance(CONTEXT,sEngineModelID);
				DomainObject issueDOM = DomainObject.newInstance(CONTEXT,sRFA_OID);
				DomainRelationship rel = issueDOM.connect(CONTEXT, PWCConstants.RELATIONSHIP_PWC_RFA_MODEL, engModelDOM, false);
			}
		}
		return sEngineModelID;
	}

	/**
	 * This method create Attribute Map with Actual attribute names in ENOVIA.
	 * @param mRFAAttributeMap
	 * @param mAttributeMap
	 * @throws Exception
	 */
	public void getAttributeMap(HashMap<String, String> mRFAAttributeMap,HashMap<String, String> mAttributeMap) throws Exception
	{
		String sAttributeName = DomainConstants.EMPTY_STRING;
		String sAttributeValue = DomainConstants.EMPTY_STRING;
		for (Iterator<String> mapKeysItr = mRFAAttributeMap.keySet().iterator(); mapKeysItr.hasNext();)
		{
			sAttributeName = mapKeysItr.next();
			sAttributeValue = (String)mRFAAttributeMap.get(sAttributeName);			
			mAttributeMap.put(PropertyUtil.getSchemaProperty(sAttributeName), sAttributeValue);
		}
	}	

	/**
	 * This method connect customer Location to new RFA Object.
	 * @param
	 */
	private void connectToCustomerLocation()throws Exception
	{		
		try
		{		
			String sEventLocationID = DomainConstants.EMPTY_STRING;
			String sEventLocation = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.EventLocation.DefaultValue");
			BusinessObject eventLocationObj = new BusinessObject(PWCConstants.TYPE_PWC_RFA_EVENT_LOCATION,sEventLocation,"1",PWCConstants.PRODUCTION_VAULT);
			if(eventLocationObj.exists(CONTEXT))
			{
				sEventLocationID = eventLocationObj.getObjectId(CONTEXT);
				if((sEventLocationID != null) && (sEventLocationID.equals("") == false))
				{
					DomainObject eventLocationDOM = DomainObject.newInstance(CONTEXT,sEventLocationID);
					DomainObject issueDOM = DomainObject.newInstance(CONTEXT,RFA_OID);
					DomainRelationship rel = issueDOM.connect(CONTEXT, PWCConstants.RELATIONSHIP_PWC_RFA_EVENT_LOCATION, eventLocationDOM,false);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}		
	}

	/**
	 * This method set IP Source, IP Owner and IP Sensitivity Level of newly created RFA.
	 * @param
	 */
	private void setIPInformation()throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::setIPInformation()");
		try
		{
			String sIPSensitivityLevel = EnoviaResourceBundle.getProperty(CONTEXT,"pwcComponents.RFA.CRM.IPClassification.IPSensitivity.DefaultValue");
			String sIPSources = EnoviaResourceBundle.getProperty(CONTEXT,"pwcComponents.RFA.CRM.IPClassification.IPSource.DefaultValue");
			//String sIPSensitivityLevelOID = "";
			//String sIPSourcesOID = "";
			if(UIUtil.isNotNullAndNotEmpty(sIPSensitivityLevel.trim()) && UIUtil.isNotNullAndNotEmpty(sIPSources.trim()))
			{
				//PWCRFACRMIntegrationRFAEventUtil eventObj = new PWCRFACRMIntegrationRFAEventUtil();
				//sIPSensitivityLevelOID = eventObj.getClassificationID(CONTEXT, LibraryCentralConstants.TYPE_GENERAL_CLASS, sIPSensitivityLevel, "-");
				//sIPSourcesOID = eventObj.getClassificationID(CONTEXT, DomainConstants.TYPE_COMPANY, sIPSources, "-");
			//}
			//if(UIUtil.isNotNullAndNotEmpty(sIPSensitivityLevelOID) && UIUtil.isNotNullAndNotEmpty(sIPSourcesOID))
			//{
				HashMap<String,Object> programMap = new HashMap<String,Object>();
				HashMap<String,Object> requestMap = new HashMap<String,Object>();
				HashMap<String,Object> paramMap = new HashMap<String,Object>();
				paramMap.put("objectId", RFA_OID);
				requestMap.put("IPSensitivityLevelRFA", sIPSensitivityLevel);
				requestMap.put("IPSourcesRFA", sIPSources);
				requestMap.put(DomainConstants.SELECT_TYPE, PWCConstants.TYPE_RFA);
				programMap.put("paramMap", paramMap);
				programMap.put("requestMap", requestMap);
				String[] args = JPO.packArgs(programMap);
				JPO.invoke(CONTEXT, "PWC_IPECCommon" , null, "postProcessIPAction", args);
			}
			else
			{
				_LOGGER.error("RFA Default Sensitivity Level OR IP Default Source objects not found.");
				throw new Exception("RFA Default Sensitivity Level OR IP Default Source objects not found.");
			}
		}catch(Exception e)
		{
			objInfoHolder.logError("ADD", "Failed to set IP Information for new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME));
			_LOGGER.error("Failed to set IP Information for new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}
		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::setIPInformation()");
	}
	
	/**
	 * This method promote the RFA to Coordinator Validation State.
	 * @param
	 */
	private void promoteRFAToCordVal()throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::promoteRFAToCordVal()");
		try
		{
			DomainObject domObj = new DomainObject(RFA_OID);
			String sState = domObj.getInfo(CONTEXT, DomainConstants.SELECT_CURRENT);

			if(PWCConstants.STATE_POLICY_RFA_FLD_CREATE.equalsIgnoreCase(sState))
			{
				domObj.promote(CONTEXT);

				objInfoHolder.logSuccess("ADD", "Promotion of new RFA '"+domObj.getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' to 'Coordinator Validation' state is successful");
			}
		}catch(Exception e)
		{
			objInfoHolder.logError("ADD", "Failed to promote new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' to 'Coordinator Validation' state");
			_LOGGER.error("Failed to promote new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' to 'Coordinator Validation' state due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}		

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::promoteRFAToCordVal()");
	}

	/**
	 * This method classify RFA with IPAC classes.
	 * @param
	 */
	private void classifyRFA(StringList slOId)throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFA.class.getName()+"::classifyRFA()");
		
		boolean bIsContextPushed = false;
		try
		{
			PWCRFACRMIntegrationUtil.pushContextToSuperUser(CONTEXT);
			bIsContextPushed = true;
			
			if(!slOId.isEmpty())
			{
				DomainObject issueDOM = DomainObject.newInstance(CONTEXT,RFA_OID);

				for(int index=0; index < slOId.size(); index++)
				{
					String sExportClassOid = (String)slOId.get(index);
					DomainObject exportClassDOM = DomainObject.newInstance(CONTEXT,sExportClassOid);
					DomainRelationship rel = issueDOM.connect(CONTEXT, LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM, exportClassDOM, true);										
				}	
				objInfoHolder.logSuccess("ADD", "Classification of new RFA '"+issueDOM.getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' is successful");

			}else
			{
				objInfoHolder.logWarning("ADD", "'IPC Classes' are not available to classify for new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			}
		}catch(Exception e) 
		{
			objInfoHolder.logWarning("ADD", "Failed to classify new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"'");
			_LOGGER.error("Failed to classify new RFA '"+(DomainObject.newInstance(CONTEXT, RFA_OID)).getInfo(CONTEXT, DomainConstants.SELECT_NAME)+"' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}
		finally
		{
			if(bIsContextPushed)
			{
				ContextUtil.popContext(CONTEXT);
			}
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFA.class.getName()+"::classifyRFA()");
	}

	/**
	 * This method assign company to RFA.
	 * @param
	 */
	private void autoAssignCompanyToRFA()throws Exception
	{
		try
		{
			String sBusinessProcess = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.BusinessProcess");
			HashMap<String,Object> programMap = new HashMap<String,Object>();
			HashMap<String,Object> requestMap = new HashMap<String,Object>();
			HashMap<String,Object> paramMap = new HashMap<String,Object>();

			paramMap.put("objectId", RFA_OID);	
			requestMap.put("BusinessProcess", sBusinessProcess);			
			programMap.put("paramMap", paramMap);
			programMap.put("requestMap", requestMap);			
			String[] args = JPO.packArgs(programMap);
			JPO.invoke(CONTEXT, "PWC_RFACommonUtil" , null, "autoAssignCompanyToRFA", args);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}	

	/**
	 * This method assign Coordinator user to RFA.
	 * @param
	 */
	private void connectRFACoordinator(String sEngineModelId)throws Exception
	{
		try{
			String sEventLocationName = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.EventLocation.DefaultValue");
			String sBusinessProcess = EnoviaResourceBundle.getProperty(CONTEXT,"PWCCRMIntegration.RFA.BusinessProcess");

			if(!UIUtil.isNullOrEmpty(sEngineModelId))
			{
				HashMap<String,String> programMap = new HashMap<String,String>();
				programMap.put("BusinessProcess", sBusinessProcess);
				programMap.put("engineModelId", sEngineModelId);
				programMap.put("eventLocationName", sEventLocationName);				
				String[] args = JPO.packArgs(programMap);
				String sCoordinator = (String)JPO.invoke(CONTEXT, "PWCRFAFLDProcess" , null, "findRFACoordinatorForCRM", args, String.class);

				if(UIUtil.isNullOrEmpty(sCoordinator) || sCoordinator.equalsIgnoreCase(CONTEXT.getUser()))
				{
					sCoordinator = PWCRFACRMIntegrationUtil.getPropertyValue("PWCCRMIntegration.RFA.Coordinator.DefaultValue");
				}
				Issue rfa = new Issue(RFA_OID);
				rfa.setOwner(CONTEXT, sCoordinator);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}		
	}	

}


