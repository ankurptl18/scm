package com.ds.report.utils;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;

import matrix.util.StringList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.ds.export.engine.DSIExportBean;

public class XmlReportBuilder 
{
	private static final Logger LOG = Logger.getLogger("XmlReportBuilder");
	
	private DSIExportBean _bean = null;
	private Document _xmlDoc = null;
	
	public XmlReportBuilder(DSIExportBean iBean) throws Exception
	{
		LOG.info("--> IN XmlReportBuilder::XmlReportBuilder()");
		if(null == iBean)
		{
			LOG.error("Input bean is null!!");
			throw new IllegalArgumentException("XmlReportBuilder..Internal error(err_1.1)");
		}
		_bean = iBean;
		_xmlDoc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		LOG.info("<-- OUT XmlReportBuilder::XmlReportBuilder()");
	}
	
	public Document getReportXML() throws Exception
	{
		LOG.info("--> IN XmlReportBuilder::getReportXML()");
		Element elem_root = _xmlDoc.createElement(XmlReportConstants.NODE_TOP_COMPONENT);
		_xmlDoc.appendChild(elem_root);
		addLabel(elem_root, _bean);
		addComponents(elem_root, _bean);
		LOG.info("<-- OUT XmlReportBuilder::getReportXML()");
		return _xmlDoc;	
	}
	
	private void addComponents(Node iXmlNode, DSIExportBean iBean)
	{
		LOG.info("--> IN XmlReportBuilder::addComponents()");
		List<DSIExportBean> lst_beans = iBean.getBeans();
		int cnt_beans = lst_beans.size();
		for(int i = 0; i < cnt_beans; i++)
		{
			DSIExportBean aBean = lst_beans.get(i);
			Element elem_comp = _xmlDoc.createElement(XmlReportConstants.NODE_COMPONENT);
			iXmlNode.appendChild(elem_comp);
			addLabel(elem_comp, aBean);
			if(aBean.getBeans().size() > 0)
			{
				addComponents(elem_comp, aBean);
			}
		}
		LOG.info("<-- OUT XmlReportBuilder::addComponents()");
	}
	
	private void addLabel(Node iXmlNode, DSIExportBean iBean)
	{
		LOG.info("--> IN XmlReportBuilder::addLabel()");
		Element elem_label = _xmlDoc.createElement(XmlReportConstants.NODE_LABEL);
		iXmlNode.appendChild(elem_label);
		Map<String, Object> map_select = iBean.getSelectables();
		Iterator<String> itr_keys = map_select.keySet().iterator();
		while(itr_keys.hasNext())
		{
			String key = itr_keys.next();
			Object value = map_select.get(key);
			String str_value = "";
			if(null != value)
			{
				Element elem_key = _xmlDoc.createElement(key);
				if(value instanceof String)
				{
					str_value = (String)value;
					elem_key.setTextContent(str_value);
					elem_label.appendChild(elem_key);
				}
				else if(value instanceof StringList)
				{
					StringList lst_value = (StringList)value;
					//StringBuilder strb_value = new StringBuilder();
					for (int j = 0; j < lst_value.size(); j++)
					{
						Element elem_value = _xmlDoc.createElement(XmlReportConstants.NODE_VALUE);
						elem_value.setTextContent(lst_value.get(j).toString());
						elem_key.appendChild(elem_value);
					}
					elem_label.appendChild(elem_key);
				}
				else
				{
					//...do nothing
				}
			}
		}
		LOG.info("<-- OUT XmlReportBuilder::addLabel()");
	}
}
