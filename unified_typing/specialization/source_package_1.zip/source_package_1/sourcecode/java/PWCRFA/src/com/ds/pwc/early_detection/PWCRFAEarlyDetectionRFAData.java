package com.ds.pwc.early_detection;

import java.util.Iterator;
import java.util.Map;

import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.util.StringList;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class PWCRFAEarlyDetectionRFAData {
	//Defining variables of PWCRFAEarlyDetectionData
	private String strRFAObj = null;
	private MapList rfaRelatedMap = null;
	private String strLocation ;
	private String strModelName ;
	private String strModelFly ;
	private String strModelCoefficient ;
	private MapList engineMapList=null;
	private MapList partMapList=null;
	private boolean isCombinedDefect =false;
	private boolean isPartDefect =false;
	private boolean isEngineDefect =false;
	private String strPrimaryEngInfo;
	
	/**
	 * @param rfaRelatedMap the rfaRelatedMap to set
	 */
	public void setRFARelatedMap(MapList rfaRelatedMap) {
		this.rfaRelatedMap = rfaRelatedMap;
	}
	
	/**
	 * @return the rfaRelatedMap
	 */
	public MapList getRFARelatedMap() {
		return rfaRelatedMap;
	}
	
	/**
	 * @param strLocation the strLocation to set
	 */
	public void setLocation(String strLocation) {
		this.strLocation = strLocation;
	}
	
	/**
	 * @return the strLocation
	 */
	public String getLocation() {
		return strLocation;
	}
	
	/**
	 * @param strModelName the strModelName to set
	 */
	public void setModelName(String strModelName) {
		if(strModelName==null || strModelName.equals("null")){
			strModelName = "";
		}
		this.strModelName = strModelName;
	}
	
	/**
	 * @return the strModelName
	 */
	public String getModelName() {
		return strModelName;
	}
	
	/**
	 * @param strModelFly the strModelFly to set
	 */
	public void setModelFly(String strModelFly) {
		if(strModelFly==null || strModelFly.equals("null")){
			strModelFly="";
		}
		this.strModelFly = strModelFly;
	}
	
	/**
	 * @return the strModelFly
	 */
	public String getModelFly() {
		return strModelFly;
	}
	
	
	/**
	 * @ dModelCoefficient is set
	 */
	public void setModelCoefficient(String strModelCoefficient) {
		if(null == strModelCoefficient || strModelCoefficient.equals("")){
			strModelCoefficient = "1";
		}
		this.strModelCoefficient = strModelCoefficient;
	}
	
	public String getModelCoefficient() {
		return strModelCoefficient;
	}
	
	/**
	 * @param strRFAObj the strRFAObj to set
	 */
	public void setRFAObjId(String strRFAObj) {
		this.strRFAObj = strRFAObj;
	}
	
	/**
	 * @return the strRFAObj
	 */
	public String getRFAObjId() {
		return strRFAObj;
	}
	
	/**
	 * engineMapList is set
	 * Get MapList containing Engine connected to RFA Object
	 */
	public MapList getEnginesInfo(){
		setEngineAndPartMaps();
		return engineMapList;
	}
	
	/**
	 * @partMapList is set
	 * Get MapList containing Part connected to RFA Object
	 */
	public MapList getPartInfo(){
		setEngineAndPartMaps();
		return partMapList;
	}
	
	/**
	 * @Sets the engineMapList and partMapList
	 */
	private void setEngineAndPartMaps(){
		StringList strList = new StringList();
		boolean setPrimary=false;
		if(engineMapList==null && partMapList== null){
			engineMapList = new MapList();
			partMapList = new MapList();
			//Get MapList containing Part and Engine Objects connected to RFA Object and making 
			// seperate malist for Part and Engine List
			for (Iterator iterator = rfaRelatedMap.iterator(); iterator.hasNext();) {
				Map relelatedMap = (Map) iterator.next();
				String relName = (String) relelatedMap.get(DomainConstants.SELECT_RELATIONSHIP_TYPE);
		
				if(PWCConstants.RELATIONSHIP_PWC_RFA_PHYSICAL_PART.equals(relName)){
					partMapList.add(relelatedMap);
				}
				else if(PWCConstants.RELATIONSHIP_PWC_RFA_ENGINE_INFO.equals(relName)){
					String strEngineCon = (String)relelatedMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
					String strEngineSym = (String)relelatedMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);

					String strPrimaryEngineInfo = getPrimaryEngineInfo();

					if(!UIUtil.isNullOrEmpty(strPrimaryEngineInfo) && !setPrimary){
						for (Iterator iteratorPrimary = rfaRelatedMap.iterator(); iteratorPrimary.hasNext();) {
							Map relelatedMapPrimary = (Map) iteratorPrimary.next();
							String strEngineId = (String)relelatedMapPrimary.get(DomainConstants.SELECT_ID);
							String strEngineConPri = (String)relelatedMapPrimary.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
							String strEngineSymPri = (String)relelatedMapPrimary.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
							if(!UIUtil.isNullOrEmpty(strEngineId) && strEngineId.equals(strPrimaryEngineInfo)){

								if(!UIUtil.isNullOrEmpty(strEngineConPri) && !UIUtil.isNullOrEmpty(strEngineSymPri) && !strList.contains(strEngineSymPri)){
									strList.add(strEngineSymPri);
									engineMapList.add(relelatedMapPrimary);
								}
								else if(!UIUtil.isNullOrEmpty(strEngineConPri) && UIUtil.isNullOrEmpty(strEngineSymPri) && !strList.contains(strEngineConPri)){
									strList.add(strEngineConPri);
									engineMapList.add(relelatedMapPrimary);
								}
								else if(!UIUtil.isNullOrEmpty(strEngineSymPri) && UIUtil.isNullOrEmpty(strEngineConPri) && !strList.contains(strEngineSymPri)) {
									strList.add(strEngineSymPri);
									engineMapList.add(relelatedMapPrimary);
								}	
							}
						}
						setPrimary = true;
					}
					
					if(!UIUtil.isNullOrEmpty(strEngineCon) && !UIUtil.isNullOrEmpty(strEngineSym) && !strList.contains(strEngineSym)){
						strList.add(strEngineSym);
						engineMapList.add(relelatedMap);
					}
					else if(!UIUtil.isNullOrEmpty(strEngineCon) && UIUtil.isNullOrEmpty(strEngineSym) && !strList.contains(strEngineCon)){
						strList.add(strEngineCon);
						engineMapList.add(relelatedMap);
					}
					else if(!UIUtil.isNullOrEmpty(strEngineSym) && UIUtil.isNullOrEmpty(strEngineCon) && !strList.contains(strEngineSym)) {
						strList.add(strEngineSym);
						engineMapList.add(relelatedMap);
					}

				}
			}
			
		}
	}
	
	/**
	 * @return the isCombinedDefect
	 */
	public boolean isCombinedDefect() {
		setEngineAndPartMaps();
		boolean isEngine = true;
		boolean isPart = true;
		if(partMapList.size()>0 && engineMapList.size()>0){
			for(int n=0;n<engineMapList.size();n++)
			{
				Map engininfoMap = (Map)engineMapList.get(n);
				String strEngineCon = (String)engininfoMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
				String strEngineSym = (String)engininfoMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
				if(!UIUtil.isNullOrEmpty(strEngineCon) || !UIUtil.isNullOrEmpty(strEngineSym))
				{
					isEngine=false;
					break;
				}

			}
			for(int n=0;n<partMapList.size();n++)
			{
				Map partinfoMap = (Map)partMapList.get(n);
				String strPartCon = (String)partinfoMap.get(PWCRFAEarlyDetectionConstants.STR_REL_PHYSICALPART_PC);
				if(!UIUtil.isNullOrEmpty(strPartCon))
				{
					isPart=false;
					break;
				}

			}
			if(!isEngine && !isPart){
			this.isCombinedDefect=true;
		}
			else{
				this.isCombinedDefect=false;
			}
			
	}
		return isCombinedDefect;
	}
	
	/**
	 * engineMapList is set
	 * Get MapList containing Engine connected to RFA Object
	 */
	public boolean isEngineDefect(){
		setEngineAndPartMaps();
		boolean isEngine = false;
		if(engineMapList.size()>0){
			for(int n=0;n<engineMapList.size();n++)
			{
				Map engininfoMap = (Map)engineMapList.get(n);
				String strEngineCon = (String)engininfoMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
				String strEngineSym = (String)engininfoMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
				if(!UIUtil.isNullOrEmpty(strEngineCon) || !UIUtil.isNullOrEmpty(strEngineSym))
				{
					isEngine=true;
					break;
				}

			}
		}
			return isEngine;
	}
	
	/**
	 * @partMapList is set
	 * Get MapList containing Part connected to RFA Object
	 */
	public boolean isPartDefect(){
		setEngineAndPartMaps();
		boolean isPart = true;
		if(partMapList.size()>0){
			for(int n=0;n<partMapList.size();n++)
			{
				Map partinfoMap = (Map)partMapList.get(n);
				String strPartCon = (String)partinfoMap.get(PWCRFAEarlyDetectionConstants.STR_REL_PHYSICALPART_PC);
				if(!UIUtil.isNullOrEmpty(strPartCon))
				{
					isPart=true;
					break;
				}

			}
		}
	return isPart;
	}
	
	/**
	 * 	 * @return the int iIFSDValue
	*/
	public int getIFSDValue(){
			Document documentCriticalLimit;
			int iIFSDLimitValue = 0;
			try {
				documentCriticalLimit = PWCRFAEarlyDetectionUtil.loadRuleDocument("CriticalLimitRules.xml");
				NodeList CLList = documentCriticalLimit.getElementsByTagName("IFSD");
				iIFSDLimitValue = (Integer.parseInt(CLList.item(0).getTextContent().trim()));
			} catch (PWCRFAEarlyDetectionException e) {
				e.printStackTrace();
			}
			return iIFSDLimitValue;
	 }

	public void setPrimaryEngineInfo(String primaryEngId) {
		this.strPrimaryEngInfo = primaryEngId;

		
	}
	public String getPrimaryEngineInfo() {
		
		return strPrimaryEngInfo;

		
	}
}
