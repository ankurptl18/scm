package com.ds.report.utils;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


import matrix.db.Context;



import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.ds.export.engine.DSExportBeanCreator;
import com.ds.export.engine.DSIExportBean;
import com.matrixone.apps.domain.util.FrameworkUtil;


public class ReportGenerator 
{
	private static final Logger LOG = Logger.getLogger("ReportGenerator");
	private static final String EBOM_PLBOM_REPORT_TRIGGER_XML = "ebom_plbom_report_trigger.xml";

	private static final String NODE_OBJECT = "object";
	private static final String ATTR_TYPE = "type";
	private static final String NODE_PROGRAM = "program";
	private static final String ATTR_NAME = "name";
	private static final String NODE_LIFECYCLE = "lifecycle";
	private static final String ATTR_STATE = "state";
	
	private static boolean _isInitFailed = false;
	private static Document _XML_DOC;
	
	private String _str_objectID;//the ID of the TOP Assy
	private Context _context;
	private DSIExportBean  _newBean;//initialized in generateEBOMReport()
	
	
	
	public ReportGenerator(Context iContext, String iStr_ObjID) throws Exception
	{
		LOG.info("--> IN ReportGenerator::ReportGenerator()");
		if(null == iContext || null == iStr_ObjID || iStr_ObjID.isEmpty() || !FrameworkUtil.isObjectId(iContext, iStr_ObjID))
		{
			LOG.error("Input is not as expected!!");
			throw new IllegalArgumentException("ReportGenerator.Internal error(err_1.1)");
		}
		_str_objectID = iStr_ObjID;
		_context = iContext;
		LOG.info("<-- OUT ReportGenerator::ReportGenerator()");
	}
	/**
	 * 
	 * @param iTemplateXML = The xml query template
	 * @return Document = the Xml representation of the DSIExportBean
	 * @throws Exception
	 * If we want the EBOM report and EBOM compare use this method first and second generateXMLReportEBOMCompare
	 * Otherwise it is too costly because the EBOM bean has to be created twice since EBOM Compare alters the EBOM bean
	 */
	public Document generateXMLReportEBOM(String iTemplateXML) throws Exception
	{
		LOG.info("--> IN ReportGenerator::generateReportEBOM()");
		DSExportBeanCreator beanCreator = new DSExportBeanCreator(_context, iTemplateXML, _str_objectID, null);
		_newBean = beanCreator.create();
		XmlReportBuilder xmlRepBuilder = new XmlReportBuilder(_newBean);
		LOG.info("<-- OUT ReportGenerator::generateReportEBOM()");
		return xmlRepBuilder.getReportXML();
	}
	


	
}
