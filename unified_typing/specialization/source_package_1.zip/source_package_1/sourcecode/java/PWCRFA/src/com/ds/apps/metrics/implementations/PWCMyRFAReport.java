package com.ds.apps.metrics.implementations;

import static com.ds.common.PWCConstants.ATTRIBUTE_RFA_BUSINESS_PROCESS;
import static com.ds.common.PWCConstants.TYPE_RFA;
import static com.matrixone.apps.domain.DomainConstants.EMPTY_STRING;

import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectItr;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.Context;
import matrix.util.StringList;

import com.ds.apps.metrics.interfaces.IPWCRFAReport;
import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCMyRFAReport implements IPWCRFAReport {

	@SuppressWarnings({ "unchecked" })
	public String buildSearchCriteria(Context paramContext, StringList objectList, HashMap searchCriteriaDataMap) throws Exception {

		System.out.println("Criteria : " + searchCriteriaDataMap);

		String SELECT_RFA_BUSINESS_PROCESS 			= 		"attribute[" + ATTRIBUTE_RFA_BUSINESS_PROCESS + "]";
		String ATTRIBUTE_INVESTIGATION_STATUS 		= 		"attribute[" + PropertyUtil.getSchemaProperty("attribute_PWC_InvestigationStatus") + "]";		
		
		String strSelectedBusinessProcess 								= 		(String) searchCriteriaDataMap.get("selectedBusinessProcess");
		String strAssignee 															= 		(String) searchCriteriaDataMap.get("txtAssigneeIdOID");
		String strAssigneeName 												= 		(String) searchCriteriaDataMap.get("txtAssigneeId");
		String strSelectedGroup 												=		(String) searchCriteriaDataMap.get("selectedDistributionGroup");
		String strSelectedTaskLifcycleState 							= 		(String) searchCriteriaDataMap.get("lstTaskLifecycleState");
		String strFromDate 														= 		(String) searchCriteriaDataMap.get("strFromDate");
		String strToDate 															= 		(String) searchCriteriaDataMap.get("strToDate");
		String strInvestigationStatus 										= 		(String) searchCriteriaDataMap.get("selectedInvestigationStatus");
		String strIsAssignee 														= 		(String) searchCriteriaDataMap.get("isAssignee");
		String strIsGroup 															= 		(String) searchCriteriaDataMap.get("isGroup");
		String strStateSelectedSYMName 								= 		(String) searchCriteriaDataMap.get("strStateSelectedSYMName");
		String strTimeStamp 													= 		(String) searchCriteriaDataMap.get("timestamp");
		String strDefaultReport 												= 		(String) searchCriteriaDataMap.get("defaultReport");		
		String strTaskFromDate 												= 		(String) searchCriteriaDataMap.get("strTaskFromDate");
		String strTaskToDate 													= 		(String) searchCriteriaDataMap.get("strTaskToDate");		
		
		
		
		
		String STATE_CHECK 									= DomainConstants.EMPTY_STRING;
		String TASK_STATE_CHECK 							= DomainConstants.EMPTY_STRING;
		String TASK_DATE_RANGE 							= DomainConstants.EMPTY_STRING;		
		String strTaskSelectable 									=  DomainConstants.EMPTY_STRING;
		StringBuilder sbExpressionBuilder 					= new StringBuilder();
		StringList TARGET_RFA_NAME_LIST 			= new StringList();
		
		String POLICY_INBOX_TASK_ASSIGNED 	= PropertyUtil.getSchemaProperty(paramContext,"policy", PropertyUtil.getSchemaProperty("policy_InboxTask"),"state_Assigned");
		String POLICY_INBOX_TASK_COMPLETE 	= PropertyUtil.getSchemaProperty(paramContext,"policy", PropertyUtil.getSchemaProperty("policy_InboxTask"),"state_Complete");
		String INBOX_TASK_TO_BE_ACCEPTED 	= EnoviaResourceBundle.getProperty(paramContext, "emxComponentsStringResource", paramContext.getLocale(), "emxComponents.Filter.TasksToBeAccepted");
		java.text.SimpleDateFormat sdf 							= new java.text.SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), paramContext.getLocale());			
	
		Date TASK_FROM_DATE 	= sdf.parse(strTaskFromDate);
		Date TASK_TO_DATE 			= sdf.parse(strTaskToDate);
				
		if (!UIUtil.isNullOrEmpty(strStateSelectedSYMName)) {
			sbExpressionBuilder.setLength(0);
			STATE_CHECK = sbExpressionBuilder.append("|attribute[").append(DomainObject.ATTRIBUTE_ROUTE_BASE_STATE).append("] matchlist ").append("\"").append(strStateSelectedSYMName).append("\" \",\"").toString();		
		}

		if (!UIUtil.isNullOrEmpty(strSelectedTaskLifcycleState)) {	
			sbExpressionBuilder.setLength(0);
			if(strSelectedTaskLifcycleState.equals(INBOX_TASK_TO_BE_ACCEPTED)) {				
				TASK_STATE_CHECK = sbExpressionBuilder.append("|from.current matchlist").append("\"").append("Assigned,Review").append("\" \",\" ").toString();
			} else {			
				TASK_STATE_CHECK = sbExpressionBuilder.append("|from.current matchlist").append("\"").append(strSelectedTaskLifcycleState).append("\" \",\" ").toString();
			}			
		}	
		
		if(!UIUtil.isNullOrEmpty(strSelectedTaskLifcycleState) && strSelectedTaskLifcycleState.equals(INBOX_TASK_TO_BE_ACCEPTED)) {
			
			if(!UIUtil.isNullOrEmpty(strTaskFromDate) && !UIUtil.isNullOrEmpty(strTaskToDate)) {
				sbExpressionBuilder.setLength(0);
				TASK_DATE_RANGE = sbExpressionBuilder.append(" && modified >=").append( "\"").append(strTaskFromDate).append("\" && modified <= ").append("\"").append(strTaskToDate).append("\"").toString();		
			}
			
			sbExpressionBuilder.setLength(0);	
			strTaskSelectable = sbExpressionBuilder.append("from[").append(DomainObject.RELATIONSHIP_OBJECT_ROUTE).append(STATE_CHECK).append("].to.to[").append(DomainObject.RELATIONSHIP_ROUTE_TASK).append(TASK_STATE_CHECK).append(" && from.from[").append(DomainObject.RELATIONSHIP_PROJECT_TASK).append("].to.type=='").append( DomainObject.TYPE_ROUTE_TASK_USER).append("'").append(TASK_DATE_RANGE).append("].from.id").toString();
		
		} else if (!UIUtil.isNullOrEmpty(strSelectedTaskLifcycleState) && (strSelectedTaskLifcycleState.equals(POLICY_INBOX_TASK_ASSIGNED))) {
			sbExpressionBuilder.setLength(0);
			strTaskSelectable = sbExpressionBuilder.append("from[").append(DomainObject.RELATIONSHIP_OBJECT_ROUTE).append(STATE_CHECK).append("].to.to[").append(DomainObject.RELATIONSHIP_ROUTE_TASK).append(TASK_STATE_CHECK).append(" && from.from[").append(DomainObject.RELATIONSHIP_PROJECT_TASK).append("].to.type=='").append( DomainObject.TYPE_PERSON ).append("'].from.id").toString();
		}	else if (!UIUtil.isNullOrEmpty(strSelectedTaskLifcycleState) && strSelectedTaskLifcycleState.equals(POLICY_INBOX_TASK_COMPLETE)) {
			
			if(!UIUtil.isNullOrEmpty(strTaskFromDate) && !UIUtil.isNullOrEmpty(strTaskToDate)) {
				sbExpressionBuilder.setLength(0);
				TASK_DATE_RANGE = sbExpressionBuilder.append(" && from.state[Complete].actual >=").append( "\"").append(strTaskFromDate).append("\" && from.state[Complete].actual<= ").append("\"").append(strTaskToDate).append("\"").toString();				
			}			
			sbExpressionBuilder.setLength(0);
			strTaskSelectable = sbExpressionBuilder.append("from[").append(DomainObject.RELATIONSHIP_OBJECT_ROUTE).append(STATE_CHECK).append("].to.to[").append(DomainObject.RELATIONSHIP_ROUTE_TASK).append(TASK_STATE_CHECK).append(TASK_DATE_RANGE).append(" && from.from[").append(DomainObject.RELATIONSHIP_PROJECT_TASK).append("].to.type=='").append( DomainObject.TYPE_PERSON ).append("'].from.id").toString();
		}	
		System.out.println("strTaskSelectable is :: "+strTaskSelectable);
	
		Map mapAssignee = (Map)PersonUtil.getPersonProperty(paramContext, "AssigneeMap");
        if (mapAssignee == null)
        {
        	mapAssignee = new HashMap(1); 
        }
        //object where to to search RFA Objects
        StringBuffer objWhere = new StringBuffer();
        
        sbExpressionBuilder.setLength(0);
   		objWhere.append(sbExpressionBuilder.append(SELECT_RFA_BUSINESS_PROCESS).append(" matchlist ").append("\"").append(strSelectedBusinessProcess).append("\" \",\"").toString());  
        
        if (!UIUtil.isNullOrEmpty(strInvestigationStatus)) {
        	 sbExpressionBuilder.setLength(0);
    			objWhere.append(sbExpressionBuilder.append(" && ").append(ATTRIBUTE_INVESTIGATION_STATUS).append(" matchlist ").append("\"").append(strInvestigationStatus).append("\" \",\""));    
        }        	
   			
   		   if (!UIUtil.isNullOrEmpty(strFromDate)) {
   			 sbExpressionBuilder.setLength(0);
   			objWhere.append(sbExpressionBuilder.append(" && originated >= \"").append(strFromDate).append("\""));   	 
   		   }
   		
   		  if (!UIUtil.isNullOrEmpty(strToDate)) {
   			 sbExpressionBuilder.setLength(0);
   			 objWhere.append(sbExpressionBuilder.append(" && originated <= \"").append(strToDate).append("\""));   	
   		  }	
   		  
   		 sbExpressionBuilder.setLength(0);
   		 objWhere.append(sbExpressionBuilder.append(" && current !=").append(PWCConstants.STATE_POLICY_RFA_DRDEV_CANCELLED));   	
   			
   		//RFA Object select
        StringList objSelects=new StringList();
        objSelects.addElement(DomainConstants.SELECT_ID);
        objSelects.addElement(DomainConstants.SELECT_NAME);
       	objSelects.add(strTaskSelectable);
		DomainConstants.MULTI_VALUE_LIST.add("from["+DomainObject.RELATIONSHIP_OBJECT_ROUTE+"].to.to["+DomainObject.RELATIONSHIP_ROUTE_TASK+"].from.id");
		
   		//find the RFA those matches the selection criteria
   			MapList RFAList =      DomainObject.findObjects(paramContext,TYPE_RFA, "*", "*", "*", "*", objWhere.toString(), false, objSelects);
   			System.out.println("RFAList is :: "+RFAList);
   			
        sbExpressionBuilder.setLength(0);
        String strProjectTaskModifiedTS = sbExpressionBuilder.append("from[").append(DomainObject.RELATIONSHIP_PROJECT_TASK).append("].modified").toString();     
   		
   		sbExpressionBuilder.setLength(0);
   		String strProjectTaskOriginatedTS = sbExpressionBuilder.append("from[").append(DomainObject.RELATIONSHIP_PROJECT_TASK).append("].originated").toString();  
   		
   		sbExpressionBuilder.setLength(0);
   		String strRouteTaskUser = sbExpressionBuilder.append( "attribute[").append(DomainObject.ATTRIBUTE_ROUTE_TASK_USER).append( "]").toString();   	
   		
   		sbExpressionBuilder.setLength(0);
   		String strAssigneeSelectable = sbExpressionBuilder.append("from[").append(DomainObject.RELATIONSHIP_PROJECT_TASK).append("].to.name").toString();   	
            
		//Task Object select
        StringList taskSelects=new StringList();
        taskSelects.add(DomainConstants.SELECT_ID);
        taskSelects.add(DomainConstants.SELECT_NAME);
        taskSelects.add(strProjectTaskModifiedTS);    
        taskSelects.add(strProjectTaskOriginatedTS);    
        taskSelects.add(strRouteTaskUser);    
        taskSelects.add(strAssigneeSelectable);        
		String strPolicySelectable = "from["+DomainObject.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainObject.RELATIONSHIP_OBJECT_ROUTE+STATE_CHECK+"].attribute[" + DomainObject.ATTRIBUTE_ROUTE_BASE_POLICY + "]";
		String strRFAStateSelectable = "from["+DomainObject.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainObject.RELATIONSHIP_OBJECT_ROUTE+STATE_CHECK+"].attribute[" + DomainObject.ATTRIBUTE_ROUTE_BASE_STATE + "]";
        taskSelects.add(strPolicySelectable);
		taskSelects.add(strRFAStateSelectable);
		
		StringBuffer sbSearchCriteria 		= new StringBuffer();
		String strSearchCriteria 				= EMPTY_STRING;
		HashMap hm 								= new HashMap();		
		StringList slTaskToProcess 			= new StringList();
		
		StringList slSelectedAssignee = FrameworkUtil.split(strAssigneeName, "|");
		StringList slSelectedGroup = FrameworkUtil.split(strSelectedGroup, ",");
		
		if (RFAList != null && !RFAList.isEmpty() && RFAList.size() > 0 ) {
			int iRFASize = RFAList.size();		
			for (int j = 0; j < iRFASize; j++) {				
				HashMap map 		= (HashMap)RFAList.get(j);				
				StringList slTasks = (StringList) map.get("from["+DomainObject.RELATIONSHIP_OBJECT_ROUTE+"].to.to["+DomainObject.RELATIONSHIP_ROUTE_TASK+"].from.id");
				if(slTasks != null && slTasks.size()>0) {				
					slTaskToProcess.addAll(slTasks);			
				}				
			}
			
			System.out.println("slTaskToProcess is " +slTaskToProcess );
				if(slTaskToProcess != null && !slTaskToProcess.isEmpty() && slTaskToProcess.size()>0) {
					
					BusinessObjectWithSelectList AssigneeList = BusinessObject.getSelectBusinessObjectData(paramContext, (String[]) slTaskToProcess.toArray(new String[0]),taskSelects);
					BusinessObjectWithSelectItr TaskWithSelectItr = new BusinessObjectWithSelectItr(AssigneeList);	
					
					while (TaskWithSelectItr.next()) 
					{
							BusinessObjectWithSelect TaskWithSelect = TaskWithSelectItr.obj();
							String sTaskName = (String)TaskWithSelect.getSelectData(DomainConstants.SELECT_NAME);
							String sTaskId = (String)TaskWithSelect.getSelectData(DomainConstants.SELECT_ID);
							String sState = (String)TaskWithSelect.getSelectData("from["+DomainObject.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainObject.RELATIONSHIP_OBJECT_ROUTE+"].attribute[" + DomainObject.ATTRIBUTE_ROUTE_BASE_STATE + "]");
							String sPolicy = (String)TaskWithSelect.getSelectData("from["+DomainObject.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainObject.RELATIONSHIP_OBJECT_ROUTE+"].attribute[" + DomainObject.ATTRIBUTE_ROUTE_BASE_POLICY + "]");
							String sAssignee = (String)TaskWithSelect.getSelectData(strAssigneeSelectable);
							String sRouteTaskUser = (String)TaskWithSelect.getSelectData(strRouteTaskUser);
							String sProjectTaskOriginatedTS = (String)TaskWithSelect.getSelectData(strProjectTaskOriginatedTS);
							String sProjectTaskModifiedTS = (String)TaskWithSelect.getSelectData(strProjectTaskModifiedTS);						
							
							String ssState = DomainConstants.EMPTY_STRING;
							String ssPolicy=  DomainConstants.EMPTY_STRING;
							
							if (!UIUtil.isNullOrEmpty(sState) && !UIUtil.isNullOrEmpty(sPolicy))
							{
								ssPolicy = PropertyUtil.getSchemaProperty(sPolicy);
								ssState = i18nNow.getStateI18NString(ssPolicy,FrameworkUtil.lookupStateName(paramContext,ssPolicy,sState), paramContext.getSession().getLanguage());
							}
							
							if(strIsAssignee != null && ( strIsAssignee.equals("on") || strIsAssignee.equals("checked") ) && strSelectedTaskLifcycleState.equals(POLICY_INBOX_TASK_ASSIGNED) ) {
								
								if(!UIUtil.isNullOrEmpty(sRouteTaskUser) && sRouteTaskUser.startsWith("group_")) {
									boolean bValidTask = isDateWithInRange(TASK_FROM_DATE, TASK_TO_DATE, sdf.parse(sProjectTaskModifiedTS));
									if(bValidTask && slSelectedAssignee!= null && slSelectedAssignee.size()>0 && !UIUtil.isNullOrEmpty(sAssignee)) {
										if (slSelectedAssignee.contains(sAssignee))
										{
											TARGET_RFA_NAME_LIST.add(sTaskName);
											hm.put(sTaskId, sAssignee+"|"+ssState);
										}
										
									} else if (bValidTask && !UIUtil.isNullOrEmpty(sAssignee))  {
										TARGET_RFA_NAME_LIST.add(sTaskName);
										hm.put(sTaskId, sAssignee+"|"+ssState);
										
									}
								} else if(UIUtil.isNullOrEmpty(sRouteTaskUser)) {
									boolean bValidTask = isDateWithInRange(TASK_FROM_DATE, TASK_TO_DATE, sdf.parse(sProjectTaskOriginatedTS));
									if(bValidTask && slSelectedAssignee!= null && slSelectedAssignee.size()>0 && !UIUtil.isNullOrEmpty(sAssignee)) {
										if (slSelectedAssignee.contains(sAssignee))
										{
											TARGET_RFA_NAME_LIST.add(sTaskName);
											hm.put(sTaskId, sAssignee+"|"+ssState);
										}
										
									} else if (bValidTask && !UIUtil.isNullOrEmpty(sAssignee))  {
										TARGET_RFA_NAME_LIST.add(sTaskName);
										hm.put(sTaskId, sAssignee+"|"+ssState);										
									}
								}												
								
							} else if(strIsAssignee != null && ( strIsAssignee.equals("on") || strIsAssignee.equals("checked") ) && strSelectedTaskLifcycleState.equals(POLICY_INBOX_TASK_COMPLETE)) {
								
								if (slSelectedAssignee!= null && slSelectedAssignee.size()>0 && !UIUtil.isNullOrEmpty(sAssignee))
								{
										if (slSelectedAssignee.contains(sAssignee))
										{
											TARGET_RFA_NAME_LIST.add(sTaskName);
											hm.put(sTaskId, sAssignee+"|"+ssState);
										}
								}
								else if (!UIUtil.isNullOrEmpty(sAssignee))
								{
									TARGET_RFA_NAME_LIST.add(sTaskName);
									hm.put(sTaskId, sAssignee+"|"+ssState);
								}
								
							} else if(strIsGroup != null && ( strIsGroup.equals("on") || strIsGroup.equals("checked") ) && strSelectedTaskLifcycleState.equals(INBOX_TASK_TO_BE_ACCEPTED)) {
								
								if (slSelectedGroup != null && slSelectedGroup.size()>0 && !UIUtil.isNullOrEmpty(sRouteTaskUser))
								{
									if (slSelectedGroup.contains(sRouteTaskUser))
									{
										TARGET_RFA_NAME_LIST.add(sTaskName);
										hm.put(sTaskId, sRouteTaskUser+"|"+ssState);
									}
								}
								else if (!UIUtil.isNullOrEmpty(sRouteTaskUser) )
								{
									TARGET_RFA_NAME_LIST.add(sTaskName);
									hm.put(sTaskId, sRouteTaskUser+"|"+ssState);
								}								
							}
					}					
				}
		}		
		String key = strDefaultReport+"_"+strTimeStamp;
		mapAssignee.put(key,hm);
		PersonUtil.setPersonProperty(paramContext, "AssigneeMap", mapAssignee);
		
		if (TARGET_RFA_NAME_LIST.size() > 0) {
					
					sbSearchCriteria.append("temp query bus \"" + DomainConstants.TYPE_INBOX_TASK + "\" ");
		
					for (int j = 0; j < TARGET_RFA_NAME_LIST.size(); j++) {
						String strRFAName = (String) TARGET_RFA_NAME_LIST.get(j);
						sbSearchCriteria.append(strRFAName);
		
						if (j != TARGET_RFA_NAME_LIST.size() - 1)
							sbSearchCriteria.append(",");
					}
					
					sbSearchCriteria.append(" 1");
				}
		strSearchCriteria = sbSearchCriteria.toString();
		
		if (strSearchCriteria.equals(EMPTY_STRING) ) {
			//strSearchCriteria = "print bus " + "" + " select name";
			strSearchCriteria = "print bus Model GENERAL \"\" select name";
		}		
		System.out.println("--strSearchCriteria--in activity graph report--->111" + strSearchCriteria);
		return strSearchCriteria;
	}				

	boolean isDateWithInRange(Date dFromDate, Date dToDate, Date dObjectDate) throws Exception{			
		boolean inRange = false;
		try {	
			long lFromDate = dFromDate.getTime();					
			long lToDate = dToDate.getTime();			
			long lObjectDate = dObjectDate.getTime();			
			if(lObjectDate >= lFromDate && lObjectDate <= lToDate) 
				inRange = true;
			
		} catch (Exception ex) {
			ex.printStackTrace();		
			throw new Exception("Exception occured in the method PWCMyRFAReport : isDateWithInRange"+ex.getMessage());
		}	
		return inRange;
	}
	
}
