package com.ds.pwc.early_detection.implementations;

import java.io.Serializable;
import java.util.HashMap;
import matrix.db.Context;
import com.ds.common.PWCConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionUtil;
import com.matrixone.apps.domain.DomainObject;



public class PWCRFAEarlyDetectionEngineDefectData extends PWCRFAEarlyDetectionDefectData  implements Serializable {
	private String strPositionWeight;
	private String strEngineSymptomWeight;
	private String strEngineConditionWeight;
	private String strPWCEnginePosition;
	private String strPWCRFAEngineSymptomDeviation;
	private String strPWCEngineCondition;
	private String strEngineModelFamily;
	private String strPWCRFAEngineModel;
	private String strEDEMCoefficient;
	private String strEDEngineDefectSeverity;
	private String strEDEngineDefectRecurrence;
	private String strEDEngineWeightedDefectFreq;
	private String strEDEngineDefectRL;
	private String strEDEngineDefectSR;
	private String strEDEngineDefectSRL;
	private String strEDEngineIFSD;
	
	HashMap<String,String> attributeMap = new HashMap<String,String>();
	
	public PWCRFAEarlyDetectionEngineDefectData() {
	}
	
	//Constructor for PWCRFAEarlyDetectionEngineDefectData class to create defect Object and setting ObjectId
	public PWCRFAEarlyDetectionEngineDefectData(Context context,String connectRFAObjId) throws Exception{
		String objId = PWCRFAEarlyDetectionUtil.createAndConnectDefect(context,PWCRFAEarlyDetectionConstants.INTERFACE_ENGINE_DEFECT,connectRFAObjId);
		setStrObjectId(objId);

	}
	/**
	 * @return the strEDEngineIFSD
	 */
	public String getStrEngineIFSD() {
		return strEDEngineIFSD;
	}

	/**
	 * @param strEDEngineIFSD the strEDEngineIFSD to set
	 */
	public void setStrEngineIFSD(String strEDEngineIFSD) {
		this.strEDEngineIFSD = strEDEngineIFSD;
	}
	
	/**
	 * @return the strEDEngineDefectRL
	 */
	public String getStrEDEngineDefectRL() {
		return strEDEngineDefectRL;
	}

	/**
	 * @param strEDEngineDefectRL the strEDEngineDefectRL to set
	 */
	public void setStrEDEngineDefectRL(String strEDEngineDefectRL) {
		this.strEDEngineDefectRL = strEDEngineDefectRL;
	}
	

	/**
	 * @return the strEDEngineDefectSR
	 */
	public String getStrEDEngineDefectSR() {
		return strEDEngineDefectSR;
	}
	

	/**
	 * @param strEDEngineDefectSR the strEDEngineDefectSR to set
	 */
	public void setStrEDEngineDefectSR(String strEDEngineDefectSR) {
		this.strEDEngineDefectSR = strEDEngineDefectSR;
	}
	

	/**
	 * @return the strEDEngineDefectSRL
	 */
	public String getStrEDEngineDefectSRL() {
		return strEDEngineDefectSRL;
	}
	

	/**
	 * @param strEDEngineDefectSRL the strEDEngineDefectSRL to set
	 */
	public void setStrEDEngineDefectSRL(String strEDEngineDefectSRL) {
		this.strEDEngineDefectSRL = strEDEngineDefectSRL;
	}
	

	/**
	 * @return the strPositionWeight
	 */
	public String getStrPositionWeight() {
		return strPositionWeight;
	}

	/**
	 * @param strPositionWeight the strPositionWeight to set
	 */
	public void setStrPositionWeight(String strPositionWeight) {
		this.strPositionWeight = strPositionWeight;
	}

	/**
	 * @return the strEngineSymptomWeight
	 */
	public String getStrEngineSymptomWeight() {
		return strEngineSymptomWeight;
	}

	/**
	 * @param strEngineSymptomWeight the strEngineSymptomWeight to set
	 */
	public void setStrEngineSymptomWeight(String strEngineSymptomWeight) {
		this.strEngineSymptomWeight = strEngineSymptomWeight;
	}

	/**
	 * @return the strEngineConditionWeight
	 */
	public String getStrEngineConditionWeight() {
		return strEngineConditionWeight;
	}

	/**
	 * @param strEngineConditionWeight the strEngineConditionWeight to set
	 */
	public void setStrEngineConditionWeight(String strEngineConditionWeight) {
		this.strEngineConditionWeight = strEngineConditionWeight;
	}

	/**
	 * @return the strPWCEnginePosition
	 */
	public String getStrPWCEnginePosition() {
		return strPWCEnginePosition;
	}

	/**
	 * @param strPWCEnginePosition the strPWCEnginePosition to set
	 */
	public void setStrPWCEnginePosition(String strPWCEnginePosition) {
		this.strPWCEnginePosition = strPWCEnginePosition;
	}

	/**
	 * @return the strPWCRFAEngineSymptomDeviation
	 */
	public String getStrPWCRFAEngineSymptomDeviation() {
		return strPWCRFAEngineSymptomDeviation;
	}

	/**
	 * @param strPWCRFAEngineSymptomDeviation the strPWCRFAEngineSymptomDeviation to set
	 */
	public void setStrPWCRFAEngineSymptomDeviation(
			String strPWCRFAEngineSymptomDeviation) {
		this.strPWCRFAEngineSymptomDeviation = strPWCRFAEngineSymptomDeviation;
	}

	/**
	 * @return the strPWCEngineCondition
	 */
	public String getStrPWCEngineCondition() {
		return strPWCEngineCondition;
	}

	/**
	 * @param strPWCEngineCondition the strPWCEngineCondition to set
	 */
	public void setStrPWCEngineCondition(String strPWCEngineCondition) {
		this.strPWCEngineCondition = strPWCEngineCondition;
	}



	/**
	 * @return the strEDEMCoefficient
	 */
	public String getStrEDEMCoefficient() {
		return strEDEMCoefficient;
	}

	/**
	 * @param strEDEMCoefficient the strEDEMCoefficient to set
	 */
	public void setStrEDEMCoefficient(String strEDEMCoefficient) {
		this.strEDEMCoefficient = strEDEMCoefficient;
	}

	/**
	 * @return the strEDEngineDefectSeverity
	 */
	public String getStrEDEngineDefectSeverity() {
		return strEDEngineDefectSeverity;
	}

	/**
	 * @param strEDEngineDefectSeverity the strEDEngineDefectSeverity to set
	 */
	public void setStrEDEngineDefectSeverity(String strEDEngineDefectSeverity) {
		this.strEDEngineDefectSeverity = strEDEngineDefectSeverity;
	}

	/**
	 * @return the strEDEngineDefectRecurrence
	 */
	public String getStrEDEngineDefectRecurrence() {
		return strEDEngineDefectRecurrence;
	}

	/**
	 * @param strEDEngineDefectRecurrence the strEDEngineDefectRecurrence to set
	 */
	public void setStrEDEngineDefectRecurrence(String strEDEngineDefectRecurrence) {
		this.strEDEngineDefectRecurrence = strEDEngineDefectRecurrence;
	}

	/**
	 * @return the strEDEngineWeightedDefectFreq
	 */
	public String getStrEDEngineWeightedDefectFreq() {
		return strEDEngineWeightedDefectFreq;
	}

	/**
	 * @param strEDEngineWeightedDefectFreq the strEDEngineWeightedDefectFreq to set
	 */
	public void setStrEDEngineWeightedDefectFreq(
			String strEDEngineWeightedDefectFreq) {
		this.strEDEngineWeightedDefectFreq = strEDEngineWeightedDefectFreq;
	}

	/**
	 * @return the strComparisionAttribute
	 */
	public String getAttributeValue(String strComparisionAttribute) {
		return attributeMap.get(strComparisionAttribute);
	}
	
	void setEngineAttributes(Context context){
		//Engine Attributes
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_POSITION_WEIGHT, strPositionWeight);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_SYMPTOM_WEIGHT, strEngineSymptomWeight);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_CONDITION_WEIGHT, strEngineConditionWeight);
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_ENGINE_POSITION, strPWCEnginePosition);
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINE_SYMPTOM_DEVIATION, strPWCRFAEngineSymptomDeviation);
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_ENGINE_CONDITION, strPWCEngineCondition);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_MODEL_FAMILY, this.getStrEngineModelFamily());
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINEMODEL, this.getStrPWCRFAEngineModel());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_MULTIPLE, this.getStrEDDefectMultiple());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_TYPE, this.getStrEDDefectType());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT, strEDEMCoefficient);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SEVERITY,strEDEngineDefectSeverity);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_RECURRENCE,strEDEngineDefectRecurrence);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_WEIGHTED_DEFECT_FREQ,strEDEngineWeightedDefectFreq);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_RL,strEDEngineDefectRL);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SR,strEDEngineDefectSR);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SRL,strEDEngineDefectSRL);
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_IFSD,strEDEngineIFSD);
		
		//Getting ID of Defect Object generated ,setting attribute values for the Defect Object 
		try {
			String strDefectObject = getStrObjectId();
			DomainObject dObj = DomainObject.newInstance(context,strDefectObject);
			dObj.setAttributeValues(context, attributeMap);
	
		} catch (Exception e) {
				e.printStackTrace();
		}
		}
	}
