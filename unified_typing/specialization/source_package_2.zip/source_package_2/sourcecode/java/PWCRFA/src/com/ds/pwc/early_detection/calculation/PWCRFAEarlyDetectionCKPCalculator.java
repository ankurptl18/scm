package com.ds.pwc.early_detection.calculation;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;

import matrix.db.Context;

import org.apache.log4j.Logger;

import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.implementations.PWCRFAEarlyDetectionDefectData;
import com.ds.pwc.early_detection.implementations.PWCRFAEarlyDetectionCombineDefectData;
import com.ds.pwc.early_detection.implementations.PWCRFAEarlyDetectionEngineDefectData;
import com.ds.pwc.early_detection.implementations.PWCRFAEarlyDetectionPartDefectData;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionCalculator;


public class PWCRFAEarlyDetectionCKPCalculator implements IPWCRFAEarlyDetectionCalculator{
	private static final Logger LOG = Logger.getLogger("PWCRFAEarlyDetectionCKPCalculator");
	
	/**
	 * The function is to calculate C K P for Part
	 * 
	 * @param context
	 * @param iRecurrenceP
	 *            int
	 * @param RFALocationRate
	 *            double
	 * @param SFPC
	 *            double
	 * @param domDefect
	 *            DomainObject
	 * @return - double
	 * @throws Exception
	 *             when problems occurred
	 */
	public Object calculate(HashMap hMap){
		LOG.debug("Start of PWCRFAEarlyDetectionCKPCalculator :calculate");
		try{
		double paramC = 0.0;
		double paramK = 0.0;
		double paramP = 0.0;
		Map attrCKP = new HashMap();
		Context context = (Context)hMap.get("context");
		Integer intRecurrence = (Integer)hMap.get("iRecurrenceP");
		int iRecurrence = intRecurrence.intValue();
		String strRFALocationRate = (String)hMap.get("RFALocationRate");
		double RFALocationRate = Double.parseDouble(strRFALocationRate);
		PWCRFAEarlyDetectionDefectData defect = (PWCRFAEarlyDetectionDefectData)hMap.get("defect");
		String strType = (String)hMap.get("Type");		
		// Creating format for the Decimal Number based on locale
		DecimalFormat format = new DecimalFormat("#.##",
				new DecimalFormatSymbols(context.getLocale()));
		
		if(strType.equals("Combined")){
			double SFESc = (Double)hMap.get("SFESc");
			double SFECc = (Double)hMap.get("SFECc");	
			// Calculating C , K , P using formula and storing values in Defect Object
			if (SFESc > 0) {
				paramC = SFESc * iRecurrence;
				paramK = SFESc * RFALocationRate;
				paramP = paramC * RFALocationRate;
			} else if (SFECc > 0) {
				paramC = SFECc * iRecurrence;
				paramK = SFECc * RFALocationRate;
				paramP = paramC * RFALocationRate;
			}

			((PWCRFAEarlyDetectionCombineDefectData)defect).setStrEDCombinedDefectRL(format.format(paramK));
			((PWCRFAEarlyDetectionCombineDefectData)defect).setStrEDCombinedDefectSR(format.format(paramC));
			((PWCRFAEarlyDetectionCombineDefectData)defect).setStrEDCombinedDefectSRL(format.format(paramP));
			System.out.println("COMBINE :: C:: "+paramC);
			System.out.println("COMBINE :: K:: "+paramK);
			System.out.println("COMBINE :: P:: "+paramP);
		}
		else if (strType.equals("Engine")){
			// Calculating C , K , P using formula and storing values in Defect Object
			double SFES = (Double)hMap.get("SFES");
			double SFEC = (Double)hMap.get("SFEC");
			if (SFES > 0) {
				paramC = SFES * iRecurrence;
				paramK = SFES * RFALocationRate;
				paramP = paramC * RFALocationRate;
			} else if (SFEC > 0) {
				paramC = SFEC * iRecurrence;
				paramK = SFEC * RFALocationRate;
				paramP = paramC * RFALocationRate;
			}

			((PWCRFAEarlyDetectionEngineDefectData)defect).setStrEDEngineDefectRL(format.format(paramK));
			((PWCRFAEarlyDetectionEngineDefectData)defect).setStrEDEngineDefectSR(format.format(paramC));
			((PWCRFAEarlyDetectionEngineDefectData)defect).setStrEDEngineDefectSRL(format.format(paramP));
			System.out.println("ENGINE :: C:: "+paramC);
			System.out.println("ENGINE :: K:: "+paramK);
			System.out.println("ENGINE :: P:: "+paramP);

		}
		else if(strType.equals("Part")){
			// Calculating C , K , P using formula and storing values in Defect Object
			double SFPC = (Double)hMap.get("SFPC");
			paramC = SFPC * iRecurrence;
			paramK = SFPC * RFALocationRate;
			paramP = paramC * RFALocationRate;
			((PWCRFAEarlyDetectionPartDefectData)defect).setStrEDPartDefectRL(format.format(paramK));
			((PWCRFAEarlyDetectionPartDefectData)defect).setStrEDPartDefectSR(format.format(paramC));
			((PWCRFAEarlyDetectionPartDefectData)defect).setStrEDPartDefectSRL(format.format(paramP));
			System.out.println("PART :: C:: "+paramC);
			System.out.println("PART :: K:: "+paramK);
			System.out.println("PART :: P:: "+paramP);
					
		}

		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Exception in PWCRFAEarlyDetectionCKPCalculator:calculate : "	+ ex.getMessage());
		}
		LOG.debug("End of PWCRFAEarlyDetectionCKPCalculator:calculate");
		return 0;

		}


}
