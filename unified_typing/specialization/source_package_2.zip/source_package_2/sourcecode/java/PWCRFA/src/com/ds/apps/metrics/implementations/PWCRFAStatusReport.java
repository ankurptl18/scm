package com.ds.apps.metrics.implementations;

import static com.ds.common.PWCConstants.ATTRIBUTE_ISSUE_CLASSIFICATION;
import static com.ds.common.PWCConstants.ATTRIBUTE_PROB_FOUND_DURING;
import static com.ds.common.PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_TYPE;
import static com.ds.common.PWCConstants.ATTRIBUTE_PWC_RFA_PART_TYPE;
import static com.ds.common.PWCConstants.ATTRIBUTE_RFA_BUSINESS_PROCESS;
import static com.ds.common.PWCConstants.RELATIONSHIP_PWC_RFA_EVENT_LOCATION;
import static com.matrixone.apps.domain.DomainConstants.SELECT_ORIGINATED;
import static com.matrixone.apps.domain.DomainConstants.EMPTY_STRING;
import static com.matrixone.apps.domain.DomainConstants.SELECT_CURRENT;
import static com.matrixone.apps.domain.DomainConstants.SELECT_ID;
import static com.matrixone.apps.domain.DomainConstants.SELECT_NAME;
import static com.matrixone.apps.domain.DomainConstants.SELECT_POLICY;
import static com.ds.common.PWCConstants.ATTRIBUTE_PWC_RFA_OCCURRENCE_TYPE;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectItr;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.Context;
import matrix.util.StringList;

import com.ds.apps.metrics.interfaces.IPWCRFAReport;
import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCRFAStatusReport implements IPWCRFAReport {

	public Date FROM_DATE=null;
    public Date TO_DATE=null;
    public static final String ATTRIBUTE_PWC_RFA_EVENT_DATE = PropertyUtil.getSchemaProperty("attribute_PWC_RFAEventDate");

	@SuppressWarnings({ "unchecked" })
	public String buildSearchCriteria(Context paramContext, StringList objectList, HashMap searchCriteriaDataMap) throws Exception {

		String STR_GROUP_BY_SELECT = DomainObject.EMPTY_STRING;
		String SELECT_RFA_BUSINESS_PROCESS = "attribute[" + ATTRIBUTE_RFA_BUSINESS_PROCESS + "]";

		String SELECT_RFA_PFD = "attribute[" + ATTRIBUTE_PROB_FOUND_DURING + "]";
		String SELECT_RFA_PART_TYPE = "attribute[" + ATTRIBUTE_PWC_RFA_PART_TYPE + "]";
		String SELECT_RFA_EVENT_LOCATION = "from[" + RELATIONSHIP_PWC_RFA_EVENT_LOCATION + "].to.id";


		// Group By
		String SELECT_ATTR_PWC_RFA_LIABILITY_CONFIRMATION_DATE = "attribute[" + PWCConstants.ATTRIBUTE_PWC_RFA_LIABILITY_CONFIRMATION_DATE + "]";
		String SELECT_ATTR_RFA_EVENT_DATE = "attribute[" + ATTRIBUTE_PWC_RFA_EVENT_DATE + "]";
		String SELECT_CLOSED_DATE = "state[Closed].actual";

		// Sub Group By
		String SELECT_ATTR_SEVERITY = "attribute[" + PWCConstants.ATTRIBUTE_RFA_SEVERITY + "]";
		String SELECT_RFA_PROBLEM_VALIDATION = "attribute[" + PWCConstants.ATTRIBUTE_PWC_RFA_PROBLEM_VALIDATION + "]";
		String SELECT_RFA_INVESTIGATION_STATUS = "attribute[" + PWCConstants.ATTRIBUTE_INVESTIGATION_STATUS + "]";
		String SELECT_RFA_SUB_PROCESS = "attribute[" + PWCConstants.ATTRIBUTE_PWC_RFAPROCESSSUBTYPE + "]";
		String SELECT_RFA_EVENT_TYPE = "attribute[" + ATTRIBUTE_PWC_RFA_EVENT_TYPE + "]";
		String SELECT_RFA_ISSUE_CLASSIFICATION= "attribute[" + ATTRIBUTE_ISSUE_CLASSIFICATION + "]";
		String SELECT_ATTR_EVENT_IMPACT = "attribute[" + PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_IMPACT + "]";
		String SELECT_ENGINE_FAMILY =  DomainConstants.EMPTY_STRING;  // This sub group has to be handled
		String SELECT_ATTR_IPT_ID = "attribute[" + PWCConstants.ATTRIBUTE_PWC_IPT_ID + "]";
		String SELECT_ATTR_PROB_FOUND_DURING = "attribute[" + PWCConstants.ATTRIBUTE_PROB_FOUND_DURING + "]";
		String SELECT_RFA_OCCURRENCE_TYPE = "attribute[" + ATTRIBUTE_PWC_RFA_OCCURRENCE_TYPE + "]";

		String strSelectedBusinessProcess = (String) searchCriteriaDataMap.get("selectedBusinessProcess");
		String strSelectedLifecycleState = (String) searchCriteriaDataMap.get("selectedLifecycleState");
		String strSelectedEventType = (String) searchCriteriaDataMap.get("selectedEventType");
		String strSelectedSubType = (String) searchCriteriaDataMap.get("selectedSubType");
		String strSelectedPFD = (String) searchCriteriaDataMap.get("selectedPFD");
		String strSelectedPartType = (String) searchCriteriaDataMap.get("selectedPartType");
		String strSelectedEventLocationOID = (String) searchCriteriaDataMap.get("txtActualContainedEventLocationOID");
		String strGroupBy = (String) searchCriteriaDataMap.get("lstGroupBy");
		String strSubGroupBy 				= (String) searchCriteriaDataMap.get("lstSubgroup");
		String strSelectedCreationFromDate 	= (String) searchCriteriaDataMap.get("txtFromDate_msvalue");
		String strSelectedCreationToDate 	= (String) searchCriteriaDataMap.get("txtToDate_msvalue");
		String strPeriodPriorToCurrentDate 	= (String) searchCriteriaDataMap.get("PeriodPriorToCurrentDate");
		String strDateUnit 					= (String) searchCriteriaDataMap.get("optDateUnit");

		String strSelectedOccurrenceType = (String) searchCriteriaDataMap.get("selectedOccurrenceType");

		if(!UIUtil.isNullOrEmpty(strSelectedCreationFromDate) && !UIUtil.isNullOrEmpty(strSelectedCreationToDate))
		{
			FROM_DATE = new Date(strSelectedCreationFromDate);
			TO_DATE = new Date(strSelectedCreationToDate);
		}
        
		if(!UIUtil.isNullOrEmpty(strPeriodPriorToCurrentDate) && !UIUtil.isNullOrEmpty(strDateUnit))
        	setFromToDate(strPeriodPriorToCurrentDate, strDateUnit);

		//object where to to search RFA Objects
	    StringBuilder sbExpressionBuilder = new StringBuilder();

		String strSearchCriteria = EMPTY_STRING;
		StringBuffer sbSearchCriteria = new StringBuffer();
		StringList models = objectList;
		StringList TARGET_RFA_NAME_LIST = new StringList();
		StringList TARGET_RFA_ID_LIST = new StringList();

		// if engine model list is empty then we need to look all RFAs
		if(null==models || models.size()==0)
		{
			StringList objectSelects = new StringList(DomainConstants.SELECT_ID);
			MapList allRFAList = DomainObject.findObjects(paramContext,
														PWCConstants.TYPE_RFA,
														DomainConstants.QUERY_WILDCARD,
														DomainConstants.QUERY_WILDCARD,
														DomainConstants.QUERY_WILDCARD,
														PWCCommonUtil.getVaultPattern(paramContext),
														null,
														false,
														objectSelects);

			int nSize = allRFAList.size();
			if(nSize > 0)
			{
				for(int n=0;n<nSize;n++)
				{
					Map tempMap = (Map)allRFAList.get(n);
					TARGET_RFA_ID_LIST.add((String)tempMap.get(DomainConstants.SELECT_ID));
				}
			}

		}else{

			// get all the RFA IDs.
			StringList MODEL_SELECTS = new StringList();

			MODEL_SELECTS.add("to[" + PWCConstants.RELATIONSHIP_PWC_RFA_MODEL + "].from.id");

			Set<String> modelIdSet = new HashSet<String>();
			for (int i = 0; i < models.size(); i++) {
				modelIdSet.add(((String) models.get(i)).trim());
			}
			BusinessObjectWithSelectList RFAList = BusinessObject.getSelectBusinessObjectData(paramContext, (String[]) modelIdSet.toArray(new String[0]),
			        MODEL_SELECTS);
			BusinessObjectWithSelectItr RFAWithSelectItr = new BusinessObjectWithSelectItr(RFAList);

			while (RFAWithSelectItr.next()) {
				BusinessObjectWithSelect RFAWithSelect = RFAWithSelectItr.obj();
				StringList strIdList = (StringList) RFAWithSelect.getSelectDataList("to[" + PWCConstants.RELATIONSHIP_PWC_RFA_MODEL + "].from.id");
				if (null != strIdList && strIdList.size() > 0) {
					for (int n = 0; n < strIdList.size(); n++) {
						TARGET_RFA_ID_LIST.add((String) strIdList.get(n));
					}
				}
			}
		}

		StringList RFA_SELECTS = new StringList();
		RFA_SELECTS.add(SELECT_POLICY);
		RFA_SELECTS.add(SELECT_CURRENT);
		RFA_SELECTS.add(SELECT_NAME);
		RFA_SELECTS.add(SELECT_ID);
		if (!UIUtil.isNullOrEmpty(strSelectedBusinessProcess))
			RFA_SELECTS.add(SELECT_RFA_BUSINESS_PROCESS);
		if (!UIUtil.isNullOrEmpty(strSelectedEventType))
			RFA_SELECTS.add(SELECT_RFA_EVENT_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedSubType))
			RFA_SELECTS.add(SELECT_RFA_ISSUE_CLASSIFICATION);
		if (!UIUtil.isNullOrEmpty(strSelectedPFD))
			RFA_SELECTS.add(SELECT_RFA_PFD);
		if (!UIUtil.isNullOrEmpty(strSelectedPartType))
			RFA_SELECTS.add(SELECT_RFA_PART_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedEventLocationOID))
			RFA_SELECTS.add(SELECT_RFA_EVENT_LOCATION);
		if (!UIUtil.isNullOrEmpty(strSelectedOccurrenceType))
			RFA_SELECTS.add(SELECT_RFA_OCCURRENCE_TYPE);

		RFA_SELECTS.add(SELECT_RFA_INVESTIGATION_STATUS);
		RFA_SELECTS.add(SELECT_RFA_PROBLEM_VALIDATION);
		RFA_SELECTS.add(SELECT_ATTR_SEVERITY);
		RFA_SELECTS.add(SELECT_RFA_INVESTIGATION_STATUS);
		RFA_SELECTS.add(SELECT_RFA_SUB_PROCESS);
		RFA_SELECTS.add(SELECT_RFA_EVENT_TYPE);
		RFA_SELECTS.add(SELECT_RFA_ISSUE_CLASSIFICATION);
		RFA_SELECTS.add(SELECT_ATTR_EVENT_IMPACT);
		RFA_SELECTS.add(SELECT_ENGINE_FAMILY);
		RFA_SELECTS.add(SELECT_ATTR_IPT_ID);
		RFA_SELECTS.add(SELECT_ATTR_PROB_FOUND_DURING);

		if (!UIUtil.isNullOrEmpty(strGroupBy))
		{
			if ("Originated".equals(strGroupBy))
			{
				RFA_SELECTS.add(SELECT_ORIGINATED);
				STR_GROUP_BY_SELECT = SELECT_ORIGINATED;
			}
			else if (ATTRIBUTE_PWC_RFA_EVENT_DATE.equals(strGroupBy))
			{
				RFA_SELECTS.add(SELECT_ATTR_RFA_EVENT_DATE);
				STR_GROUP_BY_SELECT = SELECT_ATTR_RFA_EVENT_DATE;
			}
			else if (PWCConstants.ATTRIBUTE_PWC_RFA_LIABILITY_CONFIRMATION_DATE.equals(strGroupBy))
			{
				RFA_SELECTS.add(SELECT_ATTR_PWC_RFA_LIABILITY_CONFIRMATION_DATE);
				STR_GROUP_BY_SELECT = SELECT_ATTR_PWC_RFA_LIABILITY_CONFIRMATION_DATE;
			}
			if ("Closed Date".equals(strGroupBy))
			{
				RFA_SELECTS.add(SELECT_CLOSED_DATE);
				STR_GROUP_BY_SELECT = SELECT_CLOSED_DATE;
			}
		}

		Set<String> RFAIdSet = new HashSet<String>();
		if (null != TARGET_RFA_ID_LIST && TARGET_RFA_ID_LIST.size() > 0) {
			for (int i = 0; i < TARGET_RFA_ID_LIST.size(); i++) {
				RFAIdSet.add(((String) TARGET_RFA_ID_LIST.get(i)).trim());
			}
		}

		BusinessObjectWithSelectList busRFAList = BusinessObject.getSelectBusinessObjectData(paramContext, (String[]) RFAIdSet.toArray(new String[0]),
		        RFA_SELECTS);
		BusinessObjectWithSelectItr busWithSelectItr = new BusinessObjectWithSelectItr(busRFAList);

		while (busWithSelectItr.next()) {
			String strRFAName = null;
			String strState = null;
			String strRFABusProcess = null;
			String strRFAEventType = null;
			String strRFASubType = null;
			String strRFAPFD = null;
			String strRFAPartType = null;
			String strRFAEventLocation = null;
			String strRFAInvestigationStatus = null;
			String strRFAProblemValidation = null;
			String strRFAOccurenceType = null;

			String strRFAGroupByDateValue = null;

			String strRFASeverity = null;
			String strSubProcess = null;
			String strEventImpact = null;
			String strEngineFamily = null;
			String strIPTID = null;
			String strProblemFoundDuring = null;



			BusinessObjectWithSelect busWithSelect = busWithSelectItr.obj();
			StringList strNameList = (StringList) busWithSelect.getSelectDataList(SELECT_NAME);
			StringList strStateList = (StringList) busWithSelect.getSelectDataList(SELECT_CURRENT);
			StringList strRFABusProcessList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_BUSINESS_PROCESS);
			StringList strRFAEventTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_EVENT_TYPE);
			StringList strRFASubTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_ISSUE_CLASSIFICATION);
			StringList strRFAPFDList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_PFD);
			StringList strRFAPartTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_PART_TYPE);
			StringList strRFAEventLocationList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_EVENT_LOCATION);
			StringList strRFAProblemValidationList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_PROBLEM_VALIDATION);
			StringList strRFAInvestigationStatusList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_INVESTIGATION_STATUS);

			StringList strRFASeverityList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_SEVERITY);
			StringList strSubProcessList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_SUB_PROCESS);
			StringList strEventImpactList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_EVENT_IMPACT);
			StringList strEngineFamilyList = (StringList) busWithSelect.getSelectDataList(SELECT_ENGINE_FAMILY);
			StringList strIPTIDList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_IPT_ID);
			StringList strProblemFoundDuringList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_PROB_FOUND_DURING);
			StringList strRFAGroupByDateValueList = (StringList) busWithSelect.getSelectDataList(STR_GROUP_BY_SELECT);
			StringList strRFAOccurenceTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_OCCURRENCE_TYPE);
			

			if (null != strNameList && strNameList.size() > 0)
				strRFAName = (String) strNameList.get(0);
			if (null != strStateList && strStateList.size() > 0)
				strState = (String) strStateList.get(0);
			if (null != strRFABusProcessList && strRFABusProcessList.size() > 0)
				strRFABusProcess = (String) strRFABusProcessList.get(0);
			if (null != strRFAEventTypeList && strRFAEventTypeList.size() > 0)
				strRFAEventType = (String) strRFAEventTypeList.get(0);
			if (null != strRFASubTypeList && strRFASubTypeList.size() > 0)
				strRFASubType = (String) strRFASubTypeList.get(0);
			if (null != strRFAPFDList && strRFAPFDList.size() > 0)
				strRFAPFD = (String) strRFAPFDList.get(0);
			if (null != strRFAPartTypeList && strRFAPartTypeList.size() > 0)
				strRFAPartType = (String) strRFAPartTypeList.get(0);
			if (null != strRFAEventLocationList && strRFAEventLocationList.size() > 0)
				strRFAEventLocation = (String) strRFAEventLocationList.get(0);
			if (null != strRFAProblemValidationList && strRFAProblemValidationList.size() > 0)
				strRFAProblemValidation = (String) strRFAProblemValidationList.get(0);
			if (null != strRFAInvestigationStatusList && strRFAInvestigationStatusList.size() > 0)
				strRFAInvestigationStatus = (String) strRFAInvestigationStatusList.get(0);

			if (null != strRFASeverityList && strRFASeverityList.size() > 0)
				strRFASeverity = (String) strRFASeverityList.get(0);
			if (null != strSubProcessList && strSubProcessList.size() > 0)
				strSubProcess = (String) strSubProcessList.get(0);
			if (null != strEventImpactList && strEventImpactList.size() > 0)
				strEventImpact = (String) strEventImpactList.get(0);
			if (null != strEngineFamilyList && strEngineFamilyList.size() > 0)
				strEngineFamily = (String) strEngineFamilyList.get(0);
			if (null != strIPTIDList && strIPTIDList.size() > 0)
				strIPTID = (String) strIPTIDList.get(0);
			if (null != strProblemFoundDuringList && strProblemFoundDuringList.size() > 0)
				strProblemFoundDuring = (String) strProblemFoundDuringList.get(0);
			if (null != strRFAGroupByDateValueList && strRFAGroupByDateValueList.size() > 0)
				strRFAGroupByDateValue = (String) strRFAGroupByDateValueList.get(0);
			if (null != strRFAOccurenceTypeList && strRFAOccurenceTypeList.size() > 0)
				strRFAOccurenceType = (String) strRFAOccurenceTypeList.get(0);

			boolean add = true;
			if (PWCConstants.STATE_POLICY_RFA_DRDEV_CANCELLED.equals(strState))
				add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedLifecycleState))
				if (UIUtil.isNullOrEmpty(strState) || strSelectedLifecycleState.indexOf(strState) == -1)
					add = false;
			if (add && UIUtil.isNullOrEmpty(strRFAName))
				add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedBusinessProcess))
				if (UIUtil.isNullOrEmpty(strRFABusProcess) || strSelectedBusinessProcess.indexOf(strRFABusProcess) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedEventType))
				if (UIUtil.isNullOrEmpty(strRFAEventType) || strSelectedEventType.indexOf(strRFAEventType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedSubType))
				if (UIUtil.isNullOrEmpty(strRFASubType) || strSelectedSubType.indexOf(strRFASubType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedPFD))
				if (UIUtil.isNullOrEmpty(strRFAPFD) || strSelectedPFD.indexOf(strRFAPFD) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedPartType))
				if (UIUtil.isNullOrEmpty(strRFAPartType) || strSelectedPartType.indexOf(strRFAPartType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedEventLocationOID))
				if (UIUtil.isNullOrEmpty(strRFAEventLocation) || strSelectedEventLocationOID.indexOf(strRFAEventLocation) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedOccurrenceType))
				if (UIUtil.isNullOrEmpty(strRFAOccurenceType) || strSelectedOccurrenceType.indexOf(strRFAOccurenceType) == -1)
					add = false;

			if (add && (!UIUtil.isNullOrEmpty(FROM_DATE.toString()) && !UIUtil.isNullOrEmpty(TO_DATE.toString())))
			{
				if(!UIUtil.isNullOrEmpty(strRFAGroupByDateValue))
				{
					Date RFAOriginated = new Date(strRFAGroupByDateValue);
					if(RFAOriginated.before(FROM_DATE) || RFAOriginated.after(TO_DATE))
						add = false;
				}
				else
				{
					add = false;
				}
			}


			// to handle mentioned status category only

			if(add && (strRFAInvestigationStatus.equalsIgnoreCase("Not Actionned")
					&& strRFAProblemValidation.equals(DomainConstants.EMPTY_STRING)))
			{
				add = true;
			}else if(add && (strRFAInvestigationStatus.equalsIgnoreCase("EQUEST in Progress")
					&& strRFAProblemValidation.equals(DomainConstants.EMPTY_STRING))){
				add = true;
			}else if(add && (strRFAInvestigationStatus.equalsIgnoreCase("Closed with Justification")
					&& strRFAProblemValidation.equalsIgnoreCase("Not Confirmed"))){
				add = true;
			}else if(add && (strRFAInvestigationStatus.equalsIgnoreCase("Closed with Justification")
					&& strRFAProblemValidation.equalsIgnoreCase("Confirmed"))){
				add = true;
			}else if(add && (strRFAInvestigationStatus.equalsIgnoreCase("Closed CA Complete")
					&& strRFAProblemValidation.equalsIgnoreCase("Confirmed"))){
				add = true;
			}else{
				add = false;
			}

		   if (add)
				TARGET_RFA_NAME_LIST.add(strRFAName);
		}

		if (TARGET_RFA_NAME_LIST.size() > 0) {

			sbSearchCriteria.append("temp query bus \"" + PWCConstants.TYPE_RFA + "\" ");

			for (int j = 0; j < TARGET_RFA_NAME_LIST.size(); j++) {
				String strRFAName = (String) TARGET_RFA_NAME_LIST.get(j);
				sbSearchCriteria.append(strRFAName);

				if (j != TARGET_RFA_NAME_LIST.size() - 1)
					sbSearchCriteria.append(",");
			}

			sbSearchCriteria.append(" -  where \"expression[pwcRFAOrginatedDuringPrevious2Years]\"");
		}

		strSearchCriteria = sbSearchCriteria.toString();

		if (strSearchCriteria.equals(EMPTY_STRING) && null != models && models.size() > 0) {
			String strModelId = (String) models.get(0);
			strSearchCriteria = "print bus " + strModelId + "select name";
		}
		if (strSearchCriteria.equals(EMPTY_STRING))
		{
			strSearchCriteria = "print bus Model GENERAL \"\" select name";
		}

		System.out.println("--strSearchCriteria--in RFA Status report--->" + strSearchCriteria);

		return strSearchCriteria;
	}

	private void setFromToDate(String strPeriod, String strDateUnit)
	{
		Calendar cal =  Calendar.getInstance();
		TO_DATE = cal.getTime();

		int period = Integer.parseInt(strPeriod);
		if(!UIUtil.isNullOrEmpty(strDateUnit))
		{
			if(strDateUnit.equalsIgnoreCase("M"))
				cal.add(cal.MONTH, -period);
			if(strDateUnit.equalsIgnoreCase("Y"))
				cal.add(cal.YEAR, -period);
			if(strDateUnit.equalsIgnoreCase("Q"))
				cal.add(cal.MONTH, -(3*period));
			if(strDateUnit.equalsIgnoreCase("W"))
				cal.add(cal.DATE, -(7*period));

			FROM_DATE = cal.getTime();
}

	}
}

