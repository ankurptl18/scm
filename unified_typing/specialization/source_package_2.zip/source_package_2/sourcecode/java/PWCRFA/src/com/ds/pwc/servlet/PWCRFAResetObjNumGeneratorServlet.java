package com.ds.pwc.servlet;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import matrix.db.Context;
import matrix.util.StringList;
import matrix.util.TimerClient;

import org.apache.log4j.Logger;

import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.servlet.FrameworkServlet;

public class PWCRFAResetObjNumGeneratorServlet extends FrameworkServlet implements TimerClient 
{

	private static final long serialVersionUID	= 1L;
	private static final Logger _LOGGER	= Logger.getLogger(PWCRFAResetObjNumGeneratorServlet.class.getName());
	private Context context	= null;
	
	public static final String ATTRIBUTE_ESERVICE_NAME_PREFIX	= PropertyUtil.getSchemaProperty("attribute_eServiceNamePrefix");	
	public static final String ATTRIBUTE_ESERVICE_NEXT_NUM		= PropertyUtil.getSchemaProperty("attribute_eServiceNextNumber");	
	public static final String TYPE_ESERVICE_OBJ_GEN 			= PropertyUtil.getSchemaProperty("type_eServiceObjectGenerator");
	public static final String TYPE_ESERVICE_NUM_GEN 			= PropertyUtil.getSchemaProperty("type_eServiceNumberGenerator");	
	public static final String REL_ESERVICE_NUM_GEN 			= PropertyUtil.getSchemaProperty("relationship_eServiceNumberGenerator");
	
	public void init(ServletConfig config) throws ServletException 
	{	
		_LOGGER.debug("Start of PWCRFAResetObjNumGeneratorServlet :: init()");
		super.init(config);	
		boolean bStartTimers		= true;		
		String strCurrentYearPrefix = getCurrentYearPrefix();			
		try 
		{
			context = new Context("");
			ContextUtil.pushContext(context, "creator", null, null);
			
			// Retrieve the current year
			// Get the RFA Prefixes and it will be in a Map
			// if any one of the RFA Prefix is not matched with the current year then run the time expired 
			// else if all the prefixes match with the current year then run the below methods
			//	startTimers();	
			Map<String, String> mapRFAPrefix = getRFAData(context, TYPE_ESERVICE_OBJ_GEN, ATTRIBUTE_ESERVICE_NAME_PREFIX);			
			Map newDataMap = validateExecutionProcess(mapRFAPrefix, strCurrentYearPrefix);
			
			if (newDataMap != null && !newDataMap.isEmpty()) 
			{
				timerExpired(null);				
			} 
			else 
			{
				startTimers();				
			}		
	    } 
		catch (Exception ex) 
	    {
	    	ex.printStackTrace();
			_LOGGER.error("Exception in PWCRFAResetObjNumGeneratorServlet :: init()");
	    } 
		_LOGGER.debug("End of PWCRFAResetObjNumGeneratorServlet :: init()");
	}

	public void destroy() {	
		// stop any timers that may be running
	}

	public void timerStarted(matrix.util.Timer timer) {	
		
	}

	public synchronized void timerExpired(matrix.util.Timer timer) {			
		_LOGGER.debug("Start of PWCRFAResetObjNumGeneratorServlet :: timerExpired()");
		try 
		{
			updateRFAObjectAndNumGenerator(context, TYPE_ESERVICE_OBJ_GEN, ATTRIBUTE_ESERVICE_NAME_PREFIX);
			startTimers();
		} catch (Exception ex) {
			ex.printStackTrace();
			_LOGGER.error("Exception in PWCRFAResetObjNumGeneratorServlet :: timerExpired()");
		}		
		_LOGGER.debug("End of PWCRFAResetObjNumGeneratorServlet :: timerExpired()");
	}
	
	/* 
	 * Timer to restart the service in 31st December
	 */
	private void startTimers()
	{
		Calendar cal 			= Calendar.getInstance();
		long iCurrentTime 		= cal.getTimeInMillis();
		cal.set(cal.get(Calendar.YEAR) + 1, Calendar.JANUARY, 01, 00, 00, 01);
		long iNextTime 			= cal.getTimeInMillis();
		int NEXT_RUN 			= ( (int) Math.ceil((iNextTime - iCurrentTime)/1000));
		
		matrix.util.Timer timer = new matrix.util.Timer(this, NEXT_RUN);		            
		timer.start();
	}
	
	private Map<String, String> getRFAData(Context context, String sType, String sAttribute) 
		throws Exception
	{
		_LOGGER.debug("Start of PWCRFAResetObjNumGeneratorServlet:getRFAPrefixes()");
		Map<String, String> mapRFABPPrefix 	= new HashMap<String, String>();
		String strBusinessProcessId			= DomainConstants.EMPTY_STRING;
		String strBusinessProcessPrefix 	= DomainConstants.EMPTY_STRING;
		MapList mapList  					= null;
		StringList busSelects 				= new StringList();	   		
		busSelects.addElement(DomainConstants.SELECT_ID);
	    busSelects.addElement(DomainConstants.SELECT_NAME);
	    busSelects.addElement("attribute[" + sAttribute + "]");	 
	  	
	    try 
	    {
	    	mapList	= DomainObject.findObjects(context,			//context
							sType,								//type
							PWCConstants.ADMIN_TYPE_RFA,		//name
							DomainConstants.QUERY_WILDCARD,		//revision
							DomainConstants.QUERY_WILDCARD,		//owner
							PWCConstants.ADMINISTRATION_VAULT,	//vault
							DomainConstants.EMPTY_STRING,		//where
							DomainConstants.EMPTY_STRING,		//query name
							false,								//expandType
							busSelects,							//select list
							(short) 0);							//recurse to limit
	    	
	    	if (mapList != null && mapList.size() > 0)
	    	{	
	    		Iterator itr = mapList.iterator();
	    	    while (itr.hasNext())
	    	    {
	    	        Map map 					= (Map) itr.next();
	    	        strBusinessProcessId 		= (String) map.get(DomainConstants.SELECT_ID);
	    	        strBusinessProcessPrefix 	= (String) map.get("attribute[" + sAttribute + "]");	    	        
	    	        mapRFABPPrefix.put(strBusinessProcessId, strBusinessProcessPrefix);
	    	    }
	    	}		    
	    } 
	    catch (Exception ex) 
	    {
	    	ex.printStackTrace();
	    	_LOGGER.error("Error - " + ex.getMessage());
			throw new Exception("PWCRFAResetObjNumGeneratorServlet:getRFAPrefixes()"+ex.getMessage());
	    }
	    _LOGGER.debug("End of PWCRFAResetObjNumGeneratorServlet:getRFAPrefixes()");
		return mapRFABPPrefix;	    	
	}	
	
	private String getCurrentYearPrefix() 
	{		
		_LOGGER.debug("Start of PWCRFAResetObjNumGeneratorServlet:getCurrentYearPrefix()");
		Calendar now 			= Calendar.getInstance();  	
		int iCurrentYear 		= now.get(Calendar.YEAR);
		String strCurrentYear 	= Integer.toString(iCurrentYear);
		strCurrentYear 			= strCurrentYear.substring(2, strCurrentYear.length());
		_LOGGER.debug("End of PWCRFAResetObjNumGeneratorServlet:getCurrentYearPrefix()");
		return strCurrentYear;
	}
	
	private Map validateExecutionProcess(Map<String, String> mapRFAPrefix, String strCurrentYearPrefix) {
		_LOGGER.debug("Start of PWCRFAResetObjNumGeneratorServlet:validateExecutionProcess()");
		
		Set<String> mapSet 				= (Set)mapRFAPrefix.entrySet();
		Map<String, String> newDataMap 	= new HashMap<String, String>();
        Iterator mapIterator 			= mapSet.iterator();
        String keyValue 				= DomainConstants.EMPTY_STRING;
        String value 					= DomainConstants.EMPTY_STRING;
        while (mapIterator.hasNext()) 
        {
	        Map.Entry mapEntry 	= (Map.Entry) mapIterator.next();
	        keyValue			= (String) mapEntry.getKey();
	        value 				= (String) mapEntry.getValue();     
	        
	        if (!UIUtil.isNullOrEmpty(value)) 
	        {
        		String strNewValue = value.substring(0, 2);              		
        		if (!strNewValue.equals(strCurrentYearPrefix)) 
        		{        		
        			newDataMap.put(keyValue, value);
        		} 
        	}
        }
    	_LOGGER.debug("End of PWCRFAResetObjNumGeneratorServlet:validateExecutionProcess()");
		return newDataMap;
	}
	
	private void updateRFAObjectAndNumGenerator (Context context, String sType, String sAttrName) throws Exception{
		_LOGGER.debug("End of PWCRFAResetObjNumGeneratorServlet:updateRFANumberGenerator()");
		String keyValue 					= DomainConstants.EMPTY_STRING;
		String value 						= DomainConstants.EMPTY_STRING;   
		String strObjectId 					= DomainConstants.EMPTY_STRING; 
		String strObjectRev					= DomainConstants.EMPTY_STRING;
		String strAttrNextNum 				= DomainConstants.EMPTY_STRING;
		StringBuilder sbExpressionBuilder	= new StringBuilder();
		StringList 	selectList 				= new StringList(3);
		String strObjectIdSelect 			= sbExpressionBuilder.append("from[").append(REL_ESERVICE_NUM_GEN).append("].to.").append(DomainConstants.SELECT_ID).toString();
		String strObjectRevSelect 			= sbExpressionBuilder.append("from[").append(REL_ESERVICE_NUM_GEN).append("].to.").append(DomainConstants.SELECT_REVISION).toString();
		String strAttrNextNumSelect 		= sbExpressionBuilder.append("from[").append(REL_ESERVICE_NUM_GEN).append("].to.attribute[").append(ATTRIBUTE_ESERVICE_NEXT_NUM).append("].value").toString();
		
		selectList.add(strObjectIdSelect);
		selectList.add(strObjectRevSelect);
		selectList.add(strAttrNextNumSelect);
		
		System.out.println("STARTED UPDATING THE NUMBER GENERATOR");
		try 
		{			
			Map<String, String> dataMap = getRFAData(context, TYPE_ESERVICE_OBJ_GEN, ATTRIBUTE_ESERVICE_NAME_PREFIX);			
			String strCurrentYearPrefix = getCurrentYearPrefix();			
			Map mapRFAPrefix 			= validateExecutionProcess(dataMap, strCurrentYearPrefix); 
			
			if (mapRFAPrefix != null && !mapRFAPrefix.isEmpty()) 
			{
				DomainObject doRFA  	= DomainObject.newInstance(context);
				Set mapSet				= (Set) mapRFAPrefix.entrySet();
				Iterator mapIterator 	= mapSet.iterator();
				
				while (mapIterator.hasNext()) 
				{
					Map.Entry mapEntry	= (Map.Entry) mapIterator.next();
					keyValue 			= (String) mapEntry.getKey();
					value 				= (String) mapEntry.getValue(); 
					
					doRFA.setId(keyValue);	
					Map mapNumGenInfo = doRFA.getInfo(context, selectList);
				    value = strCurrentYearPrefix + value.substring(2, value.length());		
				    doRFA.setAttributeValue(context, ATTRIBUTE_ESERVICE_NAME_PREFIX, value);			
					
				    if (mapNumGenInfo != null && !mapNumGenInfo.isEmpty()) 
					{
						strObjectId 	= (String) mapNumGenInfo.get(strObjectIdSelect);
						strObjectRev	= (String) mapNumGenInfo.get(strObjectRevSelect);
						strAttrNextNum 	= (String) mapNumGenInfo.get(strAttrNextNumSelect);						
						doRFA.setId(strObjectId);	
						
						// Write the logic here to count the number of character in the strAttrNextNum and start replacing all the characters to 0 and the last character in the string should be 1. 
						doRFA.setAttributeValue(context, ATTRIBUTE_ESERVICE_NEXT_NUM, "00001");
					}					
				}				
			}			
		} catch (Exception ex) 
		{
			ex.printStackTrace();
			_LOGGER.error("Error - " + ex.getMessage());
			throw new Exception("PWCRFAResetObjNumGeneratorServlet:updateRFANumberGenerator()"+ex.getMessage());
		}
		_LOGGER.debug("End of PWCRFAResetObjNumGeneratorServlet:updateRFANumberGenerator()");
	}
}
