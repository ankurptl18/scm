package com.ds.pwc.early_detection.implementations;

import com.ds.pwc.early_detection.PWCRFAEarlyDetectionRFAData;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionDefect;

public class PWCRFAEarlyDetectionDefectFactory {
	public static IPWCRFAEarlyDetectionDefect getDefectTypeInstance(PWCRFAEarlyDetectionRFAData rfaData ) throws Exception
	{
		//Getting Defect class name from getDefectTypeClassName()
		String strClassName = getDefectTypeClassName(rfaData);
		Class cls = Class.forName(strClassName);
		Object instance = (Object) cls.newInstance();
		return (IPWCRFAEarlyDetectionDefect) instance;
	}
	private static String getDefectTypeClassName(PWCRFAEarlyDetectionRFAData rfaData){
		String strClassName="";
		//If both the relationships are present , then call class for Combined Defect,
		//else if PWC_RFA Physical Part relationship is present then call Part Defect class
		//else if PWC_RFA Engine Info relationship is present then call Engine Defect class
		
		if(rfaData.isCombinedDefect()){
			strClassName = PWCRFAEarlyDetectionCombinedDefect.class.getName();
		}else if(rfaData.isEngineDefect()){
			strClassName = PWCRFAEarlyDetectionEngineDefect.class.getName();
		}else if (rfaData.isPartDefect()){
			strClassName = PWCRFAEarlyDetectionPartDefect.class.getName();
		}
		return strClassName;
	}
	

}