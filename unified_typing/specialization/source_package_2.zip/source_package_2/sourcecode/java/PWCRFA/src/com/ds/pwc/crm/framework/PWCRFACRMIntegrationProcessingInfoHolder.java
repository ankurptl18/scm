package com.ds.pwc.crm.framework;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * Instance of this class behaves an a holder of the error or warning information while processing each CRM Integration Data Files.
 * This information is further used to generate the log files for each data file.
 * 
 * @author ZWE
 *
 */
public class PWCRFACRMIntegrationProcessingInfoHolder 
{
	private static final Logger _LOGGER = Logger.getLogger(PWCRFACRMIntegrationProcessingInfoHolder.class.getName());

	private static final String OK = "OK" ;
	private static final String KO = "KO" ;
	private static final String WARNING = "WARNING" ;

	private static PWCRFACRMIntegrationProcessingInfoHolder INSTANCE = null;

	private Map mpErrorMessages ;
	private Map mpWarningMessages ;
	private Map mpSuccessMessages ;

	private String sProcessingStatus;
	private String sDataFileName;

	private PWCRFACRMIntegrationProcessingInfoHolder()
	{
		mpErrorMessages = initializeMesssageMaps(mpErrorMessages);
		mpWarningMessages = initializeMesssageMaps(mpWarningMessages);
		mpSuccessMessages = initializeMesssageMaps(mpSuccessMessages);

		sProcessingStatus = OK ;
		sDataFileName = null ; // without extension 
	}

	public static PWCRFACRMIntegrationProcessingInfoHolder getInstance()
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationProcessingInfoHolder.class.getName()+"::PWCRFACRMIntegrationProcessingInfoHolder()");

		if( INSTANCE == null )
		{
			INSTANCE = new PWCRFACRMIntegrationProcessingInfoHolder();
		} 

		_LOGGER.debug("End of "+PWCRFACRMIntegrationProcessingInfoHolder.class.getName()+"::PWCRFACRMIntegrationProcessingInfoHolder()");

		return INSTANCE ;
	}

	public void setDataFileName( String sDataFileName )
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationProcessingInfoHolder.class.getName()+"::setDataFileName()");

		this.sDataFileName = sDataFileName ;

		_LOGGER.debug("End of "+PWCRFACRMIntegrationProcessingInfoHolder.class.getName()+"::setDataFileName()");
	}

	public void clearInfo()
	{
		mpErrorMessages = initializeMesssageMaps(mpErrorMessages);
		mpWarningMessages = initializeMesssageMaps(mpWarningMessages);
		mpSuccessMessages = initializeMesssageMaps(mpSuccessMessages);
		sProcessingStatus = OK ;
		sDataFileName = null ;
	}

	private Map initializeMesssageMaps(Map mpMessage)
	{
		mpMessage = new HashMap<String, ArrayList<String>>() ;
			
		mpMessage.put( "AM", new ArrayList<String>() ); 	// AM = attributeMapping
		mpMessage.put( "AVM", new ArrayList<String>() ); 	// AVM = attributeValueMapping
		mpMessage.put( "EMIM", new ArrayList<String>() );	// EMIM = EngineModelIPECMapping
		mpMessage.put( "ADD", new ArrayList<String>() );	// ADD = Additional
		
		return mpMessage;
	}

	public void logError( String sCategoryKey, String sErrorMsg )
	{
		ArrayList arrMessages = (ArrayList) mpErrorMessages.get( sCategoryKey ) ;
		arrMessages.add( sErrorMsg ) ;
	}

	public void logWarning( String sCategoryKey, String sWarningMsg )
	{
		ArrayList arrMessages = (ArrayList) mpWarningMessages.get( sCategoryKey ) ;
		arrMessages.add( sWarningMsg ) ;
	}

	public void logSuccess( String sCategoryKey, String sSuccessMsg )
	{
		ArrayList arrMessages = (ArrayList) mpSuccessMessages.get( sCategoryKey ) ;
		arrMessages.add( sSuccessMsg ) ;
	}

	public String getStatus()
	{
		if ( mpErrorMessages != null) 
		{
			for (Iterator<String> mapKeysItr = mpErrorMessages.keySet().iterator(); mapKeysItr.hasNext();)
			{
				String keyCategory = mapKeysItr.next();
				ArrayList arrMessages = (ArrayList) mpErrorMessages.get(keyCategory);

				if ( !arrMessages.isEmpty() ) 
				{
					sProcessingStatus = KO ;
					break ;
				}
			}

			if ( sProcessingStatus.equals( OK ) ) 
			{
				for (Iterator<String> mapKeysItr = mpWarningMessages.keySet().iterator(); mapKeysItr.hasNext();)
				{
					String keyCategory = mapKeysItr.next();
					ArrayList arrMessages = (ArrayList) mpWarningMessages.get(keyCategory);

					if ( !arrMessages.isEmpty() ) 
					{
						sProcessingStatus = WARNING ;
						break ;
					}
				}
			}
		}

		return sProcessingStatus ;
	}


	public ArrayList generateLogFile() throws IOException 
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationProcessingInfoHolder.class.getName()+"::generateLogFile()");

		StringBuilder sb = new StringBuilder();
		File logFile = null ;
		boolean bResult = true ;
		FileOutputStream is = null;
		OutputStreamWriter osw = null;
		Writer w = null ;
		try 
		{
			String sLogFilePath = System.getProperty("java.io.tmpdir");
			sLogFilePath = sLogFilePath.trim();
			String sTimeStamp = PWCRFACRMIntegrationUtil.getCurrentTimeStamp();
			
			if ( System.getProperty("file.separator").toCharArray()[0] == sLogFilePath.charAt(sLogFilePath.length()-1) ) 
			{
				logFile = new File( (new StringBuilder(sLogFilePath)).append(sDataFileName).append("_").append(sTimeStamp).append(".log").toString() );
			}else
			{
				logFile = new File( (new StringBuilder(sLogFilePath)).append(System.getProperty("file.separator")).append(sDataFileName).append("_").append(sTimeStamp).append(".log").toString() );
			}

			if ( logFile.createNewFile() ) 
			{
				is = new FileOutputStream( logFile );
				osw = new OutputStreamWriter(is);    
				w = new BufferedWriter(osw);

				ArrayList<Map> arrTmp = new ArrayList();
				arrTmp.add(mpErrorMessages);
				arrTmp.add(mpWarningMessages);
				arrTmp.add(mpSuccessMessages);

				sb.append("The processing log of the data file '"+sDataFileName+"' is as below: \n\n");

				for (int i = 0; i < arrTmp.size(); i++) 
				{
					Map mpTmp = arrTmp.get(i);
					boolean bHeaderStatus = false;

					for (Iterator<String> mapKeysItr = mpTmp.keySet().iterator(); mapKeysItr.hasNext();)
					{
						String keyCategory = mapKeysItr.next();
						ArrayList arrMessages = (ArrayList) mpTmp.get(keyCategory);

						if ( !arrMessages.isEmpty() ) 
						{
							if ( !bHeaderStatus ) 
							{
								if ( i == 0) 
								{
									sb.append("\n  ERRORS:\n");
								}else if ( i == 1)
								{
									sb.append("\n  WARNINGS:\n");
								}else 
								{
									sb.append("\n  SUCCESS:\n");
								}
							}
							bHeaderStatus = true;

							sb.append("  "+keyCategory+":\n");
							for (int j = 0; j < arrMessages.size(); j++) 
							{
								sb.append("\t"+arrMessages.get(j)+"\n");
							}
						}
					}
				}

				sb.append("\n\nLegend for acronyms used: \n");
				sb.append("\tAM = Attribute Mapping\n");
				sb.append("\tAVM = Attribute Value Mapping\n");
				sb.append("\tEMIM = Engine Model IPEC Mapping\n");
				sb.append("\tADD = Additional\n");

				w.write(sb.toString());
				w.flush();

			} else 
			{
				this.logWarning("ADD", "Failed to generate a log file for this CRM Data File '"+sDataFileName+"'. Hence adding the log details in email containt.");
			}

		} catch ( IOException ioe ) 
		{ 
			bResult = false ;
			this.logWarning("ADD", "Failed to generate a log file for this 'CRM Data File' '"+sDataFileName+"'. Hence adding the log details in email containt.");
			_LOGGER.error("Failed to generate the Log file for 'Data File' '"+sDataFileName+"' due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(ioe));

		}finally
		{
			if ( is != null ) 
			{
			is.close();
			}
			
			if ( osw != null ) 
			{
			osw.close();
			}
			
			if ( w != null ) 
			{
			w.close();
		        }

		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationProcessingInfoHolder.class.getName()+"::generateLogFile()");

		ArrayList alResult = new ArrayList();
		alResult.add( sb.toString() );
		alResult.add( logFile );

		return alResult ;
	}

}
