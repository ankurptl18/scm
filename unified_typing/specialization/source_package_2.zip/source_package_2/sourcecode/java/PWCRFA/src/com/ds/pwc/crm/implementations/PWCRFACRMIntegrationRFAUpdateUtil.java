package com.ds.pwc.crm.implementations;

import java.util.HashMap;
import java.util.Map;

import matrix.db.Context;
import matrix.db.RelationshipWithSelect;
import matrix.db.RelationshipWithSelectItr;
import matrix.db.RelationshipWithSelectList;
import matrix.util.StringList;

import org.apache.log4j.Logger;

import com.ds.common.PWCConstants;
import com.ds.pwc.crm.framework.PWCRFACRMIntegrationProcessingInfoHolder;
import com.ds.pwc.crm.framework.PWCRFACRMIntegrationUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCRFACRMIntegrationRFAUpdateUtil
{
	private static final Logger _LOGGER = Logger.getLogger(PWCRFACRMIntegrationRFAUpdateUtil.class.getName());
	private static PWCRFACRMIntegrationProcessingInfoHolder objInfoHolder = null ;


	public String sRFA_ID = DomainConstants.EMPTY_STRING;

	public PWCRFACRMIntegrationRFAUpdateUtil()
	{
		objInfoHolder = PWCRFACRMIntegrationProcessingInfoHolder.getInstance();
	}

	public boolean checkIfExist(Context context, String sCRMReportNo)throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFAUpdateUtil.class.getName()+"::checkIfExist()");

		boolean bReturnFlag = false;
		try{
			StringList selectList = new StringList();
			StringList orderbys = new StringList();
			StringBuilder sbWhere = new StringBuilder("attribute[");
			sbWhere.append(PWCConstants.ATTRIBUTE_PWC_REFERENCE_NUMBER).append("].value==\"").append(sCRMReportNo.trim()).append("\"")
						.append(" && from.attribute[").append(PWCConstants.ATTRIBUTE_PWC_RFA_BUSINESS_PROCESS).append("].value==\"").append("Field Events").append("\"");
			selectList.add("from.id");
			selectList.add("id");

			RelationshipWithSelectList relWithSelectList = DomainRelationship.query(context,
					PWCConstants.RELATIONSHIP_PWC_RFA_REFERENCE,
					PWCConstants.PRODUCTION_VAULT,
					sbWhere.toString(),
					(short)0,
					selectList,
					orderbys);

			RelationshipWithSelectItr relWithITR = new RelationshipWithSelectItr(relWithSelectList);
			while(relWithITR.next())
			{
				RelationshipWithSelect relwithSelect = relWithITR.obj();				
				StringList idList = relwithSelect.getSelectDataList("from.id");
				if(!idList.isEmpty() && idList.size() > 0)
				{
					sRFA_ID = (String)idList.get(0);
					bReturnFlag = true;
				}				
			}

		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFAUpdateUtil.class.getName()+"::checkIfExist()");

		return bReturnFlag;
	}

	public void updateExistingRFA(Context context,HashMap<String, HashMap<String, String>> mRFAUpdateInformationMap, String sRFAOid)throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFAUpdateUtil.class.getName()+"::updateExistingRFA()");
		
		try
		{
			DomainObject dom = new DomainObject(sRFAOid);
			if(dom.exists(context))
			{
				createAndConnectEngineInfo(context, sRFAOid, (HashMap<String,String>)mRFAUpdateInformationMap.get("EngineAttributeMap"),(HashMap<String,String>)mRFAUpdateInformationMap.get("EngineRelAttributeMap"));     
			}

		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFAUpdateUtil.class.getName()+"::updateExistingRFA()");
	}

	private void createAndConnectEngineInfo(Context context,String sRFAOid,HashMap<String, String> mEngineInfoMap, HashMap<String, String> mEngineRelAttributeMap) throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFAUpdateUtil.class.getName()+"::createAndConnectEngineInfo()");
		try
		{
			if(!mEngineInfoMap.isEmpty())
			{	
				PWCRFACRMIntegrationRFA createRFAObj = new PWCRFACRMIntegrationRFA(context);
				HashMap<String, String> mEngineAttributeMap = new HashMap<String,String>();
				HashMap<String, String> mEngineRelationshipAttributeMap = new HashMap<String,String>();
				String sEngineModelID = DomainConstants.EMPTY_STRING;
				String sEngineSectionID = DomainConstants.EMPTY_STRING;
				sEngineSectionID = "123";
				String sEngineModel = (String)mEngineInfoMap.get("attribute_PWC_RFA_EngineModel");
				if(!UIUtil.isNullOrEmpty(sEngineModel))
				{
					//sEngineModelID = createRFAObj.connectEngineModelToRFA(context,sEngineModel,sRFAOid);
					mEngineInfoMap.remove("attribute_PWC_RFA_EngineModel");
				}

				createRFAObj.getAttributeMap(mEngineInfoMap,mEngineAttributeMap);
				createRFAObj.getAttributeMap(mEngineRelAttributeMap,mEngineRelationshipAttributeMap);
				createEngineInfoForRFA(context, sRFAOid, mEngineAttributeMap, mEngineRelationshipAttributeMap, sEngineModelID, sEngineSectionID);
			}
		}catch(Exception e)
		{
			objInfoHolder.logError("ADD", "Engine Model creation and connection to the RFA '"+DomainObject.newInstance(context, sRFAOid).getInfo(context, DomainObject.SELECT_NAME)+"' has failed");
			_LOGGER.error("Engine Model creation and connection to the RFA '"+DomainObject.newInstance(context, sRFAOid).getInfo(context, DomainObject.SELECT_NAME)+"' has failed"+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFAUpdateUtil.class.getName()+"::createAndConnectEngineInfo()");
	}

	/**
	 * Method to create and connect Engine Info object to RFA
	 * @param context
	 * @param strRFAId
	 * @param attrMap
	 * @param relAttrMap
	 * @param engineSectionID
	 * @throws Exception
	 */
	private void createEngineInfoForRFA(Context context, String strRFAId, Map attrMap, Map relAttrMap, String engineSectionID, String strEngineModelOID)
	throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationRFAUpdateUtil.class.getName()+"::createEngineInfoForRFA()");
		DomainObject RFAObj = DomainObject.newInstance(context, strRFAId);

		try 
		{
			PWCRFACRMIntegrationRFAEventUtil eventObj = new PWCRFACRMIntegrationRFAEventUtil();
			boolean allFieldsEmpty = (eventObj.isAllFieldsEmpty(attrMap) && eventObj.isAllFieldsEmpty(relAttrMap));

			if(allFieldsEmpty && ( !UIUtil.isNullOrEmpty(engineSectionID) || !UIUtil.isNullOrEmpty(strEngineModelOID)) )
			{
				allFieldsEmpty = false;
			}

			if(!allFieldsEmpty)
			{
				DomainObject engineInfoObj = DomainObject.newInstance(context);  	
				String strSymbolicNameEngineInfo = FrameworkUtil.getAliasForAdmin(context,
						DomainConstants.SELECT_TYPE,
						PWCConstants.TYPE_PWC_RFA_ENGINE_INFO,
						true);
				String strName = DomainObject.getAutoGeneratedName(context,
						strSymbolicNameEngineInfo,
						DomainConstants.EMPTY_STRING);

				DomainRelationship engineInfoRelObj = engineInfoObj.createAndConnect(context,
						PWCConstants.TYPE_PWC_RFA_ENGINE_INFO,
						strName,
						DomainConstants.EMPTY_STRING,
						PWCConstants.POLICY_RFA_SUB_OBJECT, 
						PWCConstants.PRODUCTION_VAULT,
						PWCConstants.RELATIONSHIP_PWC_RFA_ENGINE_INFO,
						RFAObj,
						true);

				//connectEngineInfoWithEngineSection(context, engineSectionID, engineInfoObj);
				if(attrMap.containsKey(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINE_SYMPTOM_DEVIATION))
				{
					attrMap.remove(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINE_SYMPTOM_DEVIATION);
				}			
				engineInfoObj.setAttributeValues(context, attrMap);
				engineInfoRelObj.setAttributeValues(context, relAttrMap);			

				objInfoHolder.logSuccess("ADD", "EngineInfo creation and connection to the RFA '"+RFAObj.getInfo(context, DomainObject.SELECT_NAME)+"' is done successfuly");
			}		

		} catch (Exception e) 
		{
			objInfoHolder.logError("ADD", "EngineInfo creation and connection to the RFA '"+RFAObj.getInfo(context, DomainObject.SELECT_NAME)+"' has failed");
			_LOGGER.error("Engine Model creation and connection to the RFA '"+RFAObj.getInfo(context, DomainObject.SELECT_NAME)+"' has failed"+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationRFAUpdateUtil.class.getName()+"::createEngineInfoForRFA()");
	}	
}
