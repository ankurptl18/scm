package com.ds.pwc.crm.framework;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.matrixone.apps.framework.ui.UIUtil;

public class PWCRFACRMIntegrationDataMappingHolder
{
	private static final Logger _LOGGER = Logger.getLogger(PWCRFACRMIntegrationDataMappingHolder.class.getName());

	private final String PWC_ENOVIA_EXTERNAL_CONFIG_FOLDER_PATH = "PWC_ENOVIA_EXTERNAL_CONFIG_FOLDER_PATH";
	private final String PWC_ENOVIA_CRM_ATTRIBUTE_XML_FILE = "PWCRFACRMIntegrationAttributeMapping.xml";
	private final String PWC_ENOVIA_CRM_ATTRIBUTE_VALUE_XML_FILE = "PWCRFACRMIntegrationAttributeValueMapping.xml";
	private final String PWC_ENOVIA_CRM_ENGINE_CLASSIFICATION_XML_FILE = "PWCRFACRMIntegrationEngineClassificationMapping.xml";

	public HashMap<String,String> mRFAAttributeMap = null;
	public HashMap<String,String> mPartAttributeMap = null;
	public HashMap<String,String> mPartRelationshipAttributeMap = null;
	public HashMap<String,String> mEngineAttributeMap = null;
	public HashMap<String,String> mEngineRelationshipAttributeMap = null;
	public HashMap<String,String> mAircraftAttributeMap = null;
	public HashMap<String,String> mReferanceAttributeMap = null;
	public HashMap<String,String> mAttachmentAttributeMap = null;
	public HashMap<String,HashMap<String,String>> mAttributeValueMap = null;
	public HashMap<String,HashMap<String,String>> mEngineClassificationMap = null;	

	private File attributeMappingFile;
	private File attributeValueMappingFile;
	private File engineClassificationMappingFile;

	private static PWCRFACRMIntegrationDataMappingHolder newInstance = null;
	public static String sMilitaryUses = "No";

	private PWCRFACRMIntegrationDataMappingHolder()throws Exception
	{		
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationDataMappingHolder.class.getName()+"::PWCRFACRMIntegrationDataMappingHolder()");

		mRFAAttributeMap = new HashMap<String,String>();
		mPartAttributeMap = new HashMap<String,String>();
		mPartRelationshipAttributeMap = new HashMap<String,String>();
		mEngineAttributeMap = new HashMap<String,String>();
		mEngineRelationshipAttributeMap = new HashMap<String,String>();
		mAircraftAttributeMap = new HashMap<String,String>();
		mReferanceAttributeMap = new HashMap<String,String>();
		mAttachmentAttributeMap = new HashMap<String,String>();		
		mAttributeValueMap = new HashMap<String,HashMap<String,String>>();
		mEngineClassificationMap = new HashMap<String,HashMap<String,String>>();

		try
		{
			setPath();
			this.createRFAAttributeMapping();
			this.createPartAttributeMapping();
			this.createPartRelationshipAttributeMapping();
			this.createEngineAttributeMapping();
			this.createEngineRelationshipAttributeMapping();
			this.createAttributeValueMapping();
			this.createAircraftAttributeMapping();
			this.createReferanceAttributeMapping();
			this.createAttachmentAttributeMapping();
			this.createEngineClassificationMapping();
		}
		catch (Exception e)
		{
			_LOGGER.error("Failed to load the mappings due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			e.printStackTrace();
			throw e;
		}	

		_LOGGER.debug("End of "+PWCRFACRMIntegrationDataMappingHolder.class.getName()+"::PWCRFACRMIntegrationDataMappingHolder()");
	}

	public static PWCRFACRMIntegrationDataMappingHolder getInstance()throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationDataMappingHolder.class.getName()+"::getInstance()");

		if(null == newInstance)
		{
			newInstance = new PWCRFACRMIntegrationDataMappingHolder();
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationDataMappingHolder.class.getName()+"::getInstance()");

		return newInstance;
	}		

	private void setPath() throws Exception
	{
		try{
			String strConfigFolderPath = System.getenv(PWC_ENOVIA_EXTERNAL_CONFIG_FOLDER_PATH);
			if(!UIUtil.isNullOrEmpty(strConfigFolderPath) && new File(strConfigFolderPath).exists())
			{				
				attributeMappingFile = new File(strConfigFolderPath + File.separator + PWC_ENOVIA_CRM_ATTRIBUTE_XML_FILE);
				attributeValueMappingFile = new File(strConfigFolderPath + File.separator + PWC_ENOVIA_CRM_ATTRIBUTE_VALUE_XML_FILE);
				engineClassificationMappingFile = new File(strConfigFolderPath + File.separator + PWC_ENOVIA_CRM_ENGINE_CLASSIFICATION_XML_FILE);
			}
			
			if((null == attributeMappingFile || null == attributeValueMappingFile || null == engineClassificationMappingFile) 
				|| (!attributeMappingFile.exists() || !attributeValueMappingFile.exists() || !engineClassificationMappingFile.exists()))
			{
				URL attributeURL = PWCRFACRMIntegrationDataMappingHolder.class.getClassLoader().getResource(PWC_ENOVIA_CRM_ATTRIBUTE_XML_FILE);
				URL attValueURL = PWCRFACRMIntegrationDataMappingHolder.class.getClassLoader().getResource(PWC_ENOVIA_CRM_ATTRIBUTE_VALUE_XML_FILE);
				URL classificationURL = PWCRFACRMIntegrationDataMappingHolder.class.getClassLoader().getResource(PWC_ENOVIA_CRM_ENGINE_CLASSIFICATION_XML_FILE);
				attributeMappingFile = new File(attributeURL.toURI());
				attributeValueMappingFile = new File(attValueURL.toURI());
				engineClassificationMappingFile = new File(classificationURL.toURI());
			}
			
			if((null == attributeMappingFile || null == attributeValueMappingFile || null == engineClassificationMappingFile) 
					|| (!attributeMappingFile.exists() || !attributeValueMappingFile.exists() || !engineClassificationMappingFile.exists()))
			{
				throw new Exception();
			}
		} catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}	

	private void createRFAAttributeMapping() throws Exception
	{
		NodeList nlTemp = getXMLDocument(attributeMappingFile).getElementsByTagName("RFA_Attributes");
		createAttributeMap(nlTemp, mRFAAttributeMap);		
	}	

	private void createPartAttributeMapping() throws Exception
	{
		NodeList nlTemp = getXMLDocument(attributeMappingFile).getElementsByTagName("Part_Attributes");
		createAttributeMap(nlTemp, mPartAttributeMap);
	}

	private void createPartRelationshipAttributeMapping() throws Exception
	{
		NodeList nlTemp = getXMLDocument(attributeMappingFile).getElementsByTagName("Part_Relationship_Attributes");
		createAttributeMap(nlTemp, mPartRelationshipAttributeMap);
	}

	private void createEngineAttributeMapping() throws Exception
	{
		NodeList nlTemp = getXMLDocument(attributeMappingFile).getElementsByTagName("Engine_Attributes");
		createAttributeMap(nlTemp, mEngineAttributeMap);
	}

	private void createEngineRelationshipAttributeMapping() throws Exception
	{
		NodeList nlTemp = getXMLDocument(attributeMappingFile).getElementsByTagName("Engine_Relationship_Attributes");
		createAttributeMap(nlTemp, mEngineRelationshipAttributeMap);
	}	

	private void createAircraftAttributeMapping() throws Exception
	{
		NodeList nlTemp = getXMLDocument(attributeMappingFile).getElementsByTagName("Aircraft_Attributes");
		createAttributeMap(nlTemp, mAircraftAttributeMap);
	}

	private void createReferanceAttributeMapping() throws Exception
	{
		NodeList nlTemp = getXMLDocument(attributeMappingFile).getElementsByTagName("Referance_Attributes");
		createAttributeMap(nlTemp, mReferanceAttributeMap);
	}

	private void createAttachmentAttributeMapping() throws Exception
	{
		NodeList nlTemp = getXMLDocument(attributeMappingFile).getElementsByTagName("Attachment_Attributes");
		createAttributeMap(nlTemp, mAttachmentAttributeMap);
	}

	private HashMap<String,HashMap<String,String>> createAttributeValueMapping() throws Exception
	{
		HashMap<String,String> attributeValues = null;		
		NodeList nlTemp = getXMLDocument(attributeValueMappingFile).getElementsByTagName("Attribute");	

		if(nlTemp != null && nlTemp.getLength() > 0)
		{
			Element eAttribute = null;
			String sAtributeName = "";
			for (int index = 0; index < nlTemp.getLength(); index++)
			{
				eAttribute = (Element)nlTemp.item(index);
				sAtributeName = eAttribute.getAttribute("name");
				NodeList nlCRMValues = eAttribute.getElementsByTagName("CRMValue");
				if(nlCRMValues != null && nlCRMValues.getLength() > 0)
				{
					Element eCRMValue = null;
					String sCRMValue = "";
					String sRFAValue = "";
					attributeValues = new HashMap<String,String>();
					for (int count = 0; count < nlCRMValues.getLength(); count++)
					{
						eCRMValue = (Element)nlCRMValues.item(count);
						sCRMValue = eCRMValue.getAttribute("name");
						sRFAValue = eCRMValue.getElementsByTagName("RFA_Value").item(0).getTextContent();
						attributeValues.put(sCRMValue.toUpperCase(),sRFAValue.trim());
					}
					mAttributeValueMap.put(sAtributeName, attributeValues);
				}
			}
		}
		return mAttributeValueMap;
	}

	private HashMap<String,HashMap<String,String>> createEngineClassificationMapping() 
	throws Exception
	{
		HashMap<String,String> classificationValues = null;		
		NodeList nlTemp = getXMLDocument(engineClassificationMappingFile).getElementsByTagName("EngineModel");	

		if(nlTemp != null && nlTemp.getLength() > 0)
		{
			Element eEngineModel 	= null;
			String sEngineModelName = "";
			for (int index = 0; index < nlTemp.getLength(); index++)
			{
				eEngineModel 			= (Element) nlTemp.item(index);
				sEngineModelName 		= eEngineModel.getAttribute("name");
				String strUSJURClass 	= eEngineModel.getElementsByTagName("USJURISDICTION").item(0).getTextContent();
				String strUSEXTJURClass = eEngineModel.getElementsByTagName("USEXTERNALJURISDICTION").item(0).getTextContent();
				String strCAJURClass 	= eEngineModel.getElementsByTagName("CAJURISDICTION").item(0).getTextContent();

				classificationValues = new HashMap<String,String>();
				classificationValues.put("USJURISDICTION", strUSJURClass);
				classificationValues.put("USEXTERNALJURISDICTION", strUSEXTJURClass);
				classificationValues.put("CAJURISDICTION", strCAJURClass);

				mEngineClassificationMap.put(sEngineModelName, classificationValues);
			}
		}
		return mEngineClassificationMap;
	}

	/**
	 * @param attributeMapping
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	private Document getXMLDocument(File fXmlFile)throws ParserConfigurationException, SAXException, IOException
	{
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
		doc.getDocumentElement().normalize();
		return doc;
	}	

	/**
	 * @param nlTemp
	 */
	private void createAttributeMap(NodeList nlTemp, HashMap<String,String> mAttributeMap)
	{
		if(nlTemp != null && nlTemp.getLength() > 0)
		{
			Element eRFAAttr = null;
			NodeList nlAttributes = null;
			for (int index = 0; index < nlTemp.getLength(); index++)
			{
				eRFAAttr = (Element)nlTemp.item(index);
				nlAttributes = eRFAAttr.getElementsByTagName("Attribute");
				if(nlAttributes != null && nlAttributes.getLength() > 0)
				{
					Element eAttribute = null;
					NodeList nlCRMAttributes = null;
					String sAttributeName = "";
					for (int count = 0; count < nlAttributes.getLength(); count++)
					{
						eAttribute = (Element)nlAttributes.item(count);
						sAttributeName = eAttribute.getAttribute("name");					
						nlCRMAttributes = eAttribute.getElementsByTagName("CRM");
						if(nlCRMAttributes != null && nlCRMAttributes.getLength() > 0)
						{
							StringBuilder sCRMattribute = new StringBuilder();
							for (int count1 = 0; count1 < nlCRMAttributes.getLength(); count1++)
							{
								if(count1 > 0){
									sCRMattribute.append("~");
								}
								sCRMattribute.append(nlCRMAttributes.item(count1).getTextContent().trim());								
							}
							mAttributeMap.put(sAttributeName, sCRMattribute.toString());
						}						
					}
				}
			}
		}
	}
}
