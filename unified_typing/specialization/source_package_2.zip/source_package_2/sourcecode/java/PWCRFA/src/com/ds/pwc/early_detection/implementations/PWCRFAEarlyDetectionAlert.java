package com.ds.pwc.early_detection.implementations;

import matrix.db.Context;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionUtil;
import com.matrixone.apps.domain.DomainObject;

public class PWCRFAEarlyDetectionAlert {
	private String objId = "";
	public PWCRFAEarlyDetectionAlert() {
	}
	
	//Constructor for PWCRFAEarlyDetectionAlert class to create alert Object and setting ObjectId
	public PWCRFAEarlyDetectionAlert(Context context,String connectDefectId,PWCRFAEarlyDetectionDefectData combineDefect,String strAlertType) throws Exception{
		objId = PWCRFAEarlyDetectionUtil.connectAlertToDefects(context,combineDefect,connectDefectId,strAlertType);		
		//PWCRFAEarlyDetectionUtil.createAndConnectAlertObject(context,connectDefectId,strAlertType);
		//setStrObjectId(objId);
	}
	public String getAlertName(Context context)throws Exception{
		DomainObject obj =DomainObject.newInstance(context,objId);
		String strName = obj.getName(context);
		return strName;
	}
	public String getAlertId(Context context)throws Exception{
		DomainObject obj =DomainObject.newInstance(context,objId);
		String strAlertObjectId = obj.getObjectId();
		return strAlertObjectId;
	}	
}
