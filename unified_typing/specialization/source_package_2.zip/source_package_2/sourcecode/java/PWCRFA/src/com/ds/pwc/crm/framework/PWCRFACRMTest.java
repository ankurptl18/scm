package com.ds.pwc.crm.framework;

public class PWCRFACRMTest
{	

	public PWCRFACRMTest() throws Exception
	{
		System.out.println("hello world !!");
	}	

}
