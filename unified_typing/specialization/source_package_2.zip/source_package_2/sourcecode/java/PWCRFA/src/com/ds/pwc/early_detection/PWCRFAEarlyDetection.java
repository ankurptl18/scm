/*
 *  PWCRFAEarlyDetection.java
 *  Copyright (c) 1992-2012 Dassault Systemes.
 *
 * All Rights Reserved.
 * This program contains proprietary and trade secret information of
 * MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
package com.ds.pwc.early_detection;
import java.util.Map;
import java.util.Vector;

import matrix.db.Context;
import org.apache.log4j.Logger;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.implementations.PWCRFAEarlyDetectionDefectFactory;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionDefect;

public class PWCRFAEarlyDetection {
	private static final Logger LOG = Logger.getLogger(PWCRFAEarlyDetection.class.getSimpleName());
	
	/**
	 * The function is the starting point of Early Detection.This basically gets all 
	 * information needed from RFA and sets this information in PWCRFAEarlyDetectionData
	 * class for further use in Early Detection process
	 * @param context
	 * @param sObjectId as RFA Object Id
	 * @return - int
	 */	
	public Vector startEarlyDetection(Context context,String sObjectId) 
	{

		LOG.debug("Start of PWCRFAEarlyDetection : startEarlyDetection");
		String strUser = context.getUser();
		Vector vAlerts =  new Vector();
		MapList mapPartAndEngine = null;
		String primaryEngId = "";
		try {
			DomainObject dobjRFA = DomainObject.newInstance(context,sObjectId);
			//Delete Defect objects if already existing
			PWCRFAEarlyDetectionUtil.deleteRFADefects(context,dobjRFA);
			
			// Getting all information related to RFA which will be used further in calculation
			Map connectionAttrRFAMap = PWCRFAEarlyDetectionUtil.getRelatedRFAInfo(context, dobjRFA);
			String strRFATempLoc = (String) connectionAttrRFAMap.get(PWCRFAEarlyDetectionConstants.STR_SELECT_LOCATIONRATE);
			String strModelName = (String)connectionAttrRFAMap.get(PWCRFAEarlyDetectionConstants.STR_REL_MODEL_NAME);
			String strModelFamily = (String)connectionAttrRFAMap.get(PWCRFAEarlyDetectionConstants.STR_REL_MODEL_FLY);
			String strModelCoEfficient = (String)	connectionAttrRFAMap.get(PWCRFAEarlyDetectionConstants.STR_REL_MODEL_COEFFICIENT);
			
			//Setting the information obtained from RFA in RFAData object , hence forward will get information from PWCRFAEarlyDetectionData class
		    // Continue ED only if Location > 0
			if (Double.parseDouble(strRFATempLoc) > 0) {
				PWCRFAEarlyDetectionRFAData rfaData = new PWCRFAEarlyDetectionRFAData();
				rfaData.setRFAObjId(sObjectId);
				rfaData.setLocation(strRFATempLoc);
				rfaData.setModelCoefficient(strModelCoEfficient);
				rfaData.setModelFly(strModelFamily);
				rfaData.setModelName(strModelName);
				// get size of Engine Info and Physical Part from context RFA
                mapPartAndEngine = PWCRFAEarlyDetectionUtil.getRelatedPartAndEngineInfo(context, sObjectId);
                primaryEngId = PWCRFAEarlyDetectionUtil.getPrimaryData(context, sObjectId);
                if(mapPartAndEngine!=null && mapPartAndEngine.size()> 0){
                	rfaData.setRFARelatedMap(mapPartAndEngine);
                	rfaData.setPrimaryEngineInfo(primaryEngId);
                	IPWCRFAEarlyDetectionDefect instance =  PWCRFAEarlyDetectionDefectFactory.getDefectTypeInstance(rfaData);
        			vAlerts = instance.calculateDefectDeviation(context,rfaData);
                }else{
            	  LOG.info("No early detection done, since there is no engine or part is connected");
              }

			}

		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Exception in PWC_RFAEarlyDection:startEarlyDetection : "
							+ ex.getMessage());
		}
		LOG.debug("End of PWC_RFAEarlyDection:startEarlyDetection");

		return vAlerts;
	}


	}
