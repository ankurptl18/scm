
package com.ds.pwc.early_detection;

/**
 * Exception class to handle system errors
 *
 */
public class PWCRFAEarlyDetectionException extends Exception {
	
	//method to call exception object
	public PWCRFAEarlyDetectionException(Exception e){
		super(e);
	}
	
	//method to call exception object with message
	public PWCRFAEarlyDetectionException(String message){
		super(message);
	}
}