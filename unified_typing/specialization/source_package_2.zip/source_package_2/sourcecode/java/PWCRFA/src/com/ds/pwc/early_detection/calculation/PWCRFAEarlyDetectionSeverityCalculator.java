package com.ds.pwc.early_detection.calculation;

import org.apache.log4j.Logger;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;

import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionException;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;

public class PWCRFAEarlyDetectionSeverityCalculator {

	private static final Logger LOG = Logger.getLogger("PWCRFAEarlyDetectionSeverityCalculator");

	/**
	 * The function reads type,name,revision of the object and gets the Weights
	 * on these objects
	 * 
	 * @param context
	 * @param Type
	 * @param Name
	 * @param Revision
	 * @return - integer
	 * @throws PWCRFAEarlyDetectionException 
	 * @throws Exception
	 *             when problems occurred
	 */
	public static int getPartialSeverity(Context context, String strType,
			String strName, String strRev,String strAttribute) {
		
		LOG.debug("Start of PWCRFAEarlyDetectionSeverityCalculator:getPartialSeverity");
		int iWeight = 0;
		String strWeight = "0";
		BusinessObject busObject = null;
		DomainObject domObject = null;
		try 
		{
			// Create instance of Domain Object to fetch Weight from that object

			busObject = new BusinessObject(strType, strName,strRev, context.getVault().getName());
			if(busObject.exists(context))
			{
				//domObject = DomainObject.newInstance(context, busObject);
				domObject = new DomainObject(busObject);
				domObject.open(context, true);
			strWeight = domObject.getAttributeValue(context,strAttribute);
				domObject.close(context);

			iWeight = Integer.parseInt(strWeight);
		} 
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			String message = "Early Detection failed. Could not find object "+strType+" "+strName+" " +strRev;
			LOG.error(message);
		}
	
		LOG.debug("End of PWCRFAEarlyDetectionSeverityCalculator:getPartialSeverity");
		return iWeight;

}
}
