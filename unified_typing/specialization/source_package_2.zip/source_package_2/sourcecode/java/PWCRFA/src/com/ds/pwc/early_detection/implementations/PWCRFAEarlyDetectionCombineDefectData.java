package com.ds.pwc.early_detection.implementations;

import java.io.Serializable;
import java.util.HashMap;
import com.ds.common.PWCConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import matrix.db.Context;

public class PWCRFAEarlyDetectionCombineDefectData extends PWCRFAEarlyDetectionDefectData implements Serializable{
	
	private PWCRFAEarlyDetectionEngineDefectData engine;
	private PWCRFAEarlyDetectionPartDefectData part;
	private String strEDCombinedDefectSeverity;
	private String strEDCombinedWeightedDefectFREQ;
	private String strEDCombinedDefectRecurrence;
	private String strEDCombinedDefectRL;
	private String strEDCombinedDefectSR;
	private String strEDCombinedDefectSRL;
	private String strEDEngineIFSD;
	private HashMap<String,String> attrFrequencyMap = new HashMap<String,String>();	
	
	HashMap<String,String> attributeMap = new HashMap<String,String>();
	private String strPartSerialNumber;
	private String strPartQtyDef;	

	//Constructor for PWCRFAEarlyDetectionCombineDefectData class to create defect Object and setting ObjectId
	public PWCRFAEarlyDetectionCombineDefectData(Context context, String connectRFAId) throws Exception{
		engine = new PWCRFAEarlyDetectionEngineDefectData();
		part = new PWCRFAEarlyDetectionPartDefectData();
		String objId = PWCRFAEarlyDetectionUtil.createAndConnectDefect(context,PWCRFAEarlyDetectionConstants.INTERFACE_COMBINED_DEFECT,connectRFAId);
		setStrObjectId(objId);
	}
	
	/**
	 * @return the strComparisionAttribute
	 */
	public String getAttributeValue( String strComparisionAttribute) {
		return attributeMap.get(strComparisionAttribute);
	}
	
	/**
	 * @return the strEDCombinedDefectRL
	 */
	public String getStrEDCombinedDefectRL() {
		return strEDCombinedDefectRL;
	}

	/**
	 * @param strEDCombinedDefectRL the strEDCombinedDefectRL to set
	 */
	public void setStrEDCombinedDefectRL(String strEDCombinedDefectRL) {
		this.strEDCombinedDefectRL = strEDCombinedDefectRL;
	}
	
	/**
	 * @return the attrFrequencyMap
	 */
	public HashMap<String, String> getAttrFrequencyMap() {
		return attrFrequencyMap;
	}


	/**
	 * @param attrFrequencyMap the attrFrequencyMap to set
	 */
	public void setAttrFrequencyMap(HashMap<String, String> attrFrequencyMap) {
		this.attrFrequencyMap = attrFrequencyMap;
	}

	/**
	 * @return the strEDCombinedDefectSR
	 */
	public String getStrEDCombinedDefectSR() {
		return strEDCombinedDefectSR;
	}


	/**
	 * @param strEDCombinedDefectSR the strEDCombinedDefectSR to set
	 */
	public void setStrEDCombinedDefectSR(String strEDCombinedDefectSR) {
		this.strEDCombinedDefectSR = strEDCombinedDefectSR;
	}


	/**
	 * @return the strEDCombinedDefectSRL
	 */
	public String getStrEDCombinedDefectSRL() {
		return strEDCombinedDefectSRL;
	}


	/**
	 * @param strEDCombinedDefectSRL the strEDCombinedDefectSRL to set
	 */
	public void setStrEDCombinedDefectSRL(String strEDCombinedDefectSRL) {
		this.strEDCombinedDefectSRL = strEDCombinedDefectSRL;
	}


	/**
	 * @return the strEDCombinedDefectRecurrence
	 */
	public String getStrEDCombinedDefectRecurrence() {
		return strEDCombinedDefectRecurrence;
	}


	/**
	 * @param strEDCombinedDefectRecurrence the strEDCombinedDefectRecurrence to set
	 */
	public void setStrEDCombinedDefectRecurrence(
			String strEDCombinedDefectRecurrence) {
		this.strEDCombinedDefectRecurrence = strEDCombinedDefectRecurrence;
	}


	/**
	 * @return the strEDCombinedWeightedDefectFREQ
	 */
	public String getStrEDCombinedWeightedDefectFREQ() {
		return strEDCombinedWeightedDefectFREQ;
	}


	/**
	 * @param strEDCombinedWeightedDefectFREQ the strEDCombinedWeightedDefectFREQ to set
	 */
	public void setStrEDCombinedWeightedDefectFREQ(
			String strEDCombinedWeightedDefectFREQ) {
		this.strEDCombinedWeightedDefectFREQ = strEDCombinedWeightedDefectFREQ;
	}


	/**
	 * @return the strEDCombinedDefectSeverity
	 */
	public String getStrEDCombinedDefectSeverity() {
		return strEDCombinedDefectSeverity;
	}


	/**
	 * @param strEDCombinedDefectSeverity the strEDCombinedDefectSeverity to set
	 */
	public void setStrEDCombinedDefectSeverity(String strEDCombinedDefectSeverity) {
		this.strEDCombinedDefectSeverity = strEDCombinedDefectSeverity;
	}


	/**
	 * @return the strPositionWeight
	 */
	public String getStrPositionWeight() {
		return engine.getStrPositionWeight();
	}


	/**
	 * @param strPositionWeight the strPositionWeight to set
	 */
	public void setStrPositionWeight(String strPositionWeight) {
		engine.setStrPositionWeight(strPositionWeight);
	}


	/**
	 * @return the strPositionWeight
	 */
	public String getStrEngineIFSD() {
		return engine.getStrEngineIFSD();
	}


	/**
	 * @param strPositionWeight the strPositionWeight to set
	 */
	public void setStrEngineIFSD(String strEDEngineIFSD) {
		engine.setStrEngineIFSD(strEDEngineIFSD);
	}

	/**
	 * @return the strEngineSymptomWeight
	 */
	public String getStrEngineSymptomWeight() {
		return engine.getStrEngineSymptomWeight();
	}


	/**
	 * @param strEngineSymptomWeight the strEngineSymptomWeight to set
	 */
	public void setStrEngineSymptomWeight(String strEngineSymptomWeight) {
		engine.setStrEngineSymptomWeight(strEngineSymptomWeight);
	}


	/**
	 * @return the strEngineConditionWeight
	 */
	public String getStrEngineConditionWeight() {
		return engine.getStrEngineConditionWeight();
	}


	/**
	 * @param strEngineConditionWeight the strEngineConditionWeight to set
	 */
	public void setStrEngineConditionWeight(String strEngineConditionWeight) {
		engine.setStrEngineConditionWeight(strEngineConditionWeight);
	}


	/**	 * @return the strPWCEnginePosition
	 */
	public String getStrPWCEnginePosition() {
		return engine.getStrPWCEnginePosition();
	}


	/**
	 * @param strPWCEnginePosition the strPWCEnginePosition to set
	 */
	public void setStrPWCEnginePosition(String strPWCEnginePosition) {
		engine.setStrPWCEnginePosition(strPWCEnginePosition);
	}


	/**
	 * @return the strPWCRFAEngineSymptomDeviation
	 */
	public String getStrPWCRFAEngineSymptomDeviation() {
		return engine.getStrPWCRFAEngineSymptomDeviation();
	}


	/**
	 * @param strPWCRFAEngineSymptomDeviation the strPWCRFAEngineSymptomDeviation to set
	 */
	public void setStrPWCRFAEngineSymptomDeviation(
			String strPWCRFAEngineSymptomDeviation) {
		engine.setStrPWCRFAEngineSymptomDeviation(strPWCRFAEngineSymptomDeviation);
	}


	/**
	 * @return the strPWCEngineCondition
	 */
	public String getStrPWCEngineCondition() {
		return engine.getStrPWCEngineCondition();
	}


	/**
	 * @param strPWCEngineCondition the strPWCEngineCondition to set
	 */
	public void setStrPWCEngineCondition(String strPWCEngineCondition) {
		engine.setStrPWCEngineCondition(strPWCEngineCondition);
	}


	/**
	 * @return the strEDDefectMultiple
	 */
	public String getStrEDDefectMultiple() {
		return engine.getStrEDDefectMultiple();
	}


	/**
	 * @param strEDDefectMultiple the strEDDefectMultiple to set
	 */
	public void setStrEDDefectMultiple(String strEDDefectMultiple) {
		engine.setStrEDDefectMultiple(strEDDefectMultiple);
	}


	/**
	 * @return the strEDDefectType
	 */
	public String getStrEDDefectType() {
		return engine.getStrEDDefectType();
	}


	/**
	 * @param strEDDefectType the strEDDefectType to set
	 */
	public void setStrEDDefectType(String strEDDefectType) {
		engine.setStrEDDefectType(strEDDefectType);
	}


	/**
	 * @return the strEDEMCoefficient
	 */
	public String getStrEDEMCoefficient() {
		return engine.getStrEDEMCoefficient();
	}


	/**
	 * @param strEDEMCoefficient the strEDEMCoefficient to set
	 */
	public void setStrEDEMCoefficient(String strEDEMCoefficient) {
		engine.setStrEDEMCoefficient (strEDEMCoefficient);
	}


	/**
	 * @return the strEDEngineDefectSeverity
	 */
	public String getStrEDEngineDefectSeverity() {
		return engine.getStrEDEngineDefectSeverity();
	}


	/**
	 * @param strEDEngineDefectSeverity the strEDEngineDefectSeverity to set
	 */
	public void setStrEDEngineDefectSeverity(String strEDEngineDefectSeverity) {
		engine.setStrEDEngineDefectSeverity(strEDEngineDefectSeverity);
	}


	/**
	 * @return the strEDEngineDefectRecurrence
	 */
	public String getStrEDEngineDefectRecurrence() {
		return engine.getStrEDEngineDefectRecurrence();
	}


	/**
	 * @param strEDEngineDefectRecurrence the strEDEngineDefectRecurrence to set
	 */
	public void setStrEDEngineDefectRecurrence(String strEDEngineDefectRecurrence) {
		engine.setStrEDEngineDefectRecurrence(strEDEngineDefectRecurrence);
	}


	/**
	 * @return the strEDEngineWeightedDefectFreq
	 */
	public String getStrEDEngineWeightedDefectFreq() {
		return engine.getStrEDEngineWeightedDefectFreq();
	}


	/**
	 * @param strEDEngineWeightedDefectFreq the strEDEngineWeightedDefectFreq to set
	 */
	public void setStrEDEngineWeightedDefectFreq(
			String strEDEngineWeightedDefectFreq) {
		engine.setStrEDEngineWeightedDefectFreq(strEDEngineWeightedDefectFreq);
	}


	/**
	 * @return the strEDEngineDefectRL
	 */
	public String getStrEDEngineDefectRL() {
		return engine.getStrEDEngineDefectRL();
	}


	/**
	 * @param strEDEngineDefectRL the strEDEngineDefectRL to set
	 */
	public void setStrEDEngineDefectRL(String strEDEngineDefectRL) {
		engine.setStrEDEngineDefectRL(strEDEngineDefectRL);
	}


	/**
	 * @return the strEDEngineDefectSR
	 */
	public String getStrEDEngineDefectSR() {
		return engine.getStrEDEngineDefectSR();
	}


	/**
	 * @param strEDEngineDefectSR the strEDEngineDefectSR to set
	 */
	public void setStrEDEngineDefectSR(String strEDEngineDefectSR) {
		engine.setStrEDEngineDefectSR(strEDEngineDefectSR);
	}


	/**
	 * @return the strEDEngineDefectSRL
	 */
	public String getStrEDEngineDefectSRL() {
		return engine.getStrEDEngineDefectSRL();
	}


	/**
	 * @param strEDEngineDefectSRL the strEDEngineDefectSRL to set
	 */
	public void setStrEDEngineDefectSRL(String strEDEngineDefectSRL) {
		engine.setStrEDEngineDefectSRL(strEDEngineDefectSRL);
	}


	/**
	 * @return the strEDPartConditionWeight
	 */
	public String getStrEDPartConditionWeight() {
		return part.getStrEDPartConditionWeight();
	}


	/**
	 * @param strEDPartConditionWeight the strEDPartConditionWeight to set
	 */
	public void setStrEDPartConditionWeight(String strEDPartConditionWeight) {
		part.setStrEDPartConditionWeight(strEDPartConditionWeight);
	}


	/**
	 * @return the strEDPartClassificationWeight
	 */
	public String getStrEDPartClassificationWeight() {
		return part.getStrEDPartClassificationWeight();
	}


	/**
	 * @param strEDPartClassificationWeight the strEDPartClassificationWeight to set
	 */
	public void setStrEDPartClassificationWeight(
			String strEDPartClassificationWeight) {
		part.setStrEDPartClassificationWeight(strEDPartClassificationWeight);
	}


	/**
	 * @return the strPartCondition
	 */
	public String getStrPartCondition() {
		return part.getStrPartCondition();
	}


	/**
	 * @param strPartCondition the strPartCondition to set
	 */
	public void setStrPartCondition(String strPartCondition) {
		part.setStrPartCondition(strPartCondition);
	}


	/**
	 * @return the strPartName
	 */
	public String getStrPartName() {
		return part.getStrPartName();
	}


	/**
	 * @param strPartName the strPartName to set
	 */
	public void setStrPartName(String strPartName) {
		part.setStrPartName(strPartName);
	}


	/**
	 * @return the strPWCFamily
	 */
	public String getStrPWCFamily() {
		return part.getStrPWCFamily();
	}


	/**
	 * @param strPWCFamily the strPWCFamily to set
	 */
	public void setStrPWCFamily(String strPWCFamily) {
		part.setStrPWCFamily(strPWCFamily);
	}


	/**
	 * @return the strPartNumber
	 */
	public String getStrPartNumber() {
		return part.getStrPartNumber();
	}


	/**
	 * @param strPartNumber the strPartNumber to set
	 */
	public void setStrPartNumber(String strPartNumber) {
		part.setStrPartNumber(strPartNumber);
	}


	/**
	 * @return the strEDPNCoefficient
	 */
	public String getStrEDPNCoefficient() {
		return part.getStrEDPNCoefficient();
	}


	/**
	 * @param strEDPNCoefficient the strEDPNCoefficient to set
	 */
	public void setStrEDPNCoefficient(String strEDPNCoefficient) {
		part.setStrEDPNCoefficient (strEDPNCoefficient);
	}


	/**
	 * @return the strEDPartDefectSeverity
	 */
	public String getStrEDPartDefectSeverity() {
		return part.getStrEDPartDefectSeverity();
	}


	/**
	 * @param strEDPartDefectSeverity the strEDPartDefectSeverity to set
	 */
	public void setStrEDPartDefectSeverity(String strEDPartDefectSeverity) {
		part.setStrEDPartDefectSeverity (strEDPartDefectSeverity);
	}


	/**
	 * @return the strEDPartWeightedDefectFREQ
	 */
	public String getStrEDPartWeightedDefectFREQ() {
		return part.getStrEDPartWeightedDefectFREQ();
	}


	/**
	 * @param strEDPartWeightedDefectFREQ the strEDPartWeightedDefectFREQ to set
	 */
	public void setStrEDPartWeightedDefectFREQ(String strEDPartWeightedDefectFREQ) {
		part.setStrEDPartWeightedDefectFREQ (strEDPartWeightedDefectFREQ);
	}


	/**
	 * @return the strEDPartDefectRL
	 */
	public String getStrEDPartDefectRL() {
		return part.getStrEDPartDefectRL();
	}


	/**
	 * @param strEDPartDefectRL the strEDPartDefectRL to set
	 */
	public void setStrEDPartDefectRL(String strEDPartDefectRL) {
		part.setStrEDPartDefectRL (strEDPartDefectRL);
	}


	/**
	 * @return the strEDPartDefectSR
	 */
	public String getStrEDPartDefectSR() {
		return part.getStrEDPartDefectSR();
	}


	/**
	 * @param strEDPartDefectSR the strEDPartDefectSR to set
	 */
	public void setStrEDPartDefectSR(String strEDPartDefectSR) {
		part.setStrEDPartDefectSR (strEDPartDefectSR);
	}


	/**
	 * @return the strEDPartDefectSRL
	 */
	public String getStrEDPartDefectSRL() {
		return part.getStrEDPartDefectSRL();
	}


	/**
	 * @param strEDPartDefectSRL the strEDPartDefectSRL to set
	 */
	public void setStrEDPartDefectSRL(String strEDPartDefectSRL) {
		part.setStrEDPartDefectSRL (strEDPartDefectSRL);
	}


	/**
	 * @return the strEDPartDefectRecurrence
	 */
	public String getStrEDPartDefectRecurrence() {
		return part.getStrEDPartDefectRecurrence();
	}


	/**
	 * @param strEDPartDefectRecurrence the strEDPartDefectRecurrence to set
	 */
	public void setStrEDPartDefectRecurrence(String strEDPartDefectRecurrence) {
		part.setStrEDPartDefectRecurrence (strEDPartDefectRecurrence);
	}


	/**
	 * @return the engine
	 */
	public PWCRFAEarlyDetectionEngineDefectData getEngine() {
		return engine;
	}


	/**
	 * @param engine the engine to set
	 */
	public void setEngine(PWCRFAEarlyDetectionEngineDefectData engine) {
		this.engine = engine;
	}


	/**
	 * @return the part
	 */
	public PWCRFAEarlyDetectionPartDefectData getPart() {
		return part;
	}


	/**
	 * @param part the part to set
	 */
	public void setPart(PWCRFAEarlyDetectionPartDefectData part) {
		this.part = part;
	}

	public void setStrPWCRFASerialNumber(String strPartSerialNumber) {
		part.setStrPWCRFASerialNumber(strPartSerialNumber);
		
	}

	public void setStrPWCRFAQtyDefect(String strPartQtyDef) {
		part.setStrPWCRFAQtyDefect(strPartQtyDef);
		
	}
	void setCombineAttributes(Context context){
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_RECURRENCE,strEDCombinedDefectRecurrence);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_WEIGHTED_DEFECT_FREQ,strEDCombinedWeightedDefectFREQ);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_SEVERITY,strEDCombinedDefectSeverity);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_RL,strEDCombinedDefectRL);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_SR,strEDCombinedDefectSR);
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_SRL,strEDCombinedDefectSRL);	
		//Engine 
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_POSITION_WEIGHT, engine.getStrPositionWeight());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_SYMPTOM_WEIGHT, engine.getStrEngineSymptomWeight());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_CONDITION_WEIGHT, engine.getStrEngineConditionWeight());
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_ENGINE_POSITION, engine.getStrPWCEnginePosition());
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINE_SYMPTOM_DEVIATION, engine.getStrPWCRFAEngineSymptomDeviation());
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_ENGINE_CONDITION, engine.getStrPWCEngineCondition());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_MODEL_FAMILY, this.getStrEngineModelFamily());
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINEMODEL, this.getStrPWCRFAEngineModel());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_MULTIPLE, this.getStrEDDefectMultiple());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_TYPE, this.getStrEDDefectType());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT, engine.getStrEDEMCoefficient());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SEVERITY,engine.getStrEDEngineDefectSeverity());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_RECURRENCE,engine.getStrEDEngineDefectRecurrence());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_WEIGHTED_DEFECT_FREQ,engine.getStrEDEngineWeightedDefectFreq());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_RL,engine.getStrEDEngineDefectRL());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SR,engine.getStrEDEngineDefectSR());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SRL,engine.getStrEDEngineDefectSRL());
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_RFA_IFSD,engine.getStrEngineIFSD());
		//Part
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_RL, part.getStrEDPartDefectRL());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SR, part.getStrEDPartDefectSR());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SRL, part.getStrEDPartDefectSRL());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_RECURRENCE,part.getStrEDPartDefectRecurrence());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_CONDITION_WEIGHT,part.getStrEDPartConditionWeight());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_CLASSIFICATION_WEIGHT,part.getStrEDPartClassificationWeight());
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_CONDITION, part.getStrPartCondition());
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_NAME, part.getStrPartName());
		attributeMap.put(PWCConstants.ATTRIBUTE_PWC_FAMILY, part.getStrPWCFamily());
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_NUMBER, part.getStrPartNumber());
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_SERIAL_NUMBER, part.getStrPWCRFASerialNumber());
		attributeMap.put(PWCConstants.ATTRIBUTE_PART_QTY_DEF, part.getStrPWCRFAQtyDefect());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT, part.getStrEDPNCoefficient());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SEVERITY,part.getStrEDPartDefectSeverity());
		attributeMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_WEIGHTED_DEFECT_FREQ,part.getStrEDPartWeightedDefectFREQ());
				
		
		//Getting ID of Defect Object generated ,setting attribute values for the Defect Object 
		try {
			String strDefectObject = getStrObjectId();
			DomainObject dObj = DomainObject.newInstance(context,strDefectObject);
			dObj.setAttributeValues(context, attributeMap);
		} catch (FrameworkException e) {
			e.printStackTrace();
		}
	}
	
}
