package com.ds.apps.metrics;

import static com.ds.common.PWCConstants.RELATIONSHIP_PUBLIC_LINE_MODELS;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectItr;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.Context;
import matrix.util.StringList;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.metrics.MetricsReports;
import com.ds.apps.metrics.interfaces.IPWCRFAReport;
import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;

public class PWCRFAMetricsReports extends MetricsReports {
	public static String SEARCH_CRITERIA_BUILDER = "searchCriteiraBuilder";
	public static String SEARCH_CRITERIA_DATA_MAP = "searchCriteriaDataMap";
  
	@Override
	public Map processWebReportInBackGround(Context paramContext, HashMap paramHashMap, String paramString) throws Exception {

		StringList selectedModelList = (StringList) paramHashMap.get("EngineModels");
		String CLASS_NAME = (String) paramHashMap.get(SEARCH_CRITERIA_BUILDER);
		CLASS_NAME = "com.ds.apps.metrics.implementations." + CLASS_NAME;

		HashMap searchCriteriaDataMap = new HashMap();
		if (paramHashMap.containsKey(SEARCH_CRITERIA_DATA_MAP)) {
			searchCriteriaDataMap = (HashMap) paramHashMap.get(SEARCH_CRITERIA_DATA_MAP);
		}
		
		String strTimeStamp = (String) searchCriteriaDataMap.get("timestamp");
		String strDefaultReport = (String) searchCriteriaDataMap.get("defaultReport");
		
		try 
		{
		IPWCRFAReport report = (IPWCRFAReport) Class.forName(CLASS_NAME).newInstance();
		String strSearchCriteria = report.buildSearchCriteria(paramContext, selectedModelList, searchCriteriaDataMap);
        
		paramHashMap.put(SEARCH_CRITERIA, strSearchCriteria);
		return super.processWebReportInBackGround(paramContext, paramHashMap, paramString);
		}
		finally
		{
			if (strDefaultReport.equals("PWC_MyRFAReport"))
			{
				String key = strDefaultReport+"_"+strTimeStamp;
				Map mapAssignee = (Map)PersonUtil.getPersonProperty(paramContext, "AssigneeMap");
				mapAssignee.remove(key);
			}
		}

	}
	public Map getObjectCountValuesMap(Context paramContext, String strType, String strGroupBy, String strSubGroupBy, Map resultMap, String dateUnit, String reportType) throws Exception
	{
		if(!UIUtil.isNullOrEmpty(reportType) && (reportType.equalsIgnoreCase("PWC_RFAWhoHasItReport") || reportType.equalsIgnoreCase("PWC_RFAOpenDRReport")))
			dateUnit = "";
		
		return super.getObjectCountValuesMap(paramContext, strType, strGroupBy, strSubGroupBy, resultMap, dateUnit);
	}
	public static StringList getModelListBasedOnFamily(Context context, String objList) throws Exception
	{
		StringList returnList = new StringList();
		StringList engineFamilyIdList = FrameworkUtil.split(objList,",");
		Set familyIdSet = new HashSet();
		if (null != engineFamilyIdList && engineFamilyIdList.size() > 0) {
			for (int i = 0; i < engineFamilyIdList.size(); i++) {
				familyIdSet.add(((String)engineFamilyIdList.get(i)).trim());
			}
		}
		StringBuilder selectBuilder = new StringBuilder("from");
		selectBuilder.append("[").append(RELATIONSHIP_PUBLIC_LINE_MODELS).append("]");
		selectBuilder.append(".").append("to").append(".").append("id");
		
		StringList FAMILY_SELECTS = new StringList();
		FAMILY_SELECTS.add(selectBuilder.toString());
		
		BusinessObjectWithSelectList busFamilyList = BusinessObject.getSelectBusinessObjectData(context,
																								(String[]) familyIdSet.toArray(new String[0]),
																								FAMILY_SELECTS);
		BusinessObjectWithSelectItr busWithSelectItr = new BusinessObjectWithSelectItr(busFamilyList);
		while(busWithSelectItr.next())
		{
			BusinessObjectWithSelect busWithSelect = busWithSelectItr.obj();
			StringList modelList = (StringList) busWithSelect.getSelectDataList(selectBuilder.toString());
			
			if(null!=modelList && modelList.size() > 0)
			returnList.addAll(modelList);
		}
		
		return returnList;
	}
	public static StringList getAllRanges(Context context, String attribute)throws Exception
	{
		StringList rangeList = new StringList();
		StringList businessProcessList = FrameworkProperties.getTokenizedProperty(context, "pwcComponents.RFA.BusinessProcesses", ",");
		HashSet listSet = new HashSet();
		boolean addEmptyRange = false;
		if(attribute.equalsIgnoreCase("attribute_PWC_RFAEventImpact"))
		{
			listSet.addAll(FrameworkProperties.getTokenizedProperty(context, "pwcComponents.RFA.SCNCAR.attribute_PWC_RFAEventImpact.Ranges",","));
			listSet.addAll(FrameworkProperties.getTokenizedProperty(context, "pwcComponents.RFA.OEMintervention.attribute_PWC_RFAEventImpact.Ranges",","));
			listSet.addAll(FrameworkProperties.getTokenizedProperty(context, "pwcComponents.RFA.SpareParts.attribute_PWC_RFAEventImpact.Ranges",","));
			addEmptyRange = true;
			/*
			for(int n=0;n<businessProcessList.size();n++)
			{
				String strBusinessProcess = (String)businessProcessList.get(n);
				StringBuilder sbPropertyKey = new StringBuilder("pwcComponents.RFA.").append(strBusinessProcess.replace(" ", "")).append(".").append(attribute).append(".Ranges");
				
				StringList localList = FrameworkProperties.getTokenizedProperty(context, sbPropertyKey.toString(), ",");
				listSet.addAll(localList);
			}
			*/
		}
		if(attribute.equalsIgnoreCase("attribute_PWC_RFALiableGroup")
				|| attribute.equalsIgnoreCase("attribute_PWC_IPTID"))
		{
			
			for(int n=0;n<businessProcessList.size();n++)
			{
				StringList localList = new StringList();
				String strBusinessProcess = (String)businessProcessList.get(n);
				strBusinessProcess = strBusinessProcess.replaceAll(" ", "");
				String strPolicy = EnoviaResourceBundle.getProperty(context,"pwcComponents."+strBusinessProcess+".Create.Policy");
				StringBuilder sbTempBuilder = new StringBuilder();
				
				sbTempBuilder.append(PWCConstants.TYPE_RFA).append(".").append(PropertyUtil.getSchemaProperty(strPolicy)).append(".");
				sbTempBuilder.append(strBusinessProcess).append(".").append(PropertyUtil.getSchemaProperty(attribute)).append(".Range");
				String	strProperty = sbTempBuilder.toString().replaceAll("\\s+", "");
				String strProperties = MqlUtil.mqlCommand(context,"print page PWC_RFAStringResource select content dump", true);
                byte[] bytes = strProperties.getBytes("UTF-8");
				InputStream input = new ByteArrayInputStream(bytes);
				Properties properties = new Properties();
				properties.load(input);
				if(properties.containsKey(strProperty))
				{
					String strLocalVar = properties.getProperty(strProperty);
					if(!UIUtil.isNullOrEmpty(strLocalVar))
					{
						localList = FrameworkUtil.split(strLocalVar, "|");
						listSet.addAll(localList);
					}
				}
			}
			addEmptyRange = true;
		}
		if(attribute.equalsIgnoreCase("Event Location"))
		{
			StringList localList = new StringList();
			// Here we need to return all event location name
			StringList objectSelects = new StringList(DomainConstants.SELECT_NAME);
			MapList mapList = DomainObject.findObjects(context, 
														PWCConstants.TYPE_PWC_RFA_EVENT_LOCATION,
														DomainConstants.QUERY_WILDCARD, 
														DomainConstants.QUERY_WILDCARD, 
														DomainConstants.QUERY_WILDCARD,
														PWCCommonUtil.getVaultPattern(context), 
														null, 
														false, 
														objectSelects);
			int nSize = mapList.size();
			if(nSize > 0)
			{
				for(int n=0;n<nSize;n++)
				{
					Map tempMap = (Map)mapList.get(n);
					localList.add((String)tempMap.get(DomainConstants.SELECT_NAME));
				}
			}
			listSet.addAll(localList);
			addEmptyRange = true;
		}
		if (attribute.equalsIgnoreCase("attribute_PWC_RFAEventType"))
		{
			for(int n = 0; n < businessProcessList.size(); n++)
			{
				String strBusinessProcess 	= (String)businessProcessList.get(n);
				StringBuilder sbPropertyKey = new StringBuilder("pwcComponents.RFA.Create.").append(strBusinessProcess.replace(" ", "")).append(".").append("RFAEventType");
				
				StringList localList = FrameworkProperties.getTokenizedProperty(context, sbPropertyKey.toString(), ",");
				listSet.addAll(localList);
			}
			
		}
		if (attribute.equalsIgnoreCase("attribute_PWC_RFAProcessSubType"))
		{
			for(int n = 0; n < businessProcessList.size(); n++)
			{
				String strBusinessProcess 	= (String)businessProcessList.get(n);
				StringBuilder sbPropertyKey = new StringBuilder("pwcComponents.RFA.").append(strBusinessProcess.replace(" ", "")).append(".").append(attribute).append(".Ranges");
				
				StringList localList = FrameworkProperties.getTokenizedProperty(context, sbPropertyKey.toString(), "~");
				listSet.addAll(localList);
			}
			addEmptyRange = true;
		}
		if (attribute.equalsIgnoreCase("attribute_PWC_InvestigationStatus"))
		{
			AttributeType attrType = new AttributeType("PWC_Investigation Status");
			attrType.open(context);
			listSet.addAll(attrType.getChoices());
			attrType.close(context);
		}
		if(attribute.equalsIgnoreCase("Engine Family"))
		{
			StringList localList = new StringList();
			// Here we need to return all event location name
			StringList objectSelects = new StringList(DomainConstants.SELECT_NAME);
			MapList mapList = DomainObject.findObjects(context, 
														DomainConstants.TYPE_PRODUCTLINE,
														DomainConstants.QUERY_WILDCARD, 
														DomainConstants.QUERY_WILDCARD, 
														DomainConstants.QUERY_WILDCARD,
														PWCCommonUtil.getVaultPattern(context), 
														null, 
														false, 
														objectSelects);
			int nSize = mapList.size();
			if(nSize > 0)
			{
				for(int n=0;n<nSize;n++)
				{
					Map tempMap = (Map)mapList.get(n);
					localList.add((String)tempMap.get(DomainConstants.SELECT_NAME));
				}
			}
			listSet.addAll(localList);
			addEmptyRange = true;
		}
		
		rangeList.addAll(listSet);
		if(addEmptyRange && !rangeList.contains(DomainConstants.EMPTY_STRING))
			rangeList.add(DomainConstants.EMPTY_STRING);
		
		return rangeList;
	}
	public static StringList getColorForRanges(StringList sList)
	{
		StringList returnList = new StringList();
		if(null!=sList && sList.size() > 0)
		{
			for(int n=0;n<sList.size();n++)
			{
				Random randomService = new Random();
				StringBuilder sb = new StringBuilder();
				while (sb.length() < 7) {
				    sb.append(Integer.toHexString(randomService.nextInt()));
				}
				sb.setLength(6);
				returnList.add(sb.toString().trim());
			}
		}
		
		return returnList;
	}
	
}
