package com.ds.apps.metrics.interfaces;

import java.util.HashMap;

import matrix.db.Context;
import matrix.util.StringList;

public interface IPWCRFAReport {
	
	public String buildSearchCriteria(Context paramContext, StringList objectList, HashMap searchCriteriaDataMap) throws Exception;
    
 
}
  