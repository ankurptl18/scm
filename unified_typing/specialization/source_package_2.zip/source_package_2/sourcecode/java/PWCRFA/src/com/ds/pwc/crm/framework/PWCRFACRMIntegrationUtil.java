package com.ds.pwc.crm.framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.MQLCommand;
import matrix.util.StringList;

import org.apache.log4j.Logger;

import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;

public class PWCRFACRMIntegrationUtil
{	

	private static final Logger _LOGGER  = Logger.getLogger(PWCRFACRMIntegrationUtil.class.getName());
	private PWCRFACRMIntegrationDataMappingHolder MAPPING_INSTANCE = null;
	private static PWCRFACRMIntegrationProcessingInfoHolder objInfoHolder = null ;


	public PWCRFACRMIntegrationUtil(PWCRFACRMIntegrationDataMappingHolder mappingInstance)throws Exception
	{
		MAPPING_INSTANCE = mappingInstance;
		objInfoHolder = PWCRFACRMIntegrationProcessingInfoHolder.getInstance();
	}	

	public static boolean connectCRMIntegrationUser( Context context )throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+"::connectCRMIntegrationUser()");

		boolean bResult = false ;
		try 
		{
			PWCRFACRMIntegrationUtil.pushContextToSuperUser( context );

			String sPWCRFACRMIntegrationUser = EnoviaResourceBundle.getProperty(context, "PWCCRMIntegration.RFA.PWCRFACRMIntegrationUser");

			ContextUtil.pushContext(context, sPWCRFACRMIntegrationUser, DomainConstants.EMPTY_STRING, PWCConstants.PRODUCTION_VAULT );

			String sRequiredProductLicenses = EnoviaResourceBundle.getProperty(context, "PWCCRMIntegration.RFA.IntegrationUser.RequiredLicenses");

			checkPersonsProductAssignements(context, context.getUser(), sRequiredProductLicenses);

			bResult = true ;

		} catch (FrameworkException e) 
		{
			e.printStackTrace();
			throw e ;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+"::connectCRMIntegrationUser()");

		return bResult ;
	}

	/**
	 * @param mappingData
	 * @param mRFAInfo
	 */
	public static void pushContextToSuperUser(Context context) throws FrameworkException
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+"::pushContextToSuperUser()");

		String sSafteyVault = EnoviaResourceBundle.getProperty(context,"eServiceEngineeringCentral.emxSafetyVault");
		String sSuperUser = PropertyUtil.getSchemaProperty(context, "person_UserAgent");
		ContextUtil.pushContext(context, sSuperUser, DomainConstants.EMPTY_STRING, sSafteyVault);

		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+"::pushContextToSuperUser()");

	}		

	/**
	 * @param mappingData
	 * @param mRFAInfo
	 */
	private HashMap<String,String> createAttributeMap(HashMap<String, String> mappingData, HashMap<String,String> mCRMData)
	{
		HashMap<String,String> mAttributeMap = new HashMap<String,String>();
		StringBuilder sCRMValue;
		if(null != mappingData && mappingData.size()>0)
		{
			for (Iterator<String> mapKeysItr = mappingData.keySet().iterator(); mapKeysItr.hasNext();)
			{
				String keyAttribute = mapKeysItr.next();
				boolean isValueMappingRequired = checkIfExistInValueMap(keyAttribute);
				sCRMValue = new StringBuilder();
				String valueAttribute = mappingData.get(keyAttribute);

				if(valueAttribute.contains("~"))
				{
					String[] temp = valueAttribute.split("~");
					List<String> sl = Arrays.asList(temp);
					if(keyAttribute.equalsIgnoreCase("attribute_PWC_EnginePosition") || keyAttribute.equalsIgnoreCase("attribute_PWC_RFAEventCategoryBasic/NonBasic"))
					{
						sCRMValue = calculateMultiValueAttribute(temp, mCRMData, keyAttribute);
					}
					else
					{
						for(int index=0;index<sl.size();index++)
						{
							if(index > 0){
								sCRMValue.append(",");
							}
							sCRMValue.append(getValueFromMap(sl.get(index),keyAttribute,isValueMappingRequired,mCRMData));
						}
					}					
					mAttributeMap.put(keyAttribute, sCRMValue.toString());
				}else
				{
					sCRMValue.append(getValueFromMap(valueAttribute,keyAttribute,isValueMappingRequired,mCRMData));
					mAttributeMap.put(keyAttribute, sCRMValue.toString());
				}
			}
		}
		return mAttributeMap;
	}

	/**
	 * @param mappingData
	 * @param mRFAInfo
	 */
	private String getValueFromMap(String sKey, String sAttributeName, boolean isValueMappingRequired, HashMap<String,String> mCRMData)
	{	
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+"::getValueFromMap()");

		String sReturnValue = "";
		try{
			if(mCRMData.containsKey(sKey))
			{	
				sReturnValue = mCRMData.get(sKey);
				sReturnValue.trim();
				if(isValueMappingRequired)
				{
					sReturnValue = getAttributeValueFromMapping(sAttributeName,sReturnValue);
				}
			} else
			{
				objInfoHolder.logWarning("AM", "Attribute '"+sAttributeName+"' does not exists in CRM Data File");
				_LOGGER.warn("Attribute '"+sAttributeName+"' does not exists in CRM Data File");

			}
		}catch(Exception e){

		}
		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+"::getValueFromMap()");

		return sReturnValue;
	}

	/**
	 * @param mappingData
	 * @param mRFAInfo
	 */
	private String getAttributeValueFromMapping(String sAttributeName, String sCRMValue)
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+"::getAttributeValueFromMapping()");

		String sReturnValue = "";
		HashMap<String,HashMap<String,String>> mAttributeMap = MAPPING_INSTANCE.mAttributeValueMap;
		HashMap<String,String> mValueMap = (HashMap<String,String>)mAttributeMap.get(sAttributeName);
		if(mValueMap.containsKey(sCRMValue.toUpperCase()))
		{
			sReturnValue = mValueMap.get(sCRMValue.toUpperCase());
		} else
		{
			String sActualAttrName = PropertyUtil.getSchemaProperty(sAttributeName);
			if(!UIUtil.isNullOrEmpty(sCRMValue) && !sActualAttrName.equals(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINE_SYMPTOM_FAMILY))
				objInfoHolder.logWarning("AVM", "Attribute Table:'"+sActualAttrName+"', does not contain value of '"+sCRMValue+"'");
			
			_LOGGER.warn("Attribute Table:'"+sActualAttrName+"', does not contain value of '"+sCRMValue+"'");
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+"::getAttributeValueFromMapping()");

		return sReturnValue;
	}

	private StringBuilder calculateMultiValueAttribute(String[] sCRMValue,HashMap<String,String> mCRMData,String sAttributeName)
	{	
		StringBuilder sbReturnValue = new StringBuilder();
		String sValue = "";
		if(sCRMValue.length > 1)
		{
			if(sAttributeName.equalsIgnoreCase("attribute_PWC_RFAEventCategoryBasic/NonBasic"))
			{
				StringBuilder sbValue = new StringBuilder();
				List<String> sl = Arrays.asList(sCRMValue);
				for(int index=0;index<sl.size();index++)
				{
					if(index > 0){
						sbValue.append(",");
					}
					sbValue.append(getValueFromMap(sl.get(index), sAttributeName, false, mCRMData));
				}
				sValue = sbValue.toString();				
			}
			else
			{
			String sPosition = mCRMData.get((String)sCRMValue[0]).trim();
			String sQTY = mCRMData.get((String)sCRMValue[1]).trim();
			int iQTY;

			if(!UIUtil.isNullOrEmpty(sQTY))
			{
				iQTY = Integer.parseInt(sQTY);
				if(iQTY == 1)
					sValue="1";
				else
					sValue=sPosition;
			} else
			{
				sValue=sPosition;
			}			
			}						
			sbReturnValue.append(getAttributeValueFromMapping(sAttributeName,sValue));
		}		
		return sbReturnValue;
	}

	/**
	 * @param mappingData
	 * @param mRFAInfo
	 */
	private boolean checkIfExistInValueMap(String sAttributeName)
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+"::checkIfExistInValueMap()");

		boolean returnValue = false;
		HashMap<String,HashMap<String,String>> valueMap = MAPPING_INSTANCE.mAttributeValueMap;
		if(valueMap.containsKey(sAttributeName))
		{
			returnValue = true;
		}		

		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+"::checkIfExistInValueMap()");

		return returnValue;
	}

	/**
	 * @param mappingData
	 * @param mRFAInfo
	 */
	public String getCRMReportNumber(HashMap<String,String> mCRMData)
	{
		String sCRMReportNumber = "";
		sCRMReportNumber = (String)mCRMData.get("CMS report number");
		return sCRMReportNumber;
	}	

	/**
	 * @param mappingData
	 * @param mRFAInfo
	 */
	public HashMap<String,Object> generateCreateRFAInformationMap(HashMap<String,String> mCRMData)
	{
		HashMap<String,Object> mRFACreateInformationMap = new HashMap<String,Object>();

		mRFACreateInformationMap.put("RFAAttributeMap", createAttributeMap(MAPPING_INSTANCE.mRFAAttributeMap,mCRMData));
		mRFACreateInformationMap.put("EngineAttributeMap", createAttributeMap(MAPPING_INSTANCE.mEngineAttributeMap,mCRMData));
		mRFACreateInformationMap.put("EngineRelAttributeMap", createAttributeMap(MAPPING_INSTANCE.mEngineRelationshipAttributeMap,mCRMData));
		mRFACreateInformationMap.put("PartAttributeMap", createAttributeMap(MAPPING_INSTANCE.mPartAttributeMap,mCRMData));
		mRFACreateInformationMap.put("PartRelAttributeMap", createAttributeMap(MAPPING_INSTANCE.mPartRelationshipAttributeMap,mCRMData));
		mRFACreateInformationMap.put("AircraftAttributeMap", createAttributeMap(MAPPING_INSTANCE.mAircraftAttributeMap,mCRMData));
		mRFACreateInformationMap.put("ReferanceAttributeMap", createAttributeMap(MAPPING_INSTANCE.mReferanceAttributeMap,mCRMData));
		mRFACreateInformationMap.put("AttachmentAttributeMap", createAttributeMap(MAPPING_INSTANCE.mAttachmentAttributeMap,mCRMData));
		mRFACreateInformationMap.put("ClassificationList", PWCRFACRMIntegrationManager.getStrLstClassification());

		return mRFACreateInformationMap;
	}

	/**
	 * @param mappingData
	 * @param mRFAInfo
	 */
	public HashMap<String,HashMap<String,String>> generateUpdateRFAInformationMap(HashMap<String,String> mCRMData)
	{
		HashMap<String,HashMap<String,String>> mRFAUpdateInformationMap = new HashMap<String,HashMap<String,String>>();
		mRFAUpdateInformationMap.put("EngineAttributeMap", createAttributeMap(MAPPING_INSTANCE.mEngineAttributeMap,mCRMData));
		mRFAUpdateInformationMap.put("EngineRelAttributeMap", createAttributeMap(MAPPING_INSTANCE.mEngineRelationshipAttributeMap,mCRMData));
		return mRFAUpdateInformationMap;
	}

	public static void sendMail(Context context,StringList slTo, StringList slCc, String sSubject, String sMsssage, File file) throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+"::sendMail()");

		String sUserName  = EnoviaResourceBundle.getProperty(context, "PWCCRMIntegration.CRM.Integration.NotificationUserName");
		String sUserMailId  = EnoviaResourceBundle.getProperty(context, "PWCCRMIntegration.CRM.Integration.NotificationUserMailID");

		String sHostName 	= PropertyUtil.getEnvironmentProperty(context, "MX_SMTP_HOST");

		InternetAddress[] To = createEmailList(slTo);
		InternetAddress[] Cc = createEmailList(slCc);

		try
		{	
			Properties props = System.getProperties();
			props.put("mail.smtp.host", sHostName);
			javax.mail.Session session = javax.mail.Session.getDefaultInstance(props, null);			
			Message message = new MimeMessage(session);

			message.setSubject(sSubject);
			message.setFrom(new InternetAddress(sUserMailId,sUserName));
			message.addRecipients(Message.RecipientType.TO,To);
			message.addRecipients(Message.RecipientType.CC,Cc);

			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent(sMsssage, "text/plain");	
			MimeMultipart multipart = new MimeMultipart("related");
			multipart.addBodyPart(messageBodyPart);

			if ( null != file) 
			{
				messageBodyPart = new MimeBodyPart();
				DataSource source = new FileDataSource(file.getAbsoluteFile()) {
					public String getContentType() {
					    return "mytype/mysubtype";
					}
				    };

				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName(file.getName());
				multipart.addBodyPart(messageBodyPart);			
			}

			message.setContent(multipart);
			message.saveChanges();
			Transport.send(message,message.getAllRecipients());
		}
		catch(Exception e)
		{
			
			_LOGGER.error("Failed to send Email Notification due to this error: " + PWCRFACRMIntegrationUtil.getStackTrace(e) );
			e.printStackTrace();
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+"::sendMail()");
	}

	/**
	 * This method add Email lto InternetAddress.
	 * @param args : accepts current context and User list.
	 */
	private static InternetAddress[] createEmailList(StringList sIDList)throws Exception
	{	
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+"::createEmailList()");

		int iSize = sIDList.size();
		InternetAddress[] emailIds = new InternetAddress[iSize];		
		for(int index=0; index < iSize; index++)
		{
			emailIds[index] = new InternetAddress((String)sIDList.get(index));
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+"::createEmailList()");

		return emailIds;
	}


	public static boolean CreateZipOfMultipleFiles( String[] arrSourceFile1AbsolutePaths, String[] arrSourceFileNames, String sZipFileAbsolutePath ) 
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+"::CreateZipOfMultipleFiles()");

		boolean bResult = true ;

		ZipOutputStream zout = null ;
		FileInputStream fin = null ;

		try
		{
			String zipFile = sZipFileAbsolutePath ;

			//create byte buffer
			byte[] buffer = new byte[1024];

			//create object of FileOutputStream
			FileOutputStream fout = new FileOutputStream(sZipFileAbsolutePath);

			//create object of ZipOutputStream from FileOutputStream
			zout = new ZipOutputStream(fout);

			for(int i=0; i < arrSourceFile1AbsolutePaths.length; i++)
			{

				//create object of FileInputStream for source file
				fin = new FileInputStream(arrSourceFile1AbsolutePaths[i]);

				/*
				 * To begin writing ZipEntry in the zip file, use
				 *
				 * void putNextEntry(ZipEntry entry)
				 * method of ZipOutputStream class.
				 *
				 * This method begins writing a new Zip entry to
				 * the zip file and positions the stream to the start
				 * of the entry data.
				 */

				zout.putNextEntry(new ZipEntry(arrSourceFileNames[i]));

				/*
				 * After creating entry in the zip file, actually
				 * write the file.
				 */ 
				int length;

				while((length = fin.read(buffer)) > 0)
				{
					zout.write(buffer, 0, length);
				}

				/*
				 * After writing the file to ZipOutputStream
				 * close the current entry and position the stream to
				 * write the next entry.
				 */

				zout.closeEntry();

				//close the InputStream
				fin.close();
			}
			//close the ZipOutputStream
			zout.close();

		}
		catch(IOException ioe)
		{
			bResult = false ;
			_LOGGER.error("Failed to generate the zip file due to this error "+ PWCRFACRMIntegrationUtil.getStackTrace(ioe));

		}finally
		{
			try 
			{
				if ( fin != null ) 
				{
					fin.close() ;
				}

				if ( zout != null ) 
				{
					zout.close();
				}
			} catch (Exception e) 
			{
				e.printStackTrace() ;
			}
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+"::CreateZipOfMultipleFiles()");

		return bResult ;
	}

	/**
	 * This API is used to generate stack trace along with an appropriate custom error message
	 * 
	 * @param e - java exception object with default stack trace and message
	 * @return - String representation of the Custom message and the stack trace
	 */
	public static String getStackTrace(Exception e)
	{
		StringWriter stringWriter = new StringWriter();
		PrintWriter printWriter = new PrintWriter(stringWriter, true);
		e.printStackTrace(printWriter);

		return stringWriter.toString();
	}

	private static void checkPersonsProductAssignements(Context context, String sPersonName, String sRequiredProds) throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+"::checkPersonsProductAssignements()");

		sRequiredProds = sRequiredProds.replaceAll("\\s", DomainConstants.EMPTY_STRING);
		String[] arRequiredProducts = sRequiredProds.split("\\,");

		MQLCommand mqlCommand = new MQLCommand();
		String strcommand = "print person \""+sPersonName+"\" select product dump |";

		boolean bMQLResult = false;
		bMQLResult =  mqlCommand.executeCommand(context, strcommand);

		if (bMQLResult) 
		{
			String sResult = mqlCommand.getResult();
			sResult = sResult.replaceAll("\\s", DomainConstants.EMPTY_STRING);

			String[] arAssignedProds = sResult.split("\\|");
			StringList slAssignedProds = new StringList(arAssignedProds);
			_LOGGER.debug("\n slAssignedProds: "+slAssignedProds);

			StringList slReqProds = new StringList(arRequiredProducts);
			_LOGGER.debug("\n slReqProds: "+slReqProds);

			if (!slAssignedProds.containsAll(slReqProds)) 
			{
				throw new Exception("User does not have all the required products (i.e. "+slReqProds+") assigned.");
			}
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+"::checkPersonsProductAssignements()");
	}

	/**
	 * This API returns the vault of the given person 
	 * 
	 * @param context
	 * @param sPersonName
	 * @return
	 * @throws Exception
	 */
	/*@SuppressWarnings("unchecked")
	public static String getPersonsVault(Context context, String sPersonName)throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+" : getPersonsVault()");

		MapList mlAllRevisions = new MapList();
		String sVault = DomainConstants.EMPTY_STRING;
		try 
		{
			SelectList slResultSelects = new SelectList(2);
			slResultSelects.add("latest");
			slResultSelects.add(DomainObject.SELECT_VAULT);

			mlAllRevisions =  DomainObject.findObjects(context,
					DomainConstants.TYPE_PERSON,
					sPersonName,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					PWCCommonUtil.getVaultPattern(context),
					null,
					false,
					slResultSelects);

			String sLatest = DomainConstants.EMPTY_STRING;
			Map mp;
			for (int i = 0; i < mlAllRevisions.size(); i++) 
			{
				mp = (Map)mlAllRevisions.get(i);
				sLatest = (String)mp.get("latest");
				sVault = (String)mp.get("vault");
				if ("TRUE".equalsIgnoreCase(sLatest)) 
				{
					break;
				}
			}

		} catch (Exception e) 
		{
			throw new Exception(new StringBuilder("Faild to retrieve vault of person '"+sPersonName+"' due to below error :  \n\n").append(e).toString(), e);
		}
		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+" : getPersonsVault()");

		return sVault;
	}*/
	
	/**
	 * This API reads the property value from the external folder and if it is not foud there then reads it from the stack
	 * 
	 * @param context
	 * @param sPropertyKey
	 * @return
	 * @throws FrameworkException
	 */
	public static String getPropertyValue(String sPropertyKey) throws FrameworkException
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+" : getPropertyValueFromExternalFolder()");
		
		Properties prop = new Properties();
		InputStream input = null;
		String sPropertyValue = DomainConstants.EMPTY_STRING ;
		String sExternalPropertyFilePath = DomainConstants.EMPTY_STRING ;
		
		try 
		{
			String sExternalFolderPath = System.getenv("PWC_ENOVIA_EXTERNAL_CONFIG_FOLDER_PATH") ;
			
			if(!UIUtil.isNullOrEmpty(sExternalFolderPath))
			{
				sExternalFolderPath = sExternalFolderPath.trim();
				if (System.getProperty("file.separator").toCharArray()[0] == sExternalFolderPath.charAt(sExternalFolderPath.length()-1) ) 
				{
					sExternalPropertyFilePath = new StringBuilder(sExternalFolderPath).append("PWCRFACRMIntegrationExternalConfig.properties").toString() ;
				}else
				{
					sExternalPropertyFilePath =  new StringBuilder(sExternalFolderPath).append(System.getProperty("file.separator")).append("PWCRFACRMIntegrationExternalConfig.properties").toString() ;
				}
				
				File propertiesFile = new File(sExternalPropertyFilePath);
				if(propertiesFile.exists())
				{
					input = new FileInputStream(sExternalPropertyFilePath);
				}
			}		
			
			if(null == input)
			{
				input = PWCRFACRMIntegrationDataMappingHolder.class.getClassLoader().getResourceAsStream("PWCRFACRMIntegrationExternalConfig.properties");				
			}
			
			prop.load(input);
			sPropertyValue = prop.getProperty(sPropertyKey);

		} catch (IOException ex) 
		{
			_LOGGER.error("Failed to read the value of property key '"+sPropertyKey+"' from External Folder due to this error:\n "+ getStackTrace(ex) ) ;
			ex.printStackTrace();
		} finally 
		{
			if (input != null) 
			{
				try 
				{
					input.close();
				} catch (IOException e) 
				{
					_LOGGER.equals("Failed to close the input stream of the file '"+sExternalPropertyFilePath+"' due to this error:\n " + getStackTrace(e)) ;
					e.printStackTrace();
				}
			}
		}	
		
		_LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+" : getPropertyValueFromExternalFolder()");
		return sPropertyValue ;
	}
	
	/**
	 * This API check if given Person Object is exist in ENOVIA or not.
	 * 
	 * @param context
	 * @param sEnoviaUserName
	 * @return boolean
	 * @throws Exception
	 */
	public static boolean checkIfEVUserBOExists(Context context, String sEnoviaUserName )throws Exception
    {
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+" : checkIfEVUserBOExists()");
		
        boolean bReturnValue = false;
        try
        {
            BusinessObject bo = new BusinessObject(DomainObject.TYPE_PERSON, sEnoviaUserName, "-", PWCConstants.PRODUCTION_VAULT);
            if(bo.exists(context))
            {
                bReturnValue = true;
            }
        }
        catch(Exception e)
        {
        	_LOGGER.error( "Failed to check the existance of the business object of user '"+sEnoviaUserName+"' due to this error:\n "+ getStackTrace(e) ) ;
            throw e;
        }
        _LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+" : checkIfEVUserBOExists()");
        
        return bReturnValue;
    }

	public static String getCurrentTimeStamp()
	{
		Date date = new Date(System.currentTimeMillis());
		Calendar cal = new GregorianCalendar();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMMdd-hhmmss-z");
		sdf.setCalendar(cal);
		cal.setTime(date);
		return sdf.format(date) ;
	}

	public static void setAttrIsFirstMilitaryUsage(Context context, String sObjId)throws Exception
	{
		try
		{
			DomainObject dbObj = DomainObject.newInstance(context, sObjId);
			String sRevision = dbObj.getInfo(context, DomainObject.SELECT_REVISION);
			if(!UIUtil.isNullOrEmpty(sRevision) && sRevision.contains("USML"))
			{
				PWCRFACRMIntegrationDataMappingHolder.sMilitaryUses = "Yes";
			}
		}
		catch(Exception e)
		{
			throw e;
		}		
	}
	
	public static boolean checkIPInformationAvailability(Context context)throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationUtil.class.getName()+" : checkIPInformationAvailability()");
		boolean bReturnValue = false;
        try
        {
        	String sIPSensitivityLevel = EnoviaResourceBundle.getProperty(context,"pwcComponents.RFA.CRM.IPClassification.IPSensitivity.DefaultValue").trim();
			String sIPSources = EnoviaResourceBundle.getProperty(context,"pwcComponents.RFA.CRM.IPClassification.IPSource.DefaultValue").trim();
			
			BusinessObject IPsensitivityLevelObject = new BusinessObject(LibraryCentralConstants.TYPE_GENERAL_CLASS, sIPSensitivityLevel, "-", PWCConstants.PRODUCTION_VAULT);
			BusinessObject IPsourceObject = new BusinessObject(DomainConstants.TYPE_COMPANY, sIPSources, "-", PWCConstants.PRODUCTION_VAULT);
						
			if(IPsensitivityLevelObject.exists(context) && IPsourceObject.exists(context))
			{
				bReturnValue = true;
			}
        }
        catch(Exception e)
        {
        	_LOGGER.error("Default 'IP Sensitivity Level' and 'IP Source' has not been set for CRM Integration");
        	throw new Exception("Default 'IP Sensitivity Level' and 'IP Source' has not been set for CRM Integration");
        }
        _LOGGER.debug("End of "+PWCRFACRMIntegrationUtil.class.getName()+" : checkIPInformationAvailability()");
        return bReturnValue;
	}
	

}
