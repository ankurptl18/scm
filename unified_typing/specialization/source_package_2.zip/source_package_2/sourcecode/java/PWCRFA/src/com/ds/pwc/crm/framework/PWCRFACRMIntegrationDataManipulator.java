package com.ds.pwc.crm.framework;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.Normalizer;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.regex.Pattern;

import matrix.db.Context;
import matrix.util.StringList;

import org.apache.log4j.Logger;

import com.ds.common.PWCCommonUtil;
import com.ds.pwc.crm.implementations.PWCRFACRMIntegrationRFAEventUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCRFACRMIntegrationDataManipulator
{
	private static final Logger _LOGGER = Logger.getLogger(PWCRFACRMIntegrationDataManipulator.class.getName());
	private static PWCRFACRMIntegrationProcessingInfoHolder objInfoHolder = null ;

	private static File sharedFolder;
	private static File OKFolder;
	private static File KOFolder;
	private static File WARNINGFolder;

	private static final String PWC_ENOVIA_CRM_INTEGRATION_SHARED_FOLDER_PATH = "PWC_ENOVIA_CRM_INTEGRATION_SHARED_FOLDER_PATH";
	private static final String PWC_ENOVIA_CRM_INTEGRATION_OK_FOLDER_PATH = "PWC_ENOVIA_CRM_INTEGRATION_OK_FOLDER_PATH";
	private static final String PWC_ENOVIA_CRM_INTEGRATION_KO_FOLDER_PATH = "PWC_ENOVIA_CRM_INTEGRATION_KO_FOLDER_PATH";
	private static final String PWC_ENOVIA_CRM_INTEGRATION_WARNING_FOLDER_PATH = "PWC_ENOVIA_CRM_INTEGRATION_WARNING_FOLDER_PATH";

	public PWCRFACRMIntegrationDataManipulator()
	{
		objInfoHolder = PWCRFACRMIntegrationProcessingInfoHolder.getInstance();
	}		

	/**
	 * @param mappingData
	 */
	public HashMap<String,String> getCRMData(File crmFile) throws FileNotFoundException, IOException, Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::getCRMData()");

		boolean bIsFileComplete = false ;
		HashMap<String,String> attributeMap = new HashMap<String,String>();
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader(crmFile));
			String line = "";	       
			String sValue = "";
			String sKey = "";		       

			while ((line = br.readLine()) != null)
			{
				if(line.contains("="))
				{
					int index1 = line.indexOf("=");
					sValue = line.substring(index1+1);
					sKey = line.substring(0, index1);
					attributeMap.put(sKey, sValue.trim());
				}else if(!line.contains(":END_OF_FILE"))
				{
					sValue = sValue + line;
					attributeMap.put(sKey, sValue.trim());
				}if( line.contains(":END_OF_FILE") )
				{
					bIsFileComplete = true ;
				}
			}
			br.close();

			if( !bIsFileComplete )
			{
				_LOGGER.error("The CRM Data File '"+crmFile.getName()+"' is found to be incomplete");
				throw new Exception("The CRM Data File '"+crmFile.getName()+"' is found to be incomplete");
			}

		}
		catch (FileNotFoundException e)
		{
			_LOGGER.error("Failed to read the CRM Data file '"+crmFile+"' due to this error: "+PWCRFACRMIntegrationUtil.getStackTrace(e));
			e.printStackTrace();
			throw e;
		}
		catch (IOException e)
		{
			_LOGGER.error("Failed to read the CRM Data file '"+crmFile+"' due to this error: "+PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw e;
		}
		catch(Exception e)
		{
			throw e;
		}		
		normalizeUnAccent(attributeMap);

		_LOGGER.debug("End of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::getCRMData()");

		return attributeMap;
	}

	private void normalizeUnAccent(HashMap<String, String> attributeMap)
	{
		String sCountry = attributeMap.get("Country");
		String sEngineSymptom = attributeMap.get("Engine Symptom");
		if(!UIUtil.isNullOrEmpty(sCountry))
		{
			String temp = Normalizer.normalize(sCountry, Normalizer.Form.NFD);
			Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
			sCountry = pattern.matcher(temp).replaceAll("");
			attributeMap.put("Country", sCountry);
		}
		
		if(!UIUtil.isNullOrEmpty(sEngineSymptom) && sEngineSymptom.contains("+"))
		{
			int index = sEngineSymptom.indexOf("+");
			sEngineSymptom = sEngineSymptom.substring(index+1);
			attributeMap.put("Engine Symptom", sEngineSymptom.trim());
		}
	}

	/**
	 * @param mappingData
	 */
	private static void loadSharedDirectory(String sSharedFolderPath) throws Exception
	{
		try
		{
			sharedFolder = new File(sSharedFolderPath);
			if(!sharedFolder.isDirectory() && !sharedFolder.canWrite())
			{
				throw new Exception("Failed to load the CRM Data File directory path '"+sSharedFolderPath+"'");
			}
		} 
		catch(Exception e)
		{
			throw e;
		}

	}

	public static void loadSharedFolder()throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::loadSharedFolder()");
		try
		{
			String sSharedFolder = System.getenv(PWC_ENOVIA_CRM_INTEGRATION_SHARED_FOLDER_PATH);
			String sOKFolder = System.getenv(PWC_ENOVIA_CRM_INTEGRATION_OK_FOLDER_PATH);
			String sKOFolder = System.getenv(PWC_ENOVIA_CRM_INTEGRATION_KO_FOLDER_PATH);
			String sWARNINGFolder = System.getenv(PWC_ENOVIA_CRM_INTEGRATION_WARNING_FOLDER_PATH);
			
			if(!UIUtil.isNullOrEmpty(sSharedFolder) && !UIUtil.isNullOrEmpty(sOKFolder) && !UIUtil.isNullOrEmpty(sKOFolder))
			{
				loadSharedDirectory(sSharedFolder);
				loadOKDirectory(sOKFolder);
				loadKODirectory(sKOFolder);
				loadWARNINGDirectory(sWARNINGFolder);
			} else 
			{
				_LOGGER.error("One of the Shared folder path is null or empty");
				throw new Exception("One of the Shared folder path is null or empty");
			}

		} catch(Exception e)
		{
			_LOGGER.error("Failed to load one of the shared directories due to this error:"+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			e.printStackTrace();
			throw e;
		}		

		_LOGGER.debug("End of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::loadSharedFolder()");
	}

	/**
	 * @param mappingData
	 */
	private static void loadOKDirectory(String sOKFolderPath) throws Exception
	{
		try
		{
			OKFolder = new File(sOKFolderPath);
			if(!OKFolder.isDirectory() && !OKFolder.canWrite())
			{
				throw new Exception("Failed to load the 'OK' directory path '"+sOKFolderPath+"'");
			}
		} 
		catch(Exception e)
		{
			throw e;
		}			
	}

	/**
	 * @param mappingData
	 */
	private static void loadKODirectory(String sKOFolderPath) throws Exception
	{
		try
		{
			KOFolder = new File(sKOFolderPath);
			if(!KOFolder.isDirectory() && !KOFolder.canWrite())
			{
				throw new Exception("Failed to load the 'KO' directory path '"+sKOFolderPath+"'");
			}
		} 
		catch(Exception e)
		{
			throw e;
		}			
	}


	/**
	 * @param mappingData
	 */
	private static void loadWARNINGDirectory(String sWARNINGFolder) throws Exception
	{
		try
		{
			WARNINGFolder = new File(sWARNINGFolder);
			if(!WARNINGFolder.isDirectory() && !WARNINGFolder.canWrite())
			{
				throw new Exception("Failed to load the 'WARNING' directory path '"+sWARNINGFolder+"'");
			}
		} 
		catch(Exception e)
		{
			throw e;
		}			
	}


	/**
	 * @param mappingData
	 */
	public File[] readCRMFiles()
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::readCRMFiles()");

		FilenameFilter fileNameFilter = new FilenameFilter()
		{
			@Override
			public boolean accept(File dir, String name)
			{
				if(name.lastIndexOf('.')>0)
				{
					int lastIndex = name.lastIndexOf('.');
					String str = name.substring(lastIndex);
					if(str.equalsIgnoreCase(".csv"))
					{
						return true;
					}
				}
				return false;
			}
		};

		File[] sCRMFiles = sharedFolder.listFiles(fileNameFilter);
		sortFiles(sCRMFiles);

		_LOGGER.debug("End of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::readCRMFiles()");

		return sCRMFiles;
	}	

	/**
	 * @param mappingData
	 */
	private void sortFiles(File[] sCRMFiles)
	{
		Arrays.sort(sCRMFiles, new Comparator<Object>()
				{
			public int compare(Object o1, Object o2) {

				if (((File)o1).lastModified() < ((File)o2).lastModified()) {
					return -1;
				} else if (((File)o1).lastModified() > ((File)o2).lastModified()) {
					return +1;
				} else {
					return 0;
				}
			}
				});
	}

	/**
	 * @param mappingData
	 */
	public boolean validateCRMFile(Context context,HashMap<String,String> mCRMData) throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::validateCRMFile()");

		boolean bReturnValue = false;
		try
		{	
			String sEngineModel = (String)mCRMData.get("Engine Model");
			PWCRFACRMIntegrationRFAEventUtil eventObj = new PWCRFACRMIntegrationRFAEventUtil();
			bReturnValue = eventObj.checkEngineModel(context, sEngineModel);			
			if(bReturnValue)
			{
				bReturnValue = validateEngineModelClassificationMapping(context, sEngineModel);
				if ( !bReturnValue ) 
				{
					objInfoHolder.logError("EMIM", "IPEC Classes validation for Engine Model '"+sEngineModel+"' failed as the given classes does not exist");
				}
			}else
			{
				objInfoHolder.logError("AVM", "Engine Model '"+sEngineModel+"' does not exist");
			}
		}
		catch(Exception e)
		{
			_LOGGER.error("CRM File validation failed due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			objInfoHolder.logError("ADD", "CRM File validation failed due to this error : \n"+ PWCRFACRMIntegrationUtil.getStackTrace(e));

			throw e;
		}
		_LOGGER.debug("End of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::validateCRMFile()");

		return bReturnValue;
	}

	public boolean validateEngineModelClassificationMapping(Context context, String strEngineModel)throws Exception
	{
		boolean bReturnValue 		= true;
		boolean bIsContextPushed	= false;
		StringList strLstClassList	= new StringList();
		try
		{
			PWCRFACRMIntegrationUtil.pushContextToSuperUser(context);
			bIsContextPushed = true;
			PWCRFACRMIntegrationDataMappingHolder.sMilitaryUses = "No";
			// Get the Engine - Classification Mapping
			HashMap<String,HashMap<String,String>> mapEngClassMap = PWCRFACRMIntegrationDataMappingHolder.getInstance().mEngineClassificationMap;
			
			// Get CRM Default class Map if not exist 
			if (PWCRFACRMIntegrationManager.CRM_DEFAULT_MAP.isEmpty())
			{
				PWCRFACRMIntegrationManager.getCRMDefaultClassifications(context);
			}
			
			String strCRMDefaultUSClassId 		= DomainConstants.EMPTY_STRING;
			String strCRMDefaultUSClassName		= DomainConstants.EMPTY_STRING;
			String strCRMDefaultUSExtClassId	= DomainConstants.EMPTY_STRING;
			String strCRMDefaultUSExtClassName	= DomainConstants.EMPTY_STRING;
			String strCRMDefaultCAClassId		= DomainConstants.EMPTY_STRING;
			String strCRMDefaultCAClassName		= DomainConstants.EMPTY_STRING;
			
			if(!PWCRFACRMIntegrationManager.CRM_DEFAULT_MAP.isEmpty())
			{
				// Get CRM Default US Class Name and ID
				strCRMDefaultUSClassId 		=  PWCRFACRMIntegrationManager.CRM_DEFAULT_MAP.get("USJURISDICTION").get("id");
				strCRMDefaultUSClassName 	=  PWCRFACRMIntegrationManager.CRM_DEFAULT_MAP.get("USJURISDICTION").get("name");
				
				// Get CRM Default US EXT Class Name and ID
				strCRMDefaultUSExtClassId 	=  PWCRFACRMIntegrationManager.CRM_DEFAULT_MAP.get("USEXTERNALJURISDICTION").get("id");
				strCRMDefaultUSExtClassName =  PWCRFACRMIntegrationManager.CRM_DEFAULT_MAP.get("USEXTERNALJURISDICTION").get("name");
				
				// Get CRM Default CA Class Name and ID
				strCRMDefaultCAClassId 		=  PWCRFACRMIntegrationManager.CRM_DEFAULT_MAP.get("CAJURISDICTION").get("id");
				strCRMDefaultCAClassName 	=  PWCRFACRMIntegrationManager.CRM_DEFAULT_MAP.get("CAJURISDICTION").get("name");
			}
			else
			{
				objInfoHolder.logWarning("AVM", "CRM Default Classifications are not configured");
			}
			
			// Get Classification Map
			HashMap<String,String> mapClassification 	= (HashMap<String,String>) mapEngClassMap.get(strEngineModel);
			if (mapClassification != null && !mapClassification.isEmpty())
			{
				String strUSJurClass 	= (String) mapClassification.get("USJURISDICTION"); 
				String strUSEXTJurClass = (String) mapClassification.get("USEXTERNALJURISDICTION");
				String strCAJurClass 	= (String) mapClassification.get("CAJURISDICTION");
	
				if(!UIUtil.isNullOrEmpty(strUSJurClass))
				{
					String strUSClass = getClassID(context, strUSJurClass, "USJURISDICTION");
	
					if(!UIUtil.isNullOrEmpty(strUSClass))
					{
						strLstClassList.addElement(strUSClass);
					}
					else
					{
						objInfoHolder.logError("AVM", "IPEC class '"+strUSJurClass+"' does not exist in database");
						bReturnValue = false;
					}
				}
				else //Added for CRM Default implementation start
				{		
					if(!UIUtil.isNullOrEmpty(strCRMDefaultUSClassId))
					{
						strLstClassList.addElement(strCRMDefaultUSClassId);
					}
					else
					{
						objInfoHolder.logError("AVM", "CRM Default US IPEC class '" + strCRMDefaultUSClassName + "' does not exist in database");
						bReturnValue = false;
					}
				}//Added for CRM Default implementation end
	
				if(!UIUtil.isNullOrEmpty(strUSEXTJurClass))
				{
					String strUSEXTClass = getClassID(context, strUSEXTJurClass, "USEXTERNALJURISDICTION");
	
					if(!UIUtil.isNullOrEmpty(strUSEXTClass))
					{
						strLstClassList.addElement(strUSEXTClass);
						PWCRFACRMIntegrationUtil.setAttrIsFirstMilitaryUsage(context,strUSEXTClass);
					}
					else
					{
						objInfoHolder.logError("AVM", "IPEC class '"+strUSEXTJurClass+"' does not exist in database");
						bReturnValue = false;
					}
				}
				else//Added for CRM Default implementation start
				{		
					if(!UIUtil.isNullOrEmpty(strCRMDefaultUSExtClassId))
					{
						strLstClassList.addElement(strCRMDefaultUSExtClassId);
					}
					else
					{
						objInfoHolder.logError("AVM", "CRM Default US EXT IPEC class '" + strCRMDefaultUSExtClassName + "' does not exist in database");
						bReturnValue = false;
					}
				}//Added for CRM Default implementation end
	
				if(!UIUtil.isNullOrEmpty(strCAJurClass))
				{
					String strCAClass = getClassID(context, strCAJurClass, "CAJURISDICTION");
	
					if(!UIUtil.isNullOrEmpty(strCAClass))
					{
						strLstClassList.addElement(strCAClass);
					}
					else
					{
						objInfoHolder.logError("AVM", "IPEC class '"+strCAJurClass+"' does not exist in database");
						bReturnValue = false;
					}
				}
				else//Added for CRM Default implementation start
				{	
					if(!UIUtil.isNullOrEmpty(strCRMDefaultCAClassId))
					{
						strLstClassList.addElement(strCRMDefaultCAClassId);
					}
					else
					{
						objInfoHolder.logError("AVM", "CRM Default CA IPEC class '" + strCRMDefaultCAClassName + "' does not exist in database");
						bReturnValue = false;
					}
				}//Added for CRM Default implementation end

			}
			else
			{					
				//Added for CRM Default implementation start.
				
				// Get default US Class 
				if(!UIUtil.isNullOrEmpty(strCRMDefaultUSClassId))
				{
					strLstClassList.addElement(strCRMDefaultUSClassId);
				}
				else
				{
					objInfoHolder.logError("AVM", "CRM Default US IPEC class '" + strCRMDefaultUSClassName + "' does not exist in database");
					bReturnValue = false;
				}
				
				// Get Default US External Class
				if(!UIUtil.isNullOrEmpty(strCRMDefaultUSExtClassId))
				{
					strLstClassList.addElement(strCRMDefaultUSExtClassId);
				}
				else
				{
					objInfoHolder.logError("AVM", "CRM Default US EXT IPEC class '" + strCRMDefaultUSExtClassName + "' does not exist in database");
					bReturnValue = false;
				}
				
				// Get Default CA Class
				if(!UIUtil.isNullOrEmpty(strCRMDefaultCAClassId))
				{
					strLstClassList.addElement(strCRMDefaultCAClassId);
				}
				else
				{
					objInfoHolder.logError("AVM", "CRM Default CA IPEC class '" + strCRMDefaultCAClassName + "' does not exist in database");
					bReturnValue = false;
				}

			}
			
			if (strLstClassList.isEmpty() ||  !bReturnValue)
			{
				bReturnValue = false;
				objInfoHolder.logError("AVM", "Export Control Classes validation Failed");
			}
			
			PWCRFACRMIntegrationManager.setStrLstClassification(strLstClassList);
			
		}
		catch(Exception e)
		{
			throw e;
		}
		finally
		{
			if(bIsContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
		return bReturnValue;
		
	}

	public static String getClassID(Context context, String strClassName, String strJurisdiction)
	throws Exception
	{
		String strReturnValue 	= DomainConstants.EMPTY_STRING;;
		String strClassID 		= DomainConstants.EMPTY_STRING;
		String sCriteria		= DomainConstants.EMPTY_STRING;

		if ("USJURISDICTION".equals(strJurisdiction)) 
		{
			sCriteria = (new StringBuilder(DomainConstants.QUERY_WILDCARD)).append("T-PWC").append(DomainConstants.QUERY_WILDCARD).toString();
		}
		else if ("USEXTERNALJURISDICTION".equals(strJurisdiction)) 
		{
			sCriteria = (new StringBuilder(DomainConstants.QUERY_WILDCARD)).append("T-US").append(DomainConstants.QUERY_WILDCARD).toString();
		}
		else if ("CAJURISDICTION".equals(strJurisdiction)) 
		{
			sCriteria = (new StringBuilder(DomainConstants.QUERY_WILDCARD)).append("T-CA").append(DomainConstants.QUERY_WILDCARD).toString();
		}

		PWCCommonUtil commonUtil = new PWCCommonUtil(context, new String[0]);
		strClassID = commonUtil.getECClassificationID(context, strClassName, sCriteria);

		if (!UIUtil.isNullOrEmpty(strClassID))
		{
			strReturnValue = strClassID;
		}

		return strReturnValue;
	}

	/**
	 * @param mappingData
	 */
	public void moveFilesToDestination(File[] files) throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::moveFilesToDestination()");

		String sStatus = objInfoHolder.getStatus();		

		for (int i = 0; i < files.length; i++) 
		{
			File file = files[i];

			if ( null != file ) 
			{
				if ( "KO".equals(sStatus) ) 
				{
					moveFileToFolder(file, KOFolder.getAbsolutePath());
				}else if( "WARNING".equals(sStatus) )
				{
					moveFileToFolder(file, WARNINGFolder.getAbsolutePath());
				}else if( "OK".equals(sStatus) )
				{
					moveFileToFolder(file, OKFolder.getAbsolutePath());
				}else
				{
					throw new Exception("Invalid value '"+sStatus+"' for CRM Data File processing status");
				}
			}		
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::moveFilesToDestination()");

	}

	/**
	 * @param mappingData
	 */
	public void moveFileToFolder(File file, String sFolderPath) throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::moveFileToFolder()");

		String sFileName = file.getName();		
		if(copyFile(file, new File( sFolderPath + File.separator + sFileName)))
		{
			if(!file.delete())
			{
				_LOGGER.error("Exception in PWCRFACRMIntegrationDataManipulator.moveFileToFolder(): cannot delete the file + [" + file.getPath() + "]" );
				throw new Exception ("Error: cannot delete the file + [" + file.getPath() + "]");
			}
		}		

		_LOGGER.debug("End of "+PWCRFACRMIntegrationDataManipulator.class.getName()+"::moveFileToFolder()");
	}
	
	private boolean copyFile (File inSource, File outDestination) throws IOException
	{
		boolean isCopied = false;
		FileChannel inputChannel = null;
		FileChannel outputChannel = null;
		try
		{
			inputChannel = new FileInputStream(inSource).getChannel();
			outputChannel = new FileOutputStream(outDestination).getChannel();
			outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
			isCopied = true;
		}
		catch (Exception ex)
		{
			_LOGGER.error("Exception in PWCRFACRMIntegrationDataManipulator.copyFile(): ");
			ex.printStackTrace();
		}
		finally
		{
			if(null != inputChannel) inputChannel.close();
			if(null != outputChannel) outputChannel.close();
		}
		return isCopied;
	}
}
