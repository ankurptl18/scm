package com.ds.pwc.early_detection.implementations;

import java.util.Map;

public class PWCRFAEarlyDetectionDefectData{
	private String strEDDefectMultiple;
	private String strEDDefectType;
	private String strObjectId ;
	private String strAlertType ;
	private Map strCombinedMatch;
	private Map strEngineMatch;
	private Map strPartMatch;
	private Map strW2PartMatch;
	private Map strW2PartNoMatch;
	private String strEngineModelFamily;
	private String strPWCRFAEngineModel;
	public String getAttributeValue( String strComparisionAttribute){return "";};
	
	/**
	 * @return the strEDDefectMultiple
	 */
	public String getStrEDDefectMultiple() {
		return strEDDefectMultiple;
	}

	/**
	 * @param strEDDefectMultiple the strEDDefectMultiple to set
	 */
	public void setStrEDDefectMultiple(String strEDDefectMultiple) {
		this.strEDDefectMultiple = strEDDefectMultiple;
	}

	/**
	 * @return the strEDDefectType
	 */
	public String getStrEDDefectType() {
		return strEDDefectType;
	}

	/**
	 * @param strEDDefectType the strEDDefectType to set
	 */
	public void setStrEDDefectType(String strEDDefectType) {
		this.strEDDefectType = strEDDefectType;
	}
	
	/**
	 * @param strObjectId the strObjectId to set
	 */
	public void setStrObjectId(String strObjectId) {
		this.strObjectId = strObjectId;
	}
	
	/**
	 * @return the strObjectId
	 */
	public String getStrObjectId() {
		return strObjectId;
	}
	
	/**
	 * @param strAlertType the setAlertType to set
	 */
	public void setAlertType(String strAlertType) {
		this.strAlertType = strAlertType;
	}
	
	/**
	 * @return the strAlertType
	 */
	public String getAlertType() {
		return strAlertType;
	}

	public void setW1CombinedMatch(Map strCombinedMatch) {
		this.strCombinedMatch = strCombinedMatch;
		
	}
	public Map getW1CombinedMatch() {
		return  strCombinedMatch;
		
	}

	public void setW1EngineMatch(Map strEngineMatch) {
		this.strEngineMatch = strEngineMatch;
		
	}
	public Map getW1EngineMatch() {
		return  strEngineMatch;
		
	}
	public void setW2PartNoMatch(Map strW2PartNoMatch) {
		this.strW2PartNoMatch = strW2PartNoMatch;
		
	}
	public Map getW2PartNoMatch() {
		return  strW2PartNoMatch;
		
	}
	
	public void setW2PartMatch(Map strW2PartMatch) {
		this.strW2PartMatch = strW2PartMatch;
		
	}
	public Map getW2PartMatch() {
		return  strW2PartMatch;
		
	}
	
	public void setW1PartMatch(Map strW1PartMatch) {
		this.strPartMatch = strW1PartMatch;
		
	}
	public Map getW1PartMatch() {
		return  strPartMatch;
		
	}
	
	/**
	 * @return the strEngineModelFamily
	 */
	public String getStrEngineModelFamily() {
		return strEngineModelFamily;
	}

	/**
	 * @param strEngineModelFamily the strEngineModelFamily to set
	 */
	public void setStrEngineModelFamily(String strEngineModelFamily) {
		this.strEngineModelFamily = strEngineModelFamily;
	}

	/**
	 * @return the strPWCRFAEngineModel
	 */
	public String getStrPWCRFAEngineModel() {
		return strPWCRFAEngineModel;
	}

	/**
	 * @param strPWCRFAEngineModel the strPWCRFAEngineModel to set
	 */
	public void setStrPWCRFAEngineModel(String strPWCRFAEngineModel) {
		this.strPWCRFAEngineModel = strPWCRFAEngineModel;
	}
	


}
