package com.ds.pwc.early_detection.calculation;
import org.apache.log4j.Logger;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionCalculator;
import java.util.HashMap;

public class PWCRFAEarlyDetectionRecurrenceCalculator implements IPWCRFAEarlyDetectionCalculator{

	private static final Logger LOG = Logger.getLogger("PWCRFAEarlyDetectionRecurrenceCalculator");

	/**
	 * The function is to comapre frequency Nc Ne Np with the limits in Recurrence.xml
	 * nd getting value for Recurrence
	 * 
	 * @param context
	 * @param recurrenceCombiList
	 *            Nodelist
	 * @param double Nc
	 * @return - int
	 * @throws Exception
	 *             when problems occurred
	 */
	public Object calculate(HashMap hMap){
		
		LOG.debug("Start of PWCRFAEarlyDetectionRecurrenceCalculator : calculate");
		int iRecurrenceC = 0;
		String operatorValue  = "";
		String operandValue  = "";
		String operandValue1  = "";
		String operandValue2  = "";
		int iList = 0;
		try {
			double N = (Double)hMap.get("N");
			NodeList recurrenceCombiList = (NodeList)hMap.get("recurrenceList");
			// From Recurrence xml file getting the range and value for Nc
			iList = recurrenceCombiList.getLength();
			for (int l = 0; l < iList; l++) {
				Element elemRec = (Element) recurrenceCombiList.item(l);
				//Getting elements RECURRENCE,OPERATOR,OPERAND from Recurrence.xml
				NodeList recurrencevalueList = elemRec.getElementsByTagName("RECURRENCE");
				Element recurrenceElem = (Element) recurrencevalueList.item(0);
				String strRcvalue = recurrenceElem.getAttribute("value");
				NodeList operatorList = elemRec.getElementsByTagName("OPERATOR");
				Element operatorElem = (Element) operatorList.item(0);
				operatorValue = operatorElem.getAttribute("value");
				NodeList operandList = elemRec.getElementsByTagName("OPERAND");
		
				//Based on OPERATOR and comparing frequency with OPERAND ,deciding Recurrence value
				if(operatorValue.equals("LESSTHANEQUAL")){
				Element operandElem = (Element) operandList.item(0);
				operandValue = operandElem.getAttribute("value");
				// loop exit on satisfying condition
				if (N <= Integer.parseInt(operandValue)) {
					iRecurrenceC = Integer.parseInt(strRcvalue);
					break;
				}
				}
				else if(operatorValue.equals("BETWEEN")){
					NodeList operand1List = elemRec.getElementsByTagName("OPERAND1");
					Element operand1Elem = (Element) operand1List.item(0);
					operandValue1 = operand1Elem.getAttribute("value");
					NodeList operand2List = elemRec.getElementsByTagName("OPERAND2");
					Element operand2Elem = (Element) operand2List.item(0);
					operandValue2 = operand2Elem.getAttribute("value");
					if (N > Integer.parseInt(operandValue1) && N <= Integer.parseInt(operandValue2) ) {
						iRecurrenceC = Integer.parseInt(strRcvalue);
						break;
					}
				}
				else if(operatorValue.equals("GREATERTHAN")){
					Element operandElem = (Element) operandList.item(0);
					operandValue = operandElem.getAttribute("value");
					if (N > Integer.parseInt(operandValue)) {
						iRecurrenceC = Integer.parseInt(strRcvalue);
						break;
					}			
				}
			}
		} catch (Exception ex) {
			LOG.error("Exception in PWCRFAEarlyDetectionRecurrenceCalculator:calculate "+ ex.getMessage());
		}
		LOG.debug("End of PWCRFAEarlyDetectionRecurrenceCalculator:calculate");
		return iRecurrenceC;
		
	}
}
