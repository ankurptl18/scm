package com.ds.pwc.early_detection.implementations;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import matrix.db.Context;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.ds.common.PWCConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionException;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionRFAData;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionUtil;
import com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionCalculatorFactory;
import com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionSeverityCalculator;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionCalculator;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionDefect;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCRFAEarlyDetectionCombinedDefect  implements IPWCRFAEarlyDetectionDefect{
	
	private static final Logger LOG = Logger.getLogger("PWCRFAEarlyDetectionCombinedDefect");
	

	/**
	 * The function is to create an ED Object of type "Combined"
	 * 
	 * @param rfaData 
	 * @param EngineInfo
	 * @return - void
	 * @throws Exception
	 *             when problems occurred
	 */
	public Vector calculateDefectDeviation(Context context,PWCRFAEarlyDetectionRFAData rfaData) {
		LOG.debug("Start of PWCRFAEarlyDetectionCombinedDefect : calculateDefectDeviation");
		
		String strObjectId = "";
		String strDefectCategory = "";
		StringBuilder cmdMQL = new StringBuilder();
		double CombinedWiQi = 0.0;
		double EngineWiQi = 0.0;
		double PartWiQi = 0.0;
		int iRecurrenceC = 0;
		int iRecurrenceE = 0;
		int iRecurrenceP = 0;
		String strEngineModel = "";
		String strEngineModelFly = "";
		HashMap hMap = new HashMap();
		//Getting RFA connected engine map and Part map from rfaData
		MapList mapObjEngine = rfaData.getEnginesInfo();
		MapList mapObjPart = rfaData.getPartInfo();
		int iEngine = mapObjEngine.size();
		int iPart = mapObjPart.size();	
		HashMap hVSMMap = new HashMap();
		DomainObject dObjDefect;
		Vector vDefects =  new Vector();
		Vector vAlerts =  new Vector();
		Vector vAlertIds =  new Vector();
		boolean showAlert = false;
		boolean bSymptomandCondition = false;
		// Creating format for the Decimal Number based on locale
		DecimalFormat format = new DecimalFormat("#.##",new DecimalFormatSymbols(context.getLocale()));
	
		// Getting info on Model from refData
		String strModelCoefficient  = rfaData.getModelCoefficient();
		strEngineModel = rfaData.getModelName();
		strEngineModelFly = rfaData.getModelFly();
		int iIFSDLimitValue = rfaData.getIFSDValue();
		try {
		
			if (iPart == 1 && iEngine == 1)
				strDefectCategory = "Single";

			else if (iPart > 1 || iEngine > 1)
				strDefectCategory = "Multiple";

			for (int i = 0; i < iEngine; i++) {
				// For each map from maplistEngine get attribute PWC_RFA EnginePosition , PWC_RFA Engine Symptom deviation , PWC_Engine
				// Condition,IFSD
				int iSeverityS1 = 0;
				int iSeverityS2 = 0;
				int iSeverityS3 = 0;
				int iSeverityS4 = 0;
				int iSeverityS5 = 0;
				double SFESc = 0.0;
				double SFECc = 0.0;
				double SFEC = 0.0;
				double SFES = 0.0;
				double SFPC = 0.0;
				Map engineMap = (Map) mapObjEngine.get(i);
				String strEnginePos = (String) engineMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_POSITION);
				String strEngineSymp = (String) engineMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_SYMPTOM);
				String strEngineCon = (String) engineMap.get(PWCRFAEarlyDetectionConstants.STR_ENGINE_CONDITION);
				String strEngineIFSD = (String) engineMap.get(PWCRFAEarlyDetectionConstants.STR_REL_ENGINEINFO_IFSD);

				// Get Weights on PWC_RFA Engine Position , PWC_RFA Engine Symptom deviation , PWC_Engine Condition by getPartialSeverity()
				// getting Partial Severities S1
				if (DomainConstants.EMPTY_STRING.equals(strEnginePos))
				{
					strEnginePos = "(Empty)" ;
				}
					iSeverityS1 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,PWCRFAEarlyDetectionConstants.TYPE_EDM_CONFIG,PWCRFAEarlyDetectionConstants.STR_ENGINE_POSITION_NAME, strEnginePos,PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);

				// getting Partial Severities S2
				if (!DomainConstants.EMPTY_STRING.equals(strEngineSymp)) {
					iSeverityS2 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,PWCRFAEarlyDetectionConstants.TYPE_ENGINE_SYMPTOM, strEngineSymp,"1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);
					if (iSeverityS2 < iIFSDLimitValue	&& ((PWCRFAEarlyDetectionConstants.STR_COMMANDED_IFSD).equals(strEngineIFSD) || (PWCRFAEarlyDetectionConstants.STR_UNCOMMANDED_IFSD).equals(strEngineIFSD))){
						iSeverityS2 = iIFSDLimitValue;
					}
				}
				// getting Partial Severities S3
				if (!strEngineCon.equals("") && UIUtil.isNullOrEmpty(strEngineSymp)) {
					iSeverityS3 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,PWCRFAEarlyDetectionConstants.TYPE_ENGINE_CONDITION, strEngineCon,"1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);
					
					if (iSeverityS3 < iIFSDLimitValue && ((PWCRFAEarlyDetectionConstants.STR_COMMANDED_IFSD).equals(strEngineIFSD) || (PWCRFAEarlyDetectionConstants.STR_UNCOMMANDED_IFSD).equals(strEngineIFSD)))
						iSeverityS3 = iIFSDLimitValue;
				}

				System.out.println("Value of strEnginePos in Combined Defect => "+strEnginePos+" Value of strEngineSymp in Combined Defect => " + strEngineSymp+" Value of strEngineCon in Combined Defect=> " + strEngineCon);
				System.out.println("S1 :: "+iSeverityS1+"  S2 :: " + iSeverityS2+"  S3 :: " + iSeverityS3);

				for (int j = 0; j < iPart; j++) {
				//	If either engineSym or Eng Cond exists then continue
					String strPartCoefficient = "0";
					Map partMap = (Map) mapObjPart.get(j);
					String strPartCond = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_REL_PHYSICALPART_PC);
					String strPartName = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_PART_NAME);
					String strPartNumber = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_PART_NUMBER);
					String strPartFly = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_PART_FAMILY);
					String strPartSerialNumber = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_PART_SERIAL_NUMBER);
					String strPartQtyDef = (String) partMap.get(PWCRFAEarlyDetectionConstants.STR_QTY_DEF);
					if (DomainConstants.EMPTY_STRING.equals(strPartName))
					{
						strPartName = PWCRFAEarlyDetectionConstants.STR_PART_EMPTY ;
					}
					
					if((!DomainConstants.EMPTY_STRING.equals(strEngineSymp) || !DomainConstants.EMPTY_STRING.equals(strEngineCon)) && !DomainConstants.EMPTY_STRING.equals(strPartCond))
					{					
					PWCRFAEarlyDetectionCombineDefectData combineDefect = new PWCRFAEarlyDetectionCombineDefectData(context,rfaData.getRFAObjId());
					combineDefect.setStrEDDefectType("Combined");
					combineDefect.setStrPositionWeight(Integer.toString(iSeverityS1));
					combineDefect.setStrPWCEnginePosition(strEnginePos);
					if (!strEngineSymp.equals("")) {
						combineDefect.setStrEngineSymptomWeight(Integer.toString(iSeverityS2));
						combineDefect.setStrPWCRFAEngineSymptomDeviation(strEngineSymp);
					}
					if (!strEngineCon.equals("")) {
						combineDefect.setStrEngineConditionWeight(Integer.toString(iSeverityS3));
						combineDefect.setStrPWCEngineCondition(strEngineCon);
					}
					combineDefect.setStrEDEMCoefficient(strModelCoefficient);
					combineDefect.setStrEngineModelFamily(strEngineModelFly);
					combineDefect.setStrPWCRFAEngineModel(strEngineModel);
					combineDefect.setStrEDDefectMultiple(strDefectCategory);
					combineDefect.setStrEngineIFSD(strEngineIFSD);
					

					// Get Weights on PWC_RFA Part Condition, PWC_RFA Part Name by getPartialSeverity()
					// i.e getting Partial Severities S4
					if (!strPartCond.equals(""))
					{
						iSeverityS4 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,
								PWCRFAEarlyDetectionConstants.TYPE_PART_CONDITION, strPartCond,
								"1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);
					}
					// getting Partial Severities S4
					if (!strPartName.equals(""))
					{
						iSeverityS5 = PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,
								PWCRFAEarlyDetectionConstants.TYPE_PART_CLASSIFICATION,
								strPartName, "1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PARAMETER_WEIGHT);
						
						strPartCoefficient = Integer.toString(PWCRFAEarlyDetectionSeverityCalculator.getPartialSeverity(context,
								PWCRFAEarlyDetectionConstants.TYPE_PART_CLASSIFICATION,
								strPartName, "1",PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT));

					}
					System.out.println("Value of strPartCond in Combined Defect "+strPartCond+" Value of strPartName in Combined Defect => " + strPartName);
					System.out.println("S4 :: "+iSeverityS4+"  S5 :: " + iSeverityS5);

					// Calculating Severities SFESc SFECc SFES SFEC SFPC and adding them to Map to store on Defect Object
					if (!strEngineSymp.equals("") && !strPartCond.equals("")) {
						SFESc = Math.max(Math.pow(iSeverityS1 * iSeverityS2,1.0 / 2), Math.pow(iSeverityS4 * iSeverityS5,1.0 / 2));
					}
					if (!strEngineCon.equals("") && UIUtil.isNullOrEmpty(strEngineSymp) && !strPartCond.equals("")){
						SFECc = Math.max(Math.pow(iSeverityS1 * iSeverityS3,1.0 / 2), Math.pow(iSeverityS4 * iSeverityS5,1.0 / 2));
					}
					if (!strEngineSymp.equals(""))
					{
						SFES = Math.pow(iSeverityS1 * iSeverityS2, 1.0 / 2);

					}
					if (!strEngineCon.equals("") && UIUtil.isNullOrEmpty(strEngineSymp))
					{
						SFEC = Math.pow(iSeverityS1 * iSeverityS3, 1.0 / 2);
					}
					if (!strPartCond.equals(""))
					{
						SFPC = Math.pow(iSeverityS4 * iSeverityS5, 1.0 / 2);
					}
					hVSMMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PART_DEFECT_SEVERITY, SFPC);
				
					
					if (null != strEngineSymp && !(strEngineSymp.equals(""))) {
						combineDefect.setStrEDCombinedDefectSeverity(format.format(SFESc));
						combineDefect.setStrEDEngineDefectSeverity(format.format(SFES));
						hVSMMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_SEVERITY, SFESc);
						hVSMMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SEVERITY, SFES);
						
					} else if (null != strEngineCon && !(strEngineCon.equals("")) && UIUtil.isNullOrEmpty(strEngineSymp)) {
						combineDefect.setStrEDCombinedDefectSeverity(format.format(SFECc));
						combineDefect.setStrEDEngineDefectSeverity(format.format(SFEC));
						hVSMMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_COMBINED_DEFECT_SEVERITY, SFECc);
						hVSMMap.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_ENGINE_DEFECT_SEVERITY, SFEC);
					}
					
					combineDefect.setStrPartCondition(strPartCond);
					combineDefect.setStrPartName(strPartName);
					combineDefect.setStrPWCFamily(strPartFly);
					combineDefect.setStrPartNumber(strPartNumber);
					combineDefect.setStrPWCRFASerialNumber(strPartSerialNumber);
					combineDefect.setStrPWCRFAQtyDefect(strPartQtyDef);					
					combineDefect.setStrEDPartConditionWeight(Integer.toString(iSeverityS4));
					combineDefect.setStrEDPartClassificationWeight(Integer.toString(iSeverityS5));
					combineDefect.setStrEDPNCoefficient(strPartCoefficient);
					combineDefect.setStrEDPartDefectSeverity(format.format(SFPC));
					
					System.out.println("SFESc :: "+SFESc+"  SFECc :: " + SFECc+"  SFEC :: " + SFEC+"  SFEC :: " + SFEC+"  SFPC :: " + SFPC);
				
					if(!PWCRFAEarlyDetectionUtil.isSatisfiesVSMLimits(context,hVSMMap))	
					{
					//Loading SimilarityRule.xml file
					Document document = PWCRFAEarlyDetectionUtil.loadRuleDocument("SimilarityRules.xml");
					NodeList similarityRuleCombiList = document.getElementsByTagName("SIMILARITYRULES");
					NodeList similarityRuleEngineList = document.getElementsByTagName("SIMILARITYRULESENGINE");
					NodeList similarityRulePartList = document.getElementsByTagName("SIMILARITYRULESPART");
				
					if(!UIUtil.isNullOrEmpty(strEngineSymp) && !UIUtil.isNullOrEmpty(strEngineCon)){
						strEngineCon = "";
						bSymptomandCondition = true;
					}
					
					Map mapDefectAttr = new HashMap();
					mapDefectAttr.put(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINEMODEL ,strEngineModel);
					mapDefectAttr.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ENGINE_MODEL_FAMILY ,strEngineModelFly);
					mapDefectAttr.put(PWCConstants.ATTRIBUTE_PART_NUMBER,strPartNumber);
					mapDefectAttr.put(PWCConstants.ATTRIBUTE_PWC_FAMILY,strPartFly);
					mapDefectAttr.put(PWCConstants.ATTRIBUTE_PART_NAME,strPartName);
					mapDefectAttr.put(PWCConstants.ATTRIBUTE_PWC_RFA_ENGINE_SYMPTOM_DEVIATION,strEngineSymp);
					mapDefectAttr.put(PWCConstants.ATTRIBUTE_ENGINE_CONDITION,strEngineCon);
					mapDefectAttr.put(PWCConstants.ATTRIBUTE_PART_CONDITION,strPartCond);
					mapDefectAttr.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT,strModelCoefficient);
					mapDefectAttr.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT,strPartCoefficient);					
					mapDefectAttr.put("SymptomAndCondition",bSymptomandCondition);

					//Getting frequency calculated for Combined Defect
					hMap = new HashMap();
					hMap.put("similarityRuleList", similarityRuleCombiList);
					hMap.put("context", context);
					hMap.put("mapDefectAttr", mapDefectAttr);
					hMap.put("defect", combineDefect);
					hMap.put("rfaData", rfaData);
					hMap.put("from", "combined");

					IPWCRFAEarlyDetectionCalculator instanceWQc=  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionFrequencyCalculator");
					Double dCombinedWiQi = (Double)instanceWQc.calculate(hMap);
					CombinedWiQi = dCombinedWiQi.doubleValue();
					//double Nc = CombinedWiQi *  Double.parseDouble(strModelCoefficient);
					double Nc = CombinedWiQi;
					
					//Getting frequency calculated for Engine Defect
					/*PreetihMap = new HashMap();
					hMap.put("similarityRuleList", similarityRuleEngineList);
					hMap.put("context", context);
					hMap.put("mapDefectAttr", mapDefectAttr);
					hMap.put("defect", combineDefect);
					hMap.put("rfaData", rfaData);
					hMap.put("from", "engine");
					IPWCRFAEarlyDetectionCalculator instanceWQe =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionFrequencyCalculator");
					Double dEngineWiQi = (Double)instanceWQe.calculate(hMap);
					EngineWiQi = dEngineWiQi.doubleValue();
					double Ne = EngineWiQi *  Double.parseDouble(strModelCoefficient);	
					
					//Getting frequency calculated for Part Defect
					hMap = new HashMap();
					hMap.put("similarityRuleList", similarityRulePartList);
					hMap.put("context", context);
					hMap.put("mapDefectAttr", mapDefectAttr);
					hMap.put("defect", combineDefect);
					hMap.put("rfaData", rfaData);
					hMap.put("from", "part");
					IPWCRFAEarlyDetectionCalculator instanceWQp =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionFrequencyCalculator");
					Double dPartWiQi = (Double)instanceWQp.calculate(hMap);
					PartWiQi = dPartWiQi.doubleValue();
					double Np = PartWiQi* Double.parseDouble(strPartCoefficient);*/
					
					//Setting attributes value of Defect
					combineDefect.setStrEDCombinedWeightedDefectFREQ(format.format(Nc));
					//*PreeticombineDefect.setStrEDEngineWeightedDefectFreq(format.format(Ne));
					//*PreeticombineDefect.setStrEDPartWeightedDefectFREQ(format.format(Np));
					
					System.out.println("Nc :: "+Nc);
				
					// Getting Similarity Rules NodesList fteredrom RecurrenceRules.xml document,
					Document documentR = PWCRFAEarlyDetectionUtil.loadRuleDocument("RecurrenceRules.xml");

					// Function to calculate recurrence for Defect type for Combined Defect
					NodeList recurrenceCombiList = documentR.getElementsByTagName("RECURRENCECOMBINED");
					hMap = new HashMap();
					hMap.put("recurrenceList", recurrenceCombiList);
					hMap.put("N", Nc);
					IPWCRFAEarlyDetectionCalculator instanceRc =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionRecurrenceCalculator");
					Integer intRecurrenceC = (Integer)instanceRc.calculate(hMap);
					iRecurrenceC = intRecurrenceC.intValue();
	
					// Function to calculate recurrence for Defect type for Engine Defect
					/*Preeti	NodeList recurrenceEngineList = documentR.getElementsByTagName("RECURRENCEENGINE");
					hMap = new HashMap();
					hMap.put("recurrenceList", recurrenceEngineList);
					hMap.put("N", Ne);
					IPWCRFAEarlyDetectionCalculator instanceRe =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionRecurrenceCalculator");
					Integer intRecurrenceE = (Integer)instanceRe.calculate(hMap);
					iRecurrenceE = intRecurrenceE.intValue();					
					
					// Function to calculate recurrence for Defect type for Part Defect
					NodeList recurrencePartList = documentR.getElementsByTagName("RECURRENCEPART");
					hMap = new HashMap();
					hMap.put("recurrenceList", recurrencePartList);
					hMap.put("N", Np);
					IPWCRFAEarlyDetectionCalculator instanceRp =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionRecurrenceCalculator");
					Integer intRecurrenceP = (Integer)instanceRp.calculate(hMap);
					iRecurrenceP = intRecurrenceP.intValue();*/
					System.out.println("Rc :: "+iRecurrenceC);
				
					//Setting attributes value of Defect in attrMap
					combineDefect.setStrEDCombinedDefectRecurrence(Integer.toString(iRecurrenceC));
					//*PreeticombineDefect.setStrEDEngineDefectRecurrence(Integer.toString(iRecurrenceE));
					//*PreeticombineDefect.setStrEDPartDefectRecurrence(Integer.toString(iRecurrenceP));
	
					// Function to calculate C K and P for Defect type for Combined Defect
					hMap = new HashMap();
					hMap.put("context", context);
					hMap.put("SFESc", SFESc);
					hMap.put("SFECc", SFECc);
					hMap.put("iRecurrenceP", intRecurrenceC) ;
					hMap.put("RFALocationRate", rfaData.getLocation());
					hMap.put("defect", combineDefect);
					hMap.put("Type", "Combined");				
					IPWCRFAEarlyDetectionCalculator instanceComb =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionCKPCalculator");
					Object iResultCombined = instanceComb.calculate(hMap);		
					
					// Function to calculate C K and P for Defect type for Combined Defect
					/*PreetihMap = new HashMap();
					hMap.put("context", context);
					hMap.put("SFES", SFES);
					hMap.put("SFEC", SFEC);
					hMap.put("iRecurrenceP", iRecurrenceE) ;
					hMap.put("RFALocationRate", rfaData.getLocation());
					hMap.put("Type", "Engine");	
					hMap.put("defect", combineDefect.getEngine());
					IPWCRFAEarlyDetectionCalculator instancePartComb =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionCKPCalculator");
					Object iResultEngine = instancePartComb.calculate(hMap);
					
					// Function to calculate C K and P for Defect type for Combined Defect
					hMap = new HashMap();
					hMap.put("context", context);
					hMap.put("SFPC", SFPC);
					hMap.put("iRecurrenceP", iRecurrenceP) ;
					hMap.put("RFALocationRate", rfaData.getLocation());
					hMap.put("defect", combineDefect.getPart());
					hMap.put("Type", "Part");				
					IPWCRFAEarlyDetectionCalculator instance =  PWCRFAEarlyDetectionCalculatorFactory.getCalculatorInstance("com.ds.pwc.early_detection.calculation.PWCRFAEarlyDetectionCKPCalculator");
					Object iResult = instance.calculate(hMap);*/
					combineDefect.setCombineAttributes(context);
					
					if (!PWCRFAEarlyDetectionUtil.isSatisfiesCriticalLimits(context,combineDefect)){
						/*if(!strEngineCon.equals(""))
						{
						vDefects.add("Engine Condition : "+strEngineCon); 
						}
						if(!strEngineSymp.equals(""))
						{
						vDefects.add("Engine Symptom :"+strEngineSymp); 
						}

						vDefects.add("Part Condition :"+strPartCond); */
						showAlert = true;
						String strDefectObject = combineDefect.getStrObjectId();
						String strAlertType = combineDefect.getAlertType();
						PWCRFAEarlyDetectionAlert alertObject = new PWCRFAEarlyDetectionAlert(context,strDefectObject,combineDefect,strAlertType);
						vAlerts.add(alertObject.getAlertName(context));
						vAlertIds.add(alertObject.getAlertId(context));
					
					}
					}
					else{
						combineDefect.setCombineAttributes(context);
					}
				}
			}
			}

			//if(showAlert){
			//MqlUtil.mqlCommand(context, "notice $1","Critical limit exceeds for these Objects :: "+vDefects);
			//Commenting Alert popup
				//MqlUtil.mqlCommand(context, "notice $1","Alert(s)\n Following alerts have been generated,please click OK  to get the details :: "+vAlerts);
			//}
			//Added Code for Seperate Defects
			//Creating new instance of PWCRFAEarlyDetectionEngineDefectData and setting attributes
			//for (int i = 0; i < iEngine; i++){
			PWCRFAEarlyDetectionEngineDefect engineDefect =  new PWCRFAEarlyDetectionEngineDefect();
			engineDefect.calculateDefectDeviation(context,rfaData);
			//}
			//Creating instance of PWCRFAEarlyDetectionPartDefectData and setting attributes
			
			//for (int p = 0; p < iPart; p++)
			//{
				PWCRFAEarlyDetectionPartDefect partDefect =  new PWCRFAEarlyDetectionPartDefect();
			partDefect.calculateDefectDeviation(context,rfaData);
			//}
				
			
			//Added Code for Seperate Defects
	
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Exception in PWCRFAEarlyDetectionCombinedDefect : calculateDefectDeviation : "
							+ ex.getMessage());
		}
		LOG.debug("End of PWCRFAEarlyDetectionCombinedDefect : calculateDefectDeviation");
		return vAlertIds;
	}

}
