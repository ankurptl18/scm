package com.ds.apps.metrics.implementations;

import static com.ds.common.PWCConstants.ATTRIBUTE_ISSUE_CLASSIFICATION;
import static com.ds.common.PWCConstants.ATTRIBUTE_PROB_FOUND_DURING;
import static com.ds.common.PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_TYPE;
import static com.ds.common.PWCConstants.ATTRIBUTE_PWC_RFA_OCCURRENCE_TYPE;
import static com.ds.common.PWCConstants.ATTRIBUTE_PWC_RFA_PART_TYPE;
import static com.ds.common.PWCConstants.ATTRIBUTE_RFA_BUSINESS_PROCESS;
import static com.ds.common.PWCConstants.POLICY_RFA_DRDEV;
import static com.ds.common.PWCConstants.RELATIONSHIP_PWC_RFA_EVENT_LOCATION;
import static com.matrixone.apps.domain.DomainConstants.EMPTY_STRING;
import static com.matrixone.apps.domain.DomainConstants.SELECT_CURRENT;
import static com.matrixone.apps.domain.DomainConstants.SELECT_ID;
import static com.matrixone.apps.domain.DomainConstants.SELECT_NAME;
import static com.matrixone.apps.domain.DomainConstants.SELECT_ORIGINATED;
import static com.matrixone.apps.domain.DomainConstants.SELECT_POLICY;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectItr;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.Context;
import matrix.util.StringList;

import com.ds.apps.metrics.PWCRFAMetricsReports;
import com.ds.apps.metrics.interfaces.IPWCRFAReport;
import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCRFAOpenDRReport implements IPWCRFAReport {
	public Date FROM_DATE = null;
    public Date TO_DATE = null;
    public Date FROM_LC_DATE = null;
    public Date TO_LC_DATE = null;
    
	@SuppressWarnings({ "unchecked" })
	public String buildSearchCriteria(Context paramContext, StringList objectList, HashMap searchCriteriaDataMap) throws Exception {
		
		System.out.println("Criteria : " + searchCriteriaDataMap);

		String SELECT_RFA_BUSINESS_PROCESS = "attribute[" + ATTRIBUTE_RFA_BUSINESS_PROCESS + "]";
		String SELECT_RFA_EVENT_TYPE = "attribute[" + ATTRIBUTE_PWC_RFA_EVENT_TYPE + "]";
		String SELECT_RFA_SUB_TYPE = "attribute[" + ATTRIBUTE_ISSUE_CLASSIFICATION + "]";
		String SELECT_RFA_PFD = "attribute[" + ATTRIBUTE_PROB_FOUND_DURING + "]";
		String SELECT_RFA_PART_TYPE = "attribute[" + ATTRIBUTE_PWC_RFA_PART_TYPE + "]";
		String SELECT_RFA_OCCURRENCE_TYPE = "attribute[" + ATTRIBUTE_PWC_RFA_OCCURRENCE_TYPE + "]";
		String SELECT_RFA_SUB_PROCESS = "attribute[" + PropertyUtil.getSchemaProperty("attribute_PWC_RFAProcessSubType") + "]";
		String REl_PWC_RFA_MODEL = PropertyUtil.getSchemaProperty("relationship_PWC_RFAModel");
		String TYPE_PWC_RFA_ISSUE = PropertyUtil.getSchemaProperty("type_PWC_RFAIssue");
		String STATE_CANCEL = PropertyUtil.getSchemaProperty("policy", POLICY_RFA_DRDEV, "state_Cancelled");
		String SELECT_RFA_EVENT_LOCATION = "from[" + RELATIONSHIP_PWC_RFA_EVENT_LOCATION + "].to.id";
		String STATE_CLOSE = PropertyUtil.getSchemaProperty("policy", POLICY_RFA_DRDEV, "state_Closed");
		String SELECT_RFA_LIABILITY_CONFIRMATION_DATE = "attribute[" + PWCConstants.ATTRIBUTE_PWC_RFA_LIABILITY_CONFIRMATION_DATE + "]";
		String SELECT_ATTR_SEVERITY = "attribute[" + PWCConstants.ATTRIBUTE_PWC_RFA_SEVERITY + "]";
		String SELECT_ATTR_EVENT_IMPACT = "attribute[" + PWCConstants.ATTRIBUTE_PWC_RFA_EVENT_IMPACT + "]";
		String SELECT_ATTR_IPT_ID = "attribute[" + PropertyUtil.getSchemaProperty("attribute_PWC_IPTID") + "]";
		String SELECT_ATTR_LIABLE_GROUP = "attribute[" + PropertyUtil.getSchemaProperty("attribute_PWC_RFALiableGroup") + "]";
		String SELECT_RFA_PART_NAME = "from[" + PWCConstants.RELATIONSHIP_PWC_RFA_PHYSICAL_PART + "].to.attribute["+PWCConstants.ATTRIBUTE_PART_NAME+"]";
		String SELECT_RFA_VENDOR_NAME = "from[" + PWCConstants.RELATIONSHIP_PWC_RFA_PHYSICAL_PART + "].to.attribute["+PWCConstants.ATTRIBUTE_PWC_RFA_VENDOR_CODE_NAME+"]";
		
		
		String strSelectedBusinessProcess = (String) searchCriteriaDataMap.get("selectedBusinessProcess");
		String strSelectedEventType = (String) searchCriteriaDataMap.get("selectedEventType");
		String strSelectedSubType = (String) searchCriteriaDataMap.get("selectedSubType");
		String strSelectedPFD = (String) searchCriteriaDataMap.get("selectedPFD");
		String strSelectedPartType = (String) searchCriteriaDataMap.get("selectedPartType");
		String strSelectedEventLocationOID = (String) searchCriteriaDataMap.get("txtActualContainedEventLocationOID");
		String strSelectedSubProcess = (String) searchCriteriaDataMap.get("selectedSubProcess");
		String strSelectedOccurrenceType = (String) searchCriteriaDataMap.get("selectedOccurrenceType");
		String strSelectedEngineFamilyOIDs = (String) searchCriteriaDataMap.get("txtActualContainedEngineModelFamilyOID");
		String strSelectedCreationFromDate = (String) searchCriteriaDataMap.get("txtFromDate_msvalue");
		String strSelectedCreationToDate = (String) searchCriteriaDataMap.get("txtToDate_msvalue");
		String strPeriodPriorToCurrentDate = (String) searchCriteriaDataMap.get("PeriodPriorToCurrentDate");
		String strDateUnit = (String) searchCriteriaDataMap.get("optDateUnit");
		String strSelectedLCFromDate = (String) searchCriteriaDataMap.get("txtFromLCDate_msvalue");
		String strSelectedLCToDate = (String) searchCriteriaDataMap.get("txtToLCDate_msvalue");
		String strPeriodPriorToCurrentDateForLCD = (String) searchCriteriaDataMap.get("PeriodPriorToCurrentDateForLCD");
		String strDateUnitForLCD = (String) searchCriteriaDataMap.get("optDateUnitLiabilityConfirmationDate");
		String strSelectedSeverity = (String) searchCriteriaDataMap.get("selectedSeverity");
		String strSelectedLiableGroup = (String) searchCriteriaDataMap.get("selectedLiableOrganization");
		String strSelectedPartNameOID = (String) searchCriteriaDataMap.get("txtActualContainedPartNameOID");
		String strSelectedIPTID = (String) searchCriteriaDataMap.get("selectedResponsibleInvestigationGroup");
		String strSelectedVendorNameOID = (String) searchCriteriaDataMap.get("txtActualContainedVendorNameOID");
		String strSelectedEventImpact = (String) searchCriteriaDataMap.get("selectedEventImpact");
		String strSelectedLifecycleState = (String) searchCriteriaDataMap.get("selectedLifecycleState");
		
		String strSelectedPartName = (String) searchCriteriaDataMap.get("txtContainedPartName");
		String strSelectedVendorName = (String) searchCriteriaDataMap.get("txtContainedVendorName");
		
		if(!UIUtil.isNullOrEmpty(strSelectedCreationFromDate) && 
				!UIUtil.isNullOrEmpty(strSelectedCreationToDate))
		{
			FROM_DATE = new Date(strSelectedCreationFromDate);
			TO_DATE = new Date(strSelectedCreationToDate);
		}
				
		if(!UIUtil.isNullOrEmpty(strPeriodPriorToCurrentDate) && !UIUtil.isNullOrEmpty(strDateUnit))
        	setFromToDate(strPeriodPriorToCurrentDate, strDateUnit, "creationDate");
		
		if(!UIUtil.isNullOrEmpty(strSelectedLCFromDate) && 
				!UIUtil.isNullOrEmpty(strSelectedLCToDate))
		{
			FROM_LC_DATE = new Date(strSelectedLCFromDate);
			TO_LC_DATE = new Date(strSelectedLCToDate);
		}
			
		if(!UIUtil.isNullOrEmpty(strPeriodPriorToCurrentDateForLCD) && !UIUtil.isNullOrEmpty(strDateUnitForLCD))
        	setFromToDate(strPeriodPriorToCurrentDateForLCD, strDateUnitForLCD, "LCDate");
        
		String strSearchCriteria = EMPTY_STRING;
		StringBuffer sbSearchCriteria = new StringBuffer();
		StringList models = objectList;
		StringList TARGET_RFA_NAME_LIST = new StringList();
		StringList TARGET_RFA_ID_LIST = new StringList();
        
		// Evaluating engine model list based on engine family, if model list is empty, since we aren't storing engine family direct on RFA
		if((null==models || models.size()==0) && !UIUtil.isNullOrEmpty(strSelectedEngineFamilyOIDs))
		models = PWCRFAMetricsReports.getModelListBasedOnFamily(paramContext, strSelectedEngineFamilyOIDs);
		
		// if engine model list is empty then we need to look all RFAs
		if(null==models || models.size()==0)
		{
			StringList objectSelects = new StringList(DomainConstants.SELECT_ID);
			MapList allRFAList = DomainObject.findObjects(paramContext, 
														PWCConstants.TYPE_RFA,
														DomainConstants.QUERY_WILDCARD, 
														DomainConstants.QUERY_WILDCARD, 
														DomainConstants.QUERY_WILDCARD,
														PWCCommonUtil.getVaultPattern(paramContext), 
														null, 
														false, 
														objectSelects);
			
			int nSize = allRFAList.size();
			if(nSize > 0)
			{
				for(int n=0;n<nSize;n++)
				{
					Map tempMap = (Map)allRFAList.get(n);
					TARGET_RFA_ID_LIST.add((String)tempMap.get(DomainConstants.SELECT_ID));
				}
			}
			
		}else{
		
			// get all the RFA IDs.
			StringList MODEL_SELECTS = new StringList();
	
			MODEL_SELECTS.add("to[" + REl_PWC_RFA_MODEL + "].from.id");
	
			Set<String> modelIdSet = new HashSet<String>();
			for (int i = 0; i < models.size(); i++) {
				modelIdSet.add(((String) models.get(i)).trim());
			}
			BusinessObjectWithSelectList RFAList = BusinessObject.getSelectBusinessObjectData(paramContext, (String[]) modelIdSet.toArray(new String[0]),
			        MODEL_SELECTS);
			BusinessObjectWithSelectItr RFAWithSelectItr = new BusinessObjectWithSelectItr(RFAList);
	
			while (RFAWithSelectItr.next()) {
				BusinessObjectWithSelect RFAWithSelect = RFAWithSelectItr.obj();
				StringList strIdList = (StringList) RFAWithSelect.getSelectDataList("to[" + REl_PWC_RFA_MODEL + "].from.id");
				if (null != strIdList && strIdList.size() > 0) {
					for (int n = 0; n < strIdList.size(); n++) {
						TARGET_RFA_ID_LIST.add((String) strIdList.get(n));
					}
				}
			}
			
		}
		StringList RFA_SELECTS = new StringList();
		RFA_SELECTS.add(SELECT_POLICY);
		RFA_SELECTS.add(SELECT_CURRENT);
		RFA_SELECTS.add(SELECT_NAME);
		RFA_SELECTS.add(SELECT_ID);
		RFA_SELECTS.add(SELECT_ORIGINATED);
		
		if (!UIUtil.isNullOrEmpty(strSelectedBusinessProcess))
			RFA_SELECTS.add(SELECT_RFA_BUSINESS_PROCESS);
		if (!UIUtil.isNullOrEmpty(strSelectedEventType))
			RFA_SELECTS.add(SELECT_RFA_EVENT_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedSubType))
			RFA_SELECTS.add(SELECT_RFA_SUB_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedPFD))
			RFA_SELECTS.add(SELECT_RFA_PFD);
		if (!UIUtil.isNullOrEmpty(strSelectedPartType))
			RFA_SELECTS.add(SELECT_RFA_PART_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedOccurrenceType))
			RFA_SELECTS.add(SELECT_RFA_OCCURRENCE_TYPE);
		if (!UIUtil.isNullOrEmpty(strSelectedSubProcess))
			RFA_SELECTS.add(SELECT_RFA_SUB_PROCESS);
		if (!UIUtil.isNullOrEmpty(strSelectedEventLocationOID))
			RFA_SELECTS.add(SELECT_RFA_EVENT_LOCATION);
		if (null!=FROM_LC_DATE && null!=TO_LC_DATE)
			RFA_SELECTS.add(SELECT_RFA_LIABILITY_CONFIRMATION_DATE);
		if (!UIUtil.isNullOrEmpty(strSelectedSeverity))
			RFA_SELECTS.add(SELECT_ATTR_SEVERITY);
		if (!UIUtil.isNullOrEmpty(strSelectedEventImpact))
			RFA_SELECTS.add(SELECT_ATTR_EVENT_IMPACT);
		if (!UIUtil.isNullOrEmpty(strSelectedIPTID))
			RFA_SELECTS.add(SELECT_ATTR_IPT_ID);
		if (!UIUtil.isNullOrEmpty(strSelectedLiableGroup))
			RFA_SELECTS.add(SELECT_ATTR_LIABLE_GROUP);
		if (!UIUtil.isNullOrEmpty(strSelectedPartNameOID))
			RFA_SELECTS.add(SELECT_RFA_PART_NAME);
		if (!UIUtil.isNullOrEmpty(strSelectedVendorNameOID))
			RFA_SELECTS.add(SELECT_RFA_VENDOR_NAME);
		
		
		Set<String> RFAIdSet = new HashSet<String>();
		if (null != TARGET_RFA_ID_LIST && TARGET_RFA_ID_LIST.size() > 0) {
			for (int i = 0; i < TARGET_RFA_ID_LIST.size(); i++) {
				RFAIdSet.add(((String) TARGET_RFA_ID_LIST.get(i)).trim());
			}
		}

		BusinessObjectWithSelectList busRFAList = BusinessObject.getSelectBusinessObjectData(paramContext, (String[]) RFAIdSet.toArray(new String[0]),
		        RFA_SELECTS);
		BusinessObjectWithSelectItr busWithSelectItr = new BusinessObjectWithSelectItr(busRFAList);

		while (busWithSelectItr.next()) {
			String strRFAName = null;
			String strState = null;
			String strRFABusProcess = null;
			String strRFAEventType = null;
			String strRFASubType = null;
			String strRFAPFD = null;
			String strRFAPartType = null;
			String strRFAOccurenceType = null;
			String strRFASubProcess = null;
			String strRFAEventLocation = null;
			String strRFAOriginated = null;
			String strRFALCDate = null;
			String strRFASeverity = null;
			String strRFAEventImpact = null;
			String strRFAIPTID = null;
			String strRFALiableGroup = null;
			
			BusinessObjectWithSelect busWithSelect = busWithSelectItr.obj();
			StringList strNameList = (StringList) busWithSelect.getSelectDataList(SELECT_NAME);
			StringList strStateList = (StringList) busWithSelect.getSelectDataList(SELECT_CURRENT);
			StringList strRFABusProcessList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_BUSINESS_PROCESS);
			StringList strRFAEventTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_EVENT_TYPE);
			StringList strRFASubTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_SUB_TYPE);
			StringList strRFAPFDList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_PFD);
			StringList strRFAPartTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_PART_TYPE);
			StringList strRFAOccurenceTypeList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_OCCURRENCE_TYPE);
			StringList strRFASubProcessList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_SUB_PROCESS);
			StringList strRFAEventLocationList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_EVENT_LOCATION);
			StringList strRFAoriginatedList = (StringList) busWithSelect.getSelectDataList(SELECT_ORIGINATED);
			StringList strRFALCDateList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_LIABILITY_CONFIRMATION_DATE);
			StringList strRFASeverityList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_SEVERITY);
			StringList strRFAEventImpactList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_EVENT_IMPACT);
			StringList strRFAIPTIDList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_IPT_ID);
			StringList strRFALiableGroupList = (StringList) busWithSelect.getSelectDataList(SELECT_ATTR_LIABLE_GROUP);
			StringList strRFAPartNameList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_PART_NAME);
			StringList strRFAVendorNameList = (StringList) busWithSelect.getSelectDataList(SELECT_RFA_VENDOR_NAME);
			
			if (null != strNameList && strNameList.size() > 0)
				strRFAName = (String) strNameList.get(0);
			if (null != strStateList && strStateList.size() > 0)
				strState = (String) strStateList.get(0);
			if (null != strRFABusProcessList && strRFABusProcessList.size() > 0)
				strRFABusProcess = (String) strRFABusProcessList.get(0);
			if (null != strRFAEventTypeList && strRFAEventTypeList.size() > 0)
				strRFAEventType = (String) strRFAEventTypeList.get(0);
			if (null != strRFASubTypeList && strRFASubTypeList.size() > 0)
				strRFASubType = (String) strRFASubTypeList.get(0);
			if (null != strRFAPFDList && strRFAPFDList.size() > 0)
				strRFAPFD = (String) strRFAPFDList.get(0);
			if (null != strRFAPartTypeList && strRFAPartTypeList.size() > 0)
				strRFAPartType = (String) strRFAPartTypeList.get(0);
			if (null != strRFAOccurenceTypeList && strRFAOccurenceTypeList.size() > 0)
				strRFAOccurenceType = (String) strRFAOccurenceTypeList.get(0);
			if (null != strRFASubProcessList && strRFASubProcessList.size() > 0)
				strRFASubProcess = (String) strRFASubProcessList.get(0);
			if (null != strRFAEventLocationList && strRFAEventLocationList.size() > 0)
				strRFAEventLocation = (String) strRFAEventLocationList.get(0);
			if (null != strRFAoriginatedList && strRFAoriginatedList.size() > 0)
				strRFAOriginated = (String) strRFAoriginatedList.get(0);
			if (null != strRFALCDateList && strRFALCDateList.size() > 0)
				strRFALCDate = (String) strRFALCDateList.get(0);
			if (null != strRFASeverityList && strRFASeverityList.size() > 0)
				strRFASeverity = (String) strRFASeverityList.get(0);
			if (null != strRFAEventImpactList && strRFAEventImpactList.size() > 0)
				strRFAEventImpact = (String) strRFAEventImpactList.get(0);
			if (null != strRFAIPTIDList && strRFAIPTIDList.size() > 0)
				strRFAIPTID = (String) strRFAIPTIDList.get(0);
			if (null != strRFALiableGroupList && strRFALiableGroupList.size() > 0)
				strRFALiableGroup = (String) strRFALiableGroupList.get(0);
			
			boolean add = true;
			if (STATE_CANCEL.equals(strState) || STATE_CLOSE.equals(strState))
				add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedLifecycleState))
				if (strSelectedLifecycleState.indexOf(strState) == -1)
					add = false;
			if (add && UIUtil.isNullOrEmpty(strRFAName))
				add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedBusinessProcess))
				if (UIUtil.isNullOrEmpty(strRFABusProcess) || strSelectedBusinessProcess.indexOf(strRFABusProcess) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedEventType))
				if (UIUtil.isNullOrEmpty(strRFAEventType) || strSelectedEventType.indexOf(strRFAEventType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedSubType))
				if (UIUtil.isNullOrEmpty(strRFASubType) || strSelectedSubType.indexOf(strRFASubType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedPFD))
				if (UIUtil.isNullOrEmpty(strRFAPFD) || strSelectedPFD.indexOf(strRFAPFD) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedPartType))
				if (UIUtil.isNullOrEmpty(strRFAPartType) || strSelectedPartType.indexOf(strRFAPartType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedOccurrenceType))
				if (UIUtil.isNullOrEmpty(strRFAOccurenceType) || strSelectedOccurrenceType.indexOf(strRFAOccurenceType) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedEventLocationOID))
				if (UIUtil.isNullOrEmpty(strRFAEventLocation) || strSelectedEventLocationOID.indexOf(strRFAEventLocation) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedSubProcess))
				if (UIUtil.isNullOrEmpty(strRFASubProcess) || strSelectedSubProcess.indexOf(strRFASubProcess) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedSeverity))
				if (UIUtil.isNullOrEmpty(strRFASeverity) || strSelectedSeverity.indexOf(strRFASeverity) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedEventImpact))
				if (UIUtil.isNullOrEmpty(strRFAEventImpact) || strSelectedEventImpact.indexOf(strRFAEventImpact) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedIPTID))
				if (UIUtil.isNullOrEmpty(strRFAIPTID) || strSelectedIPTID.indexOf(strRFAIPTID) == -1)
					add = false;
			if (add && !UIUtil.isNullOrEmpty(strSelectedLiableGroup))
				if (UIUtil.isNullOrEmpty(strRFALiableGroup) || strSelectedLiableGroup.indexOf(strRFALiableGroup) == -1)
					add = false;
			
			if (add && !UIUtil.isNullOrEmpty(strSelectedPartNameOID))
			{
				StringList SelectedPartNameSL = FrameworkUtil.split(strSelectedPartName, "|");
				if(null==SelectedPartNameSL || SelectedPartNameSL.size()==0)
					SelectedPartNameSL = FrameworkUtil.split(strSelectedPartName, ",");
				
				if (null != strRFAPartNameList && strRFAPartNameList.size() > 0)
				{
					strRFAPartNameList.retainAll(SelectedPartNameSL);
					if(strRFAPartNameList.size()==0)
						add = false;
				}else{
					add = false;
				}
			}
			if (add && !UIUtil.isNullOrEmpty(strSelectedVendorNameOID))
			{ 
				StringList SelectedVendorNameSL = FrameworkUtil.split(strSelectedVendorName, "|");
				if(null==SelectedVendorNameSL || SelectedVendorNameSL.size()==0)
				SelectedVendorNameSL = FrameworkUtil.split(strSelectedVendorName, ",");
				
				if (null != strRFAVendorNameList && strRFAVendorNameList.size() > 0)
				{
					strRFAVendorNameList.retainAll(SelectedVendorNameSL);
					if(strRFAVendorNameList.size()==0)
						add = false;
				}else{
					add = false;
				}
				
			}
			
			if (add && (null!=FROM_DATE && null!=TO_DATE))
			{
				Date RFAOriginated = new Date(strRFAOriginated);
				if(RFAOriginated.before(FROM_DATE) || RFAOriginated.after(TO_DATE))
					add = false;
			}
			if (add && (null!=FROM_LC_DATE && null!=TO_LC_DATE))
			{
				if(!UIUtil.isNullOrEmpty(strRFALCDate))
				{
					Date RFALCDate = new Date(strRFALCDate);
					if(RFALCDate.before(FROM_LC_DATE) || RFALCDate.after(TO_LC_DATE))
						add = false;
				}else{
					add = false;
				}
			}
			
			if (add)
				TARGET_RFA_NAME_LIST.add(strRFAName);
		}
		System.out.println("RFA List is selected");	
		if (TARGET_RFA_NAME_LIST.size() > 0) {

			sbSearchCriteria.append("temp query bus \"" + TYPE_PWC_RFA_ISSUE + "\" ");

			for (int j = 0; j < TARGET_RFA_NAME_LIST.size(); j++) {
				String strRFAName = (String) TARGET_RFA_NAME_LIST.get(j);
				sbSearchCriteria.append(strRFAName);

				if (j != TARGET_RFA_NAME_LIST.size() - 1)
					sbSearchCriteria.append(",");
			}

			sbSearchCriteria.append(" -");
		}

		strSearchCriteria = sbSearchCriteria.toString();

		if (strSearchCriteria.equals(EMPTY_STRING) && null != models && models.size() > 0) {
			String strModelId = (String) models.get(0);
			strSearchCriteria = "print bus " + strModelId + "select name";
		}
		if (strSearchCriteria.equals(EMPTY_STRING))
		{
			strSearchCriteria = "print bus Model GENERAL \"\" select name";
		}

		System.out.println("--strSearchCriteria--in active RFA report--->" + strSearchCriteria);

		return strSearchCriteria;
	}

	@SuppressWarnings("static-access")
	public static String format(String... s) {
		try {
			final String language = s[0];
			@SuppressWarnings("serial")
			Map<String, String> map = new HashMap<String, String>() {
				{
					put(PropertyUtil.getSchemaProperty("attribute_PWC_RFALiableGroup"),
					        i18nNow.getAttributeI18NString(PropertyUtil.getSchemaProperty("attribute_PWC_RFALiableGroup"), language));
					put(PropertyUtil.getSchemaProperty("attribute_PWC_IPTID"),
					        i18nNow.getAttributeI18NString(PropertyUtil.getSchemaProperty("attribute_PWC_IPTID"), language));
					put(PropertyUtil.getSchemaProperty("attribute_PWC_RFAEventType"),
					        UINavigatorUtil.getI18nString("pwcComponents.Form.Label.EventLocation", "emxComponentsStringResource", language));
					put(PropertyUtil.getSchemaProperty("attribute_PWC_InvestigationStatus"),
					        i18nNow.getAttributeI18NString(PropertyUtil.getSchemaProperty("attribute_PWC_InvestigationStatus"), language));
					put("current", UINavigatorUtil.getI18nString("pwcRFAMetrics.OpenDRReport.LifecycleState", "emxMetricsStringResource", language));
				}
			};

			return s[1].format(s[1], map.get(s[2]), map.get(s[3]));

		} catch (Exception e) {
			return EMPTY_STRING;
		}
	}
	private void setFromToDate(String strPeriod, String strDateUnit, String strDateType)
	{
		Calendar cal =  Calendar.getInstance();
		if(strDateType.equalsIgnoreCase("creationDate"))
		{
			TO_DATE = cal.getTime();
		}
		if(strDateType.equalsIgnoreCase("LCDate"))
		{
			TO_LC_DATE = cal.getTime();
		}
		int period = Integer.parseInt(strPeriod);
		if(!UIUtil.isNullOrEmpty(strDateUnit))
		{
			if(strDateUnit.equalsIgnoreCase("M"))
				cal.add(cal.MONTH, -period);
			if(strDateUnit.equalsIgnoreCase("Y"))
				cal.add(cal.YEAR, -period);
			if(strDateUnit.equalsIgnoreCase("Q"))
				cal.add(cal.MONTH, -(3*period));
			if(strDateUnit.equalsIgnoreCase("W"))
				cal.add(cal.DATE, -(7*period));
			
			if(strDateType.equalsIgnoreCase("creationDate"))
			{
				FROM_DATE = cal.getTime();
			}
			if(strDateType.equalsIgnoreCase("LCDate"))
			{
				FROM_LC_DATE = cal.getTime();
			}
			
		}
		cal.setTime(new Date());
	}
}
