package com.ds.pwc.early_detection.calculation;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.Vector;

import matrix.db.Context;
import matrix.util.StringList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionConstants;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionException;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionRFAData;
import com.ds.pwc.early_detection.PWCRFAEarlyDetectionUtil;
import com.ds.pwc.early_detection.implementations.PWCRFAEarlyDetectionDefectData;
import com.ds.pwc.early_detection.interfaces.IPWCRFAEarlyDetectionCalculator;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;

public class PWCRFAEarlyDetectionFrequencyCalculator implements IPWCRFAEarlyDetectionCalculator {

	private static final Logger LOG = Logger.getLogger("PWCRFAEarlyDetectionFrequencyCalculator");
	private Context context ;
	
	
	/**
	 * The function is to calculate WiQi for Part, Engine and Combined
	 * 
	 * @param context
	 * @param hMap
	 *            HashMap
	 * @return - Object
	 * @throws Exception
	 *             when problems occurred
	 */
	public Object calculate(HashMap hMap){
		LOG.debug("Start of PWCRFAEarlyDetectionFrequencyCalculator: calculate");
		double WiQi = 0.0;
		String strRFAId = "";
		String strEventDate = "";
		String strAttrEventDate = PropertyUtil.getSchemaProperty(context,"attribute_PWC_RFAEventDate");
		Document documentCriticalLimit;
		int iYearLimitValue = 0;
		String strLimitMXDate  = "";
		Context context = (Context)hMap.get("context");
		Map mapFields = new HashMap(); 
		String strDefectTypeMatch = "";
		try {
			documentCriticalLimit = PWCRFAEarlyDetectionUtil.loadRuleDocument("CriticalLimitRules.xml");
			NodeList CLList = documentCriticalLimit.getElementsByTagName("YEAR");
			iYearLimitValue = (Integer.parseInt(CLList.item(0).getTextContent().trim()));
	        TimeZone tz 				= TimeZone.getTimeZone(context.getSession().getTimezone());
	        double dbMilisecondsOffset	= (double)(-1)*tz.getRawOffset();
	        double clientTZOffset 		= (new Double(dbMilisecondsOffset/(1000*60*60))).doubleValue();
			SimpleDateFormat mxDateFormat 	=new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(),context.getLocale());	

	
			Calendar calReturn = Calendar.getInstance();
			Date today = calReturn.getTime();
			calReturn.add(Calendar.YEAR, -iYearLimitValue);
			
			Date limitYear = calReturn.getTime();
			strLimitMXDate 	= mxDateFormat.format(limitYear);

			try {
				strLimitMXDate = eMatrixDateFormat.getFormattedDisplayDate(strLimitMXDate,clientTZOffset,context.getLocale());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			} catch (PWCRFAEarlyDetectionException e) {
			e.printStackTrace();
		}
		try {
			String strattrEventDate = PropertyUtil.getSchemaProperty(context,"attribute_PWC_RFAEventDate");
			//Getting values from  Map
			NodeList similarityRuleList = (NodeList)hMap.get("similarityRuleList");
			String strFrom = (String)hMap.get("from");
			Map mapDefectAttr = (Map)hMap.get("mapDefectAttr");
			String strEngineCoef = (String)(mapDefectAttr.get(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT));
			String strPartCoef = (String)(mapDefectAttr.get(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT));
			boolean strSymptomandCondition = (Boolean)mapDefectAttr.get("SymptomAndCondition");
			mapFields.put(PWCConstants.ATTRIBUTE_PART_SERIAL_NUMBER,mapDefectAttr.get(PWCConstants.ATTRIBUTE_PART_SERIAL_NUMBER));
			mapFields.put(PWCConstants.ATTRIBUTE_PART_QTY_DEF,mapDefectAttr.get(PWCConstants.ATTRIBUTE_PART_QTY_DEF));
			mapFields.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT,mapDefectAttr.get(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT));
			mapFields.put(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT,mapDefectAttr.get(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT));
			PWCRFAEarlyDetectionRFAData rfaData = (PWCRFAEarlyDetectionRFAData)hMap.get("rfaData");
			strRFAId = rfaData.getRFAObjId();
			DomainObject dObjRFA =  DomainObject.newInstance(context,strRFAId);
			String strEventDateClause = new StringBuffer("to[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_DEFECT).append("].from.attribute[").append(strAttrEventDate).append("]").toString();		
			strEventDate = dObjRFA.getAttributeValue(context,strattrEventDate);
			PWCRFAEarlyDetectionDefectData defect = (PWCRFAEarlyDetectionDefectData)hMap.get("defect");
			Map mCombinedMatchMap = new HashMap();
			Map mEngineMatchMap = new HashMap();
			Map mW1PartMatchMap = new HashMap();
			Map mW2PartMatchMap = new HashMap();
			Map mW2PartNoMatchMap = new HashMap();
			// Reading the xml content
			for (int k = 0; k < similarityRuleList.getLength(); k++) {
				String strBlankCheck = "";
				// Getting value of Wi, attributes to be matched and attributes not to be matched to build Whereclause
				Element elem = (Element) similarityRuleList.item(k);
				String strWiname = elem.getAttribute("name");
				double strWivalue = Double.parseDouble(elem.getAttribute("value"));
				
				// Getting value of attributes to be matched to build Whereclause
				NodeList matchList = elem.getElementsByTagName("MATCH");
				Element matchElem = (Element) matchList.item(0);
				String matchValue = matchElem.getAttribute("value");

				// Getting value of attributes to be conditionally matched
				NodeList orMatchList = elem.getElementsByTagName("CONDITIONALMATCH");
				
				Element orMatchElem = (Element) orMatchList.item(0);
				String orMatchValue = orMatchElem.getAttribute("value");


				// Getting value of attributes not to be matched to build Whereclause
				NodeList noMatchList = elem.getElementsByTagName("NOMATCH");
				Element noMatchElem = (Element) noMatchList.item(0);
				String noMatchValue = noMatchElem.getAttribute("value");
				NodeList freqList = elem.getElementsByTagName("FREQUENCY");
				Element freqElem = (Element) freqList.item(0);
				String freqValue = freqElem.getAttribute("value");

				StringBuilder whereClause = new StringBuilder();
				StringTokenizer strTokensmatch = new StringTokenizer(matchValue, ",");
				StringTokenizer strTokensnomatch = new StringTokenizer(noMatchValue, ",");
				// Building where clause using xml tag criteria of mathing and non matching attributes
				if(orMatchValue!=  null && !orMatchValue.equals("") ){
					StringTokenizer strTokensormatch = new StringTokenizer(orMatchValue, ",");
					while (strTokensormatch.hasMoreTokens()) {
					String tempormatchEC = (String) PropertyUtil.getSchemaProperty(context,strTokensormatch.nextToken());
					String tempormatchESy = (String) PropertyUtil.getSchemaProperty(context,strTokensormatch.nextToken());
					if((mapDefectAttr.get(tempormatchESy).equals(""))&& (mapDefectAttr.get(tempormatchEC).equals(""))){
						strBlankCheck = PWCRFAEarlyDetectionConstants.STR_EMPTY;
						
					}
					//Here variables are incorrect, tempormatchEC is actually used for Engine Symptom and tempormatchESy is used for Engine Condition
					String strMacthEC = (String)mapDefectAttr.get(tempormatchEC);
					String strMacthESy = (String)mapDefectAttr.get(tempormatchESy);
					if(strWiname.equals("W1") && strFrom.equals("combined")){
							if(strSymptomandCondition || (!UIUtil.isNullOrEmpty(strMacthEC) && UIUtil.isNullOrEmpty(strMacthESy) )){
							mCombinedMatchMap.put(tempormatchEC, mapDefectAttr.get(tempormatchEC));
							}
							else{
							mCombinedMatchMap.put(tempormatchESy, mapDefectAttr.get(tempormatchESy));
								}
							defect.setW1CombinedMatch(mCombinedMatchMap);
							strDefectTypeMatch = "Combined";
					}
						if(strWiname.equals("W1") && strFrom.equals("engine")){

							if(strSymptomandCondition|| (!UIUtil.isNullOrEmpty(strMacthEC) && UIUtil.isNullOrEmpty(strMacthESy) )){
							mEngineMatchMap.put(tempormatchEC, mapDefectAttr.get(tempormatchEC));
							}
							else{
							mEngineMatchMap.put(tempormatchESy, mapDefectAttr.get(tempormatchESy));
								}	
							defect.setW1EngineMatch(mEngineMatchMap);
							strDefectTypeMatch = "Engine";
				}
		
					if(strSymptomandCondition|| (!UIUtil.isNullOrEmpty(strMacthEC) && UIUtil.isNullOrEmpty(strMacthESy) )){
						whereClause.append("(attribute["+ tempormatchEC+ "]"+ " == "+ "\""+ mapDefectAttr.get(tempormatchEC) + "\") && ");
					
					}
					else{
						whereClause.append("(attribute["+ tempormatchESy+ "]"+ " == "+ "\""+ mapDefectAttr.get(tempormatchESy) + "\") && ");				
					}
					//whereClause.append("(attribute["+ tempormatchEC+ "]"+ " == "+ "\""+ mapDefectAttr.get(tempormatchEC) + "\") && (attribute["+ tempormatchESy+ "]"+ " == "+ "\""+ mapDefectAttr.get(tempormatchESy) + "\") && ");
				}
	
				}
				while (strTokensmatch.hasMoreTokens()) {
					String tempmatchToken = (String) PropertyUtil.getSchemaProperty(context,strTokensmatch.nextToken());
					if((mapDefectAttr.get(tempmatchToken).equals("")) || (mapDefectAttr.get(tempmatchToken).equals(PWCRFAEarlyDetectionConstants.STR_PART_EMPTY))){
						strBlankCheck = PWCRFAEarlyDetectionConstants.STR_EMPTY;
						
					}				
						if(strWiname.equals("W1") && strFrom.equals("combined")){
							mCombinedMatchMap.put(tempmatchToken, mapDefectAttr.get(tempmatchToken));
							defect.setW1CombinedMatch(mCombinedMatchMap);
							strDefectTypeMatch = "Combined";
						}
						if(strWiname.equals("W1") && strFrom.equals("engine")){
							mEngineMatchMap.put(tempmatchToken, mapDefectAttr.get(tempmatchToken));
							defect.setW1EngineMatch(mEngineMatchMap);
							strDefectTypeMatch = "Engine";
						}
						if(strWiname.equals("W1") && strFrom.equals("part")){
							mW1PartMatchMap.put(tempmatchToken, mapDefectAttr.get(tempmatchToken));
							defect.setW1PartMatch(mW1PartMatchMap);
							strDefectTypeMatch = "Part";
						}
						if(strWiname.equals("W2") && strFrom.equals("part")){
							mW2PartMatchMap.put(tempmatchToken, mapDefectAttr.get(tempmatchToken));
							defect.setW2PartMatch(mW2PartMatchMap);
							strDefectTypeMatch = "Part";
						}
					
					whereClause.append("attribute["	+ tempmatchToken+ "]"+ " == "+ "\""	+ mapDefectAttr.get(tempmatchToken) + "\" && ");
				}
				
				while (strTokensnomatch.hasMoreTokens()) {
					String tempnomatchToken = (String) PropertyUtil.getSchemaProperty(context,strTokensnomatch.nextToken());
					if((mapDefectAttr.get(tempnomatchToken).equals("")) || (mapDefectAttr.get(tempnomatchToken).equals(PWCRFAEarlyDetectionConstants.STR_PART_EMPTY))){
						strBlankCheck = PWCRFAEarlyDetectionConstants.STR_EMPTY;
						
					}	
					whereClause.append("attribute["+ tempnomatchToken+ "]"+ " != "+ "\""+ mapDefectAttr.get(tempnomatchToken) + "\" && ");

						if(strWiname.equals("W1") && strFrom.equals("combined")){
							mCombinedMatchMap.put(tempnomatchToken, mapDefectAttr.get(tempnomatchToken));
							defect.setW1CombinedMatch(mCombinedMatchMap);
							strDefectTypeMatch = "Combined";
						}
						if(strWiname.equals("W1") && strFrom.equals("engine")){
							mEngineMatchMap.put(tempnomatchToken, mapDefectAttr.get(tempnomatchToken));
							defect.setW1EngineMatch(mEngineMatchMap);
							strDefectTypeMatch = "Engine";
					}
						if(strWiname.equals("W1") && strFrom.equals("part")){
							mW1PartMatchMap.put(tempnomatchToken, mapDefectAttr.get(tempnomatchToken));
							defect.setW1PartMatch(mW1PartMatchMap);
							strDefectTypeMatch = "Part";
						}
						if(strWiname.equals("W2") && strFrom.equals("part")){
							mW2PartNoMatchMap.put(tempnomatchToken, mapDefectAttr.get(tempnomatchToken));
							defect.setW2PartNoMatch(mW2PartNoMatchMap);
							strDefectTypeMatch = "Part";
					}				

				}


				mapFields.put("BlankChk",strBlankCheck);
				mapFields.put("ruleName",strWiname);
				//whereClause.append("((").append(strEventDateClause).append("!=\"\" && ").append(strEventDateClause).append("<=\"").append(strEventDate).append("\") || (").append(strEventDateClause).append("==\"\" && to[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_DEFECT).append("].from.originated").append("<=\"").append(strEventDate).append("\")) && ");
				whereClause.append("current != ").append(PWCRFAEarlyDetectionConstants.STATE_POLICY_ED_DEFECT).append(" && ").append(strEventDateClause).append("<=\"").append(strEventDate).append("\" && ");
				whereClause.append("((").append(strEventDateClause).append("!=\"\" && ").append(strEventDateClause).append(">\"").append(strLimitMXDate).append("\") || (").append(strEventDateClause).append("==\"\" && to[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_DEFECT).append("].from.originated").append(">\"").append(strLimitMXDate).append("\"))");
				whereClause.append("&& attribute[").append(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_DEFECT_TYPE).append("] == \"").append(strDefectTypeMatch).append("\"");
				WiQi = getRelatedDefectObjectFrequency(context, whereClause,freqValue, strWivalue,defect , WiQi,mapFields);
			
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("Exception in PWCRFAEarlyDetectionFrequencyCalculator : calculate : "	+ e.getMessage());
		}
		LOG.debug("End of PWCRFAEarlyDetectionFrequencyCalculator : calculate");
		return WiQi;
	}	
		
	/**
	 * The function is to calculate WiQi for Part, Engine and Combined
	 * 
	 * @param context
	 * @param whereClause
	 *            StringBuilder
	 * @param freqValue
	 *            String
	 * @param strWivalue
	 *            double
	 * @param WiQi
	 *            double
	 * @param attrMap
	 *            DomainObject
	 * @return - double
	 * @throws Exception
	 *             when problems occurred
	 */
	public static double getRelatedDefectObjectFrequency(Context context,
			StringBuilder whereClause, String freqValue, double strWivalue,
			PWCRFAEarlyDetectionDefectData defect, double WiQi,Map mapFields) throws Exception {
		LOG.debug("Start of PWCRFAEarlyDetectionFrequencyCalculator : getRelatedDefectObjectFrequency");
		StringList strlistObjectSelect = new StringList();
		strlistObjectSelect.add(new StringBuilder("to[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_DEFECT).append("].from.name").toString());
		strlistObjectSelect.add(DomainObject.SELECT_NAME);
		strlistObjectSelect.add("attribute["+PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT+"]");
		strlistObjectSelect.add("attribute["+PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT+"]");
		strlistObjectSelect.add(PWCRFAEarlyDetectionConstants.STR_ATT_QTY_DEF);
		strlistObjectSelect.add(PWCRFAEarlyDetectionConstants.STR_ATT_PART_SERIAL_NUMBER);

		
		int iQSize = 0;
		int iTj = 1;
	    StringBuilder RFANameList = new StringBuilder();
	    StringBuilder tempNameList = new StringBuilder();
	    String strDefectType = defect.getStrEDDefectType()	;
		String strDefectObject = defect.getStrObjectId();
		String strRuleName = (String)mapFields.get("ruleName");
		DomainObject dObj = DomainObject.newInstance(context,strDefectObject);
		Map defectMap = dObj.getInfo(context,strlistObjectSelect);
		try {
			// Finding objects of Defect type that satisfies the where clause from Similarity rules
	    	String strFreqAttribute =  PropertyUtil.getSchemaProperty(context,freqValue); 
	    	String strRFADetails =  freqValue+"Info";
	    	String strRFADetailsAttribute =  PropertyUtil.getSchemaProperty(context,strRFADetails);
	    	MapList FrequencyList = new MapList();
	    	
	    	String strBlankCheck = (String)mapFields.get("BlankChk");
	    	if(!strBlankCheck.equals(PWCRFAEarlyDetectionConstants.STR_EMPTY)){
			FrequencyList = DomainObject.findObjects(context,PWCRFAEarlyDetectionConstants.TYPE_DEFECT_DEVIATION, PWCCommonUtil.getVaultPattern(context), whereClause.toString(),
					strlistObjectSelect);
			

			

			//Getting the size of objectlist found and setting it in attribute 
	    	//Changes made to modify formula starts
	    	if(strRuleName.equals("W1") && !defectMap.isEmpty()){
	    		String strCurrentEMCoeff = (String)mapFields.get(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT);
	    		String strCurrentPNCoeff = (String)mapFields.get(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT);
			    String strPartSerialNum = (String)mapFields.get(PWCConstants.ATTRIBUTE_PART_SERIAL_NUMBER);
			    String strPartQtyDef = (String)mapFields.get(PWCConstants.ATTRIBUTE_PART_QTY_DEF);
	        	if(!UIUtil.isNullOrEmpty(strCurrentEMCoeff)){
	        	defectMap.put("attribute["+PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT+"]", mapFields.get(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT));
	        	}
	        	if(!UIUtil.isNullOrEmpty(strCurrentPNCoeff)){
	    		defectMap.put("attribute["+PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT+"]", mapFields.get(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT));
	        	}
	        	if(!UIUtil.isNullOrEmpty(strPartSerialNum)){
	        	defectMap.put("attribute["+PWCConstants.ATTRIBUTE_PART_SERIAL_NUMBER+"]", strPartSerialNum);
	        	}
	        	if(!UIUtil.isNullOrEmpty(strPartQtyDef)){
	    		defectMap.put("attribute["+PWCConstants.ATTRIBUTE_PART_QTY_DEF+"]", strPartQtyDef);
	        	}
	    		FrequencyList.add(defectMap);
	    	}
	    	
	    	iQSize = FrequencyList.size();

	
 
		    for(int nCnt=0;nCnt<iQSize; nCnt++)
		    {
		    	Map tempMap = (Map)FrequencyList.get(nCnt);
		    	RFANameList = RFANameList.append((String)tempMap.get(new StringBuilder("to[").append(PWCRFAEarlyDetectionConstants.RELATIONSHIP_ED_DEFECT).append("].from.name").toString())).append(",");
		    }	 

		    if(iQSize > 0)
		    {
	    	RFANameList.deleteCharAt(RFANameList.length()-1);
		    }

	    	
	    	if((strDefectType.equals("Part") || strDefectType.equals("Combined"))&& strFreqAttribute.equals(PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_FREQ_PART_Q2)){
	    		String strTempCount = dObj.getAttributeValue(context,PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_FREQ_PART_Q1 );
	    		if(null!=strTempCount && !strTempCount.equals(""))
	    		{
	    		int resetCount =Integer.parseInt(strTempCount); 
				String resetRFA =dObj.getAttributeValue(context,PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_FREQ_PART_Q1_INFO ); 
				resetCount = resetCount +iQSize;
				tempNameList.append(RFANameList).append(",").append(resetRFA);
				dObj.setAttributeValue(context, PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_FREQ_PART_Q1, Integer.toString(resetCount));
				dObj.setAttributeValue(context, PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_FREQ_PART_Q1_INFO, tempNameList.toString());
	    		}
	    	}

			dObj.setAttributeValue(context, strFreqAttribute, Integer.toString(iQSize));
			dObj.setAttributeValue(context, strRFADetailsAttribute, RFANameList.toString());
	    	}
	    	else{
				dObj.setAttributeValue(context, strFreqAttribute, Integer.toString(iQSize));
				dObj.setAttributeValue(context, strRFADetailsAttribute, RFANameList.toString());
	    		
	    	}
			// Calculating WiQi using formula

		    for(int nCnt=0;nCnt<FrequencyList.size(); nCnt++)
		    {
		    	Map tempMap = (Map)FrequencyList.get(nCnt);
		    	String strEngineCoeff = (String) tempMap.get("attribute["+PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_EM_COEFFICIENT+"]");
		    	String strPartCoeff = (String) tempMap.get("attribute["+PWCRFAEarlyDetectionConstants.ATTRIBUTE_ED_PN_COEFFICIENT+"]");
		    	if(UIUtil.isNullOrEmpty(strEngineCoeff)){
		    		strEngineCoeff = "1";
		    	}
		    	if(UIUtil.isNullOrEmpty(strPartCoeff)){
		    		strPartCoeff = "1";
		    	}
		    	if(strDefectType.equals("Engine") || strDefectType.equals("Combined")){
		    	WiQi = WiQi + (strWivalue* Integer.parseInt(strEngineCoeff));
		    	
		    	}
		    	else if(strDefectType.equals("Part")){

			    //	String strPartSerialNum = (String)mapFields.get(PWCConstants.ATTRIBUTE_PART_SERIAL_NUMBER);
			    //	String strPartQtyDef = (String)mapFields.get(PWCConstants.ATTRIBUTE_PART_QTY_DEF);
		    	String strPartQtyDef = (String)tempMap.get(PWCRFAEarlyDetectionConstants.STR_ATT_QTY_DEF);
		    	String strPartSerialNum = (String)tempMap.get(PWCRFAEarlyDetectionConstants.STR_ATT_PART_SERIAL_NUMBER);   	
			    	if(!UIUtil.isNullOrEmpty(strPartSerialNum)){
			    		StringTokenizer strSerialNumTokens =  new StringTokenizer(strPartSerialNum," ,;-");
			    		iTj = strSerialNumTokens.countTokens();
			    	}
			    	else if(!UIUtil.isNullOrEmpty(strPartQtyDef)){
			    		iTj = Integer.parseInt(strPartQtyDef) ;
			    	}
			    	else{
			    		iTj = 1;
			    	}
			    	//Chages done for ED enhancement		
			    	WiQi = WiQi + (strWivalue* Integer.parseInt(strPartCoeff) * iTj);
			    	

		    	}
		    	}
	    	//Changes made to modify formula ends

			   //WiQi = WiQi + WiQiTemp;
		    	//System.out.println("WiQi--"+WiQi);
		    
		  //  WiQi = WiQi + (strWivalue * iQSize);
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Exception in PWCRFAEarlyDetectionFrequencyCalculator : getRelatedDefectObjectFrequency "	+ ex.getMessage());
		}
		LOG.debug("End of PWCRFAEarlyDetectionFrequencyCalculator : getRelatedDefectObjectFrequency");

		return WiQi;
	}

	
}
