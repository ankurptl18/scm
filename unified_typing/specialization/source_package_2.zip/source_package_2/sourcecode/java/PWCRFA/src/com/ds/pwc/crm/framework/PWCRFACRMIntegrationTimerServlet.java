package com.ds.pwc.crm.framework;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import matrix.util.Timer;
import matrix.util.TimerClient;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.servlet.FrameworkServlet;

public class PWCRFACRMIntegrationTimerServlet extends FrameworkServlet implements TimerClient
{
	private static final long serialVersionUID = 1L;
	private static final Logger _LOGGER	= Logger.getLogger(PWCRFACRMIntegrationTimerServlet.class.getName());

	private PWCRFACRMIntegrationManager objIntegrationManager = null;

	@Override
	public void timerStarted(Timer arg0)
	{		

	}

	public void init(ServletConfig config) throws ServletException 
	{	
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationTimerServlet.class.getName()+"::init()");

		super.init(config);	

		try
		{
			_LOGGER.debug("# Initilising the 'IntegrationManger'");
			objIntegrationManager = new PWCRFACRMIntegrationManager();
			timerExpired(null);

		}catch(Exception e)
		{
			_LOGGER.error("Failed to initialize the CRM Integration Process due to this issue "+ PWCRFACRMIntegrationUtil.getStackTrace(e));
			throw new ServletException("Failed to initialize the CRM Integration Process") ;
		}		

		_LOGGER.debug("End of "+PWCRFACRMIntegrationTimerServlet.class.getName()+"::init()");
	}

	/* 
	 * Timer to restart the service in 31st December
	 */
	private void startTimers()throws Exception
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationTimerServlet.class.getName()+"::startTimers()");
		
		try
		{
			int iSleepInterval = 5;
			String sSleepInterval = PWCRFACRMIntegrationUtil.getPropertyValue("PWCCRMIntegration.RFA.ProcessExecution.TimeInterval");
			if(!UIUtil.isNullOrEmpty(sSleepInterval))
			{
				iSleepInterval = Integer.parseInt(sSleepInterval);
			}	
			long iNextTime 			= (iSleepInterval * 60) * 1000; //Min in Millisecond
			int NEXT_RUN 			= ((int) Math.ceil(iNextTime/1000));	
	
			matrix.util.Timer timer = new matrix.util.Timer(this, NEXT_RUN);		            
			timer.start();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}

		_LOGGER.debug("End of "+PWCRFACRMIntegrationTimerServlet.class.getName()+"::startTimers()");
	}

	public synchronized void timerExpired(matrix.util.Timer timer) 
	{			
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationTimerServlet.class.getName()+"::timerExpired()");

		try 
		{
			_LOGGER.debug("# Starting the integration process");
			objIntegrationManager.initiateProcessing();

			startTimers();			
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			_LOGGER.error("Failed to initialize the CRM Integration Process due to this error: "+ PWCRFACRMIntegrationUtil.getStackTrace(ex));
		}		

		_LOGGER.debug("End of "+PWCRFACRMIntegrationTimerServlet.class.getName()+"::timerExpired()");
	}	


	public void destroy()
	{
		_LOGGER.debug("Start of "+PWCRFACRMIntegrationTimerServlet.class.getName()+"::destroy()");

		_LOGGER.debug("# Disconnecting the Integration User");
		objIntegrationManager.disconnectCRMIntegrationUser();

		_LOGGER.debug("End of "+PWCRFACRMIntegrationTimerServlet.class.getName()+"::destroy()");
	}	

}
