package com.ds.pwc.early_detection;

public enum PWCRFAEarlyDetectionCriticalimitEnum 
{
	VSM("attribute_PWC_RFAEDCombinedDefectSeverity,attribute_PWC_RFAEDEngineDefectSeverity,attribute_PWC_RFAEDPartDefectSeverity"),
	Msc("attribute_PWC_RFAEDCombinedDefectSeverity"),
	Mse("attribute_PWC_RFAEDEngineDefectSeverity"),
	Msp("attribute_PWC_RFAEDPartDefectSeverity"),
	Mrc("attribute_PWC_RFAEDCombinedDefectRecurrence"),
	Mre("attribute_PWC_RFAEDEngineDefectRecurrence"),
	Mrp("attribute_PWC_RFAEDPartDefectRecurrence"),
	Mcc("attribute_PWC_RFAEDCombinedDefectSR"),
	Mce("attribute_PWC_RFAEDEngineDefectSR"),
	Mcp("attribute_PWC_RFAEDPartDefectSR"),
	Mkc("attribute_PWC_RFAEDCombinedDefectRL"),
	Mke("attribute_PWC_RFAEDEngineDefectRL"),
	Mkp("attribute_PWC_RFAEDPartDefectRL"),
	Mpc("attribute_PWC_RFAEDCombinedDefectSRL"),
	Mpe("attribute_PWC_RFAEDEngineDefectSRL"),
	Mpp("attribute_PWC_RFAEDPartDefectSRL");

	private String attrName = null;	

	private PWCRFAEarlyDetectionCriticalimitEnum(String attrName)
	{
		this.attrName = attrName;
	}

	public String getAttributeName()
	{
		return attrName;
	}
}
