package com.ds.pwc.ipp.mos;

import java.io.Serializable;
import java.util.HashMap;

import javax.activation.DataHandler;

import com.matrixone.apps.domain.DomainConstants;

/**
 * A class for response object of 'retrieveOperationPDF' web service.
 * 
 * @author ZWE
 *
 */
public class PWCIPPRetrieveOperationPDFResponse implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5804967108453579538L;
	
	private String operationname = DomainConstants.EMPTY_STRING;
	private String classificationInfo = DomainConstants.EMPTY_STRING;
	private HashMap<String,DataHandler> fileMap; 
	
	public void setclassificationInfo(String classificationInfo) 
	{
		this.classificationInfo = classificationInfo;
	}

	public String getclassificationInfo() 
	{
		return classificationInfo;
	}

	public void setFileMap(HashMap<String,DataHandler> fileMap) 
	{
		this.fileMap = fileMap;
	}

	public HashMap<String,DataHandler> getFileMap() 
	{
		return fileMap;
	}

	public void setOperationname(String operationname) 
	{
		this.operationname = operationname;
	}

	public String getOperationname() 
	{
		return operationname;
	}
	
}
