
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PAennr" type="{urn:sap-com:document:sap:rfc:functions}char12" minOccurs="0"/>
 *         &lt;element name="PControlList" type="{urn:sap-com:document:sap:rfc:functions}char1"/>
 *         &lt;element name="PDatuv" type="{urn:sap-com:document:sap:rfc:functions}date10" minOccurs="0"/>
 *         &lt;element name="PMatnr" type="{urn:sap-com:document:sap:rfc:functions}char18" minOccurs="0"/>
 *         &lt;element name="PPlnal" type="{urn:sap-com:document:sap:rfc:functions}char2"/>
 *         &lt;element name="PPlnnr" type="{urn:sap-com:document:sap:rfc:functions}char8"/>
 *         &lt;element name="PPlnty" type="{urn:sap-com:document:sap:rfc:functions}char1"/>
 *         &lt;element name="PRevlv" type="{urn:sap-com:document:sap:rfc:functions}char2" minOccurs="0"/>
 *         &lt;element name="PRtgOperMods" type="{urn:sap-com:document:sap:soap:functions:mc-style}TableOfZmippsoper"/>
 *         &lt;element name="PStatusNotappOnly" type="{urn:sap-com:document:sap:rfc:functions}char1" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pAennr",
    "pControlList",
    "pDatuv",
    "pMatnr",
    "pPlnal",
    "pPlnnr",
    "pPlnty",
    "pRevlv",
    "pRtgOperMods",
    "pStatusNotappOnly"
})
@XmlRootElement(name = "ZMosGetRtgOperMods")
public class ZMosGetRtgOperMods {

    @XmlElement(name = "PAennr")
    protected String pAennr;
    @XmlElement(name = "PControlList", required = true)
    protected String pControlList;
    @XmlElement(name = "PDatuv")
    protected String pDatuv;
    @XmlElement(name = "PMatnr")
    protected String pMatnr;
    @XmlElement(name = "PPlnal", required = true)
    protected String pPlnal;
    @XmlElement(name = "PPlnnr", required = true)
    protected String pPlnnr;
    @XmlElement(name = "PPlnty", required = true)
    protected String pPlnty;
    @XmlElement(name = "PRevlv")
    protected String pRevlv;
    @XmlElement(name = "PRtgOperMods", required = true)
    protected TableOfZmippsoper pRtgOperMods;
    @XmlElement(name = "PStatusNotappOnly")
    protected String pStatusNotappOnly;

    /**
     * Gets the value of the pAennr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPAennr() {
        return pAennr;
    }

    /**
     * Sets the value of the pAennr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPAennr(String value) {
        this.pAennr = value;
    }

    /**
     * Gets the value of the pControlList property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPControlList() {
        return pControlList;
    }

    /**
     * Sets the value of the pControlList property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPControlList(String value) {
        this.pControlList = value;
    }

    /**
     * Gets the value of the pDatuv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDatuv() {
        return pDatuv;
    }

    /**
     * Sets the value of the pDatuv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDatuv(String value) {
        this.pDatuv = value;
    }

    /**
     * Gets the value of the pMatnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPMatnr() {
        return pMatnr;
    }

    /**
     * Sets the value of the pMatnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPMatnr(String value) {
        this.pMatnr = value;
    }

    /**
     * Gets the value of the pPlnal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPPlnal() {
        return pPlnal;
    }

    /**
     * Sets the value of the pPlnal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPPlnal(String value) {
        this.pPlnal = value;
    }

    /**
     * Gets the value of the pPlnnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPPlnnr() {
        return pPlnnr;
    }

    /**
     * Sets the value of the pPlnnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPPlnnr(String value) {
        this.pPlnnr = value;
    }

    /**
     * Gets the value of the pPlnty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPPlnty() {
        return pPlnty;
    }

    /**
     * Sets the value of the pPlnty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPPlnty(String value) {
        this.pPlnty = value;
    }

    /**
     * Gets the value of the pRevlv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRevlv() {
        return pRevlv;
    }

    /**
     * Sets the value of the pRevlv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRevlv(String value) {
        this.pRevlv = value;
    }

    /**
     * Gets the value of the pRtgOperMods property.
     * 
     * @return
     *     possible object is
     *     {@link TableOfZmippsoper }
     *     
     */
    public TableOfZmippsoper getPRtgOperMods() {
        return pRtgOperMods;
    }

    /**
     * Sets the value of the pRtgOperMods property.
     * 
     * @param value
     *     allowed object is
     *     {@link TableOfZmippsoper }
     *     
     */
    public void setPRtgOperMods(TableOfZmippsoper value) {
        this.pRtgOperMods = value;
    }

    /**
     * Gets the value of the pStatusNotappOnly property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPStatusNotappOnly() {
        return pStatusNotappOnly;
    }

    /**
     * Sets the value of the pStatusNotappOnly property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPStatusNotappOnly(String value) {
        this.pStatusNotappOnly = value;
    }

}
