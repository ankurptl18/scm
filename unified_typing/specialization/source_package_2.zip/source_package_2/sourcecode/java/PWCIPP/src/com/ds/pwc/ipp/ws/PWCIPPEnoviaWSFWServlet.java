package com.ds.pwc.ipp.ws;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * This is a servlet which is responsible for starting the Enovia web-service 
 * QueueManager process as well as for resubmitting the interrupted Queue objects (due to server down) on the server startup
 * 
 * @author ZWE
 *
 */
public class PWCIPPEnoviaWSFWServlet extends HttpServlet 
{

	private static final Logger _LOGGER = Logger.getLogger(PWCIPPWSQueueManager.class.getName());

	public void init(ServletConfig servletconfig)
	throws ServletException
	{
		super.init(servletconfig);
		_LOGGER.debug("Start of "+PWCIPPEnoviaWSFWServlet.class.getName()+" :: init()");

		try 
		{
			// start the Queue Manager process on server start up
			PWCIPPWSQueueManager.start();

		} catch (Exception e) 
		{
			_LOGGER.error("Failed to start QueueManager Process due to this issue "+ PWCIPPWSUtil.getStackTrace(e));
		}

		_LOGGER.debug("End of "+PWCIPPEnoviaWSFWServlet.class.getName()+" :: init()");
	}

	public void doGet(HttpServletRequest httpservletrequest, HttpServletResponse httpservletresponse)
	throws ServletException, IOException
	{

		doPost(httpservletrequest, httpservletresponse);
	}

	public void doPost(HttpServletRequest httpservletrequest, HttpServletResponse httpservletresponse)
	throws ServletException, IOException
	{

	}

}
