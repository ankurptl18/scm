package com.ds.pwc.ipp.save;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.matrixone.apps.domain.DomainConstants;

public class PWCIPPXMLSourceTarget
{
	private String m_Name;
	private String m_Revision;
	
	public PWCIPPXMLSourceTarget()
	{
		m_Name = m_Revision = DomainConstants.EMPTY_STRING;
	}
	
	@XmlAttribute(name="name")
	public String getName()
	{
		return m_Name;
	}

	public void setName( String iName )
	{
		m_Name = iName;
	}
	
	@XmlAttribute(name="revision")
	public String getRevision()
	{
		return m_Revision;
	}

	public void setRevision( String iRevision )
	{
		m_Revision = iRevision;
	}

	public void validate()
	{
		StringBuilder st_msg = new StringBuilder( "invalid operation detail definition" );
		
		boolean b_throw = false;
		if( null == m_Name || 0 == m_Name.length() )
		{
			st_msg.append( " - missing name" );
			b_throw = true;
		}
		
		if( null == m_Revision || 0 == m_Revision.length() )
		{
			st_msg.append( " - missing revision" );
			b_throw = true;
		}
		
		if( b_throw )
		{
			throw new IllegalArgumentException( st_msg.toString() );
		}
	}
}
