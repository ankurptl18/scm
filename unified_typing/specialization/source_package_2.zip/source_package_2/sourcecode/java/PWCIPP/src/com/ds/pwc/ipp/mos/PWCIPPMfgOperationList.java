package com.ds.pwc.ipp.mos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.RelationshipType;
import matrix.util.SelectList;
import matrix.util.StringList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.ds.pwc.ipp.ws.PWCIPPWSUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;

/**
 * This class represents the "Manufacturing Operation List' (MOL) object from the database. 
 * It hosts all the operation methods and current state of this object. 
 * 
 * @author ZWE
 *
 */
public class PWCIPPMfgOperationList extends PWCIPPBasicMfgOperationList
{
	private static final Logger _LOGGER  = Logger.getLogger(PWCIPPMfgOperationList.class.getName());
	private static final String FSEPERATOR = System.getProperty("file.separator");

	private Context CONTEXT;

	StringBuilder SELECTABLE_ATTRIBUTE_PWC_MOS_CHANGE_NUMBER = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_MOS_CHANGE_NUMBER).append("]");
	StringBuilder SELECTABLE_ATTRIBUTE_PWC_IPP_CLASSIFICATION_FLAG = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_CLASSIFICATION_FLAG).append("]");
	StringBuilder SELECTABLE_ATTRIBUTE_PWC_IPP_GROUP = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_GROUP).append("]");
	StringBuilder SELECTABLE_ATTRIBUTE_PWC_IPP_GROUP_COUNTER = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_GROUP_COUNTER).append("]");
	StringBuilder SELECTABLE_ATTRIBUTE_PWC_IPP_MATERIAL_NUMBER = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_MATERIAL_NUMBER).append("]");
	StringBuilder SELECTABLE_ATTRIBUTE_PWC_IPP_MATERIAL_SECURITY_FLAG = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_MATERIAL_SECURITY_FLAG).append("]");
	StringBuilder SELECTABLE_ATTRIBUTE_PWC_IPP_TASK_TYPE = new StringBuilder().append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_TASK_TYPE).append("]");

	private StringBuilder sbObjName = new StringBuilder();
	private String sObjectId = DomainConstants.EMPTY_STRING;
	private String sRevision = DomainConstants.EMPTY_STRING;
	private DomainObject domObj = null;
	private ArrayList<PWCIPPMfgOperation> alOpList = new ArrayList<PWCIPPMfgOperation>();   
	//this member will be set at the time of WS-call to xml message conversion
	private String sOperationType;

	private String sBadgeId = DomainConstants.EMPTY_STRING;
	private String sSAPTimeStamp = DomainConstants.EMPTY_STRING;
	private String sLocation = DomainConstants.EMPTY_STRING;

	private String _sSAPMaterialNumber = DomainConstants.EMPTY_STRING;
	private String _sSAPMaterialSecurityFlag = DomainConstants.EMPTY_STRING;
	private String _sSAPRevLevel = DomainConstants.EMPTY_STRING;
	private String _sSAPClassificationFlag = DomainConstants.EMPTY_STRING;

	/**
	 * This constructor reads the passed in mpMOLInfo map and initializes all member variables 
	 * and then reads alMOSInfo list to initialize no. of MfgOp object beans and adds them to lsMfgOps 
	 * 
	 * @param mpMOLInfo - contains property/attribute infromation of 'this' MOL object. It will contain below keys,
	 * 						1. Group*
	 * 						2. TaskType*
	 *						3. GroupCounter*
	 *						4. ChangeNo*
	 *						5. RevLevel
	 * 						6. Material
	 * 						7. ClassificationFlag
	 * 						8. MaterialSecurityFlag 
	 * @param alMOSInfo - contains the infoMaps for each operations under 'this' MOL. Each map in the list will have below keys,
	 * 						1. DRFName* (this will be the actual NAME of an MfgOp)
	 * 						2. OperationNo*
	 *						3. SequenceNo*
	 *						4. ESAFlag
	 *						5. DRFVersion* (this will be the actual REVISION of an MfgOp)
	 * 						6. Description
	 */

	public PWCIPPMfgOperationList ()
	{

	}
	/**
	 * This constructor
	 * @param context
	 * @param mpMOLInfo
	 * @param alMOSInfo
	 */
	public PWCIPPMfgOperationList (Context context, PWCIPPMfgOperationList molInfo, PWCIPPMfgOperation[] arMOSInfo)
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" constructor with map and maplist objects as parameters");

		CONTEXT = context;
		//this.putOperationList(arMOSInfo);		
		this.alOpList = new ArrayList<PWCIPPMfgOperation>(Arrays.asList(arMOSInfo));
		this.alOpList.removeAll(null);
		sbObjName.append(_sGroup).append("_").append(_sTaskType).append("_").append(_sGroupCounter);

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" constructor with map and maplist objects as parameter");
	}

	public void putContext(Context context)
	{
		CONTEXT = context;
	}

	/**
	 * This constructor reads the passed in XML DOM object and initializes all member variables 
	 * and then reads alMOSInfo list to initialize no. of MfgOp object beans and adds them to lsMfgOps 
	 * 
	 */
	@SuppressWarnings("unchecked")
	public PWCIPPMfgOperationList(Context context, Document doc) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" constructor with DOM object parameter");

		doc.getDocumentElement().normalize();
		CONTEXT = context;
		Map<String,String> mAttr = new HashMap<String,String>();
		Map<String,String> mpMOLInfo = new HashMap<String,String>();
		Element eleRoot = doc.getDocumentElement();
		String sListName	=(String)eleRoot.getAttribute("name");

		if(!UIUtil.isNullOrEmpty(sListName)) 
		{
			ArrayList<PWCIPPMfgOperation> alMOSInfo = new ArrayList();
			NodeList nlTemp = null;

			sbObjName.setLength(0);
			sbObjName.append(sListName);
			Element elTransactionInfo = (Element)eleRoot.getFirstChild();
			mpMOLInfo = PWCIPPWSUtil.buildMapFromXML(elTransactionInfo);
			mAttr = PWCIPPWSUtil.buildMapFromXML(elTransactionInfo.getNextSibling());
			mpMOLInfo.putAll(mAttr);
			nlTemp = doc.getElementsByTagName("MfgOps");
			if(nlTemp != null && nlTemp.getLength() > 0)
			{
				Element eleOp = (Element)nlTemp.item(0);
				NodeList opChilds = eleOp.getElementsByTagName("Operation");
				
				if (null != opChilds) 
				{
				int iSize = opChilds.getLength();
				Element eleChildOp = null;
				PWCIPPMfgOperation mfgOp = null;

				for(int i=0;i<iSize;i++)
				{
					eleChildOp = (Element)opChilds.item(i);
					mfgOp = new PWCIPPMfgOperation(context, eleChildOp);
					alMOSInfo.add(mfgOp);
				}
			}
			}
			loadData(mpMOLInfo, alMOSInfo);

		} else  
		{
			throw new Exception("Failed to initialize MOL object as the MOL name is null or empty");
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" constructor with DOM object parameter");
	}

	/****************************************************** operations ************************************************/	
	/**
	 * This is to load Data into alOpList
	 * @param mpMOLInfo
	 * @param alMOSInfo
	 */
	public void loadData(Map<String,String> mpMOLInfo, ArrayList<PWCIPPMfgOperation> alMOSInfo)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : loadData()");
		if (mpMOLInfo != null) 
		{
			_sGroup				=(String)mpMOLInfo.get("Group");
			_sTaskType			=(String)mpMOLInfo.get("TaskType");
			_sGroupCounter		=(String)mpMOLInfo.get("GroupCounter");
			_sSAPChangeNumber	=(String)mpMOLInfo.get("SAPChangeNumber");
			if (!UIUtil.isNullOrEmpty(_sSAPChangeNumber)	&& !UIUtil.isNullOrEmpty(_sTaskType) && !UIUtil.isNullOrEmpty(_sGroupCounter) && !UIUtil.isNullOrEmpty(_sSAPChangeNumber)) 
			{
				_sSAPMaterialNumber 		= (String) mpMOLInfo.get("SAPMaterialNumber");
				_sSAPClassificationFlag	= (String) mpMOLInfo.get("SAPClassificationFlag");
				_sSAPMaterialSecurityFlag	= (String) mpMOLInfo.get("SAPMaterialSecurityFlag");
				_sSAPRevLevel				=(String)mpMOLInfo.get("SAPRevLevel");

				// loading transaction info
				sBadgeId				=(String)mpMOLInfo.get("UserId");
				sSAPTimeStamp			=(String)mpMOLInfo.get("TimeStamp");
				sLocation				=(String)mpMOLInfo.get("Location");

				this.putOperationList(alMOSInfo);

			} else {
				throw new Exception("Failed to initialize MOL object as one of the mandatory field is null or empty");
			}
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : loadData()");
	}


	/**
	 * buildAttributesMapForXML
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map buildAttributesMapForXML(String sElementName)
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : buildAttributesMapForXML()");

		Map mReturn = new HashMap();

		if("Attributes".equals(sElementName))
		{
			mReturn.put("SAPMaterialNumber", _sSAPMaterialNumber);
			mReturn.put("SAPClassificationFlag", _sSAPClassificationFlag);
			mReturn.put("SAPMaterialSecurityFlag", _sSAPMaterialSecurityFlag);
			mReturn.put("SAPRevLevel", _sSAPRevLevel);
			mReturn.put("Group", _sGroup);
			mReturn.put("TaskType", _sTaskType);
			mReturn.put("GroupCounter", _sGroupCounter);
			mReturn.put("SAPChangeNumber", _sSAPChangeNumber);
		} else
		{
			mReturn.put("UserId", sBadgeId);
			mReturn.put("TimeStamp", sSAPTimeStamp);
			mReturn.put("Location", sLocation);
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : buildAttributesMapForXML()");
		return mReturn;
	}


	/**
	 * This API creates the object of type 'PWC_MOS List' in database (name=Group_TaskType_GroupCounter, revision=SAPChange#) 
	 * followed by the creation of all the 'PWC_MOS Part' objects and then connects all these objects to 'PWC_MOS List' object. 
	 * Also updates all the attribute values for all objects. 
	 * 
	 * @return - objectId, of the created MOL
	 * @throws Exception, if operation fails
	 */
	public String create(boolean bIsFromSAP) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : create()");
		if(!checkIfExists())
		{
			try 
			{
				domObj = DomainObject.newInstance(CONTEXT);
				sRevision = readRevision();
				domObj.createObject(CONTEXT, PWCConstants.TYPE_MOS_LIST, sbObjName.toString(), sRevision, PWCConstants.POLICY_MOS_LIST, CONTEXT.getVault().getName());
				sObjectId = domObj.getObjectId(CONTEXT);
				domObj.setAttributeValue(CONTEXT,PWCConstants.ATTRIBUTE_PWC_MOS_CHANGE_NUMBER,_sSAPChangeNumber);
			} 
			catch (Exception e) 
			{
				//throw new Exception(new StringBuilder("Faild to create/revise MOL object due to below error :  \n\n").append(e).toString(), e);
				throw new Exception(new StringBuilder(EnoviaResourceBundle.getProperty(CONTEXT, "emxEngineeringCentralStringResource", CONTEXT.getLocale(), "pwcEngineeringCentral.PWCIPPMfgOperationList.CreateOrReviseOfFailedAlert")).append(PWCConstants.STR_NEWLINE).append(e).toString(), e);
							
			}

			putFromSAPFlag(bIsFromSAP);
			update();
			addMfgOperations(alOpList,bIsFromSAP);

		}
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : create()");
		return sObjectId;
	}

	/**
	 * This API get's next revision of MOL object.
	 * If no revision exist then return default revision.
	 */
	@SuppressWarnings("unchecked")
	private String readRevision()throws Exception
	{
		_LOGGER.debug("START of "+PWCIPPMfgOperationList.class.getName()+" : readRevision()");

		MapList mapList = readAllRevisions(sbObjName.toString());
		String sNewRevision = DomainConstants.EMPTY_STRING;

		if(mapList.isEmpty())
		{
			sNewRevision = domObj.getDefaultRevision(CONTEXT,PWCConstants.POLICY_MOS_LIST);
		} 
		else
		{		
			int  iSize = mapList.size();
			Map mpObjectDetailsMap = null;
			Map<Integer, String> mpRevMapping = new HashMap<Integer, String>();

			for(int index = 0; index < iSize; index++)
			{	
				mpObjectDetailsMap = (Map)mapList.get(index);
				mpRevMapping.put(Integer.valueOf((String)mpObjectDetailsMap.get(DomainObject.SELECT_REVISION)), (String)mpObjectDetailsMap.get(DomainObject.SELECT_ID));
			}
			List<Integer> lRevisionSet = new  ArrayList<Integer>(mpRevMapping.keySet());
			Collections.sort(lRevisionSet);
			String strLatestRevisionObjectId = mpRevMapping.get(lRevisionSet.get(lRevisionSet.size()-1));
			domObj = DomainObject.newInstance(CONTEXT,strLatestRevisionObjectId);
			sNewRevision = domObj.getNextSequence(CONTEXT);
		}
		_LOGGER.debug("END of "+PWCIPPMfgOperationList.class.getName()+" : readRevision()");

		return sNewRevision;
	}
	/**
	 * This API creates a new revision of 'this' object
	 * 
	 * @return - bean of new revision
	 * @throws Exception, if operation fails
	 */
	public void revise() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : revise()");
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			String sNextSeq =  domObj.getNextSequence(CONTEXT);			
			BusinessObject reviseObject = domObj.revise(CONTEXT, sNextSeq, PWCCommonUtil.getVaultPattern(CONTEXT));
			sObjectId = reviseObject.getObjectId();			
			domObj.setId(sObjectId);
			update(domObj);
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : revise()");		
	}


	/**
	 * This returns info map for this Object
	 * @param context
	 * @param sObjectId
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked"})
	public Map<String,String> readMOSListData(Context context, String sObjectId)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : getMOSListData()");
		domObj = DomainObject.newInstance(context, sObjectId);
		StringList slSelectList = new StringList();
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_MOS_CHANGE_NUMBER.toString());
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_IPP_CLASSIFICATION_FLAG.toString());
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_IPP_GROUP.toString());
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_IPP_GROUP_COUNTER.toString());
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_IPP_MATERIAL_NUMBER.toString());
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_IPP_MATERIAL_SECURITY_FLAG.toString());
		slSelectList.add(SELECTABLE_ATTRIBUTE_PWC_IPP_TASK_TYPE.toString());

		Map<String,String> mMosListDataMap = domObj.getInfo(context, slSelectList);
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : getMOSListData()");
		return mMosListDataMap;
	}

	/**
	 * This API finds the given object based on (name=Group_TaskType_GroupCounter, revision=SAPChange#) 
	 * and loads all its properties/attributes into 'this' bean object
	 * 
	 * @return, objectId of 'this' object
	 * @throws Exception, if operation fails
	 */
	public String loadFromDB() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : loadFromDB()");
		if(checkIfExists())
		{
			Map<String,String> mMosListDataMap =  readMOSListData(CONTEXT, sObjectId);
			loadDataToBean(mMosListDataMap);
			loadConnectedPart();
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : loadFromDB()");
		return sObjectId;
	}	
	/**
	 * This loads data to bean
	 * @param mMosListDataMap
	 */
	public void loadListBeanFromDB(Context context,String ObjectId) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : loadListBeanFromDB()");

		Map<String, String> mReturnMap = new HashMap<String, String>();
		this.sObjectId = ObjectId;
		mReturnMap = readMOSListData(context, ObjectId);
		loadDataToBean(mReturnMap);

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : loadListBeanFromDB()");		
	}    
	/**
	 * This loads data to bean
	 * @param mMosListDataMap
	 */
	private void loadDataToBean(Map<String,String> mMosListDataMap )
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : loadDataToBean()");

		setSAPChangeNumber((String)mMosListDataMap.get(SELECTABLE_ATTRIBUTE_PWC_MOS_CHANGE_NUMBER.toString()));
		setSAPClassificationFlag((String)mMosListDataMap.get(SELECTABLE_ATTRIBUTE_PWC_IPP_CLASSIFICATION_FLAG.toString()));
		setGroup((String)mMosListDataMap.get(SELECTABLE_ATTRIBUTE_PWC_IPP_GROUP.toString()));
		setGroupCounter((String)mMosListDataMap.get(SELECTABLE_ATTRIBUTE_PWC_IPP_GROUP_COUNTER.toString()));	
		setSAPMaterialNumber((String)mMosListDataMap.get(SELECTABLE_ATTRIBUTE_PWC_IPP_MATERIAL_NUMBER.toString()));
		setSAPMaterialSecurityFlag((String)mMosListDataMap.get(SELECTABLE_ATTRIBUTE_PWC_IPP_MATERIAL_SECURITY_FLAG.toString()));		
		setTaskType((String)mMosListDataMap.get(SELECTABLE_ATTRIBUTE_PWC_IPP_TASK_TYPE.toString()));
		sbObjName.setLength(0);
		sbObjName.append(_sGroup).append("_").append(_sTaskType).append("_").append(_sGroupCounter);

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : loadDataToBean()");
	}
	/**
	 * This connect Part with Operations
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private void loadConnectedPart()throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : loadConnectedPart()");

		PWCIPPMfgOperation operationObject = null;
		HashMap hmOperationDetailsMap = new HashMap();
		alOpList.clear();

		StringList slSelectableList = PWCIPPMfgOperation.buildSelectables();
		slSelectableList.add(DomainConstants.SELECT_NAME);
		slSelectableList.add(DomainConstants.SELECT_REVISION);
		slSelectableList.add(DomainConstants.SELECT_ID);

		domObj = DomainObject.newInstance(CONTEXT, sObjectId);
		MapList connectedObjList = domObj.getRelatedObjects(CONTEXT, PWCConstants.REL_MOS_ITEM, PWCConstants.TYPE_MOS_PART, slSelectableList, null, true, false, (short)1, "", "", (int)0);

		for(int index=0; index<connectedObjList.size(); index++)
		{
			hmOperationDetailsMap = (HashMap)connectedObjList.get(index);
			operationObject = new PWCIPPMfgOperation();
			operationObject.loadDataToBean(hmOperationDetailsMap);
			alOpList.add(operationObject);
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : loadConnectedPart()");
	}

	/**
	 * This API checks if given object (name=Group_TaskType_GroupCounter, revision=SAPChange#) exists in the database
	 * 
	 * @return - true, if it does else false
	 * @throws Exception, if operation fails
	 */
	@SuppressWarnings("unchecked")
	public boolean checkIfExists() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : checkIfExists()");

		boolean bDoesObjectExists = false;
		try 
		{
			MapList mlMapList = readObjectWithGivenSAPNumber(sbObjName.toString(), _sSAPChangeNumber);
			if(!mlMapList.isEmpty())
			{
				Map mObjectDetailsMap = (Map)mlMapList.get(0);
				sObjectId = (String)mObjectDetailsMap.get(DomainObject.SELECT_ID);
				sRevision = (String)mObjectDetailsMap.get(DomainObject.SELECT_REVISION);
				bDoesObjectExists = true;
			}

		} catch (Exception e) 
		{
			//throw new Exception(new StringBuilder("Faild to check if MOL object already exists due to below error :  \n\n").append(e).toString(), e);
			throw new Exception(new StringBuilder(EnoviaResourceBundle.getProperty(CONTEXT, "emxEngineeringCentralStringResource", CONTEXT.getLocale(), "pwcEngineeringCentral.PWCIPPMfgOperationList.CheckMOLObjectExistFailedAlert")).append(PWCConstants.STR_NEWLINE).append(e).toString(), e);

		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : checkIfExists()");
		return bDoesObjectExists;		
	}

	@SuppressWarnings("unchecked")
	public MapList readObjectWithGivenSAPNumber(String sListName, String _sSAPChangeNumber)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : getObjectWithGivenSAPNumber()");
		MapList mapList = new MapList();
		String strWhereExpression = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_MOS_CHANGE_NUMBER).append("].value == \"").append(_sSAPChangeNumber).append("\"").toString();

		SelectList resultSelects = new SelectList(2);
		resultSelects.add(DomainObject.SELECT_ID);	    
		resultSelects.add(DomainObject.SELECT_REVISION);    

		mapList =  DomainObject.findObjects(CONTEXT,
				PWCConstants.TYPE_MOS_LIST,
				sbObjName.toString(),
				DomainConstants.QUERY_WILDCARD,
				DomainConstants.QUERY_WILDCARD,
				PWCCommonUtil.getVaultPattern(CONTEXT),
				strWhereExpression,
				false,
				resultSelects);
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : getObjectWithGivenSAPNumber()");
		return mapList;
	}

	@SuppressWarnings("unchecked")
	public MapList readAllRevisions(String sListName)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : readAllRevisions()");

		MapList mlAllRevisions = new MapList();
		try 
		{
			String strChangeNumberSelectable = new StringBuilder("attribute[").append(PWCConstants.ATTRIBUTE_PWC_MOS_CHANGE_NUMBER).append("]").toString();

			SelectList slResultSelects = new SelectList(4);
			slResultSelects.add(DomainObject.SELECT_ID);
			slResultSelects.add(DomainObject.SELECT_NAME);
			slResultSelects.add(DomainObject.SELECT_REVISION);
			slResultSelects.add(strChangeNumberSelectable);

			mlAllRevisions =  DomainObject.findObjects(CONTEXT,
					PWCConstants.TYPE_MOS_LIST,
					sListName,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					PWCCommonUtil.getVaultPattern(CONTEXT),
					null,
					false,
					slResultSelects);

		} catch (Exception e) 
		{
			throw new Exception(new StringBuilder("Faild to retrieve revisions of the MOL '"+sListName+"' due to below error :  \n\n").append(e).toString(), e);
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : readAllRevisions()");
		return mlAllRevisions;
	}


	/**
	 * This API overrides all the properties/attributes of 'this' object on 
	 * the corresponding 'PWC_MOS List' object in DB in order to bring it to uptodate with SAP
	 * 
	 * @throws Exception, if operation fails
	 */
	public void update() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : update()");

		try 
		{
			if(checkIfExists())
			{
				domObj = DomainObject.newInstance(CONTEXT, sObjectId);
				update(domObj);
			}

		} catch (Exception e) 
		{
			//throw new Exception(new StringBuilder("Faild to update MOL object due to below error :  \n\n").append(e).toString(), e);
			throw new Exception(new StringBuilder(EnoviaResourceBundle.getProperty(CONTEXT, "emxEngineeringCentralStringResource", CONTEXT.getLocale(), "pwcEngineeringCentral.PWCIPPMfgOperationList.UpdateObjectMOLOfFailedAlert")).append(PWCConstants.STR_NEWLINE).append(e).toString(), e);

		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : update()");
	}
	/**
	 * This updates this Object
	 * @param domObj
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void update(DomainObject domObj) throws Exception
	{		
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : update() with List object as parameter");
		Map mAttributeMap = new HashMap();
		if(!UIUtil.isNullOrEmpty(_sSAPClassificationFlag))
			mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_IPP_CLASSIFICATION_FLAG,_sSAPClassificationFlag);
		if(!UIUtil.isNullOrEmpty(_sGroup))
			mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_IPP_GROUP,_sGroup);
		if(!UIUtil.isNullOrEmpty(_sGroupCounter))
			mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_IPP_GROUP_COUNTER,_sGroupCounter);
		if(!UIUtil.isNullOrEmpty(_sSAPMaterialNumber))
			mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_IPP_MATERIAL_NUMBER,_sSAPMaterialNumber);
		if(!UIUtil.isNullOrEmpty(_sSAPMaterialSecurityFlag))
			mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_IPP_MATERIAL_SECURITY_FLAG,_sSAPMaterialSecurityFlag);
		if(!UIUtil.isNullOrEmpty(_sTaskType))
			mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_IPP_TASK_TYPE,_sTaskType);
		if(!UIUtil.isNullOrEmpty(_sSAPRevLevel))
			mAttributeMap.put(PWCConstants.ATTRIBUTE_PWC_MOS_REVISION_LEVEL, _sSAPRevLevel);
		domObj.setAttributeValues(CONTEXT, mAttributeMap);
		
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : update() with List object as parameter");
	}


	/**
	 * This API returns the XML Element representing 'this' MfgOp
	 * 
	 * @return - Element object of DOM
	 * @throws Exception, if operation fails
	 */
	public Document toXML(Context context) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : toXML()");

		Document doc = null;
		try
		{
			DocumentBuilderFactory dFact = DocumentBuilderFactory.newInstance();
			DocumentBuilder build = dFact.newDocumentBuilder();
			doc = build.newDocument();
			Element root = doc.createElement("MOL");
			doc.appendChild(root);
			root.setAttribute("name",sbObjName.toString());

			// adding XSLT tag
			//ProcessingInstruction pi = PWCIPPWSUtil.getXSLTTag(context, doc); 
			//doc.insertBefore(pi, root);

			// adding "Processing Option" tag
			PWCIPPWSUtil.addElementInDocumentUnderRoot(doc,"TransactionInfo",buildAttributesMapForXML("TransactionInfo"));

			// "Attributes" element
			PWCIPPWSUtil.addElementInDocumentUnderRoot(doc,"Attributes",buildAttributesMapForXML("Attributes"));

			// adding Operations 
			buildMfgOpsElement(doc);
		} 
		catch(Exception e)
		{
			_LOGGER.error("Failed to get the xml representation of web service call");
			throw e;
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : toXML()");
		return doc;
	}

	/**
	 * This API returns the HTML message to notify user
	 * @param - enovia context object
	 * @return - String as HTML message
	 * @throws Exception, if operation fails
	 */
	public String toHTML(Context context) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : toHTML()");

		Document docMOLXml = toXML(context);

		String sHTMLMsg = PWCIPPWSUtil.generateHTMLMsg(context, docMOLXml);

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : toHTML()");
		return sHTMLMsg;
	}

	/**
	 * This method builds manufacturing operations tag in xml of MOL object
	 * @param doc : xml of MOL object
	 * @return void
	 * @throws Exception
	 */
	private void buildMfgOpsElement(Document doc) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : buildMfgOpsElement()");

		int iSize = alOpList.size();
		Element root = doc.getDocumentElement();
		Element eleMfgOps = doc.createElement("MfgOps");
		root.appendChild(eleMfgOps);

		try
		{
			PWCIPPMfgOperation Op;
			String sOpName = DomainConstants.EMPTY_STRING;
			for(int i=0;i<iSize;i++)
			{
				Op = alOpList.get(i);
				sOpName = Op.getDRFName();
				if (!"dummy".equalsIgnoreCase(sOpName)) 
				{
					Op.toXML(doc);
				}
			}
		} 
		catch(Exception e)
		{
			_LOGGER.debug("Exception in "+PWCIPPMfgOperationList.class.getName()+" : buildMfgOpsElement()");
			e.printStackTrace();
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : buildMfgOpsElement()");
	}

	/**
	 * This API creates and then adds the given list of MfgOps to 'this' MOL
	 * 
	 * @param alMOSInfo - contains the infoMaps for each operations to be added
	 * @throws Exception, if operation fails
	 */
	/*public void addMfgOperationsInList(PWCIPPMfgOperation[] arMOSInfo) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : addMfgOperationsInList()");

		//buildOperationList(arMOSInfo);
		addMfgOperations(this.alOpList);

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : addMfgOperationsInList()");
	}*/

	/**
	 * This API creates and then adds the given list of MfgOps to 'this' MOL
	 * 
	 * @param alMOSInfo - contains the infoMaps for each operations to be added
	 * @throws Exception, if operation fails
	 */
	public void addMfgOperations(ArrayList<PWCIPPMfgOperation> alMOSInfo, boolean bIsFromSAP) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : addMfgOperations()");

		if(checkIfExists() && !alMOSInfo.isEmpty())
		{	
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			StringList slConnectedParts = domObj.getInfoList(CONTEXT, new StringBuilder("from[").append(PWCConstants.REL_MOS_ITEM).append("].to.id").toString());

			int iSize = alMOSInfo.size();
			List<String> alToConnectPartIds= new ArrayList<String>();
			PWCIPPMfgOperation operationObj = null;
			String sMfgOperationId = null;
			for(int index=0; index < iSize; index++)
			{
				sMfgOperationId = null;
				operationObj = alMOSInfo.get(index);
				operationObj.putContext(CONTEXT);
				
				if(!operationObj.checkIfExists())
				{
					sMfgOperationId = operationObj.create(bIsFromSAP);	
				}					
				if(!UIUtil.isNullOrEmpty(sMfgOperationId) && !slConnectedParts.contains(sMfgOperationId) && !alToConnectPartIds.contains(sMfgOperationId))
				{
					alToConnectPartIds.add(sMfgOperationId);
				}
			}
			if(!alToConnectPartIds.isEmpty())
			{
				connectMfgOperations(alToConnectPartIds.toArray(new String[]{""}));

			// Applying the IP Classification to the MfgOps
				
				// code for applying the classification on the MfgOps
				HashMap programMap = new HashMap();
				programMap.put("operationIds", alToConnectPartIds);
				programMap.put("MOLId", sObjectId);
				
				String[] arg = JPO.packArgs(programMap);
				JPO.invoke(CONTEXT, "PWC_IPECCommon", new String [] {}, "classifyMfgOpsforIP", arg);
				

				// code for applying the classification on the MfgOps
				programMap = new HashMap();
				programMap.put("materialNumber",_sSAPMaterialNumber);
				programMap.put("operationIds", alToConnectPartIds);
				
				// Start of Modification for bug# BT0000000004058
				programMap.put("MOLId", sObjectId);
				// End of Modification for bug# BT0000000004058
				
				arg = JPO.packArgs(programMap);
				
				JPO.invoke(CONTEXT, "PWC_EXCCommon", new String [] {}, "classifyMfgOpsforExportControl", arg);
				
			}
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : addMfgOperations()");
	}

	/**
	 * This connects manufacturing Operations 	
	 * @param sMfgOperationId
	 */
	public void connectMfgOperation(String sMfgOperationId) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : connectMfgOperation()");

		try
		{
			DomainRelationship.connect(CONTEXT, sObjectId, PWCConstants.REL_MOS_ITEM, sMfgOperationId, false);
		} 
		catch(Exception e)
		{
			throw new Exception(new StringBuilder("Faild to connect Operation to MOL due to below error :  \n\n").append(e).toString(), e);
		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : connectMfgOperation()");
	}

	/**
	 * This connects manufacturing Operations 	
	 * @param sMfgOperationId
	 */
	public void connectMfgOperations(String[] sMfgOperationIds)throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : connectMfgOperation()");

		try
		{
			if(sMfgOperationIds.length > 0)
			{
				DomainRelationship.connect(CONTEXT, DomainObject.newInstance(CONTEXT,sObjectId), PWCConstants.REL_MOS_ITEM, true, sMfgOperationIds);
			}

		} catch(Exception e)
		{
			//throw new Exception(new StringBuilder("Faild to create one/more operations due to below error :  \n\n").append(e).toString(), e);
			throw new Exception(new StringBuilder(EnoviaResourceBundle.getProperty(CONTEXT, "emxEngineeringCentralStringResource", CONTEXT.getLocale(), "pwcEngineeringCentral.PWCIPPMfgOperationList.OneOrMoreOpertionsCreationFailedAlert")).append(PWCConstants.STR_NEWLINE).append(e).toString(), e);

		}

		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : connectMfgOperation()");
	}

	/**
	 * This disconnects manufacturing Operation from the list	
	 * @param sMfgOperationId : object id of the operation
	 */
	public void disconnectMfgOperation(String sMfgOperationId)
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : connectMfgOperation()");
		try
		{
			BusinessObject bo = new BusinessObject(sObjectId);
			bo.disconnect(CONTEXT, new RelationshipType(PWCConstants.REL_MOS_ITEM), true, new BusinessObject(sMfgOperationId));
		} 
		catch(Exception e)
		{
			_LOGGER.debug("Exception in "+PWCIPPMfgOperationList.class.getName()+" : connectMfgOperation()");
			e.printStackTrace();
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : connectMfgOperation()");
	}

	/**
	 * This API checks if the given MfgOps are connected to this MOL and if yes then disconnects them
	 * 
	 * @param alMOSInfo - contains the infoMaps for each operations to be removed 
	 * @throws Exception, if operation fails
	 */
	public void removeMfgOperations(ArrayList<PWCIPPMfgOperation> alMOSInfo) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : removeMfgOperations()");
		if(!alMOSInfo.isEmpty())
		{
			PWCIPPMfgOperation operationObj = null;
			int iSize = alMOSInfo.size(); 
			for(int index=0; index < iSize; index++)
			{
				operationObj = (PWCIPPMfgOperation)alMOSInfo.get(index);
				if(operationObj.checkIfConnectedToList(sObjectId))
				{
					disconnectMfgOperation(operationObj.readObjectId());
				}				
			}
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : removeMfgOperations()");
	}

	/**
	 * This API checks if the given MfgOps are connected to this MOL and if yes then updates them with the given info
	 * 
	 * @param alMOSInfo - contains the infoMaps for each operations to be updated
	 * @throws Exception, if operation fails
	 */
	public void updateMfgOperations(ArrayList<PWCIPPMfgOperation> alMOSInfo) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPMfgOperationList.class.getName()+" : updateMfgOperations()");
		if(!alMOSInfo.isEmpty())
		{
			PWCIPPMfgOperation operationObj = null;
			int iSize = alMOSInfo.size();
			for(int index=0; index < iSize; index++)
			{
				operationObj = (PWCIPPMfgOperation)alMOSInfo.get(index);
				if(operationObj.checkIfConnectedToList(sObjectId))
				{
					operationObj.update();
				}
			}
		}
		_LOGGER.debug("End of "+PWCIPPMfgOperationList.class.getName()+" : updateMfgOperations()");
	}
	/**
	 * It deletes 'this' object 
	 * 
	 * @throws Exception, if operation fails
	 */
	public void delete() throws Exception
	{
		if(checkIfExists())
		{
			domObj = DomainObject.newInstance(CONTEXT, sObjectId);
			removeMfgOperations(alOpList);
			domObj.deleteObject(CONTEXT);
		}
	}

	/**
	 * This API sets "FromSAPFlag" on List object if the list is coming from SAP
	 * 
	 * @throws Exception, if operation fails
	 */
	public void putFromSAPFlag(boolean bIsFromSAP) throws Exception
	{
		try 
		{
			if(checkIfExists())
			{
				domObj = DomainObject.newInstance(CONTEXT, sObjectId);
				domObj.setAttributeValue(CONTEXT,PWCConstants.ATTRIBUTE_PWC_IPP_FROMSAPFLAG,String.valueOf(bIsFromSAP));
			}

		} catch (Exception e) 
		{
			//throw new Exception(new StringBuilder("Faild to update 'FromSAPFlag' due to below error :  \n\n").append(e).toString(), e);
			throw new Exception(new StringBuilder(EnoviaResourceBundle.getProperty(CONTEXT, "emxEngineeringCentralStringResource", CONTEXT.getLocale(), "pwcEngineeringCentral.PWCIPPMfgOperationList.UpdateAttrFromSAPFlagOfFailedAlert")).append(PWCConstants.STR_NEWLINE).append(e).toString(), e);
		}
	}

	@SuppressWarnings("unchecked")
	public static PWCIPPMfgOperationList reviseLastRevision(Context context,String strSAPChangeNumer,MapList mapList, boolean bIsFromSAP)
		throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSUtil.class.getName()+"::reviseLastRevision()");

		PWCIPPMfgOperationList listObj = new PWCIPPMfgOperationList();
		listObj.putContext(context);
		try 
		{
			int  iSize = mapList.size();
			Map mpObjectDetailsMap = null;
			Map<Integer, String> mpRevMapping = new HashMap<Integer, String>();

			for(int index = 0; index < iSize; index++)
			{	
				mpObjectDetailsMap = (Map)mapList.get(index);
				mpRevMapping.put(Integer.valueOf((String)mpObjectDetailsMap.get(DomainObject.SELECT_REVISION)), (String)mpObjectDetailsMap.get(DomainObject.SELECT_ID));
			}
			List<Integer> lRevisionSet = new  ArrayList<Integer>(mpRevMapping.keySet());
			Collections.sort(lRevisionSet);
			String strLatestRevisionObjectId = mpRevMapping.get(lRevisionSet.get(lRevisionSet.size()-1));

			listObj.loadListBeanFromDB(context, strLatestRevisionObjectId);		
			listObj.revise();

			listObj.setSAPChangeNumber(strSAPChangeNumer);
			DomainObject domObj = new DomainObject(listObj.readObjectID());
			domObj.setAttributeValue(context, PWCConstants.ATTRIBUTE_PWC_MOS_CHANGE_NUMBER, strSAPChangeNumer);
			listObj.putFromSAPFlag(bIsFromSAP);

		} catch (Exception e) 
		{
			//throw new Exception(new StringBuilder("Faild to revise the MOL due to below error :  \n\n").append(e).toString(), e);
			throw new Exception(new StringBuilder(EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), "pwcEngineeringCentral.PWCIPPMfgOperationList.ReviseOfMOLFailedAlert")).append(PWCConstants.STR_NEWLINE).append(e).toString(), e);
		}

		_LOGGER.debug("End of "+PWCIPPWSUtil.class.getName()+"::reviseLastRevision()");
		return listObj;
	}

	/************************************************ accessors and mutators ******************************************/	

	public String readObjectID() 
	{
		return sObjectId;
	}

	public void putObjectID(String sObjectId) 
	{
		this.sObjectId = sObjectId;
	}

	public String readName()
	{
		return sbObjName.toString();
	}


	public String getSAPMaterialNumber() 
	{
		return _sSAPMaterialNumber;
	}

	public void setSAPMaterialNumber(String _sSAPMaterialNumber) 
	{
		this._sSAPMaterialNumber = _sSAPMaterialNumber;
	}


	public String getSAPMaterialSecurityFlag()
	{
		return _sSAPMaterialSecurityFlag;
	}

	public void setSAPMaterialSecurityFlag(String _sSAPMaterialSecurityFlag) 
	{
		this._sSAPMaterialSecurityFlag = _sSAPMaterialSecurityFlag;
	}


	public String getSAPRevLevel() 
	{
		return _sSAPRevLevel;
	}

	public void setSAPRevLevel(String _sSAPRevLevel) 
	{
		this._sSAPRevLevel = _sSAPRevLevel;
	}


	public String getSAPClassificationFlag() 
	{
		return _sSAPClassificationFlag;
	}

	public void setSAPClassificationFlag(String _sSAPClassificationFlag) 
	{
		this._sSAPClassificationFlag = _sSAPClassificationFlag;
	}

	public String readOperationType() 
	{
		return sOperationType;
	}

	public void putOperationType(String sOperationType) 
	{
		this.sOperationType = sOperationType;
	}

	public ArrayList <PWCIPPMfgOperation> readOperationList() {
		return alOpList;
	}

	public void putOperationList(ArrayList<PWCIPPMfgOperation> alMOSInfo) 
	{
		this.alOpList = alMOSInfo;
	}

	public void putOperationList(PWCIPPMfgOperation[] alOpList) 
	{
		PWCIPPMfgOperation op;
		for (int i = 0; i < alOpList.length; i++) 
		{
			op = alOpList[i];
			if (op != null) 
			{
				this.alOpList.add(op);
			}
		}
	}

	public void computeName()
	{
		sbObjName.append(_sGroup).append("_").append(_sTaskType).append("_").append(_sGroupCounter);
	}


	public String getBadgeId() 
	{
		return sBadgeId;
	}

	public void setBadgeId(String sBadgeId) 
	{
		this.sBadgeId = sBadgeId;
	}


	public String getSAPTimeStamp() 
	{
		return sSAPTimeStamp;
	}

	public void setSAPTimeStamp(String sSAPTimeStamp) 
	{
		this.sSAPTimeStamp = sSAPTimeStamp;
	}


	public String getLocation() 
	{
		return sLocation;
	}

	public void setLocation(String sLocation) 
	{
		this.sLocation = sLocation;
	}

}
