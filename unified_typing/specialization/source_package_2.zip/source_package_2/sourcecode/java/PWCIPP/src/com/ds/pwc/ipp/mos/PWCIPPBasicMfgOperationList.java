package com.ds.pwc.ipp.mos;

import com.matrixone.apps.domain.DomainConstants;

public class PWCIPPBasicMfgOperationList 
{

	protected String _sGroup = DomainConstants.EMPTY_STRING;
	protected String _sTaskType = DomainConstants.EMPTY_STRING;
	protected String _sGroupCounter = DomainConstants.EMPTY_STRING;
	protected String _sSAPChangeNumber = DomainConstants.EMPTY_STRING;

	public String getGroup() 
	{
		return _sGroup;
	}

	public void setGroup(String _sGroup) 
	{
		this._sGroup = _sGroup;
	}


	public String getTaskType() 
	{
		return _sTaskType;
	}

	public void setTaskType(String _sTaskType) 
	{
		this._sTaskType = _sTaskType;
	}


	public String getGroupCounter() 
	{
		return _sGroupCounter;
	}

	public void setGroupCounter(String _sGroupCounter) 
	{
		this._sGroupCounter = _sGroupCounter;
	}


	public String getSAPChangeNumber() 
	{
		return _sSAPChangeNumber;
	}

	public void setSAPChangeNumber(String _sSAPChangeNumber) 
	{
		this._sSAPChangeNumber = _sSAPChangeNumber;
	}


}
