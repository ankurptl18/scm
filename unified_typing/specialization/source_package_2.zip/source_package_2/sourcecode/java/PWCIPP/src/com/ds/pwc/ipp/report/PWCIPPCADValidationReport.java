package com.ds.pwc.ipp.report;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

/**
 * @author ZWE
 *
 */
@XmlRootElement(name="MfgOps")
@XmlSeeAlso(PWCIPPMfgOpCADValidationResult.class)
public class PWCIPPCADValidationReport 
{
	private List<PWCIPPMfgOpCADValidationResult> lsOperationResult = new ArrayList<PWCIPPMfgOpCADValidationResult>();

	@XmlElement(name="Operation")
	public List<PWCIPPMfgOpCADValidationResult> getLsOperationResult() 
	{
		return lsOperationResult;
	}
	public void setLsOperationResult
	(
			List<PWCIPPMfgOpCADValidationResult> lsOperationResult) {
		this.lsOperationResult = lsOperationResult;
	}
		
}
