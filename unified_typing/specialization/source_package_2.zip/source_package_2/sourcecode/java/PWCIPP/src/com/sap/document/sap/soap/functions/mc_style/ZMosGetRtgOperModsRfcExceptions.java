
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ZMosGetRtgOperMods.RfcExceptions.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ZMosGetRtgOperMods.RfcExceptions">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NoOpersFound"/>
 *     &lt;enumeration value="ChangeNumberMissing"/>
 *     &lt;enumeration value="ChangeNumberNotFound"/>
 *     &lt;enumeration value="MissingValidFrom"/>
 *     &lt;enumeration value="RevisionLvlNotFound"/>
 *     &lt;enumeration value="OtherProblems"/>
 *     &lt;enumeration value="GroupCounterMissing"/>
 *     &lt;enumeration value="InvalidOperationRange"/>
 *     &lt;enumeration value="ControlListNotCD"/>
 *     &lt;enumeration value="RoutingNotFound"/>
 *     &lt;enumeration value="KeyTaskLstTypeInput"/>
 *     &lt;enumeration value="MissingEcNumber"/>
 *     &lt;enumeration value="MissingMaterialNo"/>
 *     &lt;enumeration value="RoutingOperTabEmpty"/>
 *     &lt;enumeration value="TaskListTypeInputMissing"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ZMosGetRtgOperMods.RfcExceptions")
@XmlEnum
public enum ZMosGetRtgOperModsRfcExceptions {

    @XmlEnumValue("NoOpersFound")
    NO_OPERS_FOUND("NoOpersFound"),
    @XmlEnumValue("ChangeNumberMissing")
    CHANGE_NUMBER_MISSING("ChangeNumberMissing"),
    @XmlEnumValue("ChangeNumberNotFound")
    CHANGE_NUMBER_NOT_FOUND("ChangeNumberNotFound"),
    @XmlEnumValue("MissingValidFrom")
    MISSING_VALID_FROM("MissingValidFrom"),
    @XmlEnumValue("RevisionLvlNotFound")
    REVISION_LVL_NOT_FOUND("RevisionLvlNotFound"),
    @XmlEnumValue("OtherProblems")
    OTHER_PROBLEMS("OtherProblems"),
    @XmlEnumValue("GroupCounterMissing")
    GROUP_COUNTER_MISSING("GroupCounterMissing"),
    @XmlEnumValue("InvalidOperationRange")
    INVALID_OPERATION_RANGE("InvalidOperationRange"),
    @XmlEnumValue("ControlListNotCD")
    CONTROL_LIST_NOT_CD("ControlListNotCD"),
    @XmlEnumValue("RoutingNotFound")
    ROUTING_NOT_FOUND("RoutingNotFound"),
    @XmlEnumValue("KeyTaskLstTypeInput")
    KEY_TASK_LST_TYPE_INPUT("KeyTaskLstTypeInput"),
    @XmlEnumValue("MissingEcNumber")
    MISSING_EC_NUMBER("MissingEcNumber"),
    @XmlEnumValue("MissingMaterialNo")
    MISSING_MATERIAL_NO("MissingMaterialNo"),
    @XmlEnumValue("RoutingOperTabEmpty")
    ROUTING_OPER_TAB_EMPTY("RoutingOperTabEmpty"),
    @XmlEnumValue("TaskListTypeInputMissing")
    TASK_LIST_TYPE_INPUT_MISSING("TaskListTypeInputMissing");
    private final String value;

    ZMosGetRtgOperModsRfcExceptions(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ZMosGetRtgOperModsRfcExceptions fromValue(String v) {
        for (ZMosGetRtgOperModsRfcExceptions c: ZMosGetRtgOperModsRfcExceptions.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
