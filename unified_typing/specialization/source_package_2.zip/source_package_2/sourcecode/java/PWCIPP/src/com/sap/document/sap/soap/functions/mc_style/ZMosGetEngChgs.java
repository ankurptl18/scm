
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PEngChgsTab" type="{urn:sap-com:document:sap:soap:functions:mc-style}TableOfZmippsec" minOccurs="0"/>
 *         &lt;element name="PPlnal" type="{urn:sap-com:document:sap:rfc:functions}char2"/>
 *         &lt;element name="PPlnnr" type="{urn:sap-com:document:sap:rfc:functions}char8"/>
 *         &lt;element name="PPlnty" type="{urn:sap-com:document:sap:rfc:functions}char1"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pEngChgsTab",
    "pPlnal",
    "pPlnnr",
    "pPlnty"
})
@XmlRootElement(name = "ZMosGetEngChgs")
public class ZMosGetEngChgs {

    @XmlElement(name = "PEngChgsTab")
    protected TableOfZmippsec pEngChgsTab;
    @XmlElement(name = "PPlnal", required = true)
    protected String pPlnal;
    @XmlElement(name = "PPlnnr", required = true)
    protected String pPlnnr;
    @XmlElement(name = "PPlnty", required = true)
    protected String pPlnty;

    /**
     * Gets the value of the pEngChgsTab property.
     * 
     * @return
     *     possible object is
     *     {@link TableOfZmippsec }
     *     
     */
    public TableOfZmippsec getPEngChgsTab() {
        return pEngChgsTab;
    }

    /**
     * Sets the value of the pEngChgsTab property.
     * 
     * @param value
     *     allowed object is
     *     {@link TableOfZmippsec }
     *     
     */
    public void setPEngChgsTab(TableOfZmippsec value) {
        this.pEngChgsTab = value;
    }

    /**
     * Gets the value of the pPlnal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPPlnal() {
        return pPlnal;
    }

    /**
     * Sets the value of the pPlnal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPPlnal(String value) {
        this.pPlnal = value;
    }

    /**
     * Gets the value of the pPlnnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPPlnnr() {
        return pPlnnr;
    }

    /**
     * Sets the value of the pPlnnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPPlnnr(String value) {
        this.pPlnnr = value;
    }

    /**
     * Gets the value of the pPlnty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPPlnty() {
        return pPlnty;
    }

    /**
     * Sets the value of the pPlnty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPPlnty(String value) {
        this.pPlnty = value;
    }

}
