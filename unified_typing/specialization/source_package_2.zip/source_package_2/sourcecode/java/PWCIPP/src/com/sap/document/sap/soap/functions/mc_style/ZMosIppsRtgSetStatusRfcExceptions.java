
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ZMosIppsRtgSetStatus.RfcExceptions.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ZMosIppsRtgSetStatus.RfcExceptions">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="MissingInputDokvr"/>
 *     &lt;enumeration value="PathExistsIpps"/>
 *     &lt;enumeration value="ValidationError"/>
 *     &lt;enumeration value="NoAuthorizationToApprove"/>
 *     &lt;enumeration value="StatusNotChanged"/>
 *     &lt;enumeration value="MissingInputDokar"/>
 *     &lt;enumeration value="DrawingNotFound"/>
 *     &lt;enumeration value="CatiaVersionUnknown"/>
 *     &lt;enumeration value="MissingInputDoknr"/>
 *     &lt;enumeration value="MissingInputStabk"/>
 *     &lt;enumeration value="MissingInputDoktl"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ZMosIppsRtgSetStatus.RfcExceptions")
@XmlEnum
public enum ZMosIppsRtgSetStatusRfcExceptions {

    @XmlEnumValue("MissingInputDokvr")
    MISSING_INPUT_DOKVR("MissingInputDokvr"),
    @XmlEnumValue("PathExistsIpps")
    PATH_EXISTS_IPPS("PathExistsIpps"),
    @XmlEnumValue("ValidationError")
    VALIDATION_ERROR("ValidationError"),
    @XmlEnumValue("NoAuthorizationToApprove")
    NO_AUTHORIZATION_TO_APPROVE("NoAuthorizationToApprove"),
    @XmlEnumValue("StatusNotChanged")
    STATUS_NOT_CHANGED("StatusNotChanged"),
    @XmlEnumValue("MissingInputDokar")
    MISSING_INPUT_DOKAR("MissingInputDokar"),
    @XmlEnumValue("DrawingNotFound")
    DRAWING_NOT_FOUND("DrawingNotFound"),
    @XmlEnumValue("CatiaVersionUnknown")
    CATIA_VERSION_UNKNOWN("CatiaVersionUnknown"),
    @XmlEnumValue("MissingInputDoknr")
    MISSING_INPUT_DOKNR("MissingInputDoknr"),
    @XmlEnumValue("MissingInputStabk")
    MISSING_INPUT_STABK("MissingInputStabk"),
    @XmlEnumValue("MissingInputDoktl")
    MISSING_INPUT_DOKTL("MissingInputDoktl");
    private final String value;

    ZMosIppsRtgSetStatusRfcExceptions(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ZMosIppsRtgSetStatusRfcExceptions fromValue(String v) {
        for (ZMosIppsRtgSetStatusRfcExceptions c: ZMosIppsRtgSetStatusRfcExceptions.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
