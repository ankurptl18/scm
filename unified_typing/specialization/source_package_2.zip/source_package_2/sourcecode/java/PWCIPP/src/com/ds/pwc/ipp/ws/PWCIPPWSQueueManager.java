package com.ds.pwc.ipp.ws;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

import org.apache.log4j.Logger;

import com.ds.common.PWCCommonUtil;
import com.ds.common.PWCConstants;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.BackgroundProcess;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;


/**
 * This class is the core of 'Asynchronous web service call management framework' which is responsible for hosting the 
 * QueueManager process thread and also all the operations required for managing the 'Queue' objects
 * 
 * @author ZWE
 *
 */
public class PWCIPPWSQueueManager implements Runnable
{
	private static final Logger _LOGGER = Logger.getLogger(PWCIPPWSQueueManager.class.getName());;
	private static String _SUI;
	private static PWCIPPWSQueueManager _QMANAGER;

	private Context _context;


	private PWCIPPWSQueueManager() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: PWCIPPWSQueueManager()");

		try
		{
			// initialize context with super user
			_context =  new Context(DomainConstants.EMPTY_STRING);
						
			// push the context to the super user
			PWCIPPWSUtil.pushContextToSuperUser(_context);

			_SUI = FrameworkUtil.getServerUniqueIdentifier(_context);

		}catch(Exception mE)
		{
			_LOGGER.error("Failed to initialize the queue manager");
			throw mE;
		}

		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: PWCIPPWSQueueManager()");
	}


	public synchronized static void start() throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: start()");

		if(_QMANAGER == null)
		{
			_QMANAGER = new PWCIPPWSQueueManager();
		}

		Thread thread = new Thread(_QMANAGER);
		thread.start();

		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: start()");
	}

	@Override
	public void run() 
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: run()");
		try 
		{
			String sSUI = FrameworkUtil.getServerUniqueIdentifier(_context);
			String sLanguage = _context.getLocale().getLanguage();
			String sMessage = EnoviaResourceBundle.getProperty(_context, "emxEngineeringCentralStringResource", _context.getLocale(), "pwcEngineeringCentral.QueueManager.SUIFailureAlert");
			String sSubject = new StringBuilder("EV6_ERROR_001: ").append(EnoviaResourceBundle.getProperty(_context, "emxEngineeringCentralStringResource", _context.getLocale(), "pwcEngineeringCentral.QueueManager.FailureAlert")).toString();
			
			if (UIUtil.isNullOrEmpty(sSUI)) 
			{

				String[] arg = new String[]{DomainConstants.EMPTY_STRING, sSubject, sMessage, DomainConstants.EMPTY_STRING};
				try 
				{
					JPO.invoke(_context, "PWC_IPPWSUtil", new String[]{}, "notifyUser", arg);

				} catch (MatrixException e1) 
				{
					_LOGGER.error("Failed to send email notification due to this reason: "+e1.toString());
				}   

				throw new Exception("EV6_ERROR_001: Failed to start 'Queue Manager' as the value of 'Server Unique Identifier' is not found. Please correctly set this environment property and restart the server");
			}else
			{
				initiateQProcessing();
			}
		} catch (Exception e) 
		{
			_LOGGER.error(PWCIPPWSUtil.getStackTrace(e));
		}

		_LOGGER.debug("End of "+PWCIPPWSQueueManager.class.getName()+" :: run()");
	}

	@SuppressWarnings({ "unchecked" })
	private void initiateQProcessing()
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: initiateQProcessing()");

		String sSleepInterval = DomainConstants.EMPTY_STRING;
		int iSleepInterval = 180;

		try 
		{
			// first resubmit all the halted queues, if any due to last server shutdown 
			resubmitHaltedQueues(_context);

		} catch (Exception e) 
		{
			_LOGGER.error("Failed to resubmit the halted queues due to this error: "+PWCIPPWSUtil.getStackTrace(e));
		}

		try
		{
			sSleepInterval = EnoviaResourceBundle.getProperty(_context,"pwcEngineeringCentral.IPP.WS.QProcessor.PollingInterval");

			if(!UIUtil.isNullOrEmpty(sSleepInterval))
			{
				iSleepInterval = Integer.parseInt(sSleepInterval);
			}
		}catch(FrameworkException e)
		{
			_LOGGER.error("Failed to read configuration value for 'Polling Interval', hence using default value of 180 seconds");
		}

		while(true)
		{
			try
			{
				MapList mlQueues = getReadyQueues(_context);
				Map mpQ;
				String sQName = DomainConstants.EMPTY_STRING;

				for (int i = 0; i < mlQueues.size(); i++) 
				{
					try 
					{
						//ContextUtil.startTransaction(_context, true);

						mpQ = (Map)mlQueues.get(i);
						sQName = (String)mpQ.get(DomainConstants.SELECT_NAME);
						processQueue(mpQ);

						//ContextUtil.commitTransaction(_context);

					} catch (Exception e) 
					{
						//ContextUtil.abortTransaction(_context);

						_LOGGER.error("Failed to process Queue '"+sQName+"' due to this reason: "+PWCIPPWSUtil.getStackTrace(e));
					}
				}

				TimeUnit.SECONDS.sleep(iSleepInterval);

			} catch(Exception e)
			{
				_LOGGER.debug("Exception in "+PWCIPPWSQueueManager.class.getName()+" :: initiateQProcessing()");
			}
		}

	}

	@SuppressWarnings({ "unchecked" })
	private void processQueue(Map mpQ) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: processQueue");

		StringBuilder sbExprBuilder 	= new StringBuilder();
		String 		sAttrDirtyFlagExpr  = sbExprBuilder.append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_QUEUE_DIRTY_FLAG).append("]").toString();
		sbExprBuilder.setLength(0);
		String 			sAttrSUIExpr    = sbExprBuilder.append("attribute[").append(PWCConstants.ATTRIBUTE_SERVER_UNIQUE_IDENTIFIER).append("]").toString();

		String[] args = new String[5];
		args[0] = (String)mpQ.get(DomainConstants.SELECT_NAME);
		args[1] = (String)mpQ.get(DomainConstants.SELECT_REVISION);

		if(!UIUtil.isNullOrEmpty(args[0]) && !UIUtil.isNullOrEmpty(args[1])) 
		{
			args[2] = (String)mpQ.get(sAttrSUIExpr);
			args[3] = (String)mpQ.get(DomainConstants.SELECT_ID);
			args[4] = (String)mpQ.get(sAttrDirtyFlagExpr);

			//promoting the queue so that it is not picked up again in the next iteration by the same QManager OR
			//by the some other QManager in case of multiple server instances running
			try 
			{
			     PWCIPPWSQueue q = new PWCIPPWSQueue(_context ,args);
			q.promote();
			} catch (Exception e)  
			{
				_LOGGER.error("Failed to promote the queue '"+args[0]+"'");
				throw e;
			}

			// using background thread instead of background job just to avoid the flooding of Job bus objects
			BackgroundProcess bgpProcess = new BackgroundProcess();
			
			//creating the new context to pass it to new thread instead of clonning the existing, because there is an issue while cloning a cloned context (which is pushed to super user)
			//And since the context passed to the thread will be cloned internally by setPhysicalLocation() OOTB API, we cannot pass the cloned context.
			
			//(correction during 2014x upgrade)
			// passing only the empty context which will be pushed and connected in the individual treads and then will be disconnected there itself at the end 
			Context clonedContext = new Context(DomainConstants.EMPTY_STRING);
						
			bgpProcess.submitJob(clonedContext, "PWC_IPPWSUtil", "processQueue", args, (String) null);
			
		} 

		_LOGGER.debug("End of "+PWCIPPWSQueueManager.class.getName()+" :: processQueue");
	}


	/**
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static MapList getWSQueuesList(Context context,String sStateVal) throws Exception 
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: getWSQueuesList()");

		MapList mlReturnList				= new MapList();

		StringList 		slSelects			= new StringList(1);
		//String sWhereExpr			= DomainConstants.EMPTY_STRING;

		StringBuilder 	sbExprBuilder 		= new StringBuilder();
		String 			sAttrDirtyFlagExpr  = sbExprBuilder.append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_QUEUE_DIRTY_FLAG).append("]").toString();

		sbExprBuilder.setLength(0);
		String 			sAttrSUIExpr  = sbExprBuilder.append("attribute[").append(PWCConstants.ATTRIBUTE_SERVER_UNIQUE_IDENTIFIER).append("]").toString();

		slSelects.add(DomainConstants.SELECT_NAME);
		slSelects.add(DomainConstants.SELECT_ID);
		slSelects.add(DomainConstants.SELECT_REVISION);
		slSelects.add(sAttrDirtyFlagExpr);
		slSelects.add(sAttrSUIExpr);

		sbExprBuilder.setLength(0);
		String sWhereExpr = DomainConstants.EMPTY_STRING; 
		sbExprBuilder.append("attribute[").append(PWCConstants.ATTRIBUTE_PWC_IPP_QUEUE_DIRTY_FLAG).append("]==FALSE && ").toString();

		if(PWCConstants.STATE_POLICY_PWC_IPPWSQUEUE_READY.equalsIgnoreCase(sStateVal))
		{
			sWhereExpr = sbExprBuilder.append("current=='").append(PWCConstants.STATE_POLICY_PWC_IPPWSQUEUE_READY).append("'").toString();
		}
		else
		{
			sWhereExpr	= sbExprBuilder.append("current=='").append(PWCConstants.STATE_POLICY_PWC_IPPWSQUEUE_INPROGRESS).append("' && attribute[").append(PWCConstants.ATTRIBUTE_SERVER_UNIQUE_IDENTIFIER).append("] == ").append(_SUI).toString();
		}

		mlReturnList = DomainObject.findObjects(context,PWCConstants.TYPE_PWC_IPPWSQUEUE,
				PWCCommonUtil.getVaultPattern(context),
				sWhereExpr,
				slSelects);

		_LOGGER.debug("\n mlReturnList: "+mlReturnList);
		_LOGGER.debug("End of "+PWCIPPWSQueueManager.class.getName()+" :: getWSQueuesList()");
		return mlReturnList;
	}

	@SuppressWarnings({ "unchecked" })
	public static void resubmitHaltedQueues(Context context) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: resubmitHaltedQueues()");

		MapList mlQueues = getHaltedQueues(context);
		Map mpQueue;
		String sQId;
		DomainObject dom;

		for (int i = 0; i < mlQueues.size(); i++) 
		{
			mpQueue = (Map) mlQueues.get(i);
			sQId = (String)mpQueue.get(DomainConstants.SELECT_ID);

			dom = DomainObject.newInstance(context, sQId);
			dom.demote(context);
		}

		_LOGGER.debug("End of "+PWCIPPWSQueueManager.class.getName()+" :: resubmitHaltedQueues()");
	}


	public static MapList getReadyQueues(Context context) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: getReadyQueues()");

		MapList mlReturnList = new MapList();

		String sStateVal = PWCConstants.STATE_POLICY_PWC_IPPWSQUEUE_READY;
		mlReturnList = getWSQueuesList(context,sStateVal);

		_LOGGER.debug("End of "+PWCIPPWSQueueManager.class.getName()+" :: getReadyQueues()");
		return mlReturnList;
	}	

	public static MapList getHaltedQueues(Context context) throws Exception
	{
		_LOGGER.debug("Start of "+PWCIPPWSQueueManager.class.getName()+" :: getHaltedQueues()");

		MapList mlReturnList = new MapList();

		String sStateVal = PWCConstants.STATE_POLICY_PWC_IPPWSQUEUE_INPROGRESS;
		mlReturnList = getWSQueuesList(context,sStateVal);

		_LOGGER.debug("End of "+PWCIPPWSQueueManager.class.getName()+" :: getHaltedQueues()");
		return mlReturnList;
	}

}
