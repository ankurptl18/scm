
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PDokar" type="{urn:sap-com:document:sap:rfc:functions}char3"/>
 *         &lt;element name="PDoknr" type="{urn:sap-com:document:sap:rfc:functions}char25"/>
 *         &lt;element name="PDoktl" type="{urn:sap-com:document:sap:rfc:functions}char3"/>
 *         &lt;element name="PDokvr" type="{urn:sap-com:document:sap:rfc:functions}char2"/>
 *         &lt;element name="PStIntern" type="{urn:sap-com:document:sap:rfc:functions}char2" minOccurs="0"/>
 *         &lt;element name="PStLog" type="{urn:sap-com:document:sap:rfc:functions}char20" minOccurs="0"/>
 *         &lt;element name="PStabk" type="{urn:sap-com:document:sap:rfc:functions}char2"/>
 *         &lt;element name="PUsername" type="{urn:sap-com:document:sap:rfc:functions}char12" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pDokar",
    "pDoknr",
    "pDoktl",
    "pDokvr",
    "pStIntern",
    "pStLog",
    "pStabk",
    "pUsername"
})
@XmlRootElement(name = "ZMosIppsRtgSetStatus")
public class ZMosIppsRtgSetStatus {

    @XmlElement(name = "PDokar", required = true)
    protected String pDokar;
    @XmlElement(name = "PDoknr", required = true)
    protected String pDoknr;
    @XmlElement(name = "PDoktl", required = true)
    protected String pDoktl;
    @XmlElement(name = "PDokvr", required = true)
    protected String pDokvr;
    @XmlElement(name = "PStIntern")
    protected String pStIntern;
    @XmlElement(name = "PStLog")
    protected String pStLog;
    @XmlElement(name = "PStabk", required = true)
    protected String pStabk;
    @XmlElement(name = "PUsername")
    protected String pUsername;

    /**
     * Gets the value of the pDokar property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDokar() {
        return pDokar;
    }

    /**
     * Sets the value of the pDokar property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDokar(String value) {
        this.pDokar = value;
    }

    /**
     * Gets the value of the pDoknr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDoknr() {
        return pDoknr;
    }

    /**
     * Sets the value of the pDoknr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDoknr(String value) {
        this.pDoknr = value;
    }

    /**
     * Gets the value of the pDoktl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDoktl() {
        return pDoktl;
    }

    /**
     * Sets the value of the pDoktl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDoktl(String value) {
        this.pDoktl = value;
    }

    /**
     * Gets the value of the pDokvr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDokvr() {
        return pDokvr;
    }

    /**
     * Sets the value of the pDokvr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDokvr(String value) {
        this.pDokvr = value;
    }

    /**
     * Gets the value of the pStIntern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPStIntern() {
        return pStIntern;
    }

    /**
     * Sets the value of the pStIntern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPStIntern(String value) {
        this.pStIntern = value;
    }

    /**
     * Gets the value of the pStLog property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPStLog() {
        return pStLog;
    }

    /**
     * Sets the value of the pStLog property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPStLog(String value) {
        this.pStLog = value;
    }

    /**
     * Gets the value of the pStabk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPStabk() {
        return pStabk;
    }

    /**
     * Sets the value of the pStabk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPStabk(String value) {
        this.pStabk = value;
    }

    /**
     * Gets the value of the pUsername property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPUsername() {
        return pUsername;
    }

    /**
     * Sets the value of the pUsername property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPUsername(String value) {
        this.pUsername = value;
    }

}
