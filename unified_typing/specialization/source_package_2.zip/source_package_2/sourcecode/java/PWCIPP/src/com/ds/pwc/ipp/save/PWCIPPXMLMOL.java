package com.ds.pwc.ipp.save;

import java.util.LinkedList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.matrixone.apps.domain.DomainConstants;

@XmlRootElement(name="MOL")
@XmlSeeAlso(PWCIPPXMLMfgOps.class)
public class PWCIPPXMLMOL
{
	private String m_Name;
	private String m_SAPChangeNumber;
	
	private PWCIPPXMLMfgOps m_MfgOps;
	
	public PWCIPPXMLMOL()
	{
		m_Name = m_SAPChangeNumber = DomainConstants.EMPTY_STRING;
		m_MfgOps = null;
	}
	
	@XmlAttribute(name="name")
	public String getName()
	{
		return m_Name;
	}

	public void setName( String iName )
	{
		m_Name = iName;
	}

	@XmlAttribute(name="SAPChangeNo")
	public String getSAPChangeNumber()
	{
		return m_SAPChangeNumber;
	}

	public void setSAPChangeNumber( String iSAPChangeNumber )
	{
		m_SAPChangeNumber = iSAPChangeNumber;
	}
	
	@XmlElement(name="MfgOps")
	public PWCIPPXMLMfgOps getMfgOps()
	{
		return m_MfgOps;
	}

	public void setMfgOps( PWCIPPXMLMfgOps iMfgOps )
	{
		m_MfgOps = iMfgOps;
	}
	
	public void validate()
	{
		StringBuilder st_msg = new StringBuilder( "invalid MOL definition" );
		
		boolean b_throw = false;
		if( null == m_Name || 0 == m_Name.length() )
		{
			st_msg.append( " - missing name" );
			b_throw = true;
		}

		if( null == m_SAPChangeNumber || 0 == m_SAPChangeNumber.length() )
		{
			st_msg.append( " - missing SAP change number" );
			b_throw = true;
		}

		if( null == m_MfgOps  )
		{
			st_msg.append( " - missing operations" );
			b_throw = true;
		}
		
		if( b_throw )
		{
			throw new IllegalArgumentException( st_msg.toString() );
		}
		
		m_MfgOps.validate();
	}
}
