
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.sap.document.sap.soap.functions.mc_style package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ZMosGetEngChgsException_QNAME = new QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZMosGetEngChgs.Exception");
	private final static QName _ZMosGetRtgOperModsException_QNAME = new QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZMosGetRtgOperMods.Exception");
	private final static QName _ZMosIppsRtgSetStatusException_QNAME = new QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZMosIppsRtgSetStatus.Exception");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.sap.document.sap.soap.functions.mc_style
     * 
     */
    public ObjectFactory() {
    }
//=============================Z_PLM_MOS_GET_ENG_CHGS==========================
    /**
     * Create an instance of {@link ZMosGetEngChgs }
     * 
     */
    public ZMosGetEngChgs createZMosGetEngChgs() {
        return new ZMosGetEngChgs();
    }

    /**
     * Create an instance of {@link RfcExceptionMessage }
     * 
     */
    public RfcExceptionMessage createRfcExceptionMessage() {
        return new RfcExceptionMessage();
    }

    /**
     * Create an instance of {@link ZMosGetEngChgsResponse }
     * 
     */
    public ZMosGetEngChgsResponse createZMosGetEngChgsResponse() {
        return new ZMosGetEngChgsResponse();
    }

    /**
     * Create an instance of {@link TableOfZmippsec }
     * 
     */
    public TableOfZmippsec createTableOfZmippsec() {
        return new TableOfZmippsec();
    }

    /**
     * Create an instance of {@link Zmippsec }
     * 
     */
    public Zmippsec createZmippsec() {
        return new Zmippsec();
    }

    /**
     * Create an instance of {@link ZMosGetEngChgsRfcException }
     * 
     */
    public ZMosGetEngChgsRfcException createZMosGetEngChgsRfcException() {
        return new ZMosGetEngChgsRfcException();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ZMosGetEngChgsRfcException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:sap-com:document:sap:soap:functions:mc-style", name = "ZMosGetEngChgs.Exception")
    public JAXBElement<ZMosGetEngChgsRfcException> createZMosGetEngChgsException(ZMosGetEngChgsRfcException value) {
        return new JAXBElement<ZMosGetEngChgsRfcException>(_ZMosGetEngChgsException_QNAME, ZMosGetEngChgsRfcException.class, null, value);
    }
//=============================Z_PLM_MOS_GET_RTG_OPER_MODS=====================
	 /**
	 * Create an instance of {@link Zmippsoper }
	 * 
	 */
    public Zmippsoper createZmippsoper() {
        return new Zmippsoper();
    }

    /**
     * Create an instance of {@link TableOfZmippsoper }
     * 
     */
    public TableOfZmippsoper createTableOfZmippsoper() {
        return new TableOfZmippsoper();
    }

    /**
     * Create an instance of {@link ZMosGetRtgOperModsRfcException }
     * 
     */
    public ZMosGetRtgOperModsRfcException createZMosGetRtgOperModsRfcException() {
        return new ZMosGetRtgOperModsRfcException();
    }


    /**
     * Create an instance of {@link ZMosGetRtgOperModsResponse }
     * 
     */
    public ZMosGetRtgOperModsResponse createZMosGetRtgOperModsResponse() {
        return new ZMosGetRtgOperModsResponse();
    }

    /**
     * Create an instance of {@link ZMosGetRtgOperMods }
     * 
     */
    public ZMosGetRtgOperMods createZMosGetRtgOperMods() {
        return new ZMosGetRtgOperMods();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ZMosGetRtgOperModsRfcException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:sap-com:document:sap:soap:functions:mc-style", name = "ZMosGetRtgOperMods.Exception")
    public JAXBElement<ZMosGetRtgOperModsRfcException> createZMosGetRtgOperModsException(ZMosGetRtgOperModsRfcException value) {
        return new JAXBElement<ZMosGetRtgOperModsRfcException>(_ZMosGetRtgOperModsException_QNAME, ZMosGetRtgOperModsRfcException.class, null, value);
    }
//=============================Z_PLM_MOS_IPPS_RTG_SET_STATUS===================
    /**
     * Create an instance of {@link ZMosIppsRtgSetStatus }
     * 
     */
    public ZMosIppsRtgSetStatus createZMosIppsRtgSetStatus() {
        return new ZMosIppsRtgSetStatus();
    }


    /**
     * Create an instance of {@link ZMosIppsRtgSetStatusResponse }
     * 
     */
    public ZMosIppsRtgSetStatusResponse createZMosIppsRtgSetStatusResponse() {
        return new ZMosIppsRtgSetStatusResponse();
    }

    /**
     * Create an instance of {@link ZMosIppsRtgSetStatusRfcException }
     * 
     */
    public ZMosIppsRtgSetStatusRfcException createZMosIppsRtgSetStatusRfcException() {
        return new ZMosIppsRtgSetStatusRfcException();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ZMosIppsRtgSetStatusRfcException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:sap-com:document:sap:soap:functions:mc-style", name = "ZMosIppsRtgSetStatus.Exception")
    public JAXBElement<ZMosIppsRtgSetStatusRfcException> createZMosIppsRtgSetStatusException(ZMosIppsRtgSetStatusRfcException value) {
        return new JAXBElement<ZMosIppsRtgSetStatusRfcException>(_ZMosIppsRtgSetStatusException_QNAME, ZMosIppsRtgSetStatusRfcException.class, null, value);
    }
}
