package com.ds.pwc.ipp.save;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.matrixone.apps.domain.DomainConstants;

@XmlRootElement(name="Operation")
@XmlSeeAlso(PWCIPPXMLSourceTarget.class)
public class PWCIPPXMLOperation
{
	private String m_Result;
	private String m_Error;
	
	private PWCIPPXMLSourceTarget m_Source;
	private PWCIPPXMLSourceTarget m_Target;
	
	public PWCIPPXMLOperation()
	{
		m_Result = m_Error  = DomainConstants.EMPTY_STRING;
		m_Source = m_Target = null;
	}
	
	@XmlAttribute(name="result")
	public String getResult()
	{
		return m_Result;
	}

	public void setResult( String iResult )
	{
		m_Result = iResult;
	}
	
	@XmlAttribute(name="error")
	public String getError()
	{
		return m_Error;
	}

	public void setError( String iError )
	{
		m_Error = iError;
	}
	
	@XmlElement(name="Source",nillable=false)
	public PWCIPPXMLSourceTarget getSource()
	{
		return m_Source;
	}

	public void setSource( PWCIPPXMLSourceTarget iSource )
	{
		m_Source = iSource;
	}

	@XmlElement(name="Target",nillable=false)
	public PWCIPPXMLSourceTarget getTarget()
	{
		return m_Target;
	}

	public void setTarget( PWCIPPXMLSourceTarget iTarget )
	{
		m_Target = iTarget;
	}

	public void validate()
	{
		StringBuilder st_msg = new StringBuilder( "invalid Operation definition" );
		
		boolean b_throw = false;
		if( null == m_Source )
		{
			st_msg.append( " - missing Source" );
			b_throw = true;
		}

		if( null == m_Target  )
		{
			st_msg.append( " - missing Target" );
			b_throw = true;
		}

		if( b_throw )
		{
			throw new IllegalArgumentException( st_msg.toString() );
		}

		m_Source.validate();
		m_Target.validate();
	}
}
