
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PEngChgsTab" type="{urn:sap-com:document:sap:soap:functions:mc-style}TableOfZmippsec" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pEngChgsTab"
})
@XmlRootElement(name = "ZMosGetEngChgsResponse")
public class ZMosGetEngChgsResponse {

    @XmlElement(name = "PEngChgsTab")
    protected TableOfZmippsec pEngChgsTab;

    /**
     * Gets the value of the pEngChgsTab property.
     * 
     * @return
     *     possible object is
     *     {@link TableOfZmippsec }
     *     
     */
    public TableOfZmippsec getPEngChgsTab() {
        return pEngChgsTab;
    }

    /**
     * Sets the value of the pEngChgsTab property.
     * 
     * @param value
     *     allowed object is
     *     {@link TableOfZmippsec }
     *     
     */
    public void setPEngChgsTab(TableOfZmippsec value) {
        this.pEngChgsTab = value;
    }

}
