package com.ds.pwc.ipp.ws;

import java.util.ArrayList;

import matrix.db.Context;
import matrix.util.MatrixException;

import org.apache.log4j.Logger;

import com.ds.common.PWCConstants;
import com.ds.pwc.ipp.mos.PWCIPPMfgOperation;
import com.ds.pwc.ipp.mos.PWCIPPMfgOperationList;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;

/**
 * This is a class which hosts the actual implementation of all web-service API which are invoked asynchronously from the background thread.
 * 
 * @author ZWE
 *
 */
public class PWCIPPWSImplementor 
{

	private static final Logger _LOGGER  = Logger.getLogger(PWCIPPWSImplementor.class.getName());
	//change this value if the code is modified (the value should be the next known delivery date)
	private static final String CODE_VERSION = "2013_03_29";

	/**************************************************************Asynchronous*******************************************************************/


	/**
	 * It performs the following logic
	 *  a. constructs the name of MOL out of (Group + Task Type + Group Counter)
	 *  b. checks if MOL with the same name exists
	 *  	i. If yes, then get its revision for which given SAP_Change# matches & imposes all the MOL attributes to the existing
	 *  	ii. if not, creates the new one 
	 *  c. creates and attaches each of the MfgOp objects
	 *  d. puts/sets 'IsFromSAP' flag to true (to know this is not created manually in the Enovia system)
	 * 
	 * @param sUserBadgeId - SAP user Badge Id, which is the Enovia user name
	 * @param SAP Timestamp - Timestamp when the service was invoked from 
	 * @param mpMOLInfo - A map of key-value pairs of below given MOL and other header related information. All the keys marked with '*' are mandatory
	 * 						1. Group*
	 * 						2. Task Type*
	 *						3. Group Counter*
	 *						4. SAP_Ch#*
	 *						5. Rev Level
	 * 						6. Material
	 * 						7. SAP_Classification Flag
	 * 						8. SAP_Mat_Security Flag 
	 * @param alMOPInfo - A list of Maps of key-value pairs of below given MOS related information. All the keys marked with '*' are mandatory
	 * 						1. DRFName*
	 * 						2. OperationNo*
	 *						3. SequenceNo*
	 *						4. ESAFlag
	 *						5. DRFVersion* (this will be the actual revision of an MfgOp)
	 * 						6. Description
	 */
	@SuppressWarnings("unchecked")
	public static void saveRouting(Context context, PWCIPPMfgOperationList molObj) throws Exception
	{
		_LOGGER.debug("Entering "+PWCIPPWSImplementor.class.getName()+"START::saveRouting()");

		boolean bIsFromSAP = true;
		try
		{
			PWCIPPWSUtil.connectBgpThreadContext(context, molObj.getBadgeId(),  molObj.getLocation());

			ContextUtil.startTransaction(context, true);
			
			molObj.putContext(context);
			if(!molObj.checkIfExists())
			{
				molObj.create(bIsFromSAP);				
			} 
			else
			{
				String sErrMsg = EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), "pwcEngineeringCentral.SaveRouting.MOLCreation.FailureAlert");
				throw new Exception(sErrMsg);
			}

			ContextUtil.commitTransaction(context);
		} 
		catch(Exception e)
		{
			ContextUtil.abortTransaction(context);
			throw e;

		}finally
		{
			try 
			{
				ContextUtil.popContext(context);
			} catch (Exception e2) 
			{
				_LOGGER.warn("PopContext faild due to this reason: "+e2.toString());
			}
		}

		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"END::saveRouting()");
	}

	/**
	 * It performs the following logic
	 *  a. constructs the name of MOL out of (Group + Task Type + Group Counter)
	 *  b. checks if MOL with the same name exists
	 *  	i. if yes, get all revisions of this MOL
	 *  	   	- check if given SAP_Change# matches with that of any of these revisions
	 *  	   	- if not, then revise the MOL and impose the operation updates as described in point c.
	 *  	   	- and if yes, then impose the operation updates to the particular revision of MOL, as described in point c.
	 *  	ii. if not, reports the failure 
	 *  c. Process each operation item based on the value of 'Processing_Option' (Add, Delete, Revise, Change) as below-
	 *  		- Add : create new MOP and impose given attribute values
	 *  		- Delete : delete the given MOP 
	 *  		- Revise : revise the given MOP and impose given attribute values
	 *  		- Change : impose the given attribute values
	 *  d. puts/sets 'IsFromSAP' flag to true on any of the MOL or MOP objects that are created (to know this is not created manually in the Enovia system)
	 * 
	 * @param sUserBadgeId - SAP user Badge Id, which is the Enovia user name
	 * @param SAP Timestamp - Timestamp when the service was invoked from 
	 * @param mpMOLInfo - A map of key-value pairs of below given MOL and other header related information. All the keys marked with '*' are mandatory
	 * 						1. Group*
	 * 						2. Task Type*
	 *						3. Group Counter*
	 *						4. SAP_Ch#*
	 * @param alMOPInfo - A list of Maps of key-value pairs of below given MOS related information. All the keys marked with '*' are mandatory
	 * 						1. Name (DRF Name* on SAP side)
	 * 						2. Operation #*
	 *						3. Sequence*
	 *						4. ESA Flag
	 *						5. DRF Version* (this will be the actual revision of an MfgOp)
	 * 						6. Description
	 * 						7. Processing_Option* (Change, Add, Delete)
	 */
	public static void modifyRouting(Context context, PWCIPPMfgOperationList molObj) throws Exception
	{
		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"START::modifyRouting()");

		boolean bIsFromSAP = true;
		try
		{
			PWCIPPWSUtil.connectBgpThreadContext(context, molObj.getBadgeId(),  molObj.getLocation());

			ContextUtil.startTransaction(context, true);

			molObj.putContext(context);
			if(molObj.checkIfExists())
			{
				molObj.update();
				processMfgOperation(context, molObj, false, bIsFromSAP);
			} else
			{
				MapList mapList = molObj.readAllRevisions(molObj.readName());
				if(null != mapList && !mapList.isEmpty())
				{		
					String strSAPChangeNumer = (String)molObj.getSAPChangeNumber();
					PWCIPPMfgOperationList newReviseObject = PWCIPPMfgOperationList.reviseLastRevision(context, strSAPChangeNumer, mapList, bIsFromSAP);
					
					molObj.putObjectID(newReviseObject.readObjectID());
					
					processMfgOperation(context, molObj, true, bIsFromSAP);
					molObj.update();
					
				} else
				{
					String sErrMsg = EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), "pwcEngineeringCentral.ModifyRouting.MOLNotExist.FailureAlert");
					throw new Exception(sErrMsg);
				}
			}			
			ContextUtil.commitTransaction(context);
		}
		catch(Exception e)
		{

			ContextUtil.abortTransaction(context);
			throw e;

		}finally
		{
			try 
			{
				ContextUtil.popContext(context);
			} catch (Exception e2) 
			{
				_LOGGER.warn("PopContext faild due to this reason: "+e2.toString());
			}
		}

		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"::modifyRouting() END");
	}


	/**
	 * This method process all the MOS part as per the processing option	
	 * @param PWCIPPMfgOperationList : object of PWCIPPMfgOperationList class
	 */
	private static void processMfgOperation(Context context,PWCIPPMfgOperationList listObject, boolean bIsMOLRevised,
			boolean bIsFromSAP)	throws Exception 
	{
		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"SRART::processMfgOperation()");

		String sProcessingOption 	= DomainObject.EMPTY_STRING;
		ArrayList<PWCIPPMfgOperation> alMOSInfo = listObject.readOperationList();
		for(PWCIPPMfgOperation operationObj : alMOSInfo)
		{	
			operationObj.putContext(context);
			operationObj.checkIfExists();
			sProcessingOption = operationObj.getProcessingOption();			

			if(sProcessingOption.equalsIgnoreCase("add"))
				addOperations(context, operationObj, listObject, bIsMOLRevised, bIsFromSAP);
			else if(sProcessingOption.equalsIgnoreCase("modify"))
				modifyOperations(context, operationObj, listObject);
			else if(sProcessingOption.equalsIgnoreCase("delete"))
				deleteOperations(context, operationObj, listObject);					
			else
			{
				String[] messageKeys = new String[]{"sProcessingOption"};
				String[] messageValues = new String[]{sProcessingOption};
				String sErrMsg = MessageUtil.getMessage(context,"pwcEngineeringCentral.WebService.ProcessingOption.Failure",messageKeys,messageValues,null,context.getLocale(),"emxEngineeringCentralStringResource");
				throw new Exception(sErrMsg);
			}			
		}

		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"END::processMfgOperation()");
	}	

	/**
	 * This method adds operation and connects it to the list object.	
	 * @param PWCIPPMfgOperationList : object of PWCIPPMfgOperationList class
	 */
	private static void addOperations(Context context, PWCIPPMfgOperation operationObj, PWCIPPMfgOperationList listObject, boolean bIsMOLRevised,
				boolean bIsFromSAP) throws Exception
	{
		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"SRART::addOperations()");		

		try 
		{
			String sOperationId = DomainConstants.EMPTY_STRING;

			//checks if the operation already exists
			if(!operationObj.checkIfExists())
			{
				MapList mlOperationRevisions = new MapList();
				mlOperationRevisions = operationObj.readAllRevisions(operationObj.getDRFName());

				//if not, then checks if any revision of it exists
				if(null != mlOperationRevisions && !mlOperationRevisions.isEmpty())
				{
					/*//if yes, then checks if the parent MOL is revised
					if(bIsMOLRevised)
					{
						//if yes, then creates the new revision of the operation
						PWCIPPMfgOperation newRevisedObject = PWCIPPMfgOperation.reviseLastRevisionOfMOS(context,operationObj.getDRFVersion(), mlOperationRevisions, bIsFromSAP);
						sOperationId = newRevisedObject.readObjectId();
						operationObj.update(DomainObject.newInstance(context,sOperationId));
					}
					else
					{
						//this means revision of an Operation to be added already exists and MOL is also not revised. 
						//Hence new operation with the same name can't be created and it can't even be revised. Hence it is a wrong usecase with processing option 
						MatrixException mE = new MatrixException();
						mE.addMessage(new StringBuilder("Revisions of Operation '").append(operationObj.getDRFName()).append("' already exists and MOL is not revised, so can not create/revise this operation.").toString());
						throw(mE);								
					}*/
					
					//above code is commented to handle the the revise of MfgOp even if the given MOL is not revised
					//if yes, then create the new revision of Operation
					PWCIPPMfgOperation newRevisedObject = PWCIPPMfgOperation.reviseLastRevisionOfMOS(context,operationObj.getDRFVersion(), mlOperationRevisions, bIsFromSAP);
					sOperationId = newRevisedObject.readObjectId();
					operationObj.update(DomainObject.newInstance(context,sOperationId));
				}			
				else
				{
					//means, no revision of Operation exists. Hence create new operation
					sOperationId = operationObj.create(bIsFromSAP);
				}
			}
			else if(!operationObj.checkIfConnectedToList())
			{
				//means, the Operation already exists but not connected to any MOL
				//so, update this stand alone operation to connect to the MOL
				operationObj.update();
				sOperationId = operationObj.readObjectId();
			}

			if(!sOperationId.isEmpty())
			{
				//operationObj.disconnectFromList();
				listObject.connectMfgOperation(sOperationId);
			}else
			{
				//means, it is an invalid usecase
				MatrixException mE = new MatrixException();
				mE.addMessage(new StringBuilder(EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), "pwcEngineeringCentral.AddOperation.FailureAlert"))
				.append(operationObj.getDRFName()).append("'").toString());
				throw(mE);
			}

		} catch (Exception e) 
		{
			StringBuilder sbErrMsg = new StringBuilder(EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(), "pwcEngineeringCentral.WebService.OptionAdditionFailure"));
			sbErrMsg.append(PWCConstants.STR_NEWLINE).append(e);
			throw new Exception(sbErrMsg.toString(), e);
		}

		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"END::addOperations()");
	}

	/**
	 * This method modify operation and connect to the list object.	
	 * @param PWCIPPMfgOperationList : object of PWCIPPMfgOperationList class
	 */
	private static void modifyOperations(Context context, PWCIPPMfgOperation operationObj, PWCIPPMfgOperationList listObject)throws Exception
	{
		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"START::modifyOperations()");
		if(operationObj.checkIfExists() && operationObj.checkIfConnectedToList(listObject.readObjectID()))
		{
			operationObj.update();
		}
		else
		{
			MatrixException mE = new MatrixException();
			String[] messageKeys = new String[]{"sDRFName"};
			String[] messageValues = new String[]{operationObj.getDRFName()};
			String sErrMsg = MessageUtil.getMessage(context,"pwcEngineeringCentral.modifyOperations.FailureAlert",messageKeys,messageValues,null,context.getLocale(),"emxEngineeringCentralStringResource");
			mE.addMessage(sErrMsg);
			throw(mE);
		}

		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"END::modifyOperations()");
	}

	/**
	 * This method disconnect operation and connect to the list object.
	 * @param PWCIPPMfgOperationList : object of PWCIPPMfgOperationList class
	 */
	private static void deleteOperations(Context context, PWCIPPMfgOperation operationObj, PWCIPPMfgOperationList listObject)throws Exception
	{
		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"START::deleteOperations()");

		if(operationObj.checkIfConnectedToList(listObject.readObjectID()))
		{
			operationObj.disconnectFromList();
		}

		_LOGGER.debug(PWCIPPWSImplementor.class.getName()+"END::deleteOperations()");
	}

	
	/*********************************************************************************************************************************************/

	public static boolean callWebService(Context context,String sWebSericeName,PWCIPPMfgOperationList molInfo) throws Exception
	{
		boolean bReturn = false;
		if("saveRouting".equalsIgnoreCase(sWebSericeName))
		{
			saveRouting(context,molInfo);
		} 
		else if("modifyRouting".equalsIgnoreCase(sWebSericeName))
		{
			modifyRouting(context,molInfo);
		}
		return bReturn;
	}
}
