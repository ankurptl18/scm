
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Zmippsoper complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Zmippsoper">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Mandt" type="{urn:sap-com:document:sap:rfc:functions}clnt3"/>
 *         &lt;element name="Vornr" type="{urn:sap-com:document:sap:rfc:functions}char4"/>
 *         &lt;element name="Ltxa1" type="{urn:sap-com:document:sap:rfc:functions}char40"/>
 *         &lt;element name="Doknr" type="{urn:sap-com:document:sap:rfc:functions}char25"/>
 *         &lt;element name="Dokvr" type="{urn:sap-com:document:sap:rfc:functions}char2"/>
 *         &lt;element name="Stabk" type="{urn:sap-com:document:sap:rfc:functions}char2"/>
 *         &lt;element name="Plnfl" type="{urn:sap-com:document:sap:rfc:functions}char6"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Zmippsoper", propOrder = {
    "mandt",
    "vornr",
    "ltxa1",
    "doknr",
    "dokvr",
    "stabk",
    "plnfl"
})
public class Zmippsoper {

    @XmlElement(name = "Mandt", required = true)
    protected String mandt;
    @XmlElement(name = "Vornr", required = true)
    protected String vornr;
    @XmlElement(name = "Ltxa1", required = true)
    protected String ltxa1;
    @XmlElement(name = "Doknr", required = true)
    protected String doknr;
    @XmlElement(name = "Dokvr", required = true)
    protected String dokvr;
    @XmlElement(name = "Stabk", required = true)
    protected String stabk;
    @XmlElement(name = "Plnfl", required = true)
    protected String plnfl;

    /**
     * Gets the value of the mandt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMandt() {
        return mandt;
    }

    /**
     * Sets the value of the mandt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMandt(String value) {
        this.mandt = value;
    }

    /**
     * Gets the value of the vornr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVornr() {
        return vornr;
    }

    /**
     * Sets the value of the vornr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVornr(String value) {
        this.vornr = value;
    }

    /**
     * Gets the value of the ltxa1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLtxa1() {
        return ltxa1;
    }

    /**
     * Sets the value of the ltxa1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLtxa1(String value) {
        this.ltxa1 = value;
    }

    /**
     * Gets the value of the doknr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoknr() {
        return doknr;
    }

    /**
     * Sets the value of the doknr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoknr(String value) {
        this.doknr = value;
    }

    /**
     * Gets the value of the dokvr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDokvr() {
        return dokvr;
    }

    /**
     * Sets the value of the dokvr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDokvr(String value) {
        this.dokvr = value;
    }

    /**
     * Gets the value of the stabk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStabk() {
        return stabk;
    }

    /**
     * Sets the value of the stabk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStabk(String value) {
        this.stabk = value;
    }

    /**
     * Gets the value of the plnfl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlnfl() {
        return plnfl;
    }

    /**
     * Sets the value of the plnfl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlnfl(String value) {
        this.plnfl = value;
    }

}
