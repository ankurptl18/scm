package com.ds.pwc.ipp.report;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import com.matrixone.apps.domain.DomainConstants;

/**
 * @author ZWE
 *
 */
public class PWCIPPCADObjectValidationResult 
{
	private String sObjectTNR = DomainConstants.EMPTY_STRING;
	private String sResult = DomainConstants.EMPTY_STRING;
	private String sError = DomainConstants.EMPTY_STRING;
	private String sWarning = DomainConstants.EMPTY_STRING;
	
	@XmlAttribute(name="object")
	public String getsObjectTNR() 
	{
		return sObjectTNR;
	}
	public void setsObjectTNR(String sObjectTNR) 
	{
		this.sObjectTNR = sObjectTNR;
	}
	
	@XmlAttribute(name="result")
	public String getsResult() 
	{
		return sResult;
	}
	public void setsResult(String sResult) 
	{
		this.sResult = sResult;
	}
	
	@XmlAttribute(name="error")
	public String getsError() 
	{
		return sError;
	}
	public void setsError(String sError) 
	{
		this.sError = sError;
	}
	
	@XmlAttribute(name="warning")
	public String getsWarning() 
	{
		return sWarning;
	}
	public void setsWarning(String sWarning) 
	{
		this.sWarning = sWarning;
	}
	
	
		
}
