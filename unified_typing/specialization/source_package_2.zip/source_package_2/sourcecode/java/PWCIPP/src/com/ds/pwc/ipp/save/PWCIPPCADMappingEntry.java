package com.ds.pwc.ipp.save;

import matrix.db.BusinessObject;
import matrix.db.Context;

import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;

import matrix.util.MatrixException;
import com.matrixone.MCADIntegration.utils.MCADException;

public class PWCIPPCADMappingEntry
{
	private final PWCIPPCADDetails m_Source;
	private final PWCIPPCADDetails m_Target;
	
	private boolean m_TargetLoaded;
	
	public PWCIPPCADMappingEntry( PWCIPPCADDetails iSource , String iTargetMajorName , String iTargetMajorRevision )
	{
		m_Source = iSource;
		m_Target = new PWCIPPCADDetails();
		
		m_Target.setMajorValues( null , m_Source.getMajorType() , iTargetMajorName , iTargetMajorRevision , m_Source.getCADType() );
		m_TargetLoaded = false;
	}
	
	public PWCIPPCADDetails getSource()
	{
		return m_Source;
	}

	public PWCIPPCADDetails getTarget()
	{
		return m_Target;
	}
	
	public void loadTargetIDs( Context iContext , MCADMxUtil iMCADMxUtil )  throws MatrixException , MCADException
	{
		if( !m_TargetLoaded )
		{
			BusinessObject major = new BusinessObject( m_Target.getMajorType() , m_Target.getMajorName() , m_Target.getMajorRevision() , iContext.getVault().getName() );
			m_Target.setMajorID( major.getObjectId( iContext ) );

			BusinessObject minor = iMCADMxUtil.getActiveMinor( iContext , major );
			m_Target.setMinorID( minor.getObjectId() );
			minor.open( iContext );
			
			try
			{
				m_Target.setMinorType( minor.getTypeName() );
				m_Target.setMinorName( minor.getName() );
				m_Target.setMinorRevision( minor.getRevision() );
			}
			finally
			{
				minor.close( iContext );
			}
			// If an exception occurs, we consider that the loading didn't occur and it will have to be performed again.
			m_TargetLoaded = true;
		}
	}
}
