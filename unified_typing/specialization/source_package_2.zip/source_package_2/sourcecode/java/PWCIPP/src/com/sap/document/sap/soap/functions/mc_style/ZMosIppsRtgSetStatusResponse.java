
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PReterrorCode" type="{urn:sap-com:document:sap:rfc:functions}char3"/>
 *         &lt;element name="PReterrorText" type="{urn:sap-com:document:sap:rfc:functions}char73"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pReterrorCode",
    "pReterrorText"
})
@XmlRootElement(name = "ZMosIppsRtgSetStatusResponse")
public class ZMosIppsRtgSetStatusResponse {

    @XmlElement(name = "PReterrorCode", required = true)
    protected String pReterrorCode;
    @XmlElement(name = "PReterrorText", required = true)
    protected String pReterrorText;

    /**
     * Gets the value of the pReterrorCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPReterrorCode() {
        return pReterrorCode;
    }

    /**
     * Sets the value of the pReterrorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPReterrorCode(String value) {
        this.pReterrorCode = value;
    }

    /**
     * Gets the value of the pReterrorText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPReterrorText() {
        return pReterrorText;
    }

    /**
     * Sets the value of the pReterrorText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPReterrorText(String value) {
        this.pReterrorText = value;
    }

}
